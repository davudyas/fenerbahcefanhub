const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();
for (const [w,h,n,hash] of [[1280,900,'d','#football'],[400,850,'m','#womens-basketball']]){
const pg=await b.newPage({viewport:{width:w,height:h}});
const errs=[];pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error')errs.push(m.text())});
await pg.goto('file://'+process.cwd()+'/fenerbahce.html'+hash);await pg.waitForTimeout(800);
if(n==='m'){await pg.click('[data-tab=games]');}
await pg.screenshot({path:n+'.png',fullPage:n==='d'?false:true});
console.log(n,errs,await pg.evaluate(()=>document.documentElement.scrollWidth));}
await b.close();})();
