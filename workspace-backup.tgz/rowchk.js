const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const errs=[];const pg=await b.newPage({viewport:{width:1366,height:800}});pg.on('pageerror',e=>errs.push(e.message));
await pg.goto('file://'+process.argv[2]+'#all');await pg.waitForTimeout(500);
for(const L of ['en','tr','de','ar']){await pg.selectOption('#lang',L);await pg.waitForTimeout(300);console.log(L,await pg.evaluate(()=>[...document.querySelectorAll('#brRow [data-br]')].map(x=>x.textContent.trim()).join(' | ')))}
await pg.selectOption('#lang','en');await pg.waitForTimeout(300);await pg.screenshot({path:'../row_d.png',clip:{x:0,y:90,width:1366,height:120}});
console.log('sw',await pg.evaluate(()=>document.documentElement.scrollWidth),errs);await b.close()})();
