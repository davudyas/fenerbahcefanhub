import re
d='v4/'
v3=open('v3/fenerbahce.html').read()
pre=v3[:v3.index('<script>')]
pre=re.sub(r'\s*<option value="games">Fan Games</option>','',pre)
OPT='<option value="volleyball">Volleyball</option>'
assert OPT in pre
pre=pre.replace('<option value="football">Football</option>','<option value="home" data-t="All branches">All branches</option><option value="football">Football</option>',1)
pre=pre.replace('<a class="brand" href="#football">','<a class="brand" href="#all">',1)
pre=pre.replace(OPT,'<option value="volleyball">Women\'s Volleyball</option><option value="mens-volleyball">Men\'s Volleyball</option><option value="womens-football">Women\'s Football</option>')
pre=pre.replace('</style>',open(d+'extra.css').read()+'\n</style>',1)
def xform(css):
    out=[];i=0
    for m in re.finditer(r':root\{[^}]*\}',css):
        out.append(tf(css[i:m.start()]));out.append(m.group(0));i=m.end()
    out.append(tf(css[i:]));return ''.join(out)
def tf(s):
    return (s.replace('color:var(--yellow)','color:var(--accent)').replace('#0a1530','var(--on-accent)').replace('rgba(255,255,255,','rgba(var(--hl),')
             .replace('rgba(6,14,32,','rgba(var(--bg-rgb),').replace('rgba(13,28,61,','rgba(var(--panel-rgb),').replace('#fff 30%,#cfd7ea','var(--h1a) 30%,var(--h1b)'))
a=pre.index('<style>');z=pre.index('</style>')
pre=pre[:a]+xform(pre[a:z])+open(d+'themes.css').read()+open(d+'ux.css').read()+open(d+'clean.css').read()+open(d+'look.css').read()+pre[z:]
import re as _re
_m=_re.search(r'<link rel="stylesheet" href="(https://fonts.googleapis.com/css2\?[^"]*)">',pre)
_core=_m.group(1)
# core fonts load without blocking the first paint; Cairo (Arabic) and Playfair (Retro theme) load only when needed
pre=pre.replace(_m.group(0),'<link rel="preload" as="style" href="'+_core+'">\n<script>(function(){var d=document;window.loadFont=function(h){if(d.querySelector(\'link[data-f="\'+h+\'"]\'))return;var l=d.createElement("link");l.rel="stylesheet";l.href=h;l.setAttribute("data-f",h);d.head.appendChild(l)};loadFont("'+_core+'")})();</script>')
GLOBE='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="9.5"/><path d="M2.5 12h19M12 2.5c2.6 2.8 3.9 6 3.9 9.5s-1.3 6.7-3.9 9.5c-2.6-2.8-3.9-6-3.9-9.5s1.3-6.7 3.9-9.5z"/></svg>'
a='</select></div></div>\n</div></header>'
assert a in pre
pre=pre.replace(a,'</select></div></div>\n  <button class="hsearch" id="hSearch" type="button"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.2\" aria-hidden=\"true\"><circle cx=\"10.5\" cy=\"10.5\" r=\"6.5\"/><path d=\"M15.5 15.5l5 5\" stroke-linecap=\"round\"/></svg><span data-t="Search">Search</span></button>\n  <div class="themepick"><select id="theme" aria-label="Design"></select><span class="tc" aria-hidden="true"><i id="themeSw"></i></span></div>\n  <div class="langpick"><select id="lang" aria-label="Language"></select><span class="lc" aria-hidden="true">'+GLOBE+'<span id="langCode">EN</span></span></div>\n</div></header>')
pre=pre.replace('<span>Fan Hub · Kadıköy 1907</span>','<span>Fan Hub</span>',1)
for txt in ['Fan Hub','Unofficial fan page. Not affiliated with Fenerbahçe SK.','Yaşa Fenerbahçe · Sarı Lacivert']:
    assert '<span>'+txt+'</span>' in pre,txt
    pre=pre.replace('<span>'+txt+'</span>','<span data-t="'+txt+'">'+txt+'</span>')
pre=pre.replace('<span data-t="Yaşa Fenerbahçe · Sarı Lacivert">Yaşa Fenerbahçe · Sarı Lacivert</span>','',1)
a='<div class="cap">Fener · the lighthouse that named the club</div>'
assert a in pre
pre=pre.replace(a,'<div class="cap" data-t="Fener · the lighthouse that named the club">Fener · the lighthouse that named the club</div>')
parts=['v3/seasons.js',d+'sports_head.js',d+'sports_rest.js',d+'bdata.js',d+'live.js',d+'x_data.js',d+'core.js',d+'football.js',d+'generic.js',d+'x_feat.js',d+'x_more.js',d+'x_new.js',d+'x_helper.js',d+'x_sdata.js',d+'x_season.js',d+'x_ux.js',d+'x_eu.js',d+'x_rec.js',d+'x_plus.js',d+'x_quiz.js',d+'x_race.js',d+'x_live.js',d+'x_nav.js',d+'x_look.js',d+'x_gz.js',d+'x_mod.js',d+'i18n_ui.js',d+'i18n_ui2.js',d+'i18n_new.js',d+'i18n_season.js',d+'i18n_ux.js',d+'i18n_plus.js',d+'i18n_quiz.js',d+'i18n_live.js',d+'i18n_nav.js',d+'i18n_pats.js',d+'i18n_pats_x.js',d+'x1.js',d+'x2.js',d+'x3.js',d+'x4.js',d+'x5.js',d+'x6.js',d+'x7.js',d+'x8.js',d+'i18n_tr.js',d+'i18n_de.js',d+'i18n.js',d+'i18n_full.js']
import json
js='const I18N_CAT='+json.dumps(json.load(open('catalog.json')),ensure_ascii=False)+';\n'+'\n'.join(open(p).read() for p in parts)
js=js.replace('color:var(--yellow)','color:var(--accent)')
INIT='\nWP_FB=wPool(PEOPLE);\ninitTheme();initLang();mergeContent();mergeNew();staticTexts();initHelper();initSettings();lookInit();\nrenderOnThisDay();\n{const [h,play]=fromHash();setSport(h,play)}\ninitCommunity();maybeTour();\n'
js+=INIT
out=pre+'<script>\n'+js+'</script>'
open(d+'fenerbahce_full.html','w').write(out)
import subprocess
subprocess.run(['node',d+'extract_packs.js'],check=True)
# newer languages: translations live in v4/xl/<code>.tsv ("index<TAB>text", index into xl/master.json) and xl/pats_<code>.tsv
import json as _j
NEW_LANGS=['it','pt','nl','pl','ru','az','bs','sq','fa']
_master=_j.load(open(d+'xl/master.json'))
for L in NEW_LANGS:
    D={};P=[]
    try:
        for ln in open(d+'xl/%s.tsv'%L,encoding='utf-8').read().split('\n'):
            if '\t' not in ln:continue
            i,txt=ln.split('\t',1);i=int(i);txt=txt.replace('\\n','\n')
            if txt and txt!=_master[i]:D[_master[i]]=txt
    except FileNotFoundError:pass
    try:
        for ln in open(d+'xl/pats_%s.tsv'%L,encoding='utf-8').read().split('\n'):
            if '\t' not in ln:continue
            i,tpl=ln.split('\t',1)
            if tpl.strip():P.append([int(i),tpl])
    except FileNotFoundError:pass
    open(d+'lang-%s.js'%L,'w',encoding='utf-8').write('LANGPACK(%s,%s);\n'%(_j.dumps(L),_j.dumps({'d':D,'o':[],'p':P},ensure_ascii=False,separators=(',',':'))))
    print('pack',L,len(D),'texts',len(P),'templates')
DATA=['i18n_full.js','i18n_ui.js','i18n_ui2.js','i18n_new.js','i18n_season.js','i18n_ux.js','i18n_plus.js','i18n_quiz.js','i18n_live.js','i18n_nav.js','i18n_tr.js','i18n_de.js']+['x%d.js'%i for i in range(1,9)]
parts2=[p for p in parts if p.split('/')[-1] not in DATA]
parts2.insert(parts2.index(d+'i18n.js')+1,d+'i18n_pack.js')
js2='\n'.join(open(p).read() for p in parts2).replace('color:var(--yellow)','color:var(--accent)')
js2+=INIT
out2=pre+'<script>\n'+js2+'</script>'
open(d+'fenerbahce.html','w').write(out2)
print(len(out),'->',len(out2))
# ---------- stand-alone site build (GitHub Pages): Supabase replaces the Claude page features ----------
import os,shutil
cfg=json.load(open(d+'site_config.json'))
SITE_TXT={
 "Live features need the page open in Claude while signed in. You can still play everything else here.":"Live features couldn't connect right now. You can still play everything else here.",
 "Saved on this device only. Sign in to Claude to share with other fans.":"Saved on this device only. Shared features couldn't connect right now.",
 "Shared features (the prediction league, live quiz, watch parties, fan ratings and leaderboards) work with other fans when you're signed in to Claude and open this page there. Until then, what you do is saved on this device only.":"Shared features (the prediction league, live quiz, watch parties, fan ratings and leaderboards) couldn't connect right now, so what you do is saved on this device only.",
 "You're signed in, so your predictions, votes, ratings and scores are shared with other fans here. The live quiz and watch parties work with friends who open this page.":"Your predictions, votes, ratings and scores are shared with other fans here. Pick a fan name in Settings so others know who you are. The live quiz and watch parties work with friends who open this page.",
 "The prediction league, live quiz, watch parties, ratings and leaderboards are shared with other fans when you're signed in to Claude. Otherwise, everything is saved on this device.":"The prediction league, live quiz, watch parties, ratings and leaderboards are shared with other fans. Pick a fan name in Settings to appear on the leaderboards.",
}
js3=js2[:-len(INIT)]+'\n'+open(d+'x_sb.js').read()+'\n'+open(d+'x_lg.js').read()+INIT
for a_,b_ in SITE_TXT.items():
    assert a_ in js3,a_[:50]
    js3=js3.replace(a_,b_)
FAV="data:image/svg+xml,"+"%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='14' fill='%230d1c3d'/%3E%3Cpath d='M26 52h12l-3-30h-6z' fill='%23ffd500'/%3E%3Crect x='27' y='14' width='10' height='8' rx='2' fill='%23ffd500'/%3E%3Cpath d='M32 8l6 6H26z' fill='%23ffd500'/%3E%3C/svg%3E"
HEAD=('<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
 '<meta name="description" content="Unofficial Fenerbahçe fan site: results, tables, squads, history and games for every branch, in six languages.">\n'
 '<meta property="og:title" content="Fenerbahçe Fan Hub">\n<meta property="og:description" content="Unofficial fan site: every Fenerbahçe branch on one page.">\n'
 '<meta name="theme-color" content="#0d1c3d">\n<link rel="icon" href="'+FAV+'">\n'
 '<script>window.FB_SB='+json.dumps(cfg)+';</script>\n'
 '<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/dist/umd/supabase.min.js"></script>\n</head>\n<body>\n')
_pre=pre.replace('<meta name="claude:viewport-fit-sides" content="cover">\n','');_ti=_pre[:_pre.index('</title>')+8];_pre=_pre[len(_ti):]
out3=HEAD.replace('</head>',_ti+'\n</head>')+_pre+'<script>\n'+js3+'</script>\n</body>\n</html>\n'
os.makedirs('site',exist_ok=True)
open('site/index.html','w').write(out3)
for L in ['tr','de','es','fr','ar','it','pt','nl','pl','ru','az','bs','sq','fa']:shutil.copy(d+'lang-%s.js'%L,'site/lang-%s.js'%L)
open('site/.nojekyll','w').write('')
print('site',len(out3))
