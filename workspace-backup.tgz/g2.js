/* ---------- FAN GAMES ---------- */
const norm = s => String(s).toLocaleLowerCase("tr").replace(/ç/g,"c").replace(/ğ/g,"g").replace(/ı/g,"i").replace(/ö/g,"o").replace(/ş/g,"s").replace(/ü/g,"u").normalize("NFD").replace(/[̀-ͯ]/g,"").replace(/[^a-z ]/g," ").replace(/\s+/g," ").trim();
const shuffle = a => {a=[...a];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
const store = {get(k,d){try{const v=localStorage.getItem(k);return v==null?d:JSON.parse(v)}catch(e){return d}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const rnd=(a,b)=>a+Math.random()*(b-a);
const pickW=(items,wf)=>{const ws=items.map(wf);let t=ws.reduce((a,b)=>a+b,0)*Math.random();for(let i=0;i<items.length;i++){t-=ws[i];if(t<=0)return items[i]}return items[items.length-1]};
function lev(a,b){const m=a.length,n=b.length;if(Math.abs(m-n)>2)return 9;const d=Array.from({length:m+1},(_,i)=>[i]);for(let j=1;j<=n;j++)d[0][j]=j;for(let i=1;i<=m;i++)for(let j=1;j<=n;j++)d[i][j]=Math.min(d[i-1][j]+1,d[i][j-1]+1,d[i-1][j-1]+(a[i-1]===b[j-1]?0:1));return d[m][n]}
const closeEnough=(v,a)=>v===a||(a.length>=5&&lev(v,a)<=(a.length>=8?2:1));
const lastName=n=>{const w=n.split(" ");return w.length>1?w.slice(1).join(" "):n};
const CUR=2026;

/* ===== Player database ===== */
const NAT={TUR:"Turkey",BRA:"Brazil",GER:"Germany",CRO:"Croatia",CHI:"Chile",URU:"Uruguay",SVK:"Slovakia",POR:"Portugal",DEN:"Denmark",NGA:"Nigeria",NED:"the Netherlands",SUI:"Switzerland",GHA:"Ghana",FRA:"France",ISR:"Israel",ARG:"Argentina",ESP:"Spain",POL:"Poland",SRB:"Serbia",BIH:"Bosnia and Herzegovina",SEN:"Senegal",MAR:"Morocco",ECU:"Ecuador",COL:"Colombia",CMR:"Cameroon"};
const P_RAW=[
 ["Rüştü Reçber","GK","",86,"TUR",1994,2007,"Rüştü"],["Volkan Demirel","GK","",84,"TUR",2002,2019,"Volkan"],["Harald Schumacher","GK","",84,"GER",1988,1991,"Schumacher"],["Ederson","GK","",86,"BRA",2025,2026],["Dominik Livaković","GK","",81,"CRO",2023,2026],["Altay Bayındır","GK","",77,"TUR",2019,2023],["Mert Günok","GK","",76,"TUR",2008,2015],
 ["Gökhan Gönül","RB","",80,"TUR",2007,2017],["Mert Müldür","RB","LB",78,"TUR",2024,2026],["Önder Turacı","RB","CB",76,"TUR",2006,2010],["Fatih Akyel","RB","",77,"TUR",2002,2004],["Mauricio Isla","RB","W",77,"CHI",2017,2019],["Şener Özbayraklı","RB","",75,"TUR",2014,2017],
 ["Diego Lugano","CB","",84,"URU",2006,2011],["Edu Dracena","CB","",81,"BRA",2006,2009],["Milan Škriniar","CB","",85,"SVK",2024,2026],["Bruno Alves","CB","",81,"POR",2013,2016],["Simon Kjær","CB","",81,"DEN",2015,2017],["Joseph Yobo","CB","",79,"NGA",2010,2014],["Ogün Temizkanoğlu","CB","CM",80,"TUR",1990,2003],["Çağlar Söyüncü","CB","",79,"TUR",2023,2026],["Jayden Oosterwolde","CB","LB",79,"NED",2022,2026],["Serdar Aziz","CB","",77,"TUR",2018,2024],["Egemen Korkmaz","CB","",76,"TUR",2011,2015],["Bekir İrtegün","CB","",75,"TUR",2010,2015],
 ["Roberto Carlos","LB","",87,"BRA",2007,2009,"Roberto Carlos"],["Ümit Özat","LB","CM",80,"TUR",1997,2007],["Ferdi Kadıoğlu","LB","RB,W",81,"TUR",2018,2024,"Ferdi"],["Hasan Ali Kaldırım","LB","",76,"TUR",2013,2019,"Hasan Ali"],["Reto Ziegler","LB","",76,"SUI",2011,2013],["Wederson","LB","",75,"BRA",2007,2009],["Levent Mercan","LB","",75,"TUR",2024,2026],
 ["Emre Belözoğlu","CM","AM",85,"TUR",2008,2020,"Emre"],["Mehmet Aurélio","CM","",81,"TUR",2006,2009,"Aurélio"],["Stephen Appiah","CM","",81,"GHA",2005,2008],["Fred","CM","",83,"BRA",2023,2026],["Mattéo Guendouzi","CM","",83,"FRA",2025,2026],["Raul Meireles","CM","",80,"POR",2012,2015],["Josef de Souza","CM","",80,"BRA",2016,2019,"Josef"],["Oğuz Çetin","CM","AM",80,"TUR",1988,1996],["Selçuk Şahin","CM","",76,"TUR",2004,2010],["İsmail Yüksek","CM","",77,"TUR",2019,2026,"İsmail"],["Cristian Baroni","CM","",78,"BRA",2010,2014,"Cristian"],["Mehmet Topal","CM","CB",78,"TUR",2012,2017],["Mehmet Topuz","CM","W",77,"TUR",2009,2014],["Claudio Maldonado","CM","",76,"CHI",2007,2009],["Deivid","CM","CB",76,"BRA",2006,2010],["Willian Arão","CM","",77,"BRA",2022,2023],["Yusuf Şimşek","CM","",75,"TUR",2001,2004],
 ["Alex de Souza","AM","",91,"BRA",2004,2012,"Alex"],["Jay-Jay Okocha","AM","CM",86,"NGA",1996,1998,"Okocha"],["Rıdvan Dilmen","AM","",85,"TUR",1985,1994,"Rıdvan"],["Haim Revivo","AM","W",83,"ISR",1997,2000],["Ariel Ortega","AM","",82,"ARG",2002,2003],["Can Bartu","AM","ST",87,"TUR",1955,1970,"Can Bartu"],["Diego Ribas","AM","",80,"BRA",2014,2016,"Diego"],["Mesut Özil","AM","",79,"GER",2021,2022],["Marco Asensio","AM","W",83,"ESP",2025,2026],["Sebastian Szymański","AM","CM",81,"POL",2023,2025],["Arda Güler","AM","W",82,"TUR",2021,2023,"Arda"],
 ["Dušan Tadić","W","AM",84,"SRB",2023,2025],["Dirk Kuyt","W","ST",84,"NED",2012,2015],["Kerem Aktürkoğlu","W","",81,"TUR",2025,2026,"Kerem"],["İrfan Can Kahveci","W","AM",80,"TUR",2021,2026],["Miroslav Stoch","W","",79,"SVK",2011,2014],["Uğur Boral","W","",77,"TUR",2006,2011],["Tuncay Şanlı","W","ST,AM",82,"TUR",2002,2007,"Tuncay"],["Caner Erkin","W","LB",78,"TUR",2010,2016,"Caner"],["Allan Saint-Maximin","W","",80,"FRA",2024,2025],["Anthony Musaba","W","",76,"NED",2025,2026],
 ["Lefter Küçükandonyadis","ST","AM",93,"TUR",1947,1964,"Lefter"],["Cemil Turan","ST","",85,"TUR",1969,1979],["Aykut Kocaman","ST","",86,"TUR",1988,1996,"Aykut"],["Tanju Çolak","ST","",86,"TUR",1991,1993,"Tanju"],["Elvir Bolić","ST","",82,"BIH",1995,2000],["Pierre van Hooijdonk","ST","",83,"NED",2003,2005,"Van Hooijdonk"],["Nicolas Anelka","ST","",84,"FRA",2005,2006],["Mateja Kežman","ST","",81,"SRB",2006,2008],["Semih Şentürk","ST","",80,"TUR",1999,2013,"Semih"],["Serhat Akın","ST","W",78,"TUR",1998,2005,"Serhat"],["Edin Džeko","ST","",85,"BIH",2023,2025],["Robin van Persie","ST","",83,"NED",2015,2017,"Van Persie"],["Moussa Sow","ST","W",81,"SEN",2011,2015],["Emmanuel Emenike","ST","",80,"NGA",2013,2016],["Youssef En-Nesyri","ST","",82,"MAR",2024,2026],["Enner Valencia","ST","",81,"ECU",2020,2023],["Jhon Durán","ST","",80,"COL",2025,2026],["Pierre Webó","ST","",76,"CMR",2012,2014]
];
const PLAYERS=P_RAW.map(([n,pos,alt,r,nat,from,to,short])=>({n,pos,alt:alt?alt.split(","):[],r,nat,from,to,short:short||lastName(n)}));
const together=(a,b)=>a!==b&&a.from<=b.to&&b.from<=a.to;
const ROLE={GK:"GK",LB:"LB",RB:"RB",CB:"CB",CM:"CM",AM:"AM",LW:"W",RW:"W",LM:"W",RM:"W",ST:"ST"};
const ROLE_NAME={GK:"Goalkeeper",LB:"Left-back",RB:"Right-back",CB:"Centre-back",CM:"Central midfielder",AM:"Attacking midfielder",W:"Winger",ST:"Striker"};
const yrs=p=>p.to>=CUR?`${p.from}–`:`${p.from}–${String(p.to).slice(2)}`;

function arcadeStats(){const b=store.get("fb-draft-best",null),c=store.get("fb-cups",0),ws=store.get("fb-wd-stats",{}),tb=store.get("fb-tl-best",0);
  return [[b!=null?Number(b).toFixed(1):"–","Best XI rating"],[String(c),"Legends Cups won"],[String(ws.streak||0),"Fenerdle streak"],[String(tb),"Timeline record"]]}
function updateArcadeStats(){if(current==="games")$("stats").innerHTML=arcadeStats().map(([v,k])=>`<div class="stat"><span class="v">${esc(v)}</span><span class="k">${esc(k)}</span></div>`).join("")}

/* ===== 1. ALL-TIME XI DRAFT + LEGENDS CUP ===== */
const FORMS={
 "4-3-3":{s:[["GK",50,90],["LB",13,70],["CB",37,75],["CB",63,75],["RB",87,70],["CM",26,49],["CM",50,54],["CM",74,49],["LW",16,22],["ST",50,12],["RW",84,22]],
   l:[[0,2],[0,3],[1,2],[2,3],[3,4],[1,5],[4,7],[2,6],[3,6],[5,6],[6,7],[5,8],[7,10],[8,9],[9,10],[6,9]]},
 "4-4-2":{s:[["GK",50,90],["LB",13,70],["CB",37,75],["CB",63,75],["RB",87,70],["LM",12,42],["CM",37,48],["CM",63,48],["RM",88,42],["ST",36,14],["ST",64,14]],
   l:[[0,2],[0,3],[1,2],[2,3],[3,4],[1,5],[4,8],[2,6],[3,7],[5,6],[6,7],[7,8],[5,9],[6,9],[7,10],[8,10],[9,10]]},
 "4-2-3-1":{s:[["GK",50,90],["LB",13,70],["CB",37,75],["CB",63,75],["RB",87,70],["CM",37,55],["CM",63,55],["LW",14,30],["AM",50,33],["RW",86,30],["ST",50,11]],
   l:[[0,2],[0,3],[1,2],[2,3],[3,4],[2,5],[3,6],[5,6],[1,7],[4,9],[5,8],[6,8],[7,8],[8,9],[7,10],[8,10],[9,10]]},
 "3-5-2":{s:[["GK",50,90],["CB",24,73],["CB",50,77],["CB",76,73],["LM",10,45],["CM",32,52],["AM",50,36],["CM",68,52],["RM",90,45],["ST",36,13],["ST",64,13]],
   l:[[0,1],[0,2],[0,3],[1,2],[2,3],[1,4],[3,8],[1,5],[3,7],[2,5],[2,7],[4,5],[5,6],[6,7],[7,8],[4,9],[8,10],[6,9],[6,10],[9,10]]}
};
const CHEM_BONUS=[-2,0,1,2];
const linkVal=(a,b)=>(together(a,b)?2:0)+(a.nat===b.nat?1:0);
const slotRole=(form,i)=>ROLE[FORMS[form].s[i][0]];
function chemArr(form,picks){return picks.map((p,i)=>{if(!p)return null;let s=0;FORMS[form].l.forEach(([a,b])=>{const o=a===i?b:b===i?a:-1;if(o>=0&&picks[o])s+=linkVal(p,picks[o])});return Math.min(3,s)})}
function effOf(form,picks,chem,cap,i){const p=picks[i];return p.r-(p.pos===slotRole(form,i)?0:3)+CHEM_BONUS[chem[i]]+(cap===i?2:0)}
function teamInfo(form,picks,cap){const chem=chemArr(form,picks),idx=picks.map((p,i)=>p?i:-1).filter(i=>i>=0);
  if(!idx.length)return{chem,eff:[],ovr:0,base:0,chemTotal:0};
  const eff=picks.map((p,i)=>p?effOf(form,picks,chem,cap,i):null);
  return{chem,eff,ovr:idx.reduce((a,i)=>a+eff[i],0)/idx.length,base:idx.reduce((a,i)=>a+picks[i].r,0)/idx.length,chemTotal:idx.reduce((a,i)=>a+chem[i],0)}}

let dr=null;
const drOrder=()=>{const S=FORMS[dr.form].s;return S.map((_,i)=>i).sort((a,b)=>S[b][2]-S[a][2]||S[a][1]-S[b][1])};
function newDraft(form){dr={form,picks:Array(11).fill(null),offers:{},active:0,rerolls:3,captain:null,phase:"pick",cup:null};dr.active=drOrder()[0]}
function getOffers(i){
  const used=new Set(dr.picks.filter(Boolean));
  if(!dr.offers[i]){const role=slotRole(dr.form,i);
    const nat=shuffle(PLAYERS.filter(p=>!used.has(p)&&p.pos===role)),alt=shuffle(PLAYERS.filter(p=>!used.has(p)&&p.pos!==role&&p.alt.includes(role)));
    const list=nat.slice(0,4);if(alt.length)list.push(alt[0]);else if(nat[4])list.push(nat[4]);dr.offers[i]=shuffle(list)}
  return dr.offers[i].filter(p=>!used.has(p));
}
function pitch2(form,picks,o={}){
  const F=FORMS[form],info=o.info;
  const lines=F.l.map(([a,b])=>{const A=F.s[a],B=F.s[b];let c="le";if(picks[a]&&picks[b]){const v=linkVal(picks[a],picks[b]);c=v>=2?"l2":v===1?"l1":"l0"}return `<line x1="${A[1]}" y1="${A[2]}" x2="${B[1]}" y2="${B[2]}" class="${c}"/>`}).join("");
  const tag=o.clickable?"button":"div";
  const slots=F.s.map(([pos,x,y],i)=>{const p=picks[i],ch=info&&p?info.chem[i]:null,oop=p&&p.pos!==ROLE[pos];
    return `<${tag} class="ps ${p?"filled":""} ${o.active===i?"active":""} ${oop?"oop":""}" style="left:${x}%;top:${y}%" ${o.clickable?`type="button" data-slot="${i}"`:""} aria-label="${pos}${p?": "+esc(p.n):", empty"}">
      <span class="disc">${p?(info?info.eff[i]:p.r):pos}</span>${o.captain===i?'<span class="cap">C</span>':""}
      <span class="nm">${p?esc(p.short):""}</span>${ch!=null?`<span class="pips">${[0,1,2].map(k=>`<i class="${k<ch?"on":""}"></i>`).join("")}</span>`:""}</${tag}>`}).join("");
  return `<div class="pitch2"><svg viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">${lines}</svg>${slots}</div>`;
}
function tier(o){return o>=90?"Immortal. Lefter would approve.":o>=87?"Champions of Europe.":o>=84?"Title winners.":o>=81?"Champions League nights in Kadıköy.":o>=78?"A top-four side.":"A rebuild is needed."}

function renderDraft(p){
  if(!dr)newDraft("4-3-3");
  const info=teamInfo(dr.form,dr.picks,dr.captain),filled=dr.picks.filter(Boolean).length;
  let side="";
  if(dr.phase==="pick"){
    const i=dr.active,role=slotRole(dr.form,i),offers=getOffers(i);
    const cands=offers.map((c,k)=>{const hyp=[...dr.picks];hyp[i]=c;const hi=teamInfo(dr.form,hyp,dr.captain),delta=hi.chemTotal-info.chemTotal,oop=c.pos!==role;
      const links=FORMS[dr.form].l.filter(([a,b])=>a===i||b===i).map(([a,b])=>dr.picks[a===i?b:a]).filter(Boolean).filter(q=>linkVal(c,q)>0);
      return `<button class="cand2" data-cand="${k}"><span class="r">${c.r}</span><span class="info"><b>${esc(c.n)}</b><small>${c.nat} · ${yrs(c)} · ${c.pos==="W"?"Winger":c.pos}</small>${links.length?`<small class="lk">Links with ${links.map(q=>esc(q.short)).join(", ")}</small>`:""}</span><span class="tags">${oop?'<em class="tag bad">Out of position −3</em>':""}<em class="tag ${delta>0?"good":""}">${delta>0?"+":""}${delta} chem</em></span></button>`}).join("");
    side=`<div class="box"><span class="label">Pick ${filled+1} of 11 · tap any empty spot to switch</span><h3 style="margin-top:4px">${ROLE_NAME[role]}</h3><div class="cands2">${cands}</div>
      <div class="btns"><button class="btn ghost" data-d="reroll" ${dr.rerolls?"":"disabled"}>New options (${dr.rerolls} left)</button></div></div>`;
  }else if(dr.phase==="captain"){
    side=`<div class="box"><span class="label">Last step</span><h3 style="margin-top:4px">Choose your captain</h3><p style="margin-top:8px;color:var(--muted)">Tap a player on the pitch. The captain plays +2 above his rating.</p></div>`;
  }else{
    side=`<div class="box" id="cupBox"></div>`;
  }
  const sum=`<div class="box"><span class="label">${dr.phase==="pick"?"Team so far":"Your XI"}</span><div class="ovr" style="margin-top:8px"><span class="big">${filled?info.ovr.toFixed(1):"–"}</span><dl><dt>Base rating</dt><dd>${filled?info.base.toFixed(1):"–"}</dd><dt>Chemistry</dt><dd>${info.chemTotal}/33</dd><dt>Best ever</dt><dd>${store.get("fb-draft-best",null)!=null?Number(store.get("fb-draft-best")).toFixed(1):"–"}</dd></dl></div></div>`;
  p.innerHTML=`<h2>All-Time XI Draft</h2><p class="intro">Build the best Fenerbahçe XI in history, then take it through the Legends Cup. Linked players boost each other: real teammates (their years at the club overlap) make a strong link, and players from the same country a weaker one. Up to three chemistry points per player add as much as +2 to their rating. Zero chemistry costs −2.</p>
  <div class="filter" role="group" aria-label="Formation">${Object.keys(FORMS).map(f=>`<button data-form="${f}" aria-pressed="${f===dr.form}">${f}</button>`).join("")}</div>
  <div class="draft"><div>${pitch2(dr.form,dr.picks,{info,active:dr.phase==="pick"?dr.active:null,captain:dr.captain,clickable:dr.phase!=="done"||true})}
    <div class="linklegend"><span><i class="l2"></i>Teammates</span><span><i class="l1"></i>Same country</span><span><i class="l0"></i>No link</span><span><i class="pipkey"></i>Chemistry (0–3)</span></div></div>
    <div class="side">${side}${sum}</div></div>
  <p class="gnote">Ratings are fan ratings made for this game. The numbers on the pitch include chemistry, position and captain bonuses. Changing formation starts a new draft.</p>`;
  p.querySelectorAll("[data-form]").forEach(b=>b.onclick=()=>{newDraft(b.dataset.form);renderPanel()});
  p.querySelectorAll("[data-slot]").forEach(b=>b.onclick=()=>{const i=+b.dataset.slot;
    if(dr.phase==="pick"&&!dr.picks[i]){dr.active=i;renderPanel()}
    else if(dr.phase==="captain"&&dr.picks[i]){dr.captain=i;dr.phase="done";const o=teamInfo(dr.form,dr.picks,i).ovr,bs=store.get("fb-draft-best",null);if(bs==null||o>bs)store.set("fb-draft-best",Math.round(o*10)/10);dr.cup={round:0,results:[],live:null,opp:buildOpp(0),newBest:bs==null||o>bs};updateArcadeStats();renderPanel()}});
  p.querySelectorAll("[data-cand]").forEach(b=>b.onclick=()=>{const c=getOffers(dr.active)[+b.dataset.cand];dr.picks[dr.active]=c;
    const nx=drOrder().find(i=>!dr.picks[i]);if(nx==null){dr.phase="captain";dr.active=null}else dr.active=nx;renderPanel()});
  const rr=p.querySelector('[data-d="reroll"]');if(rr)rr.onclick=()=>{if(!dr.rerolls)return;dr.rerolls--;delete dr.offers[dr.active];renderPanel()};
  if(dr.phase==="done")renderCupBox();
}

/* Legends Cup */
const ROUNDS=[["Quarter-final","2010s Select",2010,2019,"4-4-2"],["Semi-final","2000s Select",2000,2009,"4-2-3-1"],["Final","Legends Select",0,0,"4-3-3"]];
function buildOpp(k){const [,name,a,b,form]=ROUNDS[k],used=new Set(dr.picks),picks=Array(11).fill(null);
  FORMS[form].s.forEach(([pos],i)=>{const role=ROLE[pos];let pool=PLAYERS.filter(p=>!used.has(p)&&p.pos===role&&(!a||(p.from<=b&&p.to>=a)));
    if(!pool.length)pool=PLAYERS.filter(p=>!used.has(p)&&p.pos===role);if(!pool.length)pool=PLAYERS.filter(p=>!used.has(p)&&p.alt.includes(role));
    pool.sort((x,y)=>y.r-x.r);const top=pool.slice(0,k===2?2:3);const pk=top[Math.floor(Math.random()*top.length)];picks[i]=pk;used.add(pk)});
  let cap=0;picks.forEach((p,i)=>{if(p.r>picks[cap].r)cap=i});
  return{name,form,picks,cap,info:teamInfo(form,picks,cap)};
}
function sideOf(name,form,picks,cap){const info=teamInfo(form,picks,cap);const pl=picks.map((p,i)=>({p,role:slotRole(form,i),eff:info.eff[i]}));
  const avg=f=>{const xs=pl.filter(f);return xs.length?xs.reduce((a,x)=>a+x.eff,0)/xs.length:info.ovr};
  const gk=pl.find(x=>x.role==="GK");
  return{name,pl,gk,ovr:info.ovr,att:avg(x=>["ST","W","AM"].includes(x.role)),mid:avg(x=>["CM","AM"].includes(x.role)),def:(avg(x=>["CB","LB","RB"].includes(x.role))*3+gk.eff)/4}}
const SCW={ST:6,W:4,AM:4,CM:1.5,CB:.6,LB:.5,RB:.5,GK:0},ASW={AM:5,W:4,CM:3,ST:2,LB:2,RB:2,CB:.5,GK:.1};
function simulate(H,A){
  const ev=[],g=[0,0],sh=[0,0],on=[0,0],ps=[0,0],S=[H,A];
  for(let k=0;k<30;k++){const min=Math.min(90,k*3+1+Math.floor(Math.random()*3));
    if(k===15)ev.push({min:45,type:"ht"});
    const t=Math.random()<clamp(.5+(H.mid-A.mid)*.025,.3,.7)?0:1;ps[t]++;
    if(Math.random()<.28){const at=S[t],df=S[1-t],q=clamp(.3+(at.att-df.def)*.03,.08,.6);
      const s=pickW(at.pl.filter(x=>x.role!=="GK"),x=>SCW[x.role]*x.eff/80);sh[t]++;const r=Math.random();
      if(r<q){g[t]++;on[t]++;const as=Math.random()<.68?pickW(at.pl.filter(x=>x!==s&&x.role!=="GK"),x=>ASW[x.role]):null;ev.push({min,type:"goal",t,s:s.p.short,a:as?as.p.short:null,sc:[...g]})}
      else if(r<q+.32){on[t]++;ev.push({min,type:"save",t,s:s.p.short,gk:df.gk.p.short})}
      else ev.push({min,type:"miss",t,s:s.p.short})}
    if(Math.random()<.035){const tt=Math.random()<.5?0:1,pl=pickW(S[tt].pl,x=>x.role==="CB"||x.role==="CM"?3:1);ev.push({min,type:"card",t:tt,s:pl.p.short})}
  }
  ev.push({min:90,type:"ft"});
  let pens=null;
  if(g[0]===g[1]){const kick=X=>X.pl.filter(x=>x.role!=="GK").sort((a,b)=>b.eff-a.eff);const kh=kick(H),ka=kick(A),rh=[],ra=[];
    for(let i=0;i<20;i++){rh.push(Math.random()<clamp(.75+(kh[i%10].eff-A.gk.eff)*.01,.55,.92));ra.push(Math.random()<clamp(.75+(ka[i%10].eff-H.gk.eff)*.01,.55,.92));
      const sh_=rh.filter(Boolean).length,sa=ra.filter(Boolean).length;if(i>=4&&sh_!==sa)break}
    pens={h:rh,a:ra}}
  return{ev,g,sh,on,pos:Math.round(ps[0]/30*100),pens};
}
const pensScore=p=>[p.h.filter(Boolean).length,p.a.filter(Boolean).length];
function won(res){if(res.g[0]!==res.g[1])return res.g[0]>res.g[1];const s=pensScore(res.pens);return s[0]>s[1]}
function line(e,H,A){const T=e.t===0?H.name:A.name,r=a=>a[Math.floor((e.min*7+(e.s||"").length)%a.length)];
  if(e.type==="goal")return r([`GOAL! ${e.s} scores${e.a?` after a pass from ${e.a}`:""}.`,`GOAL! ${e.s} finishes it off${e.a?`. ${e.a} with the assist`:""}.`,`GOAL! What a strike from ${e.s}!`]);
  if(e.type==="save")return r([`${e.gk} saves from ${e.s}.`,`Big stop by ${e.gk}, denying ${e.s}.`,`${e.s} tests ${e.gk}, who holds on.`]);
  if(e.type==="miss")return r([`${e.s} drags it wide.`,`${e.s} heads over the bar.`,`Chance for ${e.s}, but it's blocked.`]);
  if(e.type==="card")return `Yellow card for ${e.s} (${T}).`;
  if(e.type==="ht")return "Half-time.";return "Full-time.";}
let cupTimer=null;
function playRound(){const c=dr.cup;if(c.live&&!c.live.doneAt)return;
  const H=sideOf("Your XI",dr.form,dr.picks,dr.captain),A=sideOf(c.opp.name,c.opp.form,c.opp.picks,c.opp.cap);
  c.live={H,A,res:simulate(H,A),clock:0};clearInterval(cupTimer);
  cupTimer=setInterval(()=>{if(!c.live)return clearInterval(cupTimer);c.live.clock+=1;if(c.live.clock>=90)finishRound();renderCupBox()},70);renderCupBox()}
function finishRound(){const c=dr.cup,L=c.live;clearInterval(cupTimer);if(L.doneAt)return;L.clock=90;L.doneAt=true;const w=won(L.res);c.results.push({opp:c.opp.name,g:L.res.g,pens:L.res.pens?pensScore(L.res.pens):null,w});
  if(w&&c.round===2){store.set("fb-cups",store.get("fb-cups",0)+1);c.champion=true;updateArcadeStats()}
  if(!w)c.out=true}
function renderCupBox(){const el=document.getElementById("cupBox");if(!el||!dr||!dr.cup)return;const c=dr.cup,L=c.live,info=teamInfo(dr.form,dr.picks,dr.captain);
  const bracket=ROUNDS.map(([rn,nm],i)=>{const r=c.results[i];return `<li class="${r?(r.w?"w":"l"):i===c.round&&!c.out?"next":""}"><span class="label">${rn}</span><b>${esc(nm)}</b><span class="res">${r?`${r.g[0]}–${r.g[1]}${r.pens?` (${r.pens[0]}–${r.pens[1]} pens)`:""}`:i===c.round&&!c.out&&!c.champion?"Next":"–"}</span></li>`}).join("");
  let body="";
  if(L){const vis=L.res.ev.filter(e=>e.min<=L.clock||L.doneAt),g=[0,0];vis.forEach(e=>{if(e.type==="goal")g[e.t]++});
    body=`<div class="scoreboard"><span class="tm">Your XI</span><span class="sc">${g[0]}–${g[1]}</span><span class="tm">${esc(L.A.name)}</span></div>
      <div class="clockline"><span class="label">${L.doneAt?(L.res.pens?`Full-time · penalties ${pensScore(L.res.pens).join("–")}`:"Full-time"):`${L.clock}'`}</span>${L.doneAt?`<span class="label">Possession ${L.res.pos}% · Chances ${L.res.sh[0]}–${L.res.sh[1]} · On target ${L.res.on[0]}–${L.res.on[1]}</span>`:""}</div>
      <ol class="ticker">${vis.slice().reverse().map(e=>`<li class="${e.type} ${e.t===1?"opp":""}"><span>${e.min}'</span>${esc(line(e,L.H,L.A))}</li>`).join("")}</ol>`;
    if(L.doneAt){const last=c.results[c.results.length-1];
      body+=c.champion?`<p class="msg good" style="font-size:20px">Legends Cup winners! Your XI lifts the trophy.</p>`:last.w?`<p class="msg good">Through to the ${ROUNDS[c.round+1][0].toLowerCase()}.</p>`:`<p class="msg bad">Knocked out in the ${ROUNDS[c.round][0].toLowerCase()}.</p>`;
      body+=`<div class="btns">${!c.champion&&last.w?`<button class="btn" data-c="next">Next round</button>`:""}${c.champion||c.out?`<button class="btn" data-c="retry">Play the cup again</button><button class="btn ghost" data-c="new">New draft</button>`:""}</div>`}
    else body+=`<div class="btns"><button class="btn ghost" data-c="skip">Skip to full-time</button></div>`;
  }else{const o=c.opp,top=o.picks.slice().sort((a,b)=>b.r-a.r).slice(0,3);
    body=`<div class="scout"><span class="label">Scouting report</span><p><b>${esc(o.name)}</b> · ${o.form} · rated ${o.info.ovr.toFixed(1)} (you: ${info.ovr.toFixed(1)})</p><p style="color:var(--muted)">Danger men: ${top.map(x=>`${esc(x.n)} (${x.r})`).join(", ")}</p></div>
      <div class="btns"><button class="btn" data-c="play">Kick off the ${ROUNDS[c.round][0].toLowerCase()}</button><button class="btn ghost" data-c="new">New draft</button></div>`}
  el.innerHTML=`<span class="label">Legends Cup${c.newBest&&!L&&c.round===0?" · New best XI!":""}</span><h3 style="margin-top:4px">${tier(info.ovr)}</h3><ol class="bracket">${bracket}</ol>${body}`;
  const on=(k,f)=>{const b=el.querySelector(`[data-c="${k}"]`);if(b)b.onclick=f};
  on("play",playRound);on("skip",()=>{finishRound();renderCupBox()});
  on("next",()=>{c.round++;c.live=null;c.opp=buildOpp(c.round);renderCupBox()});
  on("retry",()=>{dr.cup={round:0,results:[],live:null,opp:buildOpp(0)};renderCupBox()});
  on("new",()=>{clearInterval(cupTimer);newDraft(dr.form);renderPanel()});
}

/* ===== 2. FENERDLE ===== */
const WP=(()=>{const seen=new Set();return PLAYERS.map(p=>({p,w:norm(p.short).toUpperCase()})).filter(x=>/^[A-Z]{4,9}$/.test(x.w)&&!seen.has(x.w)&&seen.add(x.w))})();
const localDay=()=>Math.floor((Date.now()-new Date().getTimezoneOffset()*6e4)/864e5);
const DAY0=Math.floor(Date.UTC(2026,10,1)/864e5);
let wd=null;
function newWordle(daily){const d=localDay(),idx=daily?((d*7919+13)%WP.length):Math.floor(Math.random()*WP.length),{p,w}=WP[idx];
  wd={p,ans:w,daily,day:d,num:d-DAY0+1,rows:[],hints:[],cur:"",done:false,won:false,msg:"",flip:-1,hard:store.get("fb-wd-hard",false),copied:""};
  if(daily){const s=store.get("fb-wd-day",null);if(s&&s.day===d)Object.assign(wd,{rows:s.rows,hints:s.hints,done:s.done,won:s.won,hard:s.hard})}}
function saveDaily(){if(wd.daily)store.set("fb-wd-day",{day:wd.day,rows:wd.rows,hints:wd.hints,done:wd.done,won:wd.won,hard:wd.hard})}
function scoreGuess(g,a){const r=Array(a.length).fill("absent"),c={};for(let i=0;i<a.length;i++){if(g[i]===a[i])r[i]="correct";else c[a[i]]=(c[a[i]]||0)+1}for(let i=0;i<a.length;i++){if(r[i]!=="correct"&&c[g[i]]>0){r[i]="present";c[g[i]]--}}return r}
function hardBreak(g){for(const r of wd.rows){const sc=scoreGuess(r,wd.ans);for(let i=0;i<r.length;i++)if(sc[i]==="correct"&&g[i]!==r[i])return `Hard mode: letter ${i+1} must be ${r[i]}.`;
  const need={};[...r].forEach((c,i)=>{if(sc[i]!=="absent")need[c]=(need[c]||0)+1});for(const c in need)if([...g].filter(x=>x===c).length<need[c])return `Hard mode: your guess must use ${c}.`}return null}
function wdFinish(){if(!wd.daily)return;const st=store.get("fb-wd-stats",{played:0,wins:0,streak:0,max:0,dist:[0,0,0,0,0,0],last:null});
  if(st.last===wd.day)return;st.played++;if(wd.won){st.wins++;st.streak=(st.last===wd.day-1?st.streak:0)+1;st.max=Math.max(st.max,st.streak);st.dist[wd.rows.length-1]++}else st.streak=0;st.last=wd.day;store.set("fb-wd-stats",st);updateArcadeStats()}
function wordleKey(k){
  if(!wd||wd.done)return;const L=wd.ans.length;wd.msg="";
  if(k==="ENTER"){
    if(wd.cur.length<L)wd.msg=`The name has ${L} letters.`;
    else{const hb=wd.hard?hardBreak(wd.cur):null;
      if(hb)wd.msg=hb;else{wd.rows.push(wd.cur);wd.flip=wd.rows.length-1;const g=wd.cur;wd.cur="";
        if(g===wd.ans){wd.done=wd.won=true}else if(wd.rows.length>=6)wd.done=true;
        if(wd.done)wdFinish();saveDaily()}}
  }else if(k==="BACK")wd.cur=wd.cur.slice(0,-1);
  else if(/^[A-Z]$/.test(k)&&wd.cur.length<L)wd.cur+=k;
  renderPanel();
}
const HINTS={pos:["Position",p=>ROLE_NAME[p.pos]],nat:["Country",p=>NAT[p.nat].replace(/^the /,"The ")],yrs:["Joined",p=>`around ${p.from}`]};
function shareText(){const em={correct:"🟨",present:"🟦",absent:"⬛"};return `Fenerdle #${wd.num} ${wd.won?wd.rows.length:"X"}/6${wd.hard?"*":""}${wd.hints.length?` (${wd.hints.length} hint${wd.hints.length>1?"s":""})`:""}\n`+wd.rows.map(r=>scoreGuess(r,wd.ans).map(s=>em[s]).join("")).join("\n")}
function renderWordle(p){
  if(!wd)newWordle(true);
  const L=wd.ans.length,ks={},rank={absent:1,present:2,correct:3};
  wd.rows.forEach(g=>scoreGuess(g,wd.ans).forEach((s,i)=>{if(!ks[g[i]]||rank[s]>rank[ks[g[i]]])ks[g[i]]=s}));
  let grid="";for(let r=0;r<6;r++){let t="";
    if(r<wd.rows.length){const sc=scoreGuess(wd.rows[r],wd.ans);for(let i=0;i<L;i++)t+=`<div class="tile ${sc[i]} ${r===wd.flip?"flip":""}" style="${r===wd.flip?`animation-delay:${i*110}ms`:""}">${wd.rows[r][i]}</div>`}
    else if(r===wd.rows.length&&!wd.done){for(let i=0;i<L;i++)t+=`<div class="tile ${wd.cur[i]?"filled":""}">${wd.cur[i]||""}</div>`}
    else for(let i=0;i<L;i++)t+=`<div class="tile"></div>`;
    grid+=`<div class="wrow" style="--n:${L}">${t}</div>`}
  wd.flip=-1;
  const rows=["QWERTYUIOP","ASDFGHJKL","^ZXCVBNM<"];
  const kb=rows.map(r=>`<div class="kbr">${[...r].map(c=>c==="^"?`<button class="key wide" data-k="ENTER">Enter</button>`:c==="<"?`<button class="key wide" data-k="BACK" aria-label="Delete">⌫</button>`:`<button class="key ${ks[c]||""}" data-k="${c}">${c}</button>`).join("")}</div>`).join("");
  const hintBtns=Object.entries(HINTS).map(([k,[lab,f]])=>wd.hints.includes(k)||wd.done?`<div class="hint on"><span class="label">${lab}</span><b>${esc(f(wd.p))}</b></div>`:`<button class="hint" data-h="${k}"><span class="label">${lab}</span><b>Reveal</b></button>`).join("");
  const st=store.get("fb-wd-stats",{played:0,wins:0,streak:0,max:0,dist:[0,0,0,0,0,0]}),mx=Math.max(1,...st.dist);
  let status;
  if(wd.done)status=`<p class="msg ${wd.won?"good":"bad"}">${wd.won?`Got it in ${wd.rows.length}!`:"Out of guesses."} It was <b>${esc(wd.p.n)}</b> (${esc(ROLE_NAME[wd.p.pos].toLowerCase())}, ${yrs(wd.p)}).</p>`;
  else status=`<p class="msg ${wd.msg?"bad":""}">${wd.msg?esc(wd.msg):`${L} letters · ${6-wd.rows.length} guesses left · ${wd.daily?`daily puzzle #${wd.num}`:"practice round"}`}</p>`;
  p.innerHTML=`<h2>Fenerdle</h2><p class="intro">Guess the Fenerbahçe player in six tries. Answers are the names fans use, usually the surname (Alex, Volkan and Lefter go by first name). Turkish letters are written without accents, so Ş becomes S. There's a new daily puzzle every day, plus unlimited practice rounds.</p>
  <div class="wtop"><div class="filter" role="group" aria-label="Mode"><button data-wm="daily" aria-pressed="${wd.daily}">Daily</button><button data-wm="practice" aria-pressed="${!wd.daily}">Practice</button></div>
    <label class="toggle"><input type="checkbox" id="wdHard" ${wd.hard?"checked":""} ${wd.rows.length?"disabled":""}> Hard mode</label></div>
  <div class="wcenter">${status}</div>
  <div class="wgame"><div class="wgrid">${grid}</div>
   <div class="wside"><span class="label">Hints · each one shows in your shared result</span><div class="hints">${hintBtns}</div>
   ${wd.done?`<div class="btns">${wd.daily?`<button class="btn" data-w="share">Copy result</button>`:""}<button class="btn ${wd.daily?"ghost":""}" data-w="new">Practice round</button></div>${wd.copied?`<p class="msg good">${esc(wd.copied)}</p>`:""}<textarea id="wdShare" class="sharebox" readonly hidden>${esc(shareText())}</textarea>`:""}
   <div class="wstats"><span class="label">Daily stats</span><div class="wnums"><div><b>${st.played}</b><span>Played</span></div><div><b>${st.played?Math.round(st.wins/st.played*100):0}</b><span>Win %</span></div><div><b>${st.streak}</b><span>Streak</span></div><div><b>${st.max}</b><span>Best</span></div></div>
   <div class="dist">${st.dist.map((n,i)=>`<div><span>${i+1}</span><i style="width:${Math.max(6,n/mx*100)}%" class="${wd.daily&&wd.won&&wd.rows.length===i+1?"hl":""}">${n}</i></div>`).join("")}</div></div></div></div>
  <div class="legendrow"><span><i style="background:var(--yellow)"></i>Right spot</span><span><i style="background:var(--present)"></i>In the name, wrong spot</span><span><i style="background:var(--absent)"></i>Not in the name</span></div>
  <div class="kb">${kb}</div>`;
  p.querySelectorAll("[data-k]").forEach(b=>b.onclick=()=>wordleKey(b.dataset.k));
  p.querySelectorAll("[data-h]").forEach(b=>b.onclick=()=>{wd.hints.push(b.dataset.h);saveDaily();renderPanel()});
  p.querySelectorAll("[data-wm]").forEach(b=>b.onclick=()=>{newWordle(b.dataset.wm==="daily");renderPanel()});
  p.querySelector("#wdHard").onchange=e=>{if(wd.rows.length)return;wd.hard=e.target.checked;store.set("fb-wd-hard",wd.hard);renderPanel()};
  const n=p.querySelector('[data-w="new"]');if(n)n.onclick=()=>{newWordle(false);renderPanel()};
  const sh=p.querySelector('[data-w="share"]');if(sh)sh.onclick=()=>{const t=shareText();
    const fallback=()=>{wd.copied="Copy the text below.";renderPanel();const ta=document.getElementById("wdShare");if(ta){ta.hidden=false;ta.select()}};
    try{navigator.clipboard.writeText(t).then(()=>{wd.copied="Copied to your clipboard.";renderPanel()},fallback)}catch(e){fallback()}};
}

/* ===== 3. NAME THE XI ===== */
const LINEUPS=[
 {id:"2026",form:"4-2-3-1",what:"Super Cup final",opp:"Galatasaray",score:"2–0 win",date:"10 January 2026",coach:"Domenico Tedesco",goals:"Guendouzi 28', Oosterwolde 48'",
  rows:[[["ST","Jhon Durán",["duran"]]],[["ATT","Kerem Aktürkoğlu",["kerem","akturkoglu"]],["ATT","Marco Asensio",["asensio"]],["ATT","Anthony Musaba",["musaba"]]],[["CM","Mattéo Guendouzi",["guendouzi"]],["CM","İsmail Yüksek",["ismail","yuksek"]]],[["LB","Levent Mercan",["levent","mercan"]],["CB","Jayden Oosterwolde",["oosterwolde"]],["CB","Milan Škriniar",["skriniar"]],["RB","Mert Müldür",["mert","muldur"]]],[["GK","Ederson",["ederson"]]]]},
 {id:"2023",form:"4-4-2",what:"Turkish Cup final",opp:"İstanbul Başakşehir",score:"2–0 win",date:"11 June 2023",coach:"Jorge Jesus",goals:"",
  rows:[[["ST","Michy Batshuayi",["batshuayi","michy"]],["ST","Enner Valencia",["valencia","enner"]]],[["LM","İrfan Can Kahveci",["kahveci"]],["CM","Miha Zajc",["zajc"]],["CM","Willian Arão",["arao","willian"]],["RM","Arda Güler",["arda","guler"]]],[["LB","Luan Peres",["luan","peres"]],["CB","Attila Szalai",["szalai","attila"]],["CB","Serdar Aziz",["serdar","aziz"]],["RB","Ferdi Kadıoğlu",["ferdi","kadioglu"]]],[["GK","İrfan Can Eğribayat",["egribayat"]]]]},
 {id:"2013",form:"4-5-1",what:"Turkish Cup final",opp:"Trabzonspor",score:"1–0 win",date:"22 May 2013",coach:"Aykut Kocaman",goals:"Moussa Sow 9'",
  rows:[[["ST","Pierre Webó",["webo","pierre webo"]]],[["MF","Moussa Sow",["sow","moussa"]],["MF","Cristian Baroni",["cristian","baroni"]],["MF","Mehmet Topal",["topal"]],["MF","Emre Belözoğlu",["emre","belozoglu"]],["MF","Dirk Kuyt",["kuyt","dirk"]]],[["LB","Hasan Ali Kaldırım",["hasan ali","kaldirim"]],["CB","Joseph Yobo",["yobo"]],["CB","Egemen Korkmaz",["egemen","korkmaz"]],["RB","Gökhan Gönül",["gokhan","gonul"]]],[["GK","Mert Günok",["mert","gunok"]]]]},
 {id:"2012",form:"4-5-1",what:"Turkish Cup final",opp:"Bursaspor",score:"4–0 win",date:"16 May 2012",coach:"Aykut Kocaman",goals:"Caner Erkin 2', Cristian 45', Semih Şentürk 58', Alex 78'",
  rows:[[["ST","Semih Şentürk",["semih","senturk"]]],[["MF","Caner Erkin",["caner","erkin"]],["MF","Alex de Souza",["alex","de souza"]],["MF","Emre Belözoğlu",["emre","belozoglu"]],["MF","Cristian Baroni",["cristian","baroni"]],["MF","Mehmet Topuz",["topuz"]]],[["LB","Reto Ziegler",["ziegler","reto"]],["CB","Joseph Yobo",["yobo"]],["CB","Bekir İrtegün",["bekir","irtegun"]],["RB","Gökhan Gönül",["gokhan","gonul"]]],[["GK","Volkan Demirel",["volkan","demirel"]]]]},
 {id:"2008",form:"4-5-1",what:"Champions League quarter-final, 1st leg",opp:"Chelsea",score:"2–1 win",date:"2 April 2008",coach:"Zico",goals:"Kazım-Richards 64', Deivid 81'",
  rows:[[["ST","Mateja Kežman",["kezman","mateja"]]],[["MF","Uğur Boral",["ugur","boral"]],["MF","Alex de Souza",["alex","de souza"]],["MF","Deivid",["deivid"]],["MF","Mehmet Aurélio",["aurelio"]],["MF","Claudio Maldonado",["maldonado","claudio"]]],[["LB","Wederson",["wederson"]],["CB","Edu Dracena",["edu","dracena"]],["CB","Diego Lugano",["lugano","diego"]],["RB","Önder Turacı",["onder","turaci"]]],[["GK","Volkan Demirel",["volkan","demirel"]]]]},
 {id:"2002",form:"Not recorded",what:"Süper Lig derby",opp:"Galatasaray",score:"6–0 win",date:"6 November 2002",coach:"Werner Lorant",goals:"Tuncay 9', Ortega 38', Serhat 69' & 75', Ceyhun 79', Ümit Özat 87'",
  rows:[[["XI","Serhat Akın",["serhat","akin"]],["XI","Washington",["washington"]]],[["XI","Tuncay Şanlı",["tuncay","sanli"]],["XI","Ariel Ortega",["ortega","ariel"]],["XI","Yusuf Şimşek",["yusuf","simsek"]],["XI","Miroslav Stević",["stevic"]]],[["XI","Ümit Özat",["umit","ozat"]],["XI","Ogün Temizkanoğlu",["ogun","temizkanoglu"]],["XI","Johnson",["johnson"]],["XI","Fatih Akyel",["fatih","akyel"]]],[["GK","Rüştü Reçber",["rustu","recber"]]]]}
];
let xi=null,xiTimer=null;
const XI_TIME=150;
function newXI(id,mode){clearInterval(xiTimer);xi={id,mode:mode||(xi?xi.mode:"relaxed"),found:new Set(),hints:new Set(),wrong:0,ended:false,timeUp:false,msg:"",cls:"",start:null}}
function xiPlayers(L){const out=[];L.rows.forEach((r,ri)=>r.forEach((p,ci)=>out.push({key:ri+"-"+ci,pos:p[0],name:p[1],al:p[2].map(norm).concat(norm(p[1]))})));return out}
const xiScore=()=>Math.max(0,xi.found.size*10-xi.hints.size*4-xi.wrong*2);
const xiStars=()=>xi.found.size===11&&!xi.hints.size&&xi.wrong<=2?3:xi.found.size===11?2:xi.found.size>=6?1:0;
const xiLeft=()=>xi.start?Math.max(0,XI_TIME-Math.floor((Date.now()-xi.start)/1000)):XI_TIME;
function xiEnd(msg){if(xi.ended)return;xi.ended=true;clearInterval(xiTimer);const bonus=xi.mode==="clock"&&xi.found.size===11?xiLeft():0;xi.final=xiScore()+bonus;
  const best=store.get("fb-xi",{}),b=best[xi.id]||{stars:0,score:0};best[xi.id]={stars:Math.max(b.stars,xiStars()),score:Math.max(b.score,xi.final)};store.set("fb-xi",best);xi.msg=msg;xi.cls=xi.found.size===11?"good":""}
function renderXI(p){
  if(!xi)newXI("2026");
  const L=LINEUPS.find(l=>l.id===xi.id),ps=xiPlayers(L),n=xi.found.size,best=store.get("fb-xi",{});
  const locked=xi.ended||(xi.mode==="clock"&&!xi.start);
  const rows=L.rows,yStep=rows.length>1?76/(rows.length-1):0;
  const slots=rows.map((r,ri)=>r.map((pl,ci)=>{const k=ri+"-"+ci,f=xi.found.has(k),show=f||xi.ended;const x=(ci+1)/(r.length+1)*100,y=12+ri*yStep;
    const hint=xi.hints.has(k)?pl[1].split(" ").map(w=>w[0]+"·".repeat(Math.min(w.length-1,6))).join(" "):"";
    return `<div class="ps ${f?"filled":xi.ended?"missed":""}" style="left:${x}%;top:${y}%"><span class="disc">${f?"✓":pl[0]}</span><span class="nm ${show?"":"dim"}">${show?esc(pl[1]):esc(hint)}</span></div>`}).join("")).join("");
  const stars=s=>"★".repeat(s)+"☆".repeat(3-s);
  p.innerHTML=`<h2>Name the XI</h2><p class="intro">You get the formation, the year and the match. Name all eleven starters. Surnames work, and so do the names fans use, like Alex or Volkan. Small typos are forgiven. Each player is worth 10 points, a hint costs 4 and a wrong guess costs 2. Against the clock, you get the seconds left over as a bonus.</p>
  <div class="wtop"><div class="filter" role="group" aria-label="Match">${LINEUPS.map(l=>`<button data-xi="${l.id}" aria-pressed="${l.id===xi.id}">${l.id} <span class="stars">${stars((best[l.id]||{}).stars||0)}</span></button>`).join("")}</div>
   <div class="filter" role="group" aria-label="Mode"><button data-xm="relaxed" aria-pressed="${xi.mode==="relaxed"}">Relaxed</button><button data-xm="clock" aria-pressed="${xi.mode==="clock"}">Against the clock</button></div></div>
  <div class="draft"><div class="pitch2 xi">${slots}</div><div class="side"><div class="box">
    <span class="label">${esc(L.what)} · ${esc(L.date)}</span><h3 style="margin-top:4px">vs ${esc(L.opp)}, ${esc(L.score)}</h3>
    <div class="facts"><div><span class="label">Formation</span><b>${esc(L.form)}</b></div><div><span class="label">Year</span><b>${L.id}</b></div><div><span class="label">Coach</span><b style="font-size:20px">${esc(L.coach)}</b></div></div>
    ${xi.mode==="clock"&&!xi.start&&!xi.ended?`<div class="btns"><button class="btn" data-x="start">Start the clock (${Math.floor(XI_TIME/60)}:${String(XI_TIME%60).padStart(2,"0")})</button></div>`:
    `<form class="guessbar" id="xiForm" autocomplete="off"><input id="xiGuess" placeholder="Type a player…" aria-label="Player name" ${locked?"disabled":""}><button class="btn" ${locked?"disabled":""}>Guess</button></form>`}
    <p class="msg ${xi.cls}">${esc(xi.msg)}</p>
    <div class="xinums"><div><b class="count">${n}</b><span class="label">of 11</span></div><div><b class="count">${xi.ended?xi.final:xiScore()}</b><span class="label">points</span></div>${xi.mode==="clock"?`<div><b class="count" id="xiClock">${fmtClock(xiLeft())}</b><span class="label">left</span></div>`:""}</div>
    ${xi.ended?`<p style="margin-top:10px;font-size:22px;color:var(--yellow)">${stars(xiStars())}</p>${L.goals?`<p class="gnote">Goals: ${esc(L.goals)}</p>`:""}`:""}
    <div class="btns"><button class="btn ghost" data-x="hint" ${locked?"disabled":""}>Hint (−4)</button><button class="btn ghost" data-x="give" ${locked?"disabled":""}>Give up</button><button class="btn ghost" data-x="reset">Start over</button></div>
    ${L.form==="Not recorded"?'<p class="gnote">The formation for this match is not on record, so the players are not placed by position.</p>':""}
  </div></div></div>`;
  p.querySelectorAll("[data-xi]").forEach(b=>b.onclick=()=>{newXI(b.dataset.xi);renderPanel()});
  p.querySelectorAll("[data-xm]").forEach(b=>b.onclick=()=>{newXI(xi.id,b.dataset.xm);renderPanel()});
  const f=p.querySelector("#xiForm");if(f)f.onsubmit=e=>{e.preventDefault();if(locked)return;const raw=p.querySelector("#xiGuess").value,v=norm(raw);if(!v)return;
    const hit=ps.find(x=>!xi.found.has(x.key)&&x.al.some(a=>closeEnough(v,a)))||ps.find(x=>x.al.some(a=>closeEnough(v,a)));
    if(!hit){xi.wrong++;xi.msg=`${raw} didn't start this match (−2).`;xi.cls="bad"}
    else if(xi.found.has(hit.key)){xi.msg=`You already have ${hit.name}.`;xi.cls=""}
    else{xi.found.add(hit.key);xi.msg=`Yes: ${hit.name}.`;xi.cls="good";if(xi.found.size===11)xiEnd("All eleven!")}
    renderPanel();const i=document.getElementById("xiGuess");if(i&&!i.disabled)i.focus()};
  const on=(k,fn)=>{const b=p.querySelector(`[data-x="${k}"]`);if(b)b.onclick=fn};
  on("start",()=>{xi.start=Date.now();xiTimer=setInterval(()=>{const c=document.getElementById("xiClock");const l=xiLeft();if(c)c.textContent=fmtClock(l);if(l<=0){xiEnd(`Time's up! You found ${xi.found.size} of 11.`);if(c)renderPanel()}},250);renderPanel();const i=document.getElementById("xiGuess");if(i)i.focus()});
  on("hint",()=>{const left=ps.filter(x=>!xi.found.has(x.key)&&!xi.hints.has(x.key));if(left.length){xi.hints.add(left[Math.floor(Math.random()*left.length)].key);xi.msg="Hint: first letters of one player.";xi.cls=""}renderPanel()});
  on("give",()=>{xiEnd(`You found ${xi.found.size} of 11.`);renderPanel()});
  on("reset",()=>{newXI(xi.id);renderPanel()});
}
const fmtClock=s=>`${Math.floor(s/60)}:${String(s%60).padStart(2,"0")}`;

/* ===== 4. PENALTY SHOOTOUT ===== */
const GW=7.32,GH=2.44,gx=x=>15+x/GW*70,gy=y=>49.3-y/GH*37.3;
const ZC=z=>[[1.25,3.66,6.07][z%3],[1.72,0.6][Math.floor(z/3)]];
const zoneOf=(x,y)=>(y>1.22?0:3)+(x<2.44?0:x<4.88?1:2);
const ZN=["top left","top middle","top right","bottom left","bottom middle","bottom right"];
let pk=null,pkRAF=null;
function pkSquad(){const full=dr&&dr.picks.every(Boolean);
  const takers=full?dr.picks.filter((p,i)=>i!==0):["Edin Džeko","Alex de Souza","Dušan Tadić","Emre Belözoğlu","Dirk Kuyt","Lefter Küçükandonyadis"].map(n=>PLAYERS.find(p=>p.n===n));
  return{takers:takers.sort((a,b)=>b.r-a.r),gk:full?dr.picks[0]:PLAYERS.find(p=>p.n==="Volkan Demirel"),fromDraft:full}}
function newPK(){cancelAnimationFrame(pkRAF);pkRAF=null;pk={...pkSquad(),you:[],them:[],turn:"shoot",phase:"aimX",t0:performance.now(),cx:3.66,cy:1.2,hist:[0,0,0,0,0,0],bias:shuffle([3.2,2,1.4,1,.8,.6]),msg:"",banner:"",over:null,anim:null,tell:null,shot:null}}
const taker=()=>pk.takers[pk.you.length%pk.takers.length];
const tri=(t,per)=>{const ph=(t%(2*per))/per;return ph<1?ph:2-ph};
function pkLoop(){if(!pk||(pk.phase!=="aimX"&&pk.phase!=="aimY")){pkRAF=null;return}const el=document.getElementById("pkAim");if(!el){pkRAF=null;return}
  const r=taker().r,now=performance.now()-pk.t0;
  if(pk.phase==="aimX"){pk.cx=-0.7+tri(now,(0.95+(r-75)*0.055)*1000)*(GW+1.4);pk.cy=1.15}else pk.cy=tri(now,(0.75+(r-75)*0.045)*1000)*3.2;
  el.style.left=gx(pk.cx)+"%";el.style.top=gy(pk.cy)+"%";pkRAF=requestAnimationFrame(pkLoop)}
function pkOutcome(){const y=pk.you.filter(Boolean).length,t=pk.them.filter(Boolean).length,ny=pk.you.length,nt=pk.them.length;
  if(ny<=5&&nt<=5){if(y+(5-ny)<t)return"lose";if(t+(5-nt)<y)return"win"}
  if(ny>=5&&ny===nt&&y!==t)return y>t?"win":"lose";return null}
function pkLock(){if(!pk||pk.over)return;
  if(pk.phase==="aimX"){pk.ax=pk.cx;pk.phase="aimY";pk.t0=performance.now();renderPanel()}
  else if(pk.phase==="aimY"){pk.ay=pk.cy;pkShoot()}}
function pkResolve(scored,banner,ball,keeper,isYou){
  pk.phase="anim";pk.anim={ball,keeper,played:false};renderPanel();
  setTimeout(()=>{(isYou?pk.you:pk.them).push(scored);pk.banner=banner;const o=pkOutcome();if(o){pk.over=o;if(o==="win")store.set("fb-pk-wins",store.get("fb-pk-wins",0)+1)}renderPanel();
    setTimeout(()=>{pk.anim=null;pk.banner="";if(pk.over){pk.phase="over"}else if(isYou){pk.turn="save";pkPrepSave()}else{pk.turn="shoot";pk.phase="aimX";pk.t0=performance.now()}renderPanel()},1300)},620)}
function pkShoot(){const x=pk.ax,y=pk.ay;let banner,scored=false;
  let dive=Math.random()<.12?null:pickW([0,1,2,3,4,5],z=>1+2*pk.hist[z]);const [tx,ty]=dive==null?[3.66,1]:ZC(dive),reach=dive==null?.95:1.15;
  if(x<0||x>GW)banner="Wide!";else if(y>GH)banner="Over the bar!";
  else{pk.hist[zoneOf(x,y)]++;const post=x<.14||x>GW-.14||y>GH-.12;
    if(post&&Math.random()<.4)banner="Off the woodwork!";
    else if(Math.hypot(x-tx,(y-ty)*1.25)<reach)banner="Saved!";
    else{banner="Goal!";scored=true}}
  pkResolve(scored,banner,[x,Math.min(y,3.3)],[tx,ty,dive],true)}
function pkPrepSave(){const z=pickW([0,1,2,3,4,5],i=>pk.bias[i]),[cx,cy]=ZC(z);let x=clamp(cx+rnd(-.95,.95),.15,GW-.15),y=clamp(cy+rnd(-.45,.45),.15,GH-.12);
  const miss=Math.random()<.08;if(miss){if(Math.random()<.5)y=2.75;else x=x<GW/2?-.35:GW+.35}
  const col=z%3,tellCol=Math.random()<.62?col:[0,1,2].filter(c=>c!==col)[Math.floor(Math.random()*2)];
  pk.shot={x,y,miss};pk.tell=["the left side","the middle","the right side"][tellCol];pk.phase="dive"}
function pkDive(z){if(pk.phase!=="dive")return;const [tx,ty]=ZC(z),{x,y,miss}=pk.shot;const saved=!miss&&Math.hypot(x-tx,(y-ty)*1.25)<1.15;
  pkResolve(!miss&&!saved,miss?(y>GH?"Over the bar!":"Wide!"):saved?"You saved it!":"They score.",[x,y],[tx,ty,z],false)}
function renderPK(p){
  if(!pk)newPK();cancelAnimationFrame(pkRAF);pkRAF=null;
  const dots=(a,names)=>{let h="";const n=Math.max(5,a.length);for(let i=0;i<n;i++)h+=`<i class="dot ${a[i]===true?"g":a[i]===false?"m":""}"></i>`;return h};
  const t=taker(),aim=pk.phase==="aimX"||pk.phase==="aimY",youKeep=pk.turn==="save";
  const rot=k=>{if(!k||k[2]==null)return 0;const c=k[2]%3,top=k[2]<3;return c===1?0:(c===0?-1:1)*(top?70:55)};
  const kp=pk.anim&&pk.anim.played?pk.anim.keeper:[3.66,.95],bp=pk.anim&&pk.anim.played?pk.anim.ball:null;
  let hud;
  if(pk.over)hud=`<span class="label">Full time</span><p class="msg ${pk.over==="win"?"good":"bad"}" style="font-size:20px">${pk.over==="win"?"Fenerbahçe win the shootout!":"The opponents win this one."}</p>`;
  else if(pk.turn==="shoot")hud=`<span class="label">Your kick · ${pk.you.length+1}${pk.you.length>=5?" (sudden death)":""}</span><h3 style="margin-top:4px">${esc(t.n)} <span style="color:var(--muted);font-size:16px">composure ${t.r}</span></h3>
     <p style="margin-top:8px">${pk.phase==="aimX"?"Step 1: stop the marker to set the direction.":pk.phase==="aimY"?"Step 2: stop it again to set the height. Too high and it goes over.":"…"}</p>
     <p class="gnote">Tap the pitch, press Space or use the button. Better players move the marker more slowly. The keeper learns where you like to shoot.</p>
     ${aim?`<div class="btns"><button class="btn" data-pk="lock">${pk.phase==="aimX"?"Set direction":"Shoot"}</button></div>`:""}`;
  else hud=`<span class="label">You're in goal · ${esc(pk.gk.n)}</span><h3 style="margin-top:4px">Their taker is eyeing ${pk.tell||"…"}</h3><p class="gnote">The read is right a bit more often than not. Tap the part of the goal you want to dive to.</p>`;
  p.innerHTML=`<h2>Penalty Shootout</h2><p class="intro">Five kicks each, then sudden death. To shoot, time two taps: one for direction, one for height. In goal, read the taker and dive. ${pk.fromDraft?"Your drafted XI is taking the kicks.":"Draft a full XI and your own players will take the kicks."}</p>
  <div class="pk-wrap"><div class="pk-field" id="pkf">
    <div class="pk-line"></div><div class="pk-box"></div><div class="pk-spot"></div>
    <div class="pk-goal">${pk.phase==="dive"?[0,1,2,3,4,5].map(z=>`<button class="pk-zone" data-z="${z}" aria-label="Dive ${ZN[z]}"></button>`).join(""):""}</div>
    <div class="pk-keeper ${youKeep?"":"them"} ${pk.anim&&pk.anim.played?"notrans":""}" id="pkk" style="left:${gx(kp[0])}%;top:${gy(kp[1])}%;--rot:${pk.anim&&pk.anim.played?rot(pk.anim.keeper):0}deg"></div>
    <div class="pk-ball ${bp?"notrans":""}" id="pkb" style="left:${bp?gx(bp[0]):50}%;top:${bp?gy(bp[1]):88}%;${bp?"width:2.6%":""}"></div>
    ${aim?`<div class="pk-aim" id="pkAim" style="left:${gx(pk.cx)}%;top:${gy(pk.cy)}%"></div>${pk.phase==="aimY"?`<div class="pk-guide" style="left:${gx(pk.ax)}%"></div>`:""}`:""}
    <div class="pk-banner">${esc(pk.banner)}</div>
  </div>
  <div class="side"><div class="box">${hud}</div><div class="box">
    <div class="pk-score"><div class="pk-team"><span style="color:var(--yellow)">Fener</span><div class="dots">${dots(pk.you)}</div><b>${pk.you.filter(Boolean).length}</b></div>
    <div class="pk-team"><span>Opponents</span><div class="dots">${dots(pk.them)}</div><b>${pk.them.filter(Boolean).length}</b></div></div>
    <div class="btns"><button class="btn ${pk.over?"":"ghost"}" data-pk="new">${pk.over?"Play again":"Restart"}</button></div>
    <p class="gnote">Shootouts won: ${store.get("fb-pk-wins",0)}</p></div></div></div>`;
  p.querySelectorAll("[data-z]").forEach(b=>b.onclick=e=>{e.stopPropagation();pkDive(+b.dataset.z)});
  const lb=p.querySelector('[data-pk="lock"]');if(lb)lb.onclick=pkLock;
  p.querySelector('[data-pk="new"]').onclick=()=>{newPK();renderPanel()};
  p.querySelector("#pkf").onpointerdown=e=>{if(aim){e.preventDefault();pkLock()}};
  if(pk.anim&&!pk.anim.played){const a=pk.anim,b=p.querySelector("#pkb"),k=p.querySelector("#pkk");a.played=true;
    requestAnimationFrame(()=>requestAnimationFrame(()=>{b.style.left=gx(a.ball[0])+"%";b.style.top=gy(a.ball[1])+"%";b.style.width="2.6%";k.style.left=gx(a.keeper[0])+"%";k.style.top=gy(a.keeper[1])+"%";k.style.setProperty("--rot",rot(a.keeper)+"deg")}))}
  if(aim)pkRAF=requestAnimationFrame(pkLoop);
}

/* ===== 5. WHO AM I? ===== */
const SPECIAL={"Alex de Souza":"I arrived from Cruzeiro and wore the number 10.","Roberto Carlos":"I won the World Cup in 2002 and was famous for free kicks.","Volkan Demirel":"I was a hero of the 2008 shootout in Seville.","Lefter Küçükandonyadis":"Fans called me 'Ordinaryüs', the Professor.","Edin Džeko":"I won the Premier League in England before moving to Italy.","Arda Güler":"I came through the academy and was sold to Real Madrid.","Dirk Kuyt":"I came from Liverpool and played in a World Cup final.","Mattéo Guendouzi":"I scored the first goal in the January 2026 Super Cup final.","Jay-Jay Okocha":"I arrived from Eintracht Frankfurt and loved a step-over.","Emre Belözoğlu":"I started at Galatasaray and later played for Inter and Newcastle.","Diego Lugano":"I captained my country and was a fierce defender.","Aykut Kocaman":"I scored goals here and later coached the club to the 2012 cup.","Rüştü Reçber":"I was in goal when Turkey finished third at the 2002 World Cup.","Nicolas Anelka":"I had already played for Arsenal and Real Madrid before Istanbul.","Robin van Persie":"I was the Premier League's top scorer with Manchester United.","Tuncay Şanlı":"I scored the first goal of the 6–0 against Galatasaray.","Mesut Özil":"I won the 2014 World Cup with Germany.","Milan Škriniar":"I captain my national team and came from Paris Saint-Germain.","Harald Schumacher":"I played in two World Cup finals for West Germany."};
let who=null;
function whoClues(p){const mates=shuffle(PLAYERS.filter(q=>together(p,q)&&q.r>=79)).slice(0,2),c=[];
  c.push(mates.length?`At Fenerbahçe I played alongside ${mates.map(m=>m.n).join(" and ")}.`:"I played for Fenerbahçe a very long time ago.");
  c.push(p.to>=CUR?`I joined Fenerbahçe around ${p.from}.`:`My Fenerbahçe years were roughly ${p.from}–${p.to}.`);
  c.push(SPECIAL[p.n]||`In this site's draft game I'm rated ${p.r}.`);
  c.push(`I'm a ${ROLE_NAME[p.pos].toLowerCase()} from ${NAT[p.nat]}.`);
  const nm=norm(p.short).replace(/ /g,"");c.push(`Fans know me as a name of ${nm.length} letters starting with "${p.short[0]}".`);return c}
function newWho(){const pool=shuffle(PLAYERS.filter(p=>p.r>=79||SPECIAL[p.n]));who={q:pool.slice(0,8).map(p=>({p,c:whoClues(p)})),i:0,shown:1,score:0,state:null,msg:"",guesses:[]}}
function renderWho(p){
  if(!who)newWho();
  const head=`<h2>Who Am I?</h2><p class="intro">Eight mystery players. Each one starts at 5 points and loses a point for every clue you open. A wrong guess opens the next clue automatically. Type the name. Small typos are fine.</p>`;
  if(who.i>=who.q.length){const best=store.get("fb-who-best",0);if(who.score>best)store.set("fb-who-best",who.score);
    p.innerHTML=head+`<div class="quiz"><span class="label">Final score</span><div class="final">${who.score}/40</div><p style="font-size:18px;margin-top:6px">${who.score>=32?"Encyclopedic. You might work at the club museum.":who.score>=20?"Good effort, Fenerbahçeli.":"Back to the Legends tab!"}</p><p class="gnote">Best: ${Math.max(best,who.score)}/40</p><button class="btn" data-wh="again" style="margin-top:14px">Play again</button></div>`;
    p.querySelector('[data-wh="again"]').onclick=()=>{newWho();renderPanel()};return}
  const r=who.q[who.i],pts=6-who.shown,done=who.state!=null;
  p.innerHTML=head+`<div class="quiz"><div class="top"><span class="label">Player ${who.i+1} of ${who.q.length}</span><span class="label">Score ${who.score}</span></div>
    <div class="progress"><i style="width:${who.i/who.q.length*100}%"></i></div>
    <ol class="clues">${r.c.map((c,i)=>i<who.shown||done?`<li><span>${i+1}</span><div>${esc(c)}</div></li>`:`<li class="locked"><span>${i+1}</span><div>Hidden clue</div></li>`).join("")}</ol>
    ${done?`<p class="explain"><b>${who.state==="win"?`Correct, +${who.got}.`:"Not this time."}</b> It was ${esc(r.p.n)}.</p><button class="btn" data-wh="next" style="margin-top:14px">${who.i+1<who.q.length?"Next player":"See score"}</button>`:
    `<form class="guessbar" id="whoForm" autocomplete="off"><input id="whoGuess" placeholder="Who am I?" aria-label="Your guess"><button class="btn">Guess</button></form>
     <p class="msg bad">${esc(who.msg)}</p>
     <div class="btns">${who.shown<5?`<button class="btn ghost" data-wh="more">Next clue (−1)</button>`:""}<button class="btn ghost" data-wh="give">Give up</button></div><p class="gnote">Worth ${pts} point${pts>1?"s":""} right now.${who.guesses.length?` Tried: ${who.guesses.map(esc).join(", ")}`:""}</p>`}</div>`;
  const on=(k,f)=>{const b=p.querySelector(`[data-wh="${k}"]`);if(b)b.onclick=f};
  on("more",()=>{who.shown++;who.msg="";renderPanel()});
  on("give",()=>{who.state="lose";renderPanel()});
  on("next",()=>{who.i++;who.shown=1;who.state=null;who.msg="";who.guesses=[];renderPanel()});
  const f=p.querySelector("#whoForm");if(f){f.onsubmit=e=>{e.preventDefault();const raw=p.querySelector("#whoGuess").value,v=norm(raw);if(!v)return;
    const al=[norm(r.p.n),norm(r.p.short),norm(lastName(r.p.n))];
    if(al.some(a=>closeEnough(v,a))){who.state="win";who.got=pts;who.score+=pts}
    else{who.guesses.push(raw);if(who.shown>=5){who.state="lose"}else{who.shown++;who.msg=`Not ${raw}. Here's another clue.`}}
    renderPanel();const i=document.getElementById("whoGuess");if(i)i.focus()};
  }
}

/* ===== 6. TIMELINE ===== */
const ARRIVALS=[["Alex de Souza",2004],["Roberto Carlos",2007],["Jay-Jay Okocha",1996],["Nicolas Anelka",2005],["Dirk Kuyt",2012],["Robin van Persie",2015],["Edin Džeko",2023],["Dušan Tadić",2023],["Milan Škriniar",2024],["Mattéo Guendouzi",2025],["Ederson",2025],["Mateja Kežman",2006],["Diego Lugano",2006],["Stephen Appiah",2005],["Harald Schumacher",1988],["Pierre van Hooijdonk",2003],["Raul Meireles",2012],["Diego Ribas",2014],["Fred",2023],["Mesut Özil",2021],["Marco Asensio",2025],["Haim Revivo",1997],["Ariel Ortega",2002],["Josef de Souza",2016],["Youssef En-Nesyri",2024],["Bruno Alves",2013],["Simon Kjær",2015],["Dominik Livaković",2023],["Sebastian Szymański",2023]];
function tlDeck(){const ev=[],seen=new Set(),add=(y,t,s)=>{if(!seen.has(t)){seen.add(t);ev.push({y,t,s})}};
  Object.values(SPORTS).forEach(s=>{(s.history||[]).forEach(([y,t])=>{if(/^\d{4}$/.test(y))add(+y,t,s.label)});(s.games||[]).forEach(g=>add(+g.date.slice(0,4),g.res?`${g.home} ${g.res} ${g.away} (${g.comp})`:`${g.title} (${g.comp})`,s.label))});
  ARRIVALS.forEach(([n,y])=>add(y,`${n} signs for Fenerbahçe`,"Transfers"));return shuffle(ev)}
let tl=null;
function newTL(){const deck=tlDeck();tl={deck,placed:[deck.shift()],cur:deck.shift(),lives:3,score:0,last:null,over:false}}
function tlPlace(k){const c=tl.cur,P=tl.placed,ok=(k===0||P[k-1].y<=c.y)&&(k===P.length||c.y<=P[k].y);
  if(ok){P.splice(k,0,{...c,st:"ok"});tl.score++}else{tl.lives--;let j=P.findIndex(e=>e.y>c.y);if(j<0)j=P.length;P.splice(j,0,{...c,st:"no"})}
  tl.last={ok,c};tl.cur=tl.deck.shift();if(tl.lives<=0||!tl.cur){tl.over=true;const b=store.get("fb-tl-best",0);if(tl.score>b){store.set("fb-tl-best",tl.score);tl.record=true}updateArcadeStats()}renderPanel()}
function renderTL(p){
  if(!tl)newTL();
  const slot=k=>tl.over?"":`<li class="ins"><button data-ins="${k}">Place it here</button></li>`;
  let list=slot(0);tl.placed.forEach((e,i)=>{list+=`<li class="card ${e.st||""} ${tl.last&&tl.last.c.t===e.t?"just":""}"><span class="y">${e.y}</span><span class="t"><small>${esc(e.s)}</small>${esc(e.t)}</span></li>`+slot(i+1)});
  p.innerHTML=`<h2>Timeline</h2><p class="intro">Moments from every Fenerbahçe branch, plus famous signings. Place each new card where it belongs, oldest at the top. A wrong placement costs a life, and you have three.</p>
  <div class="tlhead"><div><b class="count">${tl.score}</b><span class="label">placed</span></div><div class="lives" aria-label="${tl.lives} lives left">${[0,1,2].map(i=>`<i class="${i<tl.lives?"on":""}"></i>`).join("")}</div><div><b class="count">${store.get("fb-tl-best",0)}</b><span class="label">record</span></div></div>
  ${tl.over?`<div class="box" style="margin-top:16px"><h3>${tl.record?"New record! ":""}You placed ${tl.score} card${tl.score===1?"":"s"}.</h3><div class="btns"><button class="btn" data-tl="new">Play again</button></div></div>`:
  `<div class="tlcur"><span class="label">Where does this go?</span><p><small>${esc(tl.cur.s)}</small>${esc(tl.cur.t)}</p></div>`}
  ${tl.last&&!tl.over?`<p class="msg ${tl.last.ok?"good":"bad"}">${tl.last.ok?"Correct.":`Not quite. That was ${tl.last.c.y}.`}</p>`:""}
  <ol class="tl2">${list}</ol>`;
  p.querySelectorAll("[data-ins]").forEach(b=>b.onclick=()=>tlPlace(+b.dataset.ins));
  const n=p.querySelector('[data-tl="new"]');if(n)n.onclick=()=>{newTL();renderPanel()};
}

const ARCADE={draft:renderDraft,wordle:renderWordle,xi:renderXI,penalties:renderPK,who:renderWho,timeline:renderTL};
document.addEventListener("keydown",e=>{
  if(current!=="games"||e.metaKey||e.ctrlKey||e.altKey)return;
  if(e.target.closest&&e.target.closest("input,select,textarea"))return;
  if(e.target.closest&&e.target.closest("button")&&(e.key===" "||e.key==="Enter"))return;
  if(tab==="wordle"){if(e.key==="Enter"){e.preventDefault();wordleKey("ENTER")}else if(e.key==="Backspace"){e.preventDefault();wordleKey("BACK")}else if(e.key.length===1){const c=norm(e.key).toUpperCase();if(/^[A-Z]$/.test(c))wordleKey(c)}}
  if(tab==="penalties"&&(e.key===" "||e.key==="Enter")){e.preventDefault();pkLock()}
});
