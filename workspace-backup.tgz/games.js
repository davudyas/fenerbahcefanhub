/* ---------- FAN GAMES ---------- */
const norm = s => String(s).toLocaleLowerCase("tr").replace(/ç/g,"c").replace(/ğ/g,"g").replace(/ı/g,"i").replace(/ö/g,"o").replace(/ş/g,"s").replace(/ü/g,"u").normalize("NFD").replace(/[̀-ͯ]/g,"").replace(/[^a-z ]/g," ").replace(/\s+/g," ").trim();
const shuffle = a => {a=[...a];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
const store = {get(k,d){try{const v=localStorage.getItem(k);return v==null?d:JSON.parse(v)}catch(e){return d}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
const initials = n => n.split(/[\s-]+/).map(w=>w[0]).join("").slice(0,3);
const lastName = n => {const w=n.split(" ");return w.length>1?w.slice(1).join(" "):n};

/* ===== 1. ALL-TIME XI DRAFT ===== */
const ERA = {C:"Classic",9:"1980s–90s",0:"2000s",1:"2010s",2:"2020s"};
const POOL = [
 ["Rüştü Reçber","GK",86,"9"],["Volkan Demirel","GK",84,"0"],["Harald Schumacher","GK",84,"9"],["Ederson","GK",85,"2"],["Dominik Livaković","GK",81,"2"],["Yaşar Duran","GK",78,"C"],
 ["Gökhan Gönül","RB",80,"1"],["Mert Müldür","RB",78,"2"],["Önder Turacı","RB",76,"0"],["Fatih Akyel","RB",77,"0"],["Mauricio Isla","RB",77,"1"],["Şener Özbayraklı","RB",75,"1"],
 ["Diego Lugano","CB",84,"0"],["Edu Dracena","CB",81,"0"],["Milan Škriniar","CB",85,"2"],["Bruno Alves","CB",81,"1"],["Simon Kjær","CB",81,"1"],["Joseph Yobo","CB",79,"1"],["Ogün Temizkanoğlu","CB",80,"9"],["Müjdat Yetkiner","CB",78,"9"],["Çağlar Söyüncü","CB",79,"2"],["Jayden Oosterwolde","CB",79,"2"],["Serdar Aziz","CB",77,"2"],["Bekir İrtegün","CB",75,"1"],
 ["Roberto Carlos","LB",87,"0"],["Ümit Özat","LB",80,"0"],["Ferdi Kadıoğlu","LB",81,"2"],["Hasan Ali Kaldırım","LB",76,"1"],["Reto Ziegler","LB",76,"1"],["Wederson","LB",75,"0"],["Levent Mercan","LB",75,"2"],
 ["Emre Belözoğlu","CM",85,"1"],["Mehmet Aurélio","CM",81,"0"],["Stephen Appiah","CM",81,"0"],["Fred","CM",83,"2"],["Mattéo Guendouzi","CM",83,"2"],["Raul Meireles","CM",80,"1"],["Josef de Souza","CM",80,"1"],["Oğuz Çetin","CM",80,"9"],["Selçuk Şahin","CM",76,"0"],["İsmail Yüksek","CM",77,"2"],["Cristian Baroni","CM",78,"1"],["Mehmet Topuz","CM",77,"1"],["Willian Arão","CM",77,"2"],
 ["Alex de Souza","AM",91,"0"],["Jay-Jay Okocha","AM",86,"9"],["Rıdvan Dilmen","AM",85,"9"],["Haim Revivo","AM",83,"9"],["Ariel Ortega","AM",82,"0"],["Can Bartu","AM",87,"C"],["Diego Ribas","AM",80,"1"],["Mesut Özil","AM",79,"2"],["Marco Asensio","AM",83,"2"],["Sebastian Szymański","AM",81,"2"],["Arda Güler","AM",82,"2"],
 ["Dušan Tadić","W",84,"2"],["Dirk Kuyt","W",84,"1"],["Kerem Aktürkoğlu","W",81,"2"],["İrfan Can Kahveci","W",80,"2"],["Miroslav Stoch","W",79,"1"],["Uğur Boral","W",77,"0"],["Tuncay Şanlı","W",82,"0"],["Caner Erkin","W",78,"1"],["Allan Saint-Maximin","W",80,"2"],
 ["Lefter Küçükandonyadis","ST",93,"C"],["Cemil Turan","ST",85,"C"],["Aykut Kocaman","ST",86,"9"],["Tanju Çolak","ST",86,"9"],["Selçuk Yula","ST",82,"9"],["Elvir Bolić","ST",82,"9"],["Pierre van Hooijdonk","ST",83,"0"],["Nicolas Anelka","ST",84,"0"],["Mateja Kežman","ST",81,"0"],["Semih Şentürk","ST",80,"0"],["Serhat Akın","ST",78,"0"],["Edin Džeko","ST",85,"2"],["Robin van Persie","ST",83,"1"],["Moussa Sow","ST",81,"1"],["Emmanuel Emenike","ST",80,"1"],["Youssef En-Nesyri","ST",82,"2"],["Enner Valencia","ST",81,"2"]
];
const FORMS = {
 "4-3-3":[["LW","ST","RW"],["CM","CM","CM"],["LB","CB","CB","RB"],["GK"]],
 "4-4-2":[["ST","ST"],["LM","CM","CM","RM"],["LB","CB","CB","RB"],["GK"]],
 "4-2-3-1":[["ST"],["LW","AM","RW"],["CM","CM"],["LB","CB","CB","RB"],["GK"]],
 "3-5-2":[["ST","ST"],["LM","CM","AM","CM","RM"],["CB","CB","CB"],["GK"]]
};
const ELIG = {GK:"GK",RB:"RB",LB:"LB",CB:"CB",CM:"CM",AM:"AM",LW:"W",RW:"W",LM:"W",RM:"W",ST:"ST"};
let draft = null;
function newDraft(form){
  const slots=[];FORMS[form].forEach((r,ri)=>r.forEach((pos,ci)=>slots.push({pos,ri,ci,p:null})));
  const order=slots.map((_,i)=>i).sort((a,b)=>slots[b].ri-slots[a].ri||slots[a].ci-slots[b].ci);
  draft={form,slots,order,step:0,rerolls:2,cands:[]};deal();
}
function deal(){
  if(draft.step>=draft.order.length){draft.cands=[];return}
  const slot=draft.slots[draft.order[draft.step]];
  const used=new Set(draft.slots.filter(s=>s.p).map(s=>s.p[0]));
  draft.cands=shuffle(POOL.filter(p=>p[1]===ELIG[slot.pos]&&!used.has(p[0]))).slice(0,4);
}
function teamScore(){
  const ps=draft.slots.map(s=>s.p).filter(Boolean);
  if(!ps.length)return{avg:0,chem:0,bonus:0,ovr:0};
  const avg=ps.reduce((a,p)=>a+p[2],0)/ps.length;
  let chem=0;ps.forEach(p=>{const n=ps.filter(q=>q!==p&&q[3]===p[3]).length;chem+=n>=2?2:n});
  const bonus=Math.round(chem/22*30)/10;
  return{avg,chem,bonus,ovr:Math.round((avg+bonus)*10)/10};
}
function tier(o){return o>=89?"Legendary. Lefter would approve.":o>=86?"Champions of Turkey, champions of Europe.":o>=83?"Title winners.":o>=80?"Champions League nights in Kadıköy.":"A rebuild is needed."}
function pitchHTML(rows,slotFn){return `<div class="pitch">${rows.map((r,ri)=>`<div class="prow">${r.map((x,ci)=>slotFn(x,ri,ci)).join("")}</div>`).join("")}</div>`}

function renderDraft(p){
  if(!draft)newDraft("4-3-3");
  const sc=teamScore(), done=draft.step>=draft.order.length, cur=done?null:draft.slots[draft.order[draft.step]];
  const best=store.get("fb-draft-best",null);
  const pitch=pitchHTML(FORMS[draft.form],(pos,ri,ci)=>{
    const s=draft.slots.find(s=>s.ri===ri&&s.ci===ci);
    if(s.p)return `<div class="slot filled"><div class="disc">${s.p[2]}</div><div class="nm">${esc(lastName(s.p[0]))}</div></div>`;
    return `<div class="slot ${s===cur?"active":""}"><div class="disc">${pos}</div><div class="nm dim">${s===cur?"Picking…":""}</div></div>`;
  });
  const side = done
    ? `<div class="box"><span class="label">Your all-time XI</span><div class="ovr" style="margin-top:8px"><span class="big">${sc.ovr.toFixed(1)}</span><dl><dt>Avg rating</dt><dd>${sc.avg.toFixed(1)}</dd><dt>Chemistry</dt><dd>${sc.chem}/22 (+${sc.bonus.toFixed(1)})</dd><dt>Best ever</dt><dd>${best?best.toFixed(1):"–"}</dd></dl></div><p style="margin-top:12px;font-size:18px;font-weight:600">${tier(sc.ovr)}</p>${best!==null&&sc.ovr>=best?'<p class="msg good">New personal best!</p>':""}<div class="btns"><button class="btn" data-d="again">Draft again</button></div></div>`
    : `<div class="box"><span class="label">Pick ${draft.step+1} of 11</span><h3 style="margin-top:4px">Choose your ${posName(cur.pos)}</h3><div class="cands">${draft.cands.map((c,i)=>`<button class="cand" data-pick="${i}"><span class="r">${c[2]}</span><span class="n">${esc(c[0])}</span><span class="e">${c[1]==="W"?"Winger":c[1]} · ${ERA[c[3]]}</span></button>`).join("")}</div><div class="btns"><button class="btn ghost" data-d="reroll" ${draft.rerolls?"":"disabled"}>New options (${draft.rerolls} left)</button></div></div>
       <div class="box"><span class="label">Team so far</span><div class="ovr" style="margin-top:8px"><span class="big">${sc.ovr?sc.ovr.toFixed(1):"–"}</span><dl><dt>Avg rating</dt><dd>${sc.avg?sc.avg.toFixed(1):"–"}</dd><dt>Chemistry</dt><dd>${sc.chem}/22</dd></dl></div></div>`;
  p.innerHTML=`<h2>All-Time XI Draft</h2><p class="intro">Pick a formation, then choose one of four Fenerbahçe players for each position. Players from the same era earn chemistry, worth up to +3 on your overall.</p>
  <div class="filter" role="group" aria-label="Formation">${Object.keys(FORMS).map(f=>`<button data-form="${f}" aria-pressed="${f===draft.form}">${f}</button>`).join("")}</div>
  <div class="draft">${pitch}<div class="side">${side}</div></div>
  <p class="gnote">Ratings are fan ratings for this game, not official numbers. Changing formation restarts the draft.</p>`;
  p.querySelectorAll("[data-form]").forEach(b=>b.onclick=()=>{newDraft(b.dataset.form);renderPanel()});
  p.querySelectorAll("[data-pick]").forEach(b=>b.onclick=()=>{
    draft.slots[draft.order[draft.step]].p=draft.cands[+b.dataset.pick];draft.step++;deal();
    if(draft.step>=draft.order.length){const o=teamScore().ovr,bs=store.get("fb-draft-best",null);if(bs===null||o>bs)store.set("fb-draft-best",o)}
    renderPanel();
  });
  const rr=p.querySelector('[data-d="reroll"]');if(rr)rr.onclick=()=>{if(!draft.rerolls)return;draft.rerolls--;deal();renderPanel()};
  const ag=p.querySelector('[data-d="again"]');if(ag)ag.onclick=()=>{newDraft(draft.form);renderPanel()};
}
function posName(p){return {GK:"goalkeeper",RB:"right-back",LB:"left-back",CB:"centre-back",CM:"central midfielder",AM:"No. 10",LW:"left winger",RW:"right winger",LM:"left midfielder",RM:"right midfielder",ST:"striker"}[p]}

/* ===== 2. FENERDLE ===== */
const WORDS=[
 ["ALEX","Alex de Souza","Brazilian No. 10 and captain, 2004–2012"],["RUSTU","Rüştü Reçber","Goalkeeper, 1990s–2000s"],["VOLKAN","Volkan Demirel","Goalkeeper, 2002–2020"],["LEFTER","Lefter Küçükandonyadis","Forward, 1940s–1960s"],
 ["TUNCAY","Tuncay Şanlı","Forward who scored in the 6–0"],["LUGANO","Diego Lugano","Uruguayan centre-back, 2006–2011"],["OKOCHA","Jay-Jay Okocha","Nigerian playmaker, 1996–1998"],["REVIVO","Haim Revivo","Israeli playmaker, late 1990s"],
 ["KEZMAN","Mateja Kežman","Serbian striker, 2006–2008"],["ANELKA","Nicolas Anelka","French striker, 2005–2006"],["APPIAH","Stephen Appiah","Ghanaian midfielder, 2005–2008"],["DZEKO","Edin Džeko","Bosnian striker, 2023–2025"],
 ["TADIC","Dušan Tadić","Serbian winger, 2023–2025"],["SEMIH","Semih Şentürk","Striker who scored in the 2012 cup final"],["AYKUT","Aykut Kocaman","Striker, later the coach who won the 2012 cup"],["TANJU","Tanju Çolak","Prolific striker of the early 1990s"],
 ["BOLIC","Elvir Bolić","Bosnian striker, late 1990s"],["KUYT","Dirk Kuyt","Dutch forward, 2012–2015"],["EMRE","Emre Belözoğlu","Turkish midfielder and captain"],["FRED","Fred","Brazilian midfielder, 2023–"],
 ["YOBO","Joseph Yobo","Nigerian centre-back, 2010s"],["STOCH","Miroslav Stoch","Slovak winger, 2011–2014"],["DIEGO","Diego Ribas","Brazilian playmaker, 2014–2016"],["SKRINIAR","Milan Škriniar","Slovak centre-back, 2024–"],
 ["EMENIKE","Emmanuel Emenike","Nigerian striker, 2010s"],["AURELIO","Mehmet Aurélio","Defensive midfielder, 2006–2009"],["DRACENA","Edu Dracena","Brazilian centre-back, 2006–2009"],["ORTEGA","Ariel Ortega","Argentine playmaker who scored in the 6–0"],
 ["SERHAT","Serhat Akın","Scored twice in the 6–0"],["KAHVECI","İrfan Can Kahveci","Turkish winger, 2021–"],["KEREM","Kerem Aktürkoğlu","Turkish winger, 2025–"],["GUENDOUZI","Mattéo Guendouzi","Scored first in the 2026 Super Cup final"],
 ["ARDA","Arda Güler","Academy product, sold to Real Madrid"],["CANER","Caner Erkin","Scored after two minutes in the 2012 cup final"],["MEIRELES","Raul Meireles","Portuguese midfielder, 2012–2014"],["ASENSIO","Marco Asensio","Spanish attacker, 2025–"]
];
let wd=null;
function newWordle(daily){
  const idx=daily?Math.floor(Date.now()/864e5)%WORDS.length:Math.floor(Math.random()*WORDS.length);
  const [ans,name,hint]=WORDS[idx];wd={ans,name,hint,rows:[],cur:"",done:false,won:false,daily,msg:""};
}
function scoreGuess(g,a){const r=Array(a.length).fill("absent"),c={};for(let i=0;i<a.length;i++){if(g[i]===a[i])r[i]="correct";else c[a[i]]=(c[a[i]]||0)+1}for(let i=0;i<a.length;i++){if(r[i]!=="correct"&&c[g[i]]>0){r[i]="present";c[g[i]]--}}return r}
function wordleKey(k){
  if(!wd||wd.done)return;const L=wd.ans.length;wd.msg="";
  if(k==="ENTER"){
    if(wd.cur.length<L){wd.msg=`The name has ${L} letters.`}
    else{wd.rows.push(wd.cur);const g=wd.cur;wd.cur="";
      if(g===wd.ans){wd.done=wd.won=true}else if(wd.rows.length>=6){wd.done=true}}
  }else if(k==="BACK"){wd.cur=wd.cur.slice(0,-1)}
  else if(/^[A-Z]$/.test(k)&&wd.cur.length<L){wd.cur+=k}
  renderPanel();
}
function renderWordle(p){
  if(!wd)newWordle(true);
  const L=wd.ans.length,ks={},rank={absent:1,present:2,correct:3};
  wd.rows.forEach(g=>scoreGuess(g,wd.ans).forEach((s,i)=>{if(!ks[g[i]]||rank[s]>rank[ks[g[i]]])ks[g[i]]=s}));
  let grid="";for(let r=0;r<6;r++){let t="";
    if(r<wd.rows.length){const sc=scoreGuess(wd.rows[r],wd.ans);for(let i=0;i<L;i++)t+=`<div class="tile ${sc[i]}">${wd.rows[r][i]}</div>`}
    else if(r===wd.rows.length&&!wd.done){for(let i=0;i<L;i++)t+=`<div class="tile ${wd.cur[i]?"filled":""}">${wd.cur[i]||""}</div>`}
    else for(let i=0;i<L;i++)t+=`<div class="tile"></div>`;
    grid+=`<div class="wrow" style="--n:${L}">${t}</div>`}
  const rows=["QWERTYUIOP","ASDFGHJKL","^ZXCVBNM<"];
  const kb=rows.map(r=>`<div class="kbr">${[...r].map(c=>c==="^"?`<button class="key wide" data-k="ENTER">Enter</button>`:c==="<"?`<button class="key wide" data-k="BACK" aria-label="Delete">⌫</button>`:`<button class="key ${ks[c]||""}" data-k="${c}">${c}</button>`).join("")}</div>`).join("");
  let status="";
  if(wd.done)status=`<p class="msg ${wd.won?"good":"bad"}">${wd.won?`Got it in ${wd.rows.length}!`:"Out of guesses."} The answer was <b>${esc(wd.name)}</b>, ${esc(wd.hint.charAt(0).toLowerCase()+wd.hint.slice(1))}.</p><div class="btns" style="justify-content:center"><button class="btn" data-w="new">Play another player</button></div>`;
  else if(wd.rows.length>=3)status=`<p class="msg">Hint: ${esc(wd.hint)}</p>`;
  else status=`<p class="msg">${wd.msg?esc(wd.msg):`${L} letters · 6 guesses · ${wd.daily?"today's player":"practice round"}`}</p>`;
  if(!wd.done&&wd.msg&&wd.rows.length>=3)status+=`<p class="msg bad" style="margin-top:0">${esc(wd.msg)}</p>`;
  p.innerHTML=`<h2>Fenerdle</h2><p class="intro">Guess the Fenerbahçe player. Most answers are surnames, but a few go by first name or nickname. Turkish letters are written without accents (Ş becomes S, Ü becomes U). A hint appears after three guesses.</p>
  <div class="wcenter">${status}</div><div class="wgrid">${grid}</div>
  <div class="legendrow"><span><i style="background:var(--yellow)"></i>Right spot</span><span><i style="background:var(--present)"></i>In the name, wrong spot</span><span><i style="background:var(--absent)"></i>Not in the name</span></div>
  <div class="kb">${kb}</div>`;
  p.querySelectorAll("[data-k]").forEach(b=>b.onclick=()=>wordleKey(b.dataset.k));
  const n=p.querySelector('[data-w="new"]');if(n)n.onclick=()=>{newWordle(false);renderPanel()};
}
document.addEventListener("keydown",e=>{
  if(current!=="games"||tab!=="wordle"||e.metaKey||e.ctrlKey||e.altKey)return;
  if(e.target.closest&&e.target.closest("input,select,textarea"))return;
  if(e.key==="Enter"){e.preventDefault();wordleKey("ENTER")}
  else if(e.key==="Backspace"){e.preventDefault();wordleKey("BACK")}
  else if(e.key.length===1){const c=norm(e.key).toUpperCase();if(/^[A-Z]$/.test(c))wordleKey(c)}
});

/* ===== 3. NAME THE XI ===== */
const LINEUPS=[
 {id:"2026",year:"2026",form:"4-2-3-1",what:"Super Cup final",opp:"Galatasaray",score:"2–0 win",date:"10 January 2026",coach:"Domenico Tedesco",venue:"Atatürk Olympic Stadium",
  rows:[[["ST","Jhon Durán",["duran"]]],[["ATT","Kerem Aktürkoğlu",["kerem","akturkoglu"]],["ATT","Marco Asensio",["asensio"]],["ATT","Anthony Musaba",["musaba"]]],[["CM","Mattéo Guendouzi",["guendouzi"]],["CM","İsmail Yüksek",["ismail","yuksek"]]],[["LB","Levent Mercan",["levent","mercan"]],["CB","Jayden Oosterwolde",["oosterwolde"]],["CB","Milan Škriniar",["skriniar"]],["RB","Mert Müldür",["mert","muldur"]]],[["GK","Ederson",["ederson"]]]]},
 {id:"2023",year:"2023",form:"4-4-2",what:"Turkish Cup final",opp:"İstanbul Başakşehir",score:"2–0 win",date:"11 June 2023",coach:"Jorge Jesus",venue:"Gürsel Aksel Stadium, İzmir",
  rows:[[["ST","Michy Batshuayi",["batshuayi","michy"]],["ST","Enner Valencia",["valencia","enner"]]],[["LM","İrfan Can Kahveci",["kahveci"]],["CM","Miha Zajc",["zajc"]],["CM","Willian Arão",["arao","willian"]],["RM","Arda Güler",["arda","guler"]]],[["LB","Luan Peres",["luan","peres"]],["CB","Attila Szalai",["szalai","attila"]],["CB","Serdar Aziz",["serdar","aziz"]],["RB","Ferdi Kadıoğlu",["ferdi","kadioglu"]]],[["GK","İrfan Can Eğribayat",["egribayat"]]]]},
 {id:"2012",year:"2012",form:"4-5-1",what:"Turkish Cup final",opp:"Bursaspor",score:"4–0 win",date:"16 May 2012",coach:"Aykut Kocaman",venue:"19 Mayıs Stadium, Ankara",
  rows:[[["ST","Semih Şentürk",["semih","senturk"]]],[["MF","Caner Erkin",["caner","erkin"]],["MF","Alex de Souza",["alex","de souza"]],["MF","Emre Belözoğlu",["emre","belozoglu"]],["MF","Cristian Baroni",["cristian","baroni"]],["MF","Mehmet Topuz",["topuz"]]],[["LB","Reto Ziegler",["ziegler","reto"]],["CB","Joseph Yobo",["yobo"]],["CB","Bekir İrtegün",["bekir","irtegun"]],["RB","Gökhan Gönül",["gokhan","gonul"]]],[["GK","Volkan Demirel",["volkan","demirel"]]]]},
 {id:"2008",year:"2008",form:"4-5-1",what:"Champions League quarter-final, 1st leg",opp:"Chelsea",score:"2–1 win",date:"2 April 2008",coach:"Zico",venue:"Şükrü Saracoğlu",
  rows:[[["ST","Mateja Kežman",["kezman","mateja"]]],[["MF","Uğur Boral",["ugur","boral"]],["MF","Alex de Souza",["alex","de souza"]],["MF","Deivid",["deivid"]],["MF","Mehmet Aurélio",["aurelio"]],["MF","Claudio Maldonado",["maldonado","claudio"]]],[["LB","Wederson",["wederson"]],["CB","Edu Dracena",["edu","dracena"]],["CB","Diego Lugano",["lugano","diego"]],["RB","Önder Turacı",["onder","turaci"]]],[["GK","Volkan Demirel",["volkan","demirel"]]]]},
 {id:"2002",year:"2002",form:"Not recorded",what:"Süper Lig derby",opp:"Galatasaray",score:"6–0 win",date:"6 November 2002",coach:"Werner Lorant",venue:"Şükrü Saracoğlu",
  rows:[[["XI","Serhat Akın",["serhat","akin"]],["XI","Washington",["washington"]]],[["XI","Tuncay Şanlı",["tuncay","sanli"]],["XI","Ariel Ortega",["ortega","ariel"]],["XI","Yusuf Şimşek",["yusuf","simsek"]],["XI","Miroslav Stević",["stevic"]]],[["XI","Ümit Özat",["umit","ozat"]],["XI","Ogün Temizkanoğlu",["ogun","temizkanoglu"]],["XI","Johnson",["johnson"]],["XI","Fatih Akyel",["fatih","akyel"]]],[["GK","Rüştü Reçber",["rustu","recber"]]]]}
];
let xi=null;
function newXI(id){xi={id,found:new Set(),hints:new Set(),gave:false,msg:"",cls:""}}
function xiPlayers(L){const out=[];L.rows.forEach((r,ri)=>r.forEach((p,ci)=>out.push({key:ri+"-"+ci,pos:p[0],name:p[1],al:p[2].map(norm).concat(norm(p[1]))})));return out}
function renderXI(p,focus){
  if(!xi)newXI("2026");
  const L=LINEUPS.find(l=>l.id===xi.id),ps=xiPlayers(L),n=xi.found.size,complete=n===11;
  const pitch=pitchHTML(L.rows,(pl,ri,ci)=>{const k=ri+"-"+ci,f=xi.found.has(k),show=f||xi.gave;
    const hint=xi.hints.has(k)?pl[1].split(" ").map(w=>w[0]+"·".repeat(Math.min(w.length-1,6))).join(" "):"";
    return `<div class="slot ${f?"filled":xi.gave?"missed":""}"><div class="disc">${f?"✓":pl[0]}</div><div class="nm ${show?"":"dim"}">${show?esc(pl[1]):esc(hint)}</div></div>`});
  p.innerHTML=`<h2>Name the XI</h2><p class="intro">You get the formation, the year and the match. Name all eleven starters. Surnames work, and so do the names fans use, like Alex or Volkan.</p>
  <div class="filter" role="group" aria-label="Match">${LINEUPS.map(l=>`<button data-xi="${l.id}" aria-pressed="${l.id===xi.id}">${l.year}</button>`).join("")}</div>
  <div class="draft">${pitch}<div class="side"><div class="box">
    <span class="label">${esc(L.what)} · ${esc(L.date)}</span><h3 style="margin-top:4px">vs ${esc(L.opp)}, ${esc(L.score)}</h3>
    <div class="facts"><div><span class="label">Formation</span><b>${esc(L.form)}</b></div><div><span class="label">Year</span><b>${L.year}</b></div><div><span class="label">Coach</span><b style="font-size:20px">${esc(L.coach)}</b></div></div>
    <form class="guessbar" id="xiForm" autocomplete="off"><input id="xiGuess" placeholder="Type a player…" aria-label="Player name" ${complete||xi.gave?"disabled":""}><button class="btn" ${complete||xi.gave?"disabled":""}>Guess</button></form>
    <p class="msg ${xi.cls}">${esc(xi.msg)}</p>
    <div style="display:flex;align-items:baseline;gap:8px;margin-top:6px"><span class="count">${n}</span><span class="label">of 11 found</span></div>
    <div class="btns"><button class="btn ghost" data-x="hint" ${complete||xi.gave?"disabled":""}>Hint</button><button class="btn ghost" data-x="give" ${complete||xi.gave?"disabled":""}>Show answers</button><button class="btn ghost" data-x="reset">Start over</button></div>
    ${L.form==="Not recorded"?'<p class="gnote">The formation for this match is not on record, so the players are not placed by position.</p>':""}
  </div></div></div>`;
  p.querySelectorAll("[data-xi]").forEach(b=>b.onclick=()=>{newXI(b.dataset.xi);renderPanel()});
  p.querySelector("#xiForm").onsubmit=e=>{e.preventDefault();const v=norm(p.querySelector("#xiGuess").value);if(!v)return;
    const hit=ps.find(x=>x.al.includes(v));
    if(!hit){xi.msg=`${p.querySelector("#xiGuess").value} didn't start this match.`;xi.cls="bad"}
    else if(xi.found.has(hit.key)){xi.msg=`You already have ${hit.name}.`;xi.cls=""}
    else{xi.found.add(hit.key);xi.msg=xi.found.size===11?"All eleven! Full marks.":`Yes: ${hit.name}.`;xi.cls="good"}
    renderPanel();const i=document.getElementById("xiGuess");if(i&&!i.disabled)i.focus()};
  p.querySelector('[data-x="hint"]').onclick=()=>{const left=ps.filter(x=>!xi.found.has(x.key)&&!xi.hints.has(x.key));if(left.length){xi.hints.add(left[Math.floor(Math.random()*left.length)].key);xi.msg="Hint added: first letters of one player.";xi.cls=""}renderPanel()};
  p.querySelector('[data-x="give"]').onclick=()=>{xi.gave=true;xi.msg=`You found ${xi.found.size} of 11.`;xi.cls="";renderPanel()};
  p.querySelector('[data-x="reset"]').onclick=()=>{newXI(xi.id);renderPanel()};
}

/* ===== 4. PENALTY SHOOTOUT ===== */
const ZX=[10+80/6,50,90-80/6],ZY=[8+50*.3,8+50*.74];
const zc=z=>[ZX[z%3],ZY[Math.floor(z/3)]];
let pk=null;
function newPK(){pk={you:[],them:[],phase:"shoot",busy:false,over:null,msg:"Your kick. Pick where to shoot.",banner:"",anim:null}}
function pkOutcome(){const y=pk.you.filter(Boolean).length,t=pk.them.filter(Boolean).length,ny=pk.you.length,nt=pk.them.length;
  if(ny<=5&&nt<=5){if(y+(5-ny)<t)return"lose";if(t+(5-nt)<y)return"win"}
  if(ny>=5&&ny===nt&&y!==t)return y>t?"win":"lose";return null}
function pkPlay(z){
  if(pk.busy||pk.over)return;pk.busy=true;
  const shooting=pk.phase==="shoot";
  const shot=shooting?z:Math.floor(Math.random()*6), dive=shooting?Math.floor(Math.random()*6):z;
  const missChance=shooting?([0,2].includes(shot)?.12:.03):.06;
  const miss=Math.random()<missChance;
  const saved=!miss&&(dive===shot||(dive%3===shot%3&&Math.random()<.25));
  const scored=!miss&&!saved;
  const [bx,by]=zc(shot),[kx,ky]=zc(dive);
  pk.anim={ball:miss?[bx+(shot%3===1?0:shot%3===0?-8:8),2]:[bx,by],keeper:[kx,ky]};
  pk.banner="";renderPanel();
  setTimeout(()=>{
    pk.banner=miss?(shooting?"Over the bar!":"They miss!"):saved?(shooting?"Saved!":"You saved it!"):(shooting?"Goal!":"They score.");
    (shooting?pk.you:pk.them).push(scored);
    const o=pkOutcome();
    if(o){pk.over=o;pk.msg=o==="win"?"Fenerbahçe win the shootout! Sevilla 2008 vibes.":"The rivals win this one. Try again."}
    else{pk.phase=shooting?"save":"shoot";pk.msg=pk.phase==="shoot"?"Your kick. Pick where to shoot.":"Now you're in goal. Pick where to dive."}
    renderPanel();
    setTimeout(()=>{pk.anim=null;pk.busy=false;if(!pk.over)pk.banner="";renderPanel()},900);
  },650);
}
function renderPK(p){
  if(!pk)newPK();
  const dots=a=>{let h="";const n=Math.max(5,a.length);for(let i=0;i<n;i++)h+=`<i class="dot ${a[i]===true?"g":a[i]===false?"m":""}"></i>`;return h};
  const youKeep=pk.phase==="save";
  p.innerHTML=`<h2>Penalty Shootout</h2><p class="intro">Five kicks each, then sudden death. Take your penalty by tapping a part of the goal, then go in goal and guess where they'll shoot. Top corners are hard to save, but you might put it over the bar.</p>
  <div class="pk-wrap"><div class="pk-field" id="pkf">
    <div class="pk-line"></div><div class="pk-box"></div><div class="pk-spot"></div>
    <div class="pk-goal">${[0,1,2,3,4,5].map(z=>`<button class="pk-zone" data-z="${z}" aria-label="${["Top left","Top middle","Top right","Bottom left","Bottom middle","Bottom right"][z]}" ${pk.busy||pk.over?"disabled":""}></button>`).join("")}</div>
    <div class="pk-keeper ${youKeep?"":"them"}" id="pkk" style="left:50%;top:${8+50*.62}%"></div>
    <div class="pk-ball" id="pkb" style="left:50%;top:88%"></div>
    <div class="pk-banner">${esc(pk.banner)}</div>
  </div>
  <div class="side"><div class="box">
    <span class="label">${pk.over?"Full time":pk.phase==="shoot"?"You're shooting":"You're in goal"}</span>
    <p class="msg ${pk.over==="win"?"good":pk.over==="lose"?"bad":""}" style="font-size:18px">${esc(pk.msg)}</p>
    <div class="pk-score" style="margin-top:14px">
      <div class="pk-team"><span style="color:var(--yellow)">Fener</span><div class="dots">${dots(pk.you)}</div><b>${pk.you.filter(Boolean).length}</b></div>
      <div class="pk-team"><span>Rivals</span><div class="dots">${dots(pk.them)}</div><b>${pk.them.filter(Boolean).length}</b></div>
    </div>
    <div class="btns"><button class="btn ${pk.over?"":"ghost"}" data-pk="new">${pk.over?"Play again":"Restart"}</button></div>
  </div></div></div>`;
  p.querySelectorAll("[data-z]").forEach(b=>b.onclick=()=>pkPlay(+b.dataset.z));
  p.querySelector('[data-pk="new"]').onclick=()=>{newPK();renderPanel()};
  if(pk.anim){const a=pk.anim,b=p.querySelector("#pkb"),k=p.querySelector("#pkk");
    requestAnimationFrame(()=>requestAnimationFrame(()=>{b.style.left=a.ball[0]+"%";b.style.top=a.ball[1]+"%";b.style.width="3.2%";k.style.left=a.keeper[0]+"%";k.style.top=a.keeper[1]+"%"}));}
}

/* ===== 5. WHO AM I? ===== */
const WHO=[
 ["Alex de Souza",["I arrived in Kadıköy from Cruzeiro in 2004.","I wore the number 10 shirt.","I captained the team to the 2011 league title.","I'm Brazilian, and fans know me by my first name."],["Diego Ribas","Ariel Ortega","Haim Revivo"]],
 ["Roberto Carlos",["I joined in 2007 after more than ten years at Real Madrid.","I won the World Cup in 2002.","My free kicks were famous all over the world.","I'm a Brazilian left-back."],["Ümit Özat","Wederson","Ferdi Kadıoğlu"]],
 ["Volkan Demirel",["I was at the club for almost two decades.","I was a hero of the 2008 shootout in Seville.","I started the 2012 Turkish Cup final.","I'm a Turkish goalkeeper."],["Rüştü Reçber","Dominik Livaković","Harald Schumacher"]],
 ["Lefter Küçükandonyadis",["My Fenerbahçe career ran from the 1940s into the 1960s.","I also played in Italy and France.","Fans called me 'Ordinaryüs', the Professor.","I'm one of the greatest scorers in club history."],["Can Bartu","Cemil Turan","Aykut Kocaman"]],
 ["Edin Džeko",["I won the Premier League in England.","I joined from Inter in 2023.","I captained my national team.","I'm a Bosnian striker."],["Robin van Persie","Mateja Kežman","Youssef En-Nesyri"]],
 ["Arda Güler",["I came through the Fenerbahçe academy.","I started the 2023 Turkish Cup final as a teenager.","Real Madrid signed me in 2023.","I'm a left-footed Turkish playmaker."],["Ferdi Kadıoğlu","İrfan Can Kahveci","Kerem Aktürkoğlu"]],
 ["Dirk Kuyt",["I joined from Liverpool in 2012.","I played in the 2010 World Cup final.","I was known for running all game long.","I'm a Dutch forward."],["Pierre van Hooijdonk","Robin van Persie","Jayden Oosterwolde"]],
 ["Mattéo Guendouzi",["I've played for Arsenal and Marseille.","I joined Fenerbahçe in 2025.","I was man of the match in a Super Cup final.","I scored the first goal against Galatasaray in January 2026."],["Fred","Sebastian Szymański","İsmail Yüksek"]],
 ["Jay-Jay Okocha",["I arrived from Eintracht Frankfurt in 1996.","I'm famous for tricks and step-overs.","I later starred for PSG and Bolton.","I'm a Nigerian midfielder."],["Emmanuel Emenike","Stephen Appiah","Joseph Yobo"]],
 ["Emre Belözoğlu",["I started my career at Galatasaray.","I played for Inter, Newcastle and Atlético Madrid.","I captained Fenerbahçe and started the 2012 cup final.","I'm a Turkish midfielder."],["Selçuk Şahin","Mehmet Topuz","Oğuz Çetin"]]
];
let who=null;
function newWho(){who={q:shuffle(WHO).slice(0,6).map(w=>({w,opts:shuffle([w[0],...w[2]])})),i:0,shown:1,score:0,picked:null}}
function renderWho(p){
  if(!who)newWho();
  const head=`<h2>Who Am I?</h2><p class="intro">Read the clues and guess the player. Each round starts at 4 points and loses a point for every extra clue you open.</p>`;
  if(who.i>=who.q.length){p.innerHTML=head+`<div class="quiz"><span class="label">Final score</span><div class="final">${who.score}/24</div><p style="font-size:18px;margin-top:6px">${who.score>=20?"You know your legends.":who.score>=12?"Good effort, Fenerbahçeli.":"Back to the Legends tab!"}</p><button class="qnext" data-wh="again">Play again</button></div>`;
    p.querySelector('[data-wh="again"]').onclick=()=>{newWho();renderPanel()};return}
  const r=who.q[who.i],[ans,clues]=r.w,pts=5-who.shown;
  p.innerHTML=head+`<div class="quiz"><div class="top"><span class="label">Player ${who.i+1} of ${who.q.length}</span><span class="label">Score ${who.score}</span></div>
    <div class="progress"><i style="width:${who.i/who.q.length*100}%"></i></div>
    <ol class="clues">${clues.map((c,i)=>i<who.shown||who.picked!==null?`<li><span>${i+1}</span><div>${esc(c)}</div></li>`:`<li class="locked"><span>${i+1}</span><div>Hidden clue</div></li>`).join("")}</ol>
    ${who.picked===null&&who.shown<4?`<div class="btns"><button class="btn ghost" data-wh="more">Show next clue (worth ${pts-1} after)</button></div>`:""}
    <div class="opts">${r.opts.map(o=>{let c="opt";if(who.picked!==null){if(o===ans)c+=" right";else if(o===who.picked)c+=" wrong"}return `<button class="${c}" data-who="${esc(o)}" ${who.picked!==null?"disabled":""}>${esc(o)}</button>`}).join("")}</div>
    ${who.picked!==null?`<p class="explain"><b>${who.picked===ans?`Correct, +${pts}.`:"Not quite."}</b> It was ${esc(ans)}.</p><button class="qnext" data-wh="next">${who.i+1<who.q.length?"Next player":"See score"}</button>`:`<p class="gnote">Worth ${pts} point${pts>1?"s":""} right now.</p>`}</div>`;
  const m=p.querySelector('[data-wh="more"]');if(m)m.onclick=()=>{who.shown++;renderPanel()};
  p.querySelectorAll("[data-who]").forEach(b=>b.onclick=()=>{who.picked=b.dataset.who;if(who.picked===ans)who.score+=pts;renderPanel()});
  const nx=p.querySelector('[data-wh="next"]');if(nx)nx.onclick=()=>{who.i++;who.shown=1;who.picked=null;renderPanel()};
}

/* ===== 6. TIMELINE ===== */
let tl=null;
function newTL(){
  const ev=[];Object.values(SPORTS).forEach(s=>(s.history||[]).forEach(([y,t])=>{if(/^\d{4}$/.test(y))ev.push({y:+y,t,s:s.label})}));
  const pick=[],years=new Set();for(const e of shuffle(ev)){if(!years.has(e.y)){years.add(e.y);pick.push(e)}if(pick.length===5)break}
  let order=shuffle(pick);while(order.every((e,i,a)=>!i||a[i-1].y<e.y))order=shuffle(pick);
  tl={items:order,checked:false,streak:tl?tl.streak:0};
}
function renderTL(p){
  if(!tl)newTL();
  const sorted=[...tl.items].sort((a,b)=>a.y-b.y),allOk=tl.items.every((e,i)=>e===sorted[i]);
  p.innerHTML=`<h2>Timeline</h2><p class="intro">Five moments from across the club, out of order. Put them in order from oldest at the top to newest at the bottom.</p>
  <ol class="tlg">${tl.items.map((e,i)=>`<li class="${tl.checked?(e===sorted[i]?"ok":"no"):""}"><span class="y ${tl.checked?"":"hide"}">${tl.checked?e.y:"????"}</span><span class="t"><small>${esc(e.s)}</small>${esc(e.t)}</span><span class="mv"><button data-mv="${i},-1" aria-label="Move up" ${i===0||tl.checked?"disabled":""}>▲</button><button data-mv="${i},1" aria-label="Move down" ${i===tl.items.length-1||tl.checked?"disabled":""}>▼</button></span></li>`).join("")}</ol>
  ${tl.checked?`<p class="msg ${allOk?"good":"bad"}">${allOk?`Perfect order! Streak: ${tl.streak}`:`${tl.items.filter((e,i)=>e===sorted[i]).length} of 5 in the right place.`}</p>`:""}
  <div class="btns">${tl.checked?`<button class="btn" data-tl="new">New timeline</button>`:`<button class="btn" data-tl="check">Check order</button>`}</div>`;
  p.querySelectorAll("[data-mv]").forEach(b=>b.onclick=()=>{const [i,d]=b.dataset.mv.split(",").map(Number),a=tl.items;[a[i],a[i+d]]=[a[i+d],a[i]];renderPanel();const nb=p.querySelector(`[data-mv="${i+d},${d}"]`);if(nb&&!nb.disabled)nb.focus()});
  const c=p.querySelector('[data-tl="check"]');if(c)c.onclick=()=>{tl.checked=true;const s=[...tl.items].sort((a,b)=>a.y-b.y);tl.streak=tl.items.every((e,i)=>e===s[i])?tl.streak+1:0;renderPanel()};
  const n=p.querySelector('[data-tl="new"]');if(n)n.onclick=()=>{newTL();renderPanel()};
}

const ARCADE={draft:renderDraft,wordle:renderWordle,xi:renderXI,penalties:renderPK,who:renderWho,timeline:renderTL};
