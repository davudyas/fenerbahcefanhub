const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();for(const w of [1280,1366,1440]){const pg=await b.newPage({viewport:{width:w,height:800}});
await pg.goto('file://'+process.argv[2]+'#all');await pg.waitForTimeout(500);
for(const L of ['en','tr','de','es','fr','ar']){if(L!=='en'){await pg.selectOption('#lang',L);await pg.waitForTimeout(300)}
 console.log(w,L,await pg.evaluate(()=>{const x=document.querySelector('#brRow .wrap');return x.scrollWidth-x.clientWidth}))}
await pg.selectOption('#lang','en');await pg.waitForTimeout(300);if(w===1366)await pg.screenshot({path:'row_d.png',clip:{x:0,y:90,width:1366,height:120}});await pg.close()}
await b.close()})();
