const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const errs=[];
for(const [w,h,dv] of [[390,844,'m'],[1366,800,'d']]){const pg=await b.newPage({viewport:{width:w,height:h}});pg.on('pageerror',e=>errs.push(e.message));
 await pg.goto('file://'+process.argv[2]+'#all');await pg.waitForTimeout(500);
 await pg.selectOption('#lang','ar');await pg.waitForTimeout(400);await pg.screenshot({path:`../ar_${dv}_home.png`});
 await pg.evaluate(()=>{setSport('football')});await pg.waitForTimeout(300);await pg.evaluate(()=>scrollTo(0,innerHeight*0.8));await pg.screenshot({path:`../ar_${dv}_fb.png`});
 console.log(dv,'ar sw',await pg.evaluate(()=>document.documentElement.scrollWidth));
 await pg.selectOption('#lang','en');await pg.waitForTimeout(300);
 for(const th of ['night','clean','canary']){await pg.evaluate(th=>{const s=document.getElementById('theme');s.value=th;s.dispatchEvent(new Event('change',{bubbles:true}))},th);await pg.waitForTimeout(200);
  await pg.evaluate(()=>{setSport('home');scrollTo(0,0)});await pg.waitForTimeout(250);await pg.screenshot({path:`../th_${th}_${dv}_home.png`});
  await pg.evaluate(()=>{setSport('basketball');scrollTo(0,innerHeight*0.7)});await pg.waitForTimeout(250);await pg.screenshot({path:`../th_${th}_${dv}_bb.png`})}
 console.log(dv,await pg.evaluate(()=>document.documentElement.dataset.theme));await pg.close()}
console.log('errs',errs);await b.close()})();
