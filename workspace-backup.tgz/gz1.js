const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const pg=await b.newPage();await pg.goto('file://'+process.argv[2]);await pg.waitForTimeout(400);
console.log(await pg.evaluate(()=>{const out=[];const cur=new Set();SQUADS.football.groups.forEach(g=>g[1].forEach(x=>cur.add(x[1])));
 const ids=SEASONS.map(s=>s[0]).concat(["2026-27"]);
 ids.forEach(id=>{const y=+id.slice(0,4);const S=SEASONS.find(s=>s[0]===id);const xi=new Set(S?S[3].flat():[]);
  const pool=PLAYERS.filter(p=>xi.has(p.n)||(p.from<=y&&p.to>=y+1)||(y===2026&&cur.has(p.n)));
  const byPos={};pool.forEach(p=>byPos[p.pos]=(byPos[p.pos]||0)+1);
  out.push(id+" "+pool.length+" "+JSON.stringify(byPos)+" xiMissing:"+[...xi].filter(n=>!PBY[n]).length)});
 return out.join("\n")+"\nPLAYERS "+PLAYERS.length+" keys "+Object.keys(PLAYERS[0]).join(",")}));await b.close()})();
