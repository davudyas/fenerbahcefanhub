const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const pg=await b.newPage();await pg.goto('file://'+process.argv[2]+'#all');await pg.waitForTimeout(500);
console.log(await pg.evaluate(()=>[...document.querySelectorAll('main h1,main h2,main h3')].slice(0,8).map(h=>h.tagName+':'+h.className+':'+h.textContent.slice(0,30)+':'+h.getBoundingClientRect().width)));await b.close()})();
