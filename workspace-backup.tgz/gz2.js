const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const pg=await b.newPage();await pg.goto('file://'+process.argv[2]);await pg.waitForTimeout(400);
console.log(await pg.evaluate(()=>{const m={};SEASONS.forEach(([id,,,rows])=>rows.forEach((r,ri)=>r.forEach(n=>{if(!PBY[n]){(m[n]=m[n]||{l:["FW","MF","DF","GK"][ri],s:[]}).s.push(id)}})));
 const cur=[];SQUADS.football.groups.forEach(g=>g[1].forEach(x=>{if(!PBY[x[1]])cur.push(g[0]+":"+x[1]+":"+x[2])}));
 return Object.entries(m).map(([n,v])=>n+" | "+v.l+" | "+v.s.join(",")).join("\n")+"\n--- current unrated:\n"+cur.join("\n")}));await b.close()})();
