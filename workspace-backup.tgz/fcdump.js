const {chromium}=require('playwright');const fs=require('fs');
(async()=>{const b=await chromium.launch();const pg=await b.newPage({viewport:{width:1366,height:900}});
await pg.goto('file://'+process.argv[2]+'#all');await pg.waitForTimeout(600);
const brs=['home','football','womens-football','basketball','womens-basketball','volleyball','mens-volleyball','more'];
let total=0;
for(const br of brs){
 const tabs=await pg.evaluate(br=>{setSport(br);return br==='home'?[['home','home']]:tabsFor(br).map(x=>x)},br);
 for(const [tb] of tabs){if(tb==='play')continue;
  await pg.evaluate(([br,tb])=>{setSport(br);if(br!=='home'){tab=tb;render()}},[br,tb]);await pg.waitForTimeout(250);
  // expand everything
  for(let k=0;k<4;k++){await pg.evaluate(()=>{document.querySelectorAll('#panel details').forEach(d=>d.open=true);
    document.querySelectorAll('#panel [data-mall],#panel [aria-expanded="false"],#panel .more-btn,#panel [data-more]').forEach(x=>{try{x.click()}catch(e){}})});await pg.waitForTimeout(150)}
  // sub-tabs / filters inside panel: collect text for each sub-group button
  let txt=await pg.evaluate(()=>document.getElementById('panel').innerText);
  const subs=await pg.evaluate(()=>[...document.querySelectorAll('#panel [data-tg],#panel [data-sg],#panel [data-era],#panel [data-sq]')].map((x,i)=>i));
  for(const i of subs){const t2=await pg.evaluate(i=>{const x=[...document.querySelectorAll('#panel [data-tg],#panel [data-sg],#panel [data-era],#panel [data-sq]')][i];if(!x)return '';x.click();document.querySelectorAll('#panel details').forEach(d=>d.open=true);return document.getElementById('panel').innerText},i);txt+='\n\n=== SUB '+i+'\n'+t2}
  if(br==='home')txt=await pg.evaluate(()=>document.querySelector('main').innerText);
  fs.writeFileSync(`fc/${br}__${tb}.txt`,txt);total+=txt.length;console.log(br,tb,txt.length,subs.length)}}
console.log('total',total);await b.close()})();
