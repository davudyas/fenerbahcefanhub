const SPORTS = {
  football: {
    label:"Football", tr:"Futbol", title:"Football", num:"07",
    nick:"Sarı Kanaryalar — the Yellow Canaries",
    lede:"The heart of the club. Fenerbahçe were the first champions of Turkey's national league in 1959 and have stayed one of the Big Three of Turkish football ever since. Latest silverware: the 2025 Super Cup, won 2–0 against Galatasaray in January 2026.",
    stats:[["19","Süper Lig titles"],["7","Turkish Cups"],["10","Super Cups"],["2nd","2025–26 league finish"]],
    home:["Home ground","Şükrü Saracoğlu Stadium, Kadıköy · about 47,000 seats"],
    history:[
      ["1907","The club is founded","Ziya Songülen, Ayetullah Bey and Necip Okaner start the club in Kadıköy, on the Asian side of Istanbul. The name comes from the lighthouse (fener) at Fenerbahçe point."],
      ["1910s","Yellow and navy","The club settles on yellow and navy blue. The story goes that the colours came from daffodils growing around the lighthouse."],
      ["1923","General Harington Cup","Fenerbahçe beat a team from the British forces occupying Istanbul, a win remembered as a point of national pride."],
      ["1959","First national champions","Fenerbahçe win the first edition of the new nationwide Turkish league."],
      ["2002","The 6–0","A 6–0 home win over Galatasaray on 6 November, still the biggest margin in the derby's modern era."],
      ["2008","Champions League quarter-finals","A shootout win over Sevilla takes Fenerbahçe to the last eight, where they beat Chelsea 2–1 in the first leg."],
      ["2014","Title number 19","Fenerbahçe win the Süper Lig for the 19th time, their most recent league crown."],
      ["2026","Super Cup at the Olympic Stadium","Guendouzi and Oosterwolde score in a 2–0 final win over Galatasaray, the club's first Super Cup since 2014. The team finishes the season second, back in the Champions League."]
    ],
    games:[
      {date:"2002-11-06",comp:"Süper Lig",home:"Fenerbahçe",away:"Galatasaray",res:"6–0",out:"win",tag:"Derby",note:"The most famous night in the Intercontinental Derby. Fenerbahçe ran riot at home and the scoreline became a chant for a generation.",where:"Şükrü Saracoğlu, Istanbul"},
      {date:"2026-01-10",comp:"Super Cup final",home:"Galatasaray",away:"Fenerbahçe",res:"0–2",out:"win",tag:"Derby",note:"Guendouzi (28') and Oosterwolde (48') won the final in front of 58,397 fans. Guendouzi was man of the match.",where:"Atatürk Olympic Stadium, Istanbul"},
      {date:"2008-03-04",comp:"Champions League · Round of 16",home:"Sevilla",away:"Fenerbahçe",res:"3–2",out:"win",tag:"Europe",note:"5–5 on aggregate, then penalties. Volkan Demirel became a hero in the shootout and Fenerbahçe reached the quarter-finals.",where:"Ramón Sánchez Pizjuán, Seville"},
      {date:"2008-04",comp:"Champions League · Quarter-final",home:"Fenerbahçe",away:"Chelsea",res:"2–1",out:"win",tag:"Europe",note:"Fenerbahçe came from behind to beat Chelsea in Kadıköy. Chelsea turned it round in the return leg.",where:"Şükrü Saracoğlu, Istanbul"},
      {date:"2013-04-25",comp:"Europa League · Semi-final",home:"Fenerbahçe",away:"Benfica",res:"1–0",out:"win",tag:"Europe",note:"A first-leg win that put Fenerbahçe one step from a European final. Benfica won the second leg in Lisbon.",where:"Şükrü Saracoğlu, Istanbul"},
      {date:"2010-05-16",comp:"Süper Lig · Final day",home:"Fenerbahçe",away:"Trabzonspor",res:"1–1",out:"draw",tag:"Heartbreak",note:"A win would have sealed the title. The draw handed the championship to Bursaspor. Every club has a day it would rather forget.",where:"Şükrü Saracoğlu, Istanbul"}
    ],
    filters:["All","Derby","Europe","Heartbreak"],
    legends:[
      ["Lefter Küçükandonyadis","Forward · 1947–1964","Known as 'Ordinaryüs', the Professor. One of the greatest scorers in the club's history and a symbol of Kadıköy."],
      ["Can Bartu","Forward · 1950s–1970s","Played both football and basketball for Fenerbahçe, and later starred in Italy with Fiorentina."],
      ["Cemil Turan","Striker · 1970s","A prolific centre-forward in the title-winning sides of the 1970s."],
      ["Rıdvan Dilmen","Playmaker · 1980s–1990s","A gifted attacking midfielder, later one of Turkey's best-known football commentators."],
      ["Alex de Souza","No. 10 · 2004–2012","The Brazilian captain who led the 2011 title team. Probably the most loved foreign player in the club's history."],
      ["Volkan Demirel","Goalkeeper · 2002–2020","Spent almost two decades in goal, including the 2008 shootout against Sevilla."]
    ],
    trophies:[
      ["19","Süper Lig","1959, 1961, 1964, 1965, 1968, 1970, 1974, 1975, 1978, 1983, 1985, 1989, 1996, 2001, 2004, 2005, 2007, 2011, 2014"],
      ["7","Turkish Cup","1968, 1974, 1979, 1983, 2012, 2013, 2023"],
      ["10","Turkish Super Cup","Most recent: 2025 edition, won January 2026 against Galatasaray"],
      ["1","Balkans Cup","1968"]
    ],
    quiz:[
      {q:"In which Istanbul district was Fenerbahçe founded?",o:["Kadıköy","Beşiktaş","Taksim","Üsküdar"],a:0,e:"Kadıköy, on the Asian side. The stadium is still there."},
      {q:"What was the score in the derby against Galatasaray on 6 November 2002?",o:["4–0","6–0","3–1","5–2"],a:1,e:"6–0 at Şükrü Saracoğlu."},
      {q:"How many Süper Lig titles has Fenerbahçe won?",o:["17","21","19","24"],a:2,e:"19 since the national league started in 1959. The club also counts earlier Istanbul-era championships, which is why some fans say 28."},
      {q:"What is the football team's nickname?",o:["Kara Kartallar","Sarı Kanaryalar","Cimbom","Bordo-Mavililer"],a:1,e:"Sarı Kanaryalar, the Yellow Canaries. Kara Kartallar is Beşiktaş, Cimbom is Galatasaray."},
      {q:"Who scored first in the 2025 Super Cup final?",o:["Oosterwolde","En-Nesyri","Guendouzi","Szymański"],a:2,e:"Guendouzi in the 28th minute. Oosterwolde added the second."}
    ]
  },

  basketball: {
    label:"Men's Basketball", tr:"Erkek Basketbol", title:"Basketball", num:"25",
    nick:"Fenerbahçe Beko",
    lede:"Two-time champions of Europe. Fenerbahçe won the EuroLeague at home in Istanbul in 2017 and again in Abu Dhabi in 2025, and reached their eighth Final Four in 2026.",
    stats:[["2","EuroLeague titles"],["8","Final Fours"],["4","EuroLeague finals"],["1913","Department founded"]],
    home:["Home court","Ülker Sports and Event Hall, Ataşehir"],
    history:[
      ["1913","The basketball department opens","One of the oldest basketball sections in Turkey."],
      ["2013","Obradović arrives","Željko Obradović, Europe's most decorated coach, takes over and builds a contender."],
      ["2016","First EuroLeague final","Fenerbahçe reach the final in Berlin and lose to CSKA Moscow in overtime."],
      ["2017","Champions of Europe","At the Final Four in Istanbul they beat Real Madrid, then Olympiacos 80–64. Ekpe Udoh is Final Four MVP."],
      ["2018","Back in the final","A second straight final, this time lost to Real Madrid in Belgrade."],
      ["2025","Second star","Under Šarūnas Jasikevičius they beat Panathinaikos and then Monaco 81–70 in Abu Dhabi. Nigel Hayes-Davis is MVP."],
      ["2026","Eighth Final Four","A third Final Four in a row, ending with a semi-final loss to Olympiacos in Athens."]
    ],
    games:[
      {date:"2017-05-21",comp:"EuroLeague Final",home:"Fenerbahçe",away:"Olympiacos",res:"80–64",out:"win",tag:"Final",note:"The first European title, won in front of a home crowd in Istanbul.",where:"Sinan Erdem Dome, Istanbul"},
      {date:"2017-05-19",comp:"EuroLeague Semi-final",home:"Fenerbahçe",away:"Real Madrid",res:"84–75",out:"win",tag:"Final Four",note:"Beating the favourites set up the final two days later.",where:"Sinan Erdem Dome, Istanbul"},
      {date:"2025-05-25",comp:"EuroLeague Final",home:"Fenerbahçe",away:"Monaco",res:"81–70",out:"win",tag:"Final",note:"Title number two. Nigel Hayes-Davis was named Final Four MVP.",where:"Etihad Arena, Abu Dhabi"},
      {date:"2025-05-23",comp:"EuroLeague Semi-final",home:"Fenerbahçe",away:"Panathinaikos",res:"82–76",out:"win",tag:"Final Four",note:"Fenerbahçe knocked out the defending champions.",where:"Etihad Arena, Abu Dhabi"},
      {date:"2016-05-15",comp:"EuroLeague Final",home:"Fenerbahçe",away:"CSKA Moscow",res:"96–101",out:"loss",tag:"Final",note:"So close in their first final. It went to overtime before CSKA pulled away.",where:"Mercedes-Benz Arena, Berlin"}
    ],
    filters:["All","Final","Final Four"],
    legends:[
      ["Željko Obradović","Head coach · 2013–2020","Brought the first EuroLeague title and five straight Final Fours."],
      ["Šarūnas Jasikevičius","Head coach · 2023–","Coached the 2025 champions."],
      ["Ekpe Udoh","Center · 2014–2017","Final Four MVP in 2017, a defensive anchor."],
      ["Bogdan Bogdanović","Guard · 2014–2017","Scoring guard of the 2017 team, later an NBA player."],
      ["Jan Veselý","Forward · 2014–2022","Thunderous dunks over eight seasons in Istanbul."],
      ["Nigel Hayes-Davis","Forward · 2022–2025","Final Four MVP in 2025."]
    ],
    trophies:[
      ["2","EuroLeague","2017, 2025"],
      ["4","EuroLeague finals","2016, 2017, 2018, 2025"],
      ["8","Final Four appearances","Most recent: Athens 2026"]
    ],
    quiz:[
      {q:"In which city did Fenerbahçe win their first EuroLeague?",o:["Berlin","Istanbul","Belgrade","Madrid"],a:1,e:"Istanbul, 2017, at a home Final Four."},
      {q:"Who did Fenerbahçe beat in the 2025 EuroLeague final?",o:["Real Madrid","Olympiacos","Monaco","Barcelona"],a:2,e:"Monaco, 81–70 in Abu Dhabi."},
      {q:"Who coached the 2025 title team?",o:["Željko Obradović","Ergin Ataman","Šarūnas Jasikevičius","Dimitris Itoudis"],a:2,e:"Šarūnas Jasikevičius."},
      {q:"Who was the 2017 Final Four MVP?",o:["Ekpe Udoh","Bogdan Bogdanović","Kostas Sloukas","Jan Veselý"],a:0,e:"Ekpe Udoh."}
    ]
  },

  "womens-basketball": {
    label:"Women's Basketball", tr:"Kadın Basketbol", title:"Women's Basketball", num:"26",
    nick:"Potanın Kraliçeleri — Queens of the Hoop",
    lede:"The most successful team in the club right now. Three EuroLeague Women titles since 2023, a record 20 Turkish league titles, and in 2025–26 they won every competition they entered.",
    stats:[["3","EuroLeague Women"],["20","Turkish league titles"],["2","Triple Crowns"],["3","European SuperCups"]],
    home:["Based in","Istanbul · Turkish Super League and EuroLeague Women"],
    history:[
      ["1954","The team is formed","Women's basketball becomes a permanent part of the club."],
      ["1999","First league title","The first of a record 20 Turkish Super League titles."],
      ["2013","First EuroLeague final","The first of four runner-up finishes before the breakthrough."],
      ["2023","Champions of Europe","With Breanna Stewart and Emma Meesseman, Fenerbahçe win their first EuroLeague Women title."],
      ["2024","Perfect season","35 wins from 35 league games, plus the EuroLeague, the Turkish Cup and the SuperCup."],
      ["2026","Third star","The EuroLeague Women title returns to Kadıköy after a Final Six in Zaragoza, part of a clean sweep of every trophy."]
    ],
    games:[
      {date:"2023-04",comp:"EuroLeague Women",title:"First European title",out:"win",tag:"Europe",note:"After four lost finals, Fenerbahçe finally lift the trophy. Breanna Stewart and Emma Meesseman lead the way.",where:"Final Four, Prague"},
      {date:"2024-04",comp:"EuroLeague Women",title:"Back-to-back",out:"win",tag:"Europe",note:"The title is defended, capping a season without a domestic defeat.",where:"Final Four, Zaragoza"},
      {date:"2024",comp:"Turkish Super League",title:"35–0",out:"win",tag:"League",note:"A perfect league season: every one of 35 games won.",where:"Turkey"},
      {date:"2026",comp:"EuroLeague Women",title:"Number three",out:"win",tag:"Europe",note:"Fenerbahçe reclaim the crown at the Final Six on the way to winning every competition of 2025–26.",where:"Final Six, Zaragoza"}
    ],
    filters:["All","Europe","League"],
    legends:[
      ["Emma Meesseman","Forward · 2022–","Belgian star, back-to-back EuroLeague Women MVP and one of the most decorated players in the competition."],
      ["Breanna Stewart","Forward · 2022–2023","WNBA superstar who helped win the first EuroLeague title."],
      ["Alperi Onar","Point guard · 2021–","Club captain since 2023."],
      ["Birsel Vardarlı","Guard · captain 2012–2019","Captain through the years of near-misses in Europe."],
      ["Kayla McBride","Guard · 2020s","Sharp-shooting guard of the title teams."],
      ["Gabby Williams","Forward · 2020s","Two-way forward and a fan favourite."]
    ],
    trophies:[
      ["3","EuroLeague Women","2023, 2024, 2026"],
      ["20","Turkish Super League","1999 to 2026, a record"],
      ["3","FIBA Europe SuperCup Women","2023, 2024, 2026"],
      ["2","Triple Crowns","2024, 2026"]
    ],
    quiz:[
      {q:"When did Fenerbahçe win their first EuroLeague Women title?",o:["2013","2019","2023","2026"],a:2,e:"2023, after four lost finals."},
      {q:"What was the team's league record in 2023–24?",o:["33–2","35–0","30–5","34–1"],a:1,e:"35–0, a perfect season."},
      {q:"Where did Fenerbahçe win the 2026 EuroLeague Women title?",o:["Zaragoza","Istanbul","Prague","Valencia"],a:0,e:"At the Final Six in Zaragoza."},
      {q:"What does 'Potanın Kraliçeleri' mean?",o:["Yellow Angels","Queens of the Hoop","Lady Canaries","Kadıköy Stars"],a:1,e:"Queens of the Hoop."}
    ]
  },

  volleyball: {
    label:"Volleyball", tr:"Voleybol", title:"Volleyball", num:"10",
    nick:"Sarı Melekler — the Yellow Angels",
    lede:"The first Turkish club to become world champions in an Olympic team sport. The women's team won the Club World Championship undefeated in 2010 and the CEV Champions League in 2012.",
    stats:[["1","Club World title"],["1","CEV Champions League"],["1","CEV Cup"],["1928","Women's team founded"]],
    home:["Home court","Burhan Felek Sport Hall, Istanbul"],
    history:[
      ["1928","A pioneer starts the team","Sabiha Gürayman founds the women's volleyball team. She had played on the men's team and became Turkey's first female architect."],
      ["2010","World champions","Fenerbahçe win the FIVB Club World Championship in Doha without losing a match."],
      ["2012","Champions of Europe","They beat RC Cannes in three straight sets in the Champions League final in Baku."],
      ["2014","Two European cups in one day","The women win the CEV Cup and the men win the CEV Challenge Cup on the same day, a first for a Turkish club."]
    ],
    games:[
      {date:"2012-03",comp:"CEV Champions League Final",home:"Fenerbahçe",away:"RC Cannes",res:"3–0",out:"win",tag:"Women",note:"25–14, 25–22, 25–20. The club's first Champions League title.",where:"Baku, Azerbaijan"},
      {date:"2014-03-29",comp:"CEV Cup Final",home:"Fenerbahçe",away:"Uralochka",res:"3–0",out:"win",tag:"Women",note:"25–11, 28–26, 25–22, in front of a home crowd.",where:"Istanbul"},
      {date:"2010-12",comp:"FIVB Club World Championship",title:"World champions",out:"win",tag:"Women",note:"Won without dropping a match. The first world title for a Turkish club in an Olympic team sport.",where:"Doha, Qatar"},
      {date:"2014-03-29",comp:"CEV Challenge Cup",title:"Men's European title",out:"win",tag:"Men",note:"The men's team won its European trophy on the same day as the women's CEV Cup.",where:"Europe"}
    ],
    filters:["All","Women","Men"],
    legends:[
      ["Sabiha Gürayman","Founder · 1928","Founded the women's team, played alongside men, and became Turkey's first female architect."],
      ["Eda Erdem Dündar","Middle blocker · captain","Longtime captain and a Turkish national team great."],
      ["Kim Yeon-koung","Outside hitter · 2011–2017","South Korean superstar and MVP of the 2012 Champions League title run."],
      ["Melissa Vargas","Opposite","One of the hardest hitters in the world game."]
    ],
    trophies:[
      ["1","FIVB Club World Championship","2010"],
      ["1","CEV Champions League","2012"],
      ["1","CEV Cup (women)","2014"],
      ["1","CEV Challenge Cup (men)","2014"]
    ],
    quiz:[
      {q:"Who founded Fenerbahçe's women's volleyball team in 1928?",o:["Sabiha Gürayman","Halide Edib","Sabiha Gökçen","Eda Erdem"],a:0,e:"Sabiha Gürayman, also Turkey's first female architect."},
      {q:"In which year were Fenerbahçe crowned Club World Champions?",o:["2008","2010","2012","2014"],a:1,e:"2010, in Doha, undefeated."},
      {q:"Who did they beat in the 2012 Champions League final?",o:["VakıfBank","Dynamo Moscow","RC Cannes","Imoco Conegliano"],a:2,e:"RC Cannes, 3–0."},
      {q:"What is the volleyball team's nickname?",o:["Sarı Melekler","Sarı Kanaryalar","File Sultanları","Potanın Kraliçeleri"],a:0,e:"Sarı Melekler, the Yellow Angels."}
    ]
  },

  more: {
    label:"Other Branches", tr:"Diğer Branşlar", title:"More Sports", num:"∞",
    nick:"One club, many sports",
    lede:"Fenerbahçe is a full multi-sport club. Beyond football, basketball and volleyball it runs teams and athletes in athletics, rowing, sailing, swimming, table tennis, boxing, wheelchair basketball and esports.",
    stats:[["10+","Active branches"],["1907","Club founded"],["6","Branches with European titles"],["1","World title (volleyball)"]],
    home:["Base","Kadıköy, Istanbul, with facilities across the city"],
    branches:[
      ["Athletics","Track and field athletes competing in Turkish and European championships."],
      ["Rowing","A long-standing branch, rowing on the waters of the Bosphorus and Marmara."],
      ["Sailing","Sailors racing on the sea right next to the club's birthplace."],
      ["Swimming","Swimmers who feed the Turkish national team."],
      ["Table Tennis","The women's team has won European silverware."],
      ["Boxing","A traditional branch with a long history at the club."],
      ["Wheelchair Basketball","European club champions, among the club's continental winners."],
      ["Esports","The club's digital branch, competing in online leagues."]
    ]
  }
};

