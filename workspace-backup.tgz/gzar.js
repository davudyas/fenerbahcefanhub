const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const pg=await b.newPage({viewport:{width:1366,height:900}});const errs=[];pg.on('pageerror',e=>errs.push(e.message));
await pg.goto('file://'+process.argv[2]+'#football-play');await pg.waitForTimeout(400);await pg.selectOption('#lang','ar');await pg.waitForTimeout(400);
await pg.evaluate(()=>{const s=document.getElementById('theme');s.value='night';s.dispatchEvent(new Event('change',{bubbles:true}));pickGame('draft')});await pg.waitForTimeout(200);
await pg.click('[data-gz="form"]');await pg.waitForSelector('[data-gz="season"]');await pg.click('[data-gz="season"]');await pg.waitForTimeout(900);
await pg.evaluate(()=>document.querySelector('.gzhead').scrollIntoView());await pg.evaluate(()=>scrollBy(0,-140));await pg.screenshot({path:'../gz_ar_spin.png'});
await pg.waitForSelector('.gzsq');await pg.screenshot({path:'../gz_ar_sq.png'});console.log(errs);await b.close()})();
