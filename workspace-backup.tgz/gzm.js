const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},deviceScaleFactor:1,reducedMotion:'reduce'});const pg=await ctx.newPage();
await pg.goto('file://'+process.argv[2]+'#football-play');await pg.waitForTimeout(400);await pg.evaluate(()=>pickGame('draft'));
await pg.click('[data-gz="form"]');await pg.waitForTimeout(100);
// force a season with multi-fit player
for(let k=0;k<3;k++){await pg.click('[data-gz="season"]');await pg.waitForTimeout(80);const b2=await pg.$('.gzp:not([disabled])');await b2.click();await pg.waitForTimeout(80);const f=await pg.$('.ps.fit');if(f){await pg.screenshot({path:'../gzm_fit.png'});await f.click()}}
await pg.click('[data-gz="season"]');await pg.waitForTimeout(80);
const el=await pg.$('.gzdraft');await el.scrollIntoViewIfNeeded();await pg.evaluate(()=>document.querySelector('.gzdraft').scrollIntoView());await pg.screenshot({path:'../gzm_a.png'});
await pg.evaluate(()=>scrollBy(0,500));await pg.screenshot({path:'../gzm_b.png'});await b.close()})();
