import re,sys
E=[
# ---- football live
("live.js",'["Mason Greenwood",""],["Archie Brown",""],["Vedat Muriqi","89\'"]],op:[["Trey Nyoni",""],["Alexander Isak",""]]','["Mason Greenwood","29\'"],["Archie Brown","73\'"],["Vedat Muriqi","79\'"]],op:[["Trey Nyoni","25\'"],["Alexander Isak","69\'"]]'),
("live.js","Vedat Muriqi scored the winner in the 89th minute.","Vedat Muriqi scored the winner in the 79th minute."),
("live.js","galibiyet golünü 89. dakikada Vedat Muriqi attı","galibiyet golünü 79. dakikada Vedat Muriqi attı"),
("live.js","Vedat Muriqi erzielte in der 89. Minute den Siegtreffer","Vedat Muriqi erzielte in der 79. Minute den Siegtreffer"),
("live.js","gol de la victoria en el minuto 89","gol de la victoria en el minuto 79"),
("live.js","le but de la victoire à la 89e minute","le but de la victoire à la 79e minute"),
("live.js","هدف الفوز في الدقيقة 89","هدف الفوز في الدقيقة 79"),
("live.js",'["Oğuz Aydın","74\'"]],op:[],v:"Turhan Kılıççıoğlu Stadium"','["Oğuz Aydın","75\'"]],op:[],v:"Çorum City Stadium"'),
("live.js",'["2026-07-29","Champions League","A","Górnik Zabrze",1,1,"2nd qualifying round, 2nd leg"]],','["2026-07-29","Champions League","A","Górnik Zabrze",1,1,"2nd qualifying round, 2nd leg"],\n    ["2026-07-21","Champions League","H","Górnik Zabrze",1,0,"2nd qualifying round, 1st leg"]],'),
("live.js",'["2027-01-17","21:00","Süper Lig","H","Amed SFK"]','["2027-01-17","","Süper Lig","H","Amed SFK"]'),
("live.js",'["2027-01-24","21:00","Süper Lig","H","Gençlerbirliği"]','["2027-01-24","","Süper Lig","H","Gençlerbirliği"]'),
# ---- basketball live
("live.js",'["2","Trophies won this autumn"]','["1","Trophy won this autumn"]'),
("live.js",'["2026-10","EuroLeague","H","Zalgiris Kaunas"','["2026-10-13","EuroLeague","H","Zalgiris Kaunas"'),
("live.js",'["2026-10","EuroLeague","A","Panathinaikos"','["2026-10-08","EuroLeague","A","Panathinaikos"'),
("live.js",'["2026-09","EuroLeague","H","Bayern München"','["2026-09-29","EuroLeague","H","Bayern München"'),
("live.js",'["2026-09","BSL","A","Bahçeşehir Koleji"','["2026-09-27","BSL","A","Bahçeşehir Koleji"'),
# ---- women's basketball live
("live.js","Group C, round 4: first defeat since January","Group C, round 4: first EuroLeague Women defeat since January"),
("live.js",'["2026-10","KBSL","A","Beşiktaş BOA"','["2026-10-17","KBSL","A","Beşiktaş BOA"'),
# ---- football squad / venue / derbies
("x_data.js",'coachNote:"Appointed on 6 November 2026, after İsmail Kartal resigned in October."','coachNote:"Signed on 3 November 2026, a week after İsmail Kartal left by mutual agreement. Assistant coach Dirk Kuyt took charge for the Göztepe and Liverpool games."'),
("x_data.js",'cap:"About 47,000 seats"','cap:"47,911 seats"'),
("x_data.js","Football has been played on this ground since 1908. Fenerbahçe made it their home in 1929.","Opened in 1908 as the Union Club Field and Fenerbahçe's home ever since. The club bought it from the state in 1933."),
("x_data.js",'all:{label:"All official matches, as of September 2024",p:279,w:101,d:91,l:87,gf:370,ga:343}','all:{label:"All meetings, including friendlies, as of 26 October 2026",p:407,w:150,d:125,l:132,gf:547,ga:510}'),
("x_data.js",'league:{label:"Süper Lig, before the April 2026 derby",p:137,w:53,d:46,l:38,gf:165,ga:134}','league:{label:"Süper Lig, as of 26 October 2026",p:139,w:53,d:46,l:40,gf:166,ga:139}'),
("x_data.js","Galatasaray's biggest verifiable official win: 5–0 on 18 December 1960.","Galatasaray's biggest win: 7–0 in the Istanbul Football League on 12 February 1911."),
("x_data.js",'all:{label:"All official matches, before September 2026",p:364','all:{label:"All meetings, before September 2026",p:364'),
("x_data.js",'league:{label:"Süper Lig, before September 2026",p:140,w:51,d:45,l:44}','league:{label:"Süper Lig, before September 2026",p:140,w:51,d:45,l:44,gf:162,ga:160}'),
("x_data.js",'recent:[["2026-09-05","Süper Lig","H",1,2]]','recent:[["2026-09-05","Süper Lig","H",1,2],["2026-04-05","Süper Lig","H",1,0],["2025-12-23","Turkish Cup","H",1,2]]'),
("x_data.js",'all:{label:"All official matches, after February 2026",p:139','all:{label:"All meetings, after February 2026",p:139'),
("x_data.js",'recent:[["2026-02-14","Süper Lig","A",3,2],["2025-04-06","Süper Lig","H",4,1]]','recent:[["2026-02-14","Süper Lig","A",3,2],["2025-09-14","Süper Lig","H",1,0],["2025-04-06","Süper Lig","H",4,1]]'),
("x_ux.js",'t("All official matches, head to head")','t("All meetings, head to head")'),
# ---- football history/legends/records/trophies
("x_more.js",'["Appointed head coach on 6 November 2026."]','["Appointed head coach on 3 November 2026."]'),
("x_more.js","A loyal servant across three decades.","A loyal servant for fourteen seasons."),
("x_more.js","As coach: the 2010–11 title and the 2012 Turkish Cup.","As coach: the 2010–11 title and the 2012 and 2013 Turkish Cups."),
("x_more.js","Fenerbahçe join the Istanbul Football League and start playing on the ground where Şükrü Saracoğlu stands today.","The Union Club Field opens on the spot where Şükrü Saracoğlu stands today, and Fenerbahçe play there. The club joins the Istanbul Football League a year later."),
("x_more.js","Fenerbahçe win the Turkish Football Championship for the first time and buy their stadium, the first Turkish club to own its ground.","Fenerbahçe win the Turkish Football Championship for the first time and buy their ground from the state on 27 May."),
("x_more.js",'F.trophies[0]=["28","Süper Lig",','F.trophies[0]=["28","Turkish championship",'),
("x_more.js","Top scorer for the starters in the 2025 final.","19 points in the 2025 final, second only to Hayes-Davis."),
("x_more.js","Energy off the bench in the 2025 title run.","A key guard in the 2025 title run."),
("x_rec.js",'["1967","First European trophy for a Turkish club","The Balkan Cup, won against AEK Athens."]','["1968","First European trophy for a Turkish club","The 1966–67 Balkans Cup, won in a play-off against AEK Athens in May 1968."]'),
("x_rec.js","Founded by Sabiha Gürayman, later Turkey's first female architect.","Founded by Sabiha Gürayman, later Turkey's first female civil engineer."),
("sports_head.js","Şükrü Saracoğlu Stadium, Kadıköy · about 47,000 seats","Şükrü Saracoğlu Stadium, Kadıköy · 47,911 seats"),
("sports_head.js",'["Volkan Demirel","Goalkeeper · 2002–2020"','["Volkan Demirel","Goalkeeper · 2002–2019"'),
("sports_head.js","19 since the national league started in 1959. The club also counts earlier Istanbul-era championships, which is why some fans say 28.","19 since the national league started in 1959. The club also counts nine national titles from before 1959, which is why it speaks of 28."),
# ---- basketball
("sports_rest.js",'nick:"Fenerbahçe Beko"','nick:"Fenerbahçe Tarfin"'),
("sports_rest.js",'"Belgian star, back-to-back EuroLeague Women MVP and one of the most decorated players in the competition."','"Belgian star, EuroLeague Women MVP three years in a row (2023–2025) and one of the most decorated players in the competition."'),
# ---- volleyball
("sports_rest.js","Sabiha Gürayman founds the women's volleyball team. She had played on the men's team and became Turkey's first female architect.","Sabiha Gürayman founds and captains the women's volleyball team. She later became Turkey's first female civil engineer."),
("sports_rest.js","Founded the women's team, played alongside men, and became Turkey's first female architect.","Founded the women's team, captained it, and later became Turkey's first female civil engineer."),
("sports_rest.js",'e:"Sabiha Gürayman, also Turkey\'s first female architect."','e:"Sabiha Gürayman, later Turkey\'s first female civil engineer."'),
("sports_rest.js",'["Melissa Vargas","Opposite · 2023–"','["Melissa Vargas","Opposite · 2018–"'),
("sports_rest.js","The women won the ETTU Cup in 2012 and 2013 and the European Champions League unbeaten in 2015.","The women won the ETTU Cup in 2012 and 2013 and the European Champions League in 2015."),
("bdata.js",'[2015,"Women\'s table tennis wins the Champions League unbeaten","Table tennis"]','[2015,"Women\'s table tennis wins the Champions League","Table tennis"]'),
# ---- women's football
("x_new.js","Ece Türkoğlu scored in the 89th minute. It was Galatasaray's first league defeat of the season, and Fenerbahçe went top.","Ece Türkoğlu scored in the 89th minute. It was Galatasaray's first league defeat of the season."),
("x_new.js",'["2026","Top of the table","Ece Türkoğlu\'s 89th-minute goal beats Galatasaray 1–0 on 7 November and takes Fenerbahçe top of the league."]','["2026","Derby winner","Ece Türkoğlu\'s 89th-minute goal beats Galatasaray 1–0 on 7 November, Galatasaray\'s first league defeat of the season."]'),
("x_new.js","Fenerbahçe form a women's football team on 4 April 1995 and reach the league semi-finals in their first season.","Fenerbahçe form a women's football team on 4 April 1995."),
("x_new.js","After finishing third in 1995–96, the team is later closed for financial reasons.","After finishing third in their group in 1995–96, the team is later closed for financial reasons."),
("x_new.js","Took over in 2023, finished second, then won the first league title.","Took over in 2023: third, then second, then the first league title."),
# ---- season game data
("x_sdata.js",'const SZ_EU_FB={2000:"UC-R1",2001:"CL-G",2002:"CL-Q3",2004:"CL-G",2005:"CL-G",2006:"CL-Q3",2007:"CL-G",2008:"CL-Q3",2009:"EL-PO",2010:"CL-Q3",2012:"CL-Q3",2013:"CL-Q3",2015:"CL-Q3",2016:"CL-Q3",2017:"EL-Q3",2018:"CL-Q3",2021:"EL-PO",2022:"CL-Q3",2023:"ECL-Q2",2024:"CL-Q3",2025:"CL-Q3",2026:"CL-Q3"};','const SZ_EU_FB={2001:"CL-Q3",2002:"CL-Q3",2004:"CL-G",2005:"CL-G",2006:"CL-Q2",2007:"CL-Q3",2008:"CL-Q2",2009:"EL-Q3",2010:"CL-Q3",2012:"CL-Q3",2013:"CL-Q3",2015:"CL-Q3",2016:"CL-Q3",2017:"EL-Q3",2018:"CL-Q3",2021:"EL-PO",2022:"CL-Q2",2023:"ECL-Q2",2024:"CL-Q2",2025:"CL-Q3",2026:"CL-Q2"};'),
("x_sdata.js",'"womens-basketball":{t:[1999,2002,2004,2006,2007,2008,2009,2010,2011,2012,2013,2016,2018,2019,2021,2022,2023,2024,2025,2026],c:[]}','"womens-basketball":{t:[1999,2002,2004,2006,2007,2008,2009,2010,2011,2012,2013,2016,2018,2019,2021,2022,2023,2024,2025,2026],c:[2000,2001,2004,2005,2006,2007,2008,2009,2015,2016,2019,2020,2024,2026]}'),
# ---- player pool
("football.js",'["Milan Škriniar","CB","",85,"SVK",2024,2026]','["Milan Škriniar","CB","",85,"SVK",2025,2026]'),
("football.js",'["İrfan Can Kahveci","W","AM",80,"TUR",2021,2025,"Kahveci"]','["İrfan Can Kahveci","W","AM",80,"TUR",2021,2026,"Kahveci"]'),
("football.js",'["Milan Škriniar",2024]','["Milan Škriniar",2025]'),
]
bad=0
for f,o,n in E:
    s=open(f).read();c=s.count(o)
    if c!=1:print("COUNT",c,f,o[:80]);bad+=1;continue
    open(f,'w').write(s.replace(o,n))
print("bad",bad)
