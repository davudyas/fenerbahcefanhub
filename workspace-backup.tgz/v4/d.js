const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const pg=await b.newPage();const errs=[];pg.on('pageerror',e=>errs.push(e.message+' '+e.stack.split('\n')[1]));
await pg.goto('file://'+process.cwd()+'/fenerbahce.html#football-play');await pg.waitForTimeout(400);
console.log(errs, await pg.evaluate(()=>[tab,current,document.getElementById('panel').innerHTML.slice(0,300)]));await b.close()})();
