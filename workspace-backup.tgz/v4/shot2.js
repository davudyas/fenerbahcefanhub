const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();
for(const [w,h,tag] of [[1280,900,'d'],[390,844,'m']]){const pg=await b.newPage({viewport:{width:w,height:h}});const errs=[];pg.on('pageerror',e=>errs.push(e.message));
await pg.addInitScript(()=>{const fake=async(input,opts)=>{const txt="Fenerbahçe play Real Sociedad at home on Wednesday 11 November at 20:00 (Turkey time) in the Women's Europa Cup round of 16, second leg.";await new Promise(r=>setTimeout(r,300));opts&&opts.onText&&opts.onText({text:txt,delta:txt});window.__lastInput=input;return {text:txt,truncated:false}};window.claude={use:async n=>n==="sample"?fake:null}});
await pg.goto('file://'+process.cwd()+'/fenerbahce.html#womens-football');await pg.waitForTimeout(500);
await pg.screenshot({path:`../n_${tag}_top.png`});
await pg.click('#kanBtn');await pg.waitForTimeout(200);await pg.screenshot({path:`../n_${tag}_kan0.png`});
await pg.click('.kchip');await pg.waitForTimeout(800);await pg.screenshot({path:`../n_${tag}_kan1.png`});
const inp=await pg.evaluate(()=>JSON.stringify(window.__lastInput).length);
await pg.click('#kanClose');
for(const tb of ['standings','trophies','squad']){await pg.click(`[data-tab=${tb}]`);await pg.waitForTimeout(150);await pg.evaluate(()=>document.querySelector('.tabs').scrollIntoView());await pg.screenshot({path:`../n_${tag}_${tb}.png`})}
await pg.selectOption('#sport','mens-volleyball');await pg.waitForTimeout(200);await pg.click('[data-tab=matches]');await pg.waitForTimeout(200);await pg.evaluate(()=>document.querySelector('#commBox').scrollIntoView());await pg.screenshot({path:`../n_${tag}_mvmatch.png`});
await pg.selectOption('#sport','football');await pg.waitForTimeout(200);await pg.click('[data-tab=trophies]');await pg.waitForTimeout(150);await pg.evaluate(()=>document.querySelector('.tabs').scrollIntoView());await pg.screenshot({path:`../n_${tag}_fbtroph.png`});
// games in new branches
for(const br of ['womens-football','mens-volleyball']){await pg.selectOption('#sport',br);await pg.click('[data-tab=play]');for(const g of ['quiz','daily','wordle','squad','who','timeline','hol','gts','board','badges']){await pg.click(`[data-game=${g}]`);await pg.waitForTimeout(120)}}
await pg.click('[data-game=squad]');await pg.waitForTimeout(100);await pg.evaluate(()=>document.querySelector('#gameArea').scrollIntoView());await pg.screenshot({path:`../n_${tag}_mvsquadgame.png`});
console.log(tag,errs,inp,await pg.evaluate(()=>document.documentElement.scrollWidth));await pg.close()}
await b.close()})();
