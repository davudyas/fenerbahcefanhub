const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const F='file://'+process.cwd()+'/fenerbahce.html';
for(const [w,h,tag] of [[1280,900,'d'],[390,844,'m']]){const pg=await b.newPage({viewport:{width:w,height:h}});
 await pg.goto(F+'#football');await pg.waitForTimeout(200);await pg.selectOption('#lang','tr');await pg.waitForTimeout(200);
 await pg.screenshot({path:`l_${tag}_tr_top.png`});
 await pg.locator('#panel').screenshot({path:`l_${tag}_tr_matches.png`});
 await pg.selectOption('#lang','de');await pg.selectOption('#sport','basketball');await pg.click('[data-tab=standings]');await pg.waitForTimeout(200);
 await pg.screenshot({path:`l_${tag}_de_top.png`});
 await pg.locator('#panel').screenshot({path:`l_${tag}_de_stand.png`});
 await pg.click('[data-tab=play]');await pg.click('[data-game=who]');await pg.click('[data-wh=more]');await pg.click('[data-wh=more]');await pg.waitForTimeout(150);
 await pg.locator('#panel').screenshot({path:`l_${tag}_de_who.png`});
 console.log(tag,'sw',await pg.evaluate(()=>document.documentElement.scrollWidth), await pg.evaluate(()=>document.documentElement.lang));
 await pg.close()}
await b.close()})();
