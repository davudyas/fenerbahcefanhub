// top-level let/const data that nothing reads
const ts=require('typescript'),fs=require('fs');const html=fs.readFileSync(process.argv[2],'utf8');const js=html.slice(html.indexOf('<script>')+8,html.lastIndexOf('</script>'));
const sf=ts.createSourceFile('a.js',js,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);const decl={},refs={};
sf.statements.forEach(st=>{if(ts.isVariableStatement(st))st.declarationList.declarations.forEach(d=>{if(ts.isIdentifier(d.name))decl[d.name.text]=d.end-d.getStart(sf)})});
(function walk(n){if(ts.isIdentifier(n)){const p=n.parent;if(!(ts.isVariableDeclaration(p)&&p.name===n))refs[n.text]=(refs[n.text]||0)+1}ts.forEachChild(n,walk)})(sf);
const dead=Object.keys(decl).filter(n=>!refs[n]);console.log(dead.map(n=>n+':'+decl[n]).join(' '));
