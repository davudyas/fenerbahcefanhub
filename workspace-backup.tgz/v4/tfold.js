const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const f=process.argv[2]||'fenerbahce.html',tag=process.argv[3]||'now';
for(const [w,h,dv] of [[390,844,'m'],[1366,768,'d']]){const pg=await b.newPage({viewport:{width:w,height:h}});
for(const hs of ['all','football']){await pg.goto('file://'+process.cwd()+'/'+f+'#'+hs);await pg.waitForTimeout(600);await pg.screenshot({path:`../fold_${tag}_${dv}_${hs}.png`});
 await pg.screenshot({path:`../fold_${tag}_${dv}_${hs}_full.png`,clip:{x:0,y:0,width:w,height:h*3}})}
await pg.close()}await b.close()})();
