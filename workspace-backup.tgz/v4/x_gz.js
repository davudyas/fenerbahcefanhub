/* ===== XI Draft, Golazo style: spin a formation, spin a season, pick one player from that squad ===== */
Object.assign(NAT,{SWE:"Sweden",ENG:"England",BEL:"Belgium",MLI:"Mali",RUS:"Russia",CPV:"Cape Verde",GRE:"Greece",COD:"DR Congo",SVN:"Slovenia",MKD:"North Macedonia"});
/* Regulars from the season line-ups who are not in the main player pool. Ratings are fan ratings made for this game. */
const GZ_EXTRA=[
 ["Kennet Andersson","ST","",77,"SWE",2000,2002],["Nikola Lazetić","CM","W",74,"SRB",2000,2001],["Milan Rapaić","W","AM",78,"CRO",2000,2001],
 ["Samuel Johnson","CM","",75,"GHA",2000,2003],["Mustafa Doğan","CB","RB",76,"TUR",2000,2002],["Zoran Mirković","CB","",75,"SRB",2000,2002],
 ["Abdullah Ercan","LB","",74,"TUR",2000,2002],["Ali Güneş","ST","W",74,"TUR",2001,2004],["Kemal Aslan","CM","",73,"TUR",2002,2003],
 ["Hakan Bayraktar","CM","",72,"TUR",2002,2003],["Ceyhun Eriş","AM","W",72,"TUR",2002,2003],["Stjepan Tomas","CB","",76,"CRO",2003,2004],
 ["Deniz Barış","CM","CB",76,"TUR",2004,2009],["Servet Çetin","CB","",76,"TUR",2004,2005],["Serkan Balcı","RB","LB",75,"TUR",2004,2006],
 ["Fábio Bilica","CB","",75,"BRA",2009,2010],["Alper Potuk","W","AM",75,"TUR",2013,2017],["Fernandão","ST","",76,"BRA",2015,2016],
 ["Jeremain Lens","W","",77,"NED",2016,2017],["Volkan Şen","W","",74,"TUR",2016,2017],["Giuliano de Paula","AM","W",78,"BRA",2017,2018],
 ["Nabil Dirar","W","RB",77,"MAR",2017,2020],["Aatif Chahechouhe","W","",74,"MAR",2017,2018],["Roman Neustädter","CB","CM",76,"RUS",2017,2019],
 ["Roberto Soldado","ST","",77,"ESP",2018,2019],["André Ayew","W","ST",77,"GHA",2018,2019],["Eljif Elmas","CM","AM",76,"MKD",2018,2019],
 ["Jailson","CM","",75,"BRA",2018,2020],["Harun Tekin","GK","",75,"TUR",2018,2019],["Ozan Tufan","CM","",76,"TUR",2019,2021],
 ["Garry Rodrigues","W","",75,"CPV",2019,2020],["Max Kruse","AM","ST",79,"GER",2019,2020],["Dimitris Pelkas","AM","",76,"GRE",2020,2021],
 ["José Sosa","AM","CM",76,"ARG",2020,2021],["Marcel Tisserand","CB","",75,"COD",2020,2021],["Serdar Dursun","ST","",76,"TUR",2021,2022],
 ["Miha Zajc","AM","CM",75,"SVN",2021,2023],["Diego Rossi","W","",76,"URU",2021,2023],["Miguel Crespo","CM","",76,"POR",2021,2022],
 ["Bright Osayi-Samuel","RB","",77,"NGA",2021,2024],["Michy Batshuayi","ST","",79,"BEL",2022,2023],["Samet Akaydın","CB","",74,"TUR",2022,2023],
 ["Lincoln","AM","W",76,"BRA",2022,2023],["Alexander Djiku","CB","",77,"GHA",2023,2025],["Sofyan Amrabat","CM","",80,"MAR",2024,2025],
 ["Dorgeles Nene","W","ST",77,"MLI",2025,2026],["Nélson Semedo","RB","",79,"POR",2025,2026],["Archie Brown","LB","",77,"ENG",2025,2026],
 ["Oğuz Aydın","W","",77,"TUR",2024,2026],["Mert Hakan Yandaş","CM","",75,"TUR",2020,2026],["Tarık Çetin","GK","",72,"TUR",2026,2026],
 ["Yiğit Efe Demir","CB","",72,"TUR",2026,2026],["Nathan Aké","CB","LB",81,"NED",2026,2026],["Kojo Peprah Oppong","CB","RB",77,"GHA",2026,2026],
 ["Ognjen Mimović","RB","",74,"SRB",2026,2026],["Bartuğ Elmaz","CM","",73,"TUR",2026,2026],["N'Golo Kanté","CM","",83,"FRA",2026,2026],
 ["Romelu Lukaku","ST","",82,"BEL",2026,2026],["Mason Greenwood","W","ST",84,"ENG",2026,2026]
].map(([n,pos,alt,r,nat,from,to])=>({n,pos,alt:alt?alt.split(","):[],r,nat,from,to,short:lastName(n),gx:1}));
const GZ_BY={};PLAYERS.concat(GZ_EXTRA).forEach(p=>{if(!GZ_BY[p.n])GZ_BY[p.n]=p});
const GZ_SEASONS=SEASONS.map(s=>s[0]).concat(["2026-27"]);
const GZ_ROLE_ORDER={GK:0,RB:1,CB:2,LB:3,CM:4,AM:5,W:6,ST:7};
const gzCurSet=()=>{const s=new Set();try{SQUADS.football.groups.forEach(g=>g[1].forEach(x=>s.add(x[1])))}catch(e){}return s};
const GZ_SQ={};
function gzSquad(id){if(GZ_SQ[id])return GZ_SQ[id];const y=+id.slice(0,4),S=SEASONS.find(s=>s[0]===id),names=new Set(S?S[3].flat():[]),cur=y===2026?gzCurSet():null;
  const list=Object.values(GZ_BY).filter(p=>names.has(p.n)||(cur&&cur.has(p.n))||(!p.gx&&p.from<=y&&p.to>=y+1&&!(y===2026)));
  return GZ_SQ[id]=list.sort((a,b)=>GZ_ROLE_ORDER[a.pos]-GZ_ROLE_ORDER[b.pos]||b.r-a.r)}
const gzCan=(p,role)=>p.pos===role||p.alt.includes(role);
const gzUsed=()=>new Set(dr.picks.filter(Boolean).map(p=>p.n));
function gzFits(p){if(gzUsed().has(p.n))return [];return FORMS[dr.form].map((_,i)=>i).filter(i=>!dr.picks[i]&&gzCan(p,slotRole(dr.form,i)))}
function gzStrength(picks){const ps=picks.filter(Boolean);if(!ps.length)return {avg:0,min:0,str:0};const avg=ps.reduce((a,p)=>a+p.r,0)/ps.length,min=Math.min(...ps.map(p=>p.r));return {avg,min,str:.65*avg+.35*min}}
/* team rating used by the season simulator, the penalties and the career mode */
function teamInfo(form,picks,cap){const eff=picks.map((p,i)=>p?p.r-(gzCan(p,slotRole(form,i))?0:3):null),f=picks.filter(Boolean);
  if(!f.length)return {eff,ovr:0,base:0};const g=gzStrength(picks.map((p,i)=>p?{r:eff[i]}:null));return {eff,ovr:f.length===11?g.str:g.avg,base:g.avg}}
function newDraft(){dr={form:null,picks:Array(11).fill(null),offers:{},active:null,rerolls:3,captain:null,phase:"form",season:null,sel:null,spun:[],free:0,anim:null}}
const gzRm=()=>{if(window.GZ_FAST)return true;try{return matchMedia("(prefers-reduced-motion: reduce)").matches}catch(e){return false}};
function gzPickRandom(list){return chWith("football","rd",()=>list[Math.floor(Math.random()*list.length)])}
function gzReel(items,label,landIdx){const W=112,reps=4,seq=[];for(let k=0;k<reps;k++)items.forEach(x=>seq.push(x));const target=(reps-1)*items.length+landIdx;
  return {html:`<div class="gzreel" role="img" aria-label="${esc(label)}"><div class="gzwin"><div class="gztrack" style="transform:translateX(0px)">${seq.map(x=>`<span class="gztile">${esc(x)}</span>`).join("")}</div></div><span class="gzmark" aria-hidden="true"></span></div>`,target,W}}
function gzAnimate(root,target,W,done){const tr=root.querySelector(".gztrack"),win=root.querySelector(".gzwin");if(!tr||!win||gzRm()){done();return}
  const off=win.clientWidth/2-W/2,x=-(target*W)+off;tr.style.transition="none";tr.style.transform=`translateX(${off}px)`;void tr.offsetWidth;
  tr.style.transition="transform 1.6s cubic-bezier(.12,.75,.18,1)";tr.style.transform=`translateX(${x}px)`;let fin=false;const end=()=>{if(fin)return;fin=true;done()};tr.addEventListener("transitionend",end,{once:true});setTimeout(end,1900)}
function gzSpinForm(p){if(dr.anim)return;const keys=Object.keys(FORMS),f=gzPickRandom(keys),R=gzReel(keys,t("Formation wheel"),keys.indexOf(f));
  const box=p.querySelector("#gzWheel");box.innerHTML=R.html;dr.anim="form";gzAnimate(box,R.target,R.W,()=>{dr.anim=null;dr.form=f;dr.phase="spin";renderPanel()})}
function gzSpinSeason(p,kind){if(dr.anim)return;if(kind==="re"){if(!dr.rerolls)return;dr.rerolls--}
  const list=GZ_SEASONS.filter(s=>s!==dr.season),s=gzPickRandom(list),R=gzReel(list.map(szDash),t("Season wheel"),list.indexOf(s));
  const box=p.querySelector("#gzWheel");box.innerHTML=R.html;dr.anim="season";dr.sel=null;
  gzAnimate(box,R.target,R.W,()=>{dr.anim=null;dr.season=s;dr.spun.push(s);dr.phase="pick";renderPanel()})}
function gzScroll(){const h=document.querySelector(".gzhead");if(!h)return;const r=h.getBoundingClientRect();if(r.top<0||r.top>innerHeight*.5)h.scrollIntoView({block:"start",behavior:gzRm()?"auto":"smooth"})}
function gzPlace(p,i){dr.picks[i]=p;dr.sel=null;dr.season=null;if(dr.picks.every(Boolean)){dr.phase="done";const g=gzStrength(dr.picks),bs=store.get("fb-gz-best",null);if(bs==null||g.str>bs)store.set("fb-gz-best",Math.round(g.str*10)/10);if(typeof updateArcadeStats==="function")updateArcadeStats()}else dr.phase="spin";renderPanel();gzScroll()}
function gzPitch(){const F=FORMS[dr.form||"4-3-3"],fit=dr.sel?gzFits(dr.sel):[];
  return `<div class="pitch2 gzpitch"><span class="box18 top"></span><span class="box18"></span>${F.map(([pos,x,y],i)=>{const p=dr.picks[i],can=fit.includes(i),lab=dr.form?pos:"";
    return `<button type="button" class="ps ${p?"filled":""} ${can?"active fit":""}" style="left:${x}%;top:${y}%" data-gzslot="${i}" ${can?"":"tabindex=\"-1\""} aria-label="${esc(dr.form?pos:t("Empty"))}${p?": "+esc(p.n):""}"><span class="disc">${p?p.r:esc(lab)}</span><span class="nm">${p?esc(p.short):""}</span></button>`}).join("")}</div>`}
function gzSquadHtml(){const sq=gzSquad(dr.season),used=gzUsed(),anyFit=sq.some(p=>gzFits(p).length);
  const rows=sq.map(p=>{const f=gzFits(p),inXI=used.has(p.n),role=p.pos,why=inXI?t("Already in your XI"):!f.length?t("No open spot for him"):"";
    return `<button class="cand2 gzp ${dr.sel===p?"on":""}" data-gzp="${esc(p.n)}" ${f.length?"":"disabled"} aria-pressed="${dr.sel===p}"><span class="r">${p.r}</span><span class="info"><b>${esc(p.n)}</b><small>${esc(t(ROLE_NAME[role]))}${p.alt.length?" · "+p.alt.map(a=>esc(t(ROLE_NAME[a]))).join(", "):""} · ${esc(t(NAT[p.nat]||p.nat))}</small></span>${why?`<em class="tag">${esc(why)}</em>`:"<span></span>"}</button>`}).join("");
  return `<div class="gzsq"><div class="gzsqh"><span class="label">${t("The wheel picked")}</span><h3>${esc(tf("The {s} squad",{s:"\u2066"+szDash(dr.season)+"\u2069"}))}</h3>
    <p class="muted">${t(dr.sel?"Now tap a highlighted spot on the pitch.":anyFit?"Pick one player. Greyed-out players have no open spot.":"Nobody in this squad fits an open spot.")}</p></div>
    <div class="cands2">${rows}</div>
    <div class="btns">${anyFit?`<button class="btn ghost" data-gz="re" ${dr.rerolls?"":"disabled"}>${esc(tf(dr.rerolls===1?"Re-spin (1 left)":"Re-spin ({n} left)",{n:dr.rerolls}))}</button>`:`<button class="btn" data-gz="free">${t("Spin again (free)")}</button>`}</div></div>`}
function renderDraft(p){if(!dr||!("spun" in dr))newDraft();clearInterval(cupTimer);
  const n=dr.picks.filter(Boolean).length,g=gzStrength(dr.picks),best=store.get("fb-gz-best",null);
  let side="";
  if(dr.phase==="form")side=`<div class="box gzstep"><span class="label">${t("Step 1 of 2")}</span><h3>${t("Spin the formation")}</h3><div id="gzWheel" class="gzwheel"></div><div class="btns"><button class="btn" data-gz="form">${t("Spin the formation")}</button></div></div>`;
  else if(dr.phase==="spin")side=`<div class="box gzstep"><span class="label">${esc(tf("Pick {n} of 11",{n:n+1}))}</span><h3>${t("Spin a season")}</h3><p class="muted">${t("The wheel lands on a Fenerbahçe season from 2000–01 to today. You take one player from that squad.")}</p><div id="gzWheel" class="gzwheel"></div><div class="btns"><button class="btn" data-gz="season">${t("Spin a season")}</button></div></div>`;
  else if(dr.phase==="pick")side=`<div class="box gzstep"><div id="gzWheel" class="gzwheel"></div>${gzSquadHtml()}</div>`;
  else side=`<div class="box" id="cupBox"></div>`;
  const head=`<div class="gzhead" role="status"><span><b>${n}/11</b> ${t("picked")}</span><span>${t("Avg rating")} <b>${n?g.avg.toFixed(1):"–"}</b></span><span>${t("Formation")} <b><bdi>${dr.form?esc(dr.form):"?"}</bdi></b></span><span>${t("Re-spins")} <b>${dr.rerolls}</b></span><span>${t("Best ever")} <b>${best!=null?Number(best).toFixed(1):"–"}</b></span></div>`;
  p.innerHTML=`<h2>${t("XI Draft")}</h2><p class="intro">${t("Spin the wheel for a formation, then spin it for a Fenerbahçe season and take one player from that squad. Eleven spins later you have your XI. A player can only go in a position he plays, and you get 3 re-spins for weak squads. Your team strength is 65% your average rating and 35% your weakest player, so one weak link costs you. Then play a whole season.")}</p>
   ${head}<div class="draft gzdraft"><div>${gzPitch()}</div><div class="side">${side}</div></div>
   <div class="btns"><button class="btn ghost sm" data-gz="restart">${t("Start a new draft")}</button></div>
   <p class="gnote">${t("Ratings are fan ratings made for this game. Squads use the players the site has for each season, so they are smaller than the real ones.")}</p>`;
  const on=(k,f)=>{const x=p.querySelector(`[data-gz="${k}"]`);if(x)x.onclick=f};
  on("form",()=>gzSpinForm(p));on("season",()=>gzSpinSeason(p));on("re",()=>gzSpinSeason(p,"re"));on("free",()=>{dr.free++;gzSpinSeason(p)});
  on("restart",()=>{if(typeof szS!=="undefined")szS.football=null;newDraft();renderPanel()});
  p.querySelectorAll("[data-gzp]").forEach(b=>b.onclick=()=>{const pl=gzSquad(dr.season).find(x=>x.n===b.dataset.gzp);if(!pl)return;const f=gzFits(pl);if(f.length===1){gzPlace(pl,f[0]);return}dr.sel=dr.sel===pl?null:pl;renderPanel();const s=p.querySelector(".ps.fit");if(s)s.focus()});
  p.querySelectorAll("[data-gzslot]").forEach(b=>b.onclick=()=>{if(!dr.sel)return;const i=+b.dataset.gzslot;if(gzFits(dr.sel).includes(i))gzPlace(dr.sel,i)});
  if(dr.phase==="done")renderCupBox()}
function renderCupBox(){const el=document.getElementById("cupBox");if(!el||!dr)return;const g=gzStrength(dr.picks),weak=dr.picks.reduce((a,p)=>p.r<a.r?p:a,dr.picks[0]);
  el.innerHTML=`<span class="label">${t("Your XI")}</span><div class="ovr" style="margin-top:8px"><span class="big">${g.str.toFixed(1)}</span><dl><dt>${t("Team strength")}</dt><dd>${t("65% average, 35% weakest")}</dd><dt>${t("Avg rating")}</dt><dd>${g.avg.toFixed(1)}</dd><dt>${t("Weakest")}</dt><dd>${esc(weak.short)} · ${weak.r}</dd><dt>${t("Seasons spun")}</dt><dd>${dr.spun.length}</dd></dl></div>
   <h3 style="margin-top:10px">${t(tier(g.str))}</h3><p class="gnote">${t("Pick a season below and play it through.")}</p>`;
  const host=el.closest(".draft");if(!host)return;szRender("football",szArea(host),g.str,t("Your XI"),()=>{szS.football=null;newDraft();renderPanel()})}
