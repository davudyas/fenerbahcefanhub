/* ===== v13: calendar file, fan league, player ratings, season board, challenges, career mode, records, Europe, match pages ===== */
const BR_CODE={football:"FB",basketball:"MB","womens-basketball":"WB",volleyball:"WV","mens-volleyball":"MV","womens-football":"WF"};
const BR_OF_CODE=Object.fromEntries(Object.entries(BR_CODE).map(([b,c])=>[c,b]));
const p2=v=>String(v).padStart(2,"0");

/* ---------- new tabs: Records (all branches) and In Europe (football) ---------- */
EXT.tabs.push((id,T)=>{if(id==="more")return;const i=T.findIndex(x=>x[0]==="trophies");if(RECORDS[id])T.splice(i+1,0,["records","Records"]);if(id==="football")T.splice(i+2,0,["europe","In Europe"])});
EXT.panels.records=p=>renderRecords(p);
EXT.panels.europe=p=>renderEurope(p);
EXT.afterPanel.push(p=>{if(tab==="matches")matchesExtras(p)});

/* ---------- Records ---------- */
function renderRecords(p){const R=RECORDS[current],s=SPORTS[current];
  const facts=`<div class="recfacts">${R.facts.map(([v,k,d])=>`<article class="card recfact"><b class="rv">${esc(v)}</b><h3>${esc(t(k))}</h3><p>${esc(t(d))}</p></article>`).join("")}</div>`;
  const lists=(R.lists||[]).map(L=>`<article class="card reclist"><span class="label">${esc(t(L.title))}</span><p class="fine">${esc(t(L.note))}</p><ol>${L.rows.map(([n,y,v],i)=>`<li><span class="rk">${i+1}</span><span class="nm"><button class="pname" data-player="${esc(n)}">${esc(n)}</button><small>${esc(y)}</small></span><b>${v}</b></li>`).join("")}</ol><span class="fine">${esc(t(L.unit))}</span></article>`).join("");
  p.innerHTML=`<h2>${t("Records")} ${dchip("real")}</h2><p class="intro">${esc(tf("The numbers that stand out in the history of {x} at Fenerbahçe.",{x:lbl(s)}))}</p>${facts}${lists?`<div class="reclists">${lists}</div>`:""}
   ${R.src?`<p class="fine srcs">${t("Sources")}: ${R.src.map(([n,u])=>`<a href="${u}" target="_blank" rel="noopener">${esc(n)}</a>`).join(" · ")}</p>`:""}`}

/* match reports: a plain English string, or {en,tr,de,es,fr,ar} written by the data refresh */
const repTxt=r=>!r?"":typeof r==="string"?t(r):(r[LANG]||r.en||"");
/* ---------- In Europe (football) ---------- */
const EU_COMP={EC:"European Cup",CWC:"Cup Winners' Cup",UC:"UEFA Cup",UCL:"Champions League",UEL:"Europa League",UECL:"Conference League"};
const euSc=s=>s==="–"||!s?null:s.split("-").map(Number);
function euTie(r){const [,,,,,h,a,ex]=r,H=euSc(h),A=euSc(a);
  if(/^G\d/.test(ex))return {k:"grp",txt:tf("Group: {p}",{p:ordL(+ex.slice(1))})};
  if(/^L\d/.test(ex))return {k:"grp",txt:tf("League phase: {p}",{p:ordL(+ex.slice(1))})};
  const f=(H?H[0]:0)+(A?A[0]:0),o=(H?H[1]:0)+(A?A[1]:0);let win=f>o,how="";
  if(/^replay/.test(ex)){const x=ex.split(" ")[1].split("-").map(Number);win=x[0]>x[1];how=tf("replay {s}",{s:ex.split(" ")[1].replace("-","–")})}
  else if(/^pens/.test(ex)){const x=ex.split(" ")[1];win=ex.startsWith("pens ");how=tf("{s} on penalties",{s:x.replace("-","–")})}
  else if(ex==="away"){win=true;how=t("away goals")}else if(ex==="awayout"){win=false;how=t("away goals")}
  return {k:win?"W":"L",agg:`${f}–${o}`,txt:t(win?"Through":"Out"),how}}
function euRows(){const live=(LIVE.football.last||[]).filter(r=>r[1]==="Champions League"&&/^League phase/.test(r[6]||"")).reverse().map(r=>["2026–27","UCL","League phase",r[3],"",r[2]==="H"?`${r[4]}-${r[5]}`:"–",r[2]==="A"?`${r[4]}-${r[5]}`:"–","LIVE"]);return EU_TIES.concat(live)}
let euQ="",euC="All",euAll=false;
function renderEurope(p){const rows=euRows(),q=sn(euQ),list=rows.filter(r=>(euC==="All"||r[1]===euC||(euC==="UEL"&&r[1]==="UC")||(euC==="UCL"&&r[1]==="EC"))&&(!q||sn(r[3]+" "+r[4]+" "+r[0]).includes(q)));
  const tot=EU_TOTAL.reduce((a,r)=>a.map((v,i)=>v+(r[i+1]||0)),[0,0,0,0,0,0]),seasons=new Set(EU_TIES.map(r=>r[0])).size;
  const bySeason=[];list.forEach(r=>{let g=bySeason.find(x=>x.s===r[0]);if(!g){g={s:r[0],rows:[]};bySeason.push(g)}g.rows.push(r)});bySeason.reverse();const cut=!euAll&&!q&&euC==="All"&&bySeason.length>8,shownS=cut?bySeason.slice(0,8):bySeason;
  const opp=q&&list.length?(()=>{let W=0,D=0,L=0,F=0,A=0;list.forEach(r=>[r[5],r[6]].forEach(x=>{const s=euSc(x);if(!s)return;F+=s[0];A+=s[1];s[0]>s[1]?W++:s[0]<s[1]?L++:D++}));return `<p class="msg">${tf("Against your search: {p} games, {w} won, {d} drawn, {l} lost, goals {f}–{a}.",{p:W+D+L,w:W,d:D,l:L,f:F,a:A})}</p>`})():"";
  p.innerHTML=`<h2>${t("In Europe")} ${dchip("real")}</h2><p class="intro">${tf("Every European tie since Fenerbahçe first entered the European Cup in 1959. {n} seasons in UEFA competitions.",{n:seasons})}</p>
   <div class="msum">${[[tot[0],"Games"],[tot[1],"Won"],[tot[2],"Drawn"],[tot[3],"Lost"],[`${tot[4]}–${tot[5]}`,"Goals"]].map(([v,k])=>`<div class="mstat"><b>${v}</b><span>${esc(t(k))}</span></div>`).join("")}</div>
   <p class="fine">${t("Totals for UEFA competitions up to 27 August 2026, before this season's league phase.")}</p>
   <div class="eubar"><input id="euQ" type="search" placeholder="${t("Search an opponent, country or season…")}" aria-label="${t("Search an opponent, country or season…")}" value="${esc(euQ)}">
   <div class="filter" role="group" aria-label="${t("Competition")}">${[["All","All"],["UCL","European Cup / Champions League"],["UEL","UEFA Cup / Europa League"],["CWC","Cup Winners' Cup"],["UECL","Conference League"]].map(([k,l])=>`<button data-euc="${k}" aria-pressed="${k===euC}">${esc(t(l))}</button>`).join("")}</div></div>${opp}
   <div class="eulist">${shownS.map(g=>`<section class="card euseason"><h3><bdi>${g.s}</bdi></h3><table class="eut"><thead><tr><th>${t("Round")}</th><th>${t("Opponent")}</th><th>${t("Home")}</th><th>${t("Away")}</th><th></th></tr></thead><tbody>${g.rows.map(r=>{const T=r[7]==="LIVE"?{k:"grp",txt:t("This season")}:euTie(r);
     return `<tr><td><span class="label">${esc(t(EU_COMP[r[1]==="EC"?"EC":r[1]]))}</span><br>${esc(t(r[2]))}</td><td><b>${esc(r[3])}</b>${r[4]?`<small>${esc(t(r[4]))}</small>`:""}</td><td class="sc" data-l="${esc(t("Home"))}">${r[5].replace("-","–")}</td><td class="sc" data-l="${esc(t("Away"))}">${r[6].replace("-","–")}</td><td>${T.k==="grp"?`<span class="muted">${esc(T.txt)}</span>`:`<span class="chip ${T.k==="W"?"win":"loss"}">${esc(T.txt)}</span><small>${T.agg}${T.how?" · "+esc(T.how):""}</small>`}</td></tr>`}).join("")}</tbody></table></section>`).join("")||`<p class="muted">${t("Nothing found.")}</p>`}</div>${cut?`<button class="btn ghost" data-euall>${tf("Show all {n} seasons",{n:bySeason.length})}</button>`:""}
   <p class="fine srcs">${t("Sources")}: <a href="https://en.wikipedia.org/wiki/Fenerbah%C3%A7e_S.K._in_European_football" target="_blank" rel="noopener">Wikipedia: Fenerbahçe S.K. in European football</a>. ${t("Scores are shown with Fenerbahçe first.")}</p>`;
  const inp=$("euQ");let tm;inp.oninput=()=>{clearTimeout(tm);tm=setTimeout(()=>{euQ=inp.value;const pos=inp.selectionStart;renderEurope(p);const n=$("euQ");n.focus();try{n.setSelectionRange(pos,pos)}catch(e){}},180)};
  p.querySelectorAll("[data-euc]").forEach(b=>b.onclick=()=>{euC=b.dataset.euc;renderEurope(p)});const ea=p.querySelector("[data-euall]");if(ea)ea.onclick=()=>{euAll=true;renderEurope(p)}}

/* ---------- Match pages ---------- */
document.addEventListener("click",e=>{const m=e.target.closest("[data-mi]");if(!m||e.target.closest("a,button:not([data-mi])"))return;matchPage(m.dataset.mb||current,+m.dataset.mi)});
document.addEventListener("keydown",e=>{if((e.key==="Enter"||e.key===" ")&&e.target.matches&&e.target.matches("[data-mi]")){e.preventDefault();matchPage(e.target.dataset.mb||current,+e.target.dataset.mi)}});
function matchPage(b,i){matchPageRaw(b,i);runExt("matchPage",b,i)}
/* highlights: an official video page when the data refresh found one (details.hl = [[source, url], ...]),
   otherwise a YouTube search. Videos open on the broadcaster's own site; this page can't play them itself. */
const PLAY_ICON='<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="11" fill="currentColor" opacity=".18"/><path d="M10 8l6 4-6 4z" fill="currentColor"/></svg>';
function mpHighlights(b,r,d,T1,T2,s1,s2){const hl=(d.hl||[]).filter(x=>x&&/^https:\/\//.test(x[1]));
  const q=`${T1} ${s1}-${s2} ${T2} ${{basketball:"basketbol ","womens-basketball":"kadın basketbol ",volleyball:"kadın voleybol ","mens-volleyball":"erkek voleybol ","womens-football":"kadın futbol "}[b]||""}maç özeti ${String(r[0]||"").slice(0,4)}`.replace(/\s+/g," ").trim();
  const yt="https://www.youtube.com/results?search_query="+encodeURIComponent(q);
  return `<section class="mphl"><h4 class="mh">${t("Highlights")}</h4><div class="btns">${hl.map(([n,u])=>`<a class="btn hlbtn" href="${esc(u)}" target="_blank" rel="noopener">${PLAY_ICON}${esc(tf("Watch on {s}",{s:n}))} ↗</a>`).join("")}
    <a class="btn ${hl.length?"ghost":""} hlbtn" href="${yt}" target="_blank" rel="noopener">${PLAY_ICON}${t(hl.length?"More on YouTube":"Find highlights on YouTube")} ↗</a></div>
    <p class="fine">${t(hl.length?"Opens the broadcaster's page in a new tab.":"Opens a YouTube search in a new tab. Pick a video from an official channel, such as the club, the league or the broadcaster.")}</p></section>`}
function matchPageRaw(b,i){const L=LIVE[b];if(!L)return;const r=L.last[i];if(!r)return;const d=r[7]||{},o=outcome(r),home=r[2]!=="A",key=xKey(b,r[0],r[3]);
  const T1=home?"Fenerbahçe":r[3],T2=home?r[3]:"Fenerbahçe",s1=home?r[4]:r[5],s2=home?r[5]:r[4];
  const scl=(list)=>list&&list.length?`<ul class="scorers">${list.map(([n,m])=>`<li><bdi>${esc(n)}</bdi>${m?` <bdi class="muted">${esc(m)}</bdi>`:""}</li>`).join("")}</ul>`:"";
  const fbS=scl(d.fb),opS=scl(d.op),sc1=home?fbS:opS,sc2=home?opS:fbS;
  /* fans */
  const preds=Object.values(xAllDocs("predictions",xPreds(),"p")).map(p=>p&&p[key]).filter(Boolean),exact=preds.filter(([a,c])=>a===+r[4]&&c===+r[5]).length,right=preds.filter(([a,c])=>Math.sign(a-c)===Math.sign(r[4]-r[5])).length;
  const votes={};Object.values(xAllDocs("motm",xVotes(),"v")).forEach(v=>{if(v&&v[key])votes[v[key]]=(votes[v[key]]||0)+1});const topV=Object.entries(votes).sort((a,c)=>c[1]-a[1]).slice(0,3);
  const avg=ratingAverages(key).slice(0,5);
  const fans=[preds.length?`<p>${tf(preds.length===1?"1 fan predicted this match: {r} got the result right, {e} the exact score.":"{n} fans predicted this match: {r} got the result right, {e} the exact score.",{n:preds.length,r:right,e:exact})}</p>`:"",
    topV.length?`<p><b>${t("Player of the match vote")}:</b> ${topV.map(([n,c])=>`${esc(n)} (${c})`).join(", ")}</p>`:"",
    avg.length?`<p><b>${t("Best fan ratings")}:</b> ${avg.map(x=>`${esc(x.n)} ${x.a.toFixed(1)}`).join(", ")}</p>`:""].join("");
  const nav=`<div class="btns mpnav">${L.last[i+1]?`<button class="btn ghost" data-mpgo="${i+1}">← ${t("Previous match")}</button>`:""}${i>0?`<button class="btn ghost" data-mpgo="${i-1}">${t("Next match")} →</button>`:""}</div>`;
  ovOpen(`<article class="mp"><span class="label">${esc(t(SPORTS[b].label))} · ${esc(t(r[1]))}${r[6]&&r[0]?" · "+esc(t(r[6])):""}</span>
    <div class="mpscore"><div class="${T1==="Fenerbahçe"?"fb":""}"><b>${esc(T1)}</b>${sc1}</div><div class="mpres"><span>${s1}<em>–</em>${s2}</span><span class="fo ${o}">${t("res:"+o)}</span></div><div class="${T2==="Fenerbahçe"?"fb":""}"><b>${esc(T2)}</b>${sc2}</div></div>
    <dl class="ppfacts"><div><dt>${t("Date")}</dt><dd>${r[0]?mDate(r[0]):"–"}</dd></div><div><dt>${t("Venue")}</dt><dd>${esc(d.v||(r[2]==="H"&&VENUES[b]?VENUES[b].name:t(r[2]==="A"?"Away":"Neutral venue")))}</dd></div><div><dt>${t("Competition")}</dt><dd>${esc(t(r[1]))}</dd></div></dl>
    ${d.rep?`<section><h4 class="mh">${t("Match report")}</h4><p>${esc(repTxt(d.rep))}</p>${d.src?`<p class="fine">${t("Source")}: <a href="${d.src[1]}" target="_blank" rel="noopener">${esc(d.src[0])}</a></p>`:""}</section>`:`<section><p class="fine">${t("Scorers and a report are added for the latest football matches when the site is refreshed.")}</p></section>`}
    ${mpHighlights(b,r,d,T1,T2,s1,s2)}
    ${fans?`<section><h4 class="mh">${t("What the fans said")}</h4>${fans}</section>`:""}${nav}</article>`,`${T1} ${s1}–${s2} ${T2}`);
  document.querySelectorAll("[data-mpgo]").forEach(x=>x.onclick=()=>matchPage(b,+x.dataset.mpgo))}

/* ---------- Matches tab extras: calendar file, player ratings ---------- */
function matchesExtras(p){const L=LIVE[current];if(!L)return;const up=L.next.filter(n=>n[0]&&n[0]>=todayISO());
  if(up.length&&!p.querySelector(".calall"))p.insertAdjacentHTML("beforeend",`<article class="card calall"><div><span class="label">${t("Calendar")}</span><h3>${tf("All {n} upcoming fixtures in one file",{n:up.length})}</h3><p class="muted">${t("A CSV file you can import into Google Calendar or Outlook. Times are converted to your time zone.")}</p></div><button class="btn ghost" data-calcsv="${current}" ${XC.dl?"":"disabled"}>${t("Download fixtures (CSV)")}</button>${XC.dl?"":`<p class="fine">${t("Downloads aren't available in this view.")}</p>`}</article>`)}
document.addEventListener("click",e=>{const c=e.target.closest("[data-calcsv]");if(c)saveFixturesCsv(c.dataset.calcsv,c)});
function fixturesCsv(brs){const today=todayISO(),q=v=>`"${String(v).replace(/"/g,'""')}"`,us=d=>`${p2(d.getMonth()+1)}/${p2(d.getDate())}/${d.getFullYear()}`,tm=d=>{let h=d.getHours(),ap=h>=12?"PM":"AM";h=h%12||12;return `${p2(h)}:${p2(d.getMinutes())} ${ap}`};
  const rows=[["Subject","Start Date","Start Time","End Date","End Time","All Day Event","Location","Description"]];
  brs.forEach(b=>(LIVE[b]?LIVE[b].next:[]).forEach(n=>{if(!n[0]||n[0]<today)return;const [Y,M,D]=n[0].split("-").map(Number),subj=(n[3]==="H"?`Fenerbahçe – ${n[4]}`:`${n[4]} – Fenerbahçe`)+` (${t(SPORTS[b].label)}, ${t(n[2])})`;
    if(n[1]){const [h,mi]=n[1].split(":").map(Number),s=new Date(Date.UTC(Y,M-1,D,h-3,mi)),e=new Date(s.getTime()+2*36e5);rows.push([subj,us(s),tm(s),us(e),tm(e),"False",n[3]==="H"&&VENUES[b]?VENUES[b].name:"",t("Unofficial Fenerbahçe fan page")])}
    else{const s=new Date(Y,M-1,D);rows.push([subj,us(s),"",us(s),"","True","",t("Kick-off time to be confirmed")])}}));
  return rows.map(r=>r.map(q).join(",")).join("\r\n")}
async function saveFixturesCsv(which,btn){if(!XC.dl)return;btn.disabled=true;const brs=which==="all"?HOME_BR:[which];
  try{await XC.dl.save({filename:`fenerbahce-fixtures-${which}.csv`,data:"﻿"+fixturesCsv(brs)})}catch(e){if(e&&e.code&&!["declined","rate_limited"].includes(e.code))xToast(t("Downloads aren't available in this view."))}btn.disabled=false}

/* player ratings (1–10) for the latest match */
const xRates=()=>store.get("fb-ratings",{});
function ratingAverages(key){const all=xAllDocs("ratings",xRates(),"r"),sum={};Object.values(all).forEach(m=>{const x=m&&m[key];if(!x)return;Object.entries(x).forEach(([n,v])=>{v=+v;if(!(v>=1&&v<=10))return;const s=sum[n]||(sum[n]={n,t:0,c:0});s.t+=v;s.c++})});
  return Object.values(sum).map(s=>({n:s.n,a:s.t/s.c,c:s.c})).sort((a,b)=>b.a-a.a||b.c-a.c)}
EXT.comm.push(()=>{const el=document.getElementById("commBox");if(!el)return;const L=XM.L,li=L.last.findIndex(r=>r[0]),last=L.last[li];if(!last)return;
  const key=xKey(current,last[0],last[3]),mine=xRates()[key]||{},avg=ratingAverages(key),names=motmNames(current).filter(n=>n&&n.length<40);
  const card=document.createElement("article");card.className="card commcard ratecard";
  card.innerHTML=`<span class="label">${t("Fan ratings")}</span><h3>${t("Rate the players")}</h3><p class="muted">${tf("Give the players a mark from 1 to 10 for Fenerbahçe {a}–{b} {o}.",{a:last[4],b:last[5],o:esc(last[3])})} <button class="linkbtn" data-mi="${li}" data-mb="${current}">${t("Match details")} →</button></p>
   ${avg.length?`<ol class="tally rates">${avg.slice(0,8).map(x=>`<li><span>${esc(x.n)}</span><i style="width:${x.a*10}%"></i><b>${x.a.toFixed(1)}</b><small>${tf(x.c===1?"1 vote":"{n} votes",{n:x.c})}</small></li>`).join("")}</ol>`:`<p class="fine">${t("No ratings yet. Be the first to rate the players.")}</p>`}
   <details ${Object.keys(mine).length?"":"open"}><summary>${t(Object.keys(mine).length?"Change your ratings":"Your ratings")}</summary><div class="rategrid">${names.map((n,i)=>`<label><span>${esc(n)}</span><select data-rate="${i}"><option value="">–</option>${[...Array(10)].map((_,k)=>`<option ${+mine[n]===k+1?"selected":""}>${k+1}</option>`).join("")}</select></label>`).join("")}</div>
   <div class="btns"><button class="btn" id="rSave">${t("Save ratings")}</button></div></details>`;
  el.querySelector(".comm").appendChild(card);
  card.querySelector("#rSave").onclick=async()=>{const R=xRates(),m={};card.querySelectorAll("[data-rate]").forEach(s=>{if(s.value)m[names[+s.dataset.rate]]=+s.value});if(!Object.keys(m).length)return;R[key]=m;
    const keys=Object.keys(R);if(keys.length>40)keys.slice(0,keys.length-40).forEach(k=>delete R[k]);store.set("fb-ratings",R);xFillComm();await xWrite("ratings",{r:R,ts:Date.now()});xFillComm();xBadgeCheck()}});

/* ---------- Club home: fan league + calendar + clickable results ---------- */
EXT.home.push(p=>{
  p.querySelectorAll(".hcard").forEach(c=>{const b=c.querySelector("[data-gosport]").dataset.gosport,L=LIVE[b];if(!L)return;const li=L.last.findIndex(r=>r[0]);const dd=c.querySelectorAll(".hrows dd")[1];if(dd&&li>=0){dd.classList.add("mclick");dd.dataset.mi=li;dd.dataset.mb=b;dd.tabIndex=0;dd.setAttribute("role","button")}});
  const fx=p.querySelector(".hfx");if(fx)fx.insertAdjacentHTML("afterend",`<div class="btns"><button class="btn ghost" data-calcsv="all" ${XC.dl?"":"disabled"}>${t("Download all fixtures (CSV)")}</button></div>`);
  const more=p.querySelector(".hmore");more.insertAdjacentHTML("beforebegin",`<section id="leagueBox" class="league"></section>`);fillLeague()});
let lgB="all",lgP="all";
/* "week": matches played in the last 7 days */
const lgCut=()=>{const d=new Date(Date.now()-6*864e5);return d.toISOString().slice(0,10)};
function lgTable(b,per){const R=xResults(),all=xAllDocs("predictions",xPreds(),"p"),cut=per==="week"?lgCut():"";return Object.entries(all).map(([id,p])=>{let pts=0,n=0,ex=0,rt=0;Object.entries(p||{}).forEach(([k,v])=>{if(b!=="all"&&!k.startsWith(b+"|"))return;if(cut&&k.split("|")[1]<cut)return;const s=xPoints(v,R[k]);if(s!=null){n++;pts+=s;if(s===3)ex++;if(s>=1)rt++}});return {id,pts,n,ex,rt}}).filter(r=>r.n>0).sort((a,b)=>b.pts-a.pts||b.ex-a.ex||a.n-b.n)}
function fillLeague(){const box=$("leagueBox");if(!box)return;const f=document.activeElement;if(f&&box.contains(f)&&f.tagName==="INPUT")return;
  const rows=lgTable(lgB,lgP),wk=lgTable("all","week")[0];xNames(rows.concat(wk?[wk]:[]).map(r=>r.id).filter(i=>i!=="me"));const P=xPreds(),R=xResults(),now=Date.now();
  const nameOf=r=>r.id==="me"?t("You"):xName(r.id);
  const open=[];HOME_BR.forEach(b=>{(LIVE[b]?LIVE[b].next:[]).filter(n=>n[0]).slice(0,2).forEach(n=>{const [Y,M,D]=n[0].split("-").map(Number),[h,mi]=(n[1]||"12:00").split(":").map(Number);if(now<Date.UTC(Y,M-1,D,h-3,mi))open.push({b,n})})});
  open.sort((a,c)=>(a.n[0]+a.n[1]).localeCompare(c.n[0]+c.n[1]));
  const mine=Object.entries(P).filter(([k])=>R[k]).map(([k,v])=>{const [b,d,o]=k.split("|");return {b,d,o,v,res:R[k],pts:xPoints(v,R[k])}}).sort((a,c)=>c.d.localeCompare(a.d)).slice(0,6);
  box.innerHTML=`<h3 class="mh" style="margin-top:28px">${t("Fan prediction league")}</h3><p class="intro">${t("Predict any upcoming Fenerbahçe match. 3 points for the exact score, 1 for the right result. The table counts every branch.")}</p><p class="livenote" data-livenote></p>
   ${wk&&wk.pts>0?`<p class="lgstar"><span aria-hidden="true">★</span> ${esc(tf("Top predictor of the last 7 days: {n}, with {p} points.",{n:nameOf(wk),p:wk.pts}))}</p>`:""}
   <div class="lggrid"><article class="card"><span class="label">${t("Table")}</span><select id="lgSel" class="lgsel" aria-label="${t("Branch")}">${["all",...HOME_BR].map(b=>`<option value="${b}" ${b===lgB?"selected":""}>${esc(b==="all"?t("All branches"):t(SPORTS[b].label))}</option>`).join("")}</select>
     <div class="filter lgper" role="group" aria-label="${t("Period")}"><button data-lgp="all" aria-pressed="${lgP==="all"}">${t("Whole season")}</button><button data-lgp="week" aria-pressed="${lgP==="week"}">${t("Last 7 days")}</button></div>
     ${rows.length?`<ol class="ptable big">${rows.slice(0,15).map((r,i)=>`<li class="${r.id===XC.me||r.id==="me"?"me":""}" data-uid="${esc(r.id)}"><span class="rk">${i+1}</span><span class="nm">${esc(r.id==="me"?t("You"):xName(r.id))}</span><span class="muted">${tf("{n} played · {e} exact",{n:r.n,e:r.ex})}</span><b>${r.pts}</b></li>`).join("")}</ol>${XC.dl?`<div class="btns"><button class="btn ghost sm" data-lgshare>${t("Save the table as an image")}</button></div>`:""}`
       :`<p class="empty">${t(!Object.keys(P).length?"Nobody is on the table yet. Be the first: predict one of the next games.":lgP==="week"?"None of your predicted matches were played in the last 7 days.":"Points appear once a predicted match has been played.")}</p>`}</article>
    <article class="card"><span class="label">${t("Predict the next games")}</span>${open.length?`<ul class="lgpred">${open.slice(0,8).map(({b,n})=>{const k=xKey(b,n[0],n[4]),m=P[k],hm=n[3]==="H",inp=(w,v)=>`<input type="number" min="0" max="199" inputmode="numeric" data-lgk="${esc(k)}" data-lgw="${w}" value="${v==null?"":v}" aria-label="${esc(w==="f"?"Fenerbahçe":n[4])}">`;
       return `<li style="--br:${BR_ACCENT[b]}"><div><span class="label">${mDate(n[0],true)}${n[1]?" · "+n[1]:""} · ${esc(t(SPORTS[b].label))}</span><b>${esc(hm?"Fenerbahçe":n[4])} – ${esc(hm?n[4]:"Fenerbahçe")}</b></div><div class="lgin">${hm?inp("f",m&&m[0])+"<span>–</span>"+inp("o",m&&m[1]):inp("o",m&&m[1])+"<span>–</span>"+inp("f",m&&m[0])}</div></li>`}).join("")}</ul>
       <div class="btns"><button class="btn" id="lgSave">${t("Save predictions")}</button><span class="msg" id="lgMsg" aria-live="polite"></span></div>`:`<p class="fine">${t("No upcoming fixtures in this snapshot.")}</p>`}</article>
    <article class="card"><span class="label">${t("Your recent predictions")}</span>${mine.length?`<ul class="lgmine">${mine.map(x=>`<li><span>${esc(t(SPORTS[x.b].label))} · ${esc(x.o)}</span><span class="muted">${tf("You said {a}–{b}, it ended {c}–{d}",{a:x.v[0],b:x.v[1],c:x.res[0],d:x.res[1]})}</span><b class="${x.pts===3?"good":x.pts?"":"muted"}">${tf(x.pts===1?"1 pt":"{n} pts",{n:x.pts})}</b></li>`).join("")}</ul>`:`<p class="fine">${t("Your scored predictions will show here.")}</p>`}</article></div>`;
  const ls=$("lgSel");if(ls)ls.onchange=()=>{lgB=ls.value;fillLeague()};
  box.querySelectorAll("[data-lgp]").forEach(x=>x.onclick=()=>{lgP=x.dataset.lgp;fillLeague();const f=box.querySelector(`[data-lgp="${lgP}"]`);if(f)f.focus()});
  const sh=box.querySelector("[data-lgshare]");if(sh)sh.onclick=e=>xShare({title:t("Fan prediction league"),sub:(lgB==="all"?t("All branches"):t(SPORTS[lgB].label))+" · "+t(lgP==="week"?"Last 7 days":"Whole season"),rows:rows.slice(0,8).map((r,i)=>[i+1,nameOf(r),r.pts])},e.currentTarget);
  if(typeof paintLiveNotes==="function")paintLiveNotes();
  const sv=$("lgSave");if(sv)sv.onclick=async()=>{const P2=xPreds(),pend={};box.querySelectorAll("[data-lgk]").forEach(i=>{const k=i.dataset.lgk;(pend[k]=pend[k]||{})[i.dataset.lgw]=i.value});
    let n=0;Object.entries(pend).forEach(([k,v])=>{const a=parseInt(v.f,10),c=parseInt(v.o,10);if(isNaN(a)||isNaN(c)||a<0||c<0)return;P2[k]=[a,c];n++});if(!n){$("lgMsg").textContent=t("Fill in both scores for at least one match.");return}
    store.set("fb-preds",P2);await xWrite("predictions",{p:P2,ts:Date.now()});xBadgeCheck();fillLeague();const m=$("lgMsg");if(m)m.textContent=tf(n===1?"1 prediction saved.":"{n} predictions saved.",{n})}}

/* ---------- Challenges: same options and same luck for everyone with the code ---------- */
function chParse(code){const m=String(code||"").trim().toUpperCase().match(/^(FB|MB|WB|WV|MV|WF)-(\d{2})-(\d{4,6})$/);if(!m)return null;const b=BR_OF_CODE[m[1]],y=2000+(+m[2]),season=`${y}-${String(y+1).slice(2)}`;
  if(!SZ_DATA[b]||!SZ_DATA[b][season])return null;return {b,season,seed:+m[3],code:`${m[1]}-${m[2]}-${m[3]}`}}
function chStart(c){CH={...c,rd:szRng(c.seed*7+1),rs:null};const b=c.b;szS[b]={sel:c.season};if(CR[b])CR[b]=null;if(b==="football"){clearInterval(cupTimer);newDraft(dr?dr.form:"4-3-3")}else newTD(b);store.set("fb-ch-last",c.code);renderPanel()}
const xChs=()=>store.get("fb-ch",{});
function chBox(){const b=current,code=CH&&CH.b===b?CH.code:null,res=code?chResults(code):[];xNames(res.map(r=>r.id).filter(i=>i!=="me"));
  return `<section class="card chbox" id="chBox"><div class="chhead"><span class="label">${t("Challenge a friend")}</span>${code?`<h3>${esc(code)}</h3><p class="muted">${tf("Season {s}. Everyone who plays this code gets the same draft options and the same luck in the games.",{s:szDash(CH.season)})}</p>`:`<p class="muted">${t("Create a code and send it to a friend. You both draft from the same options and play the same season with the same luck. Then compare.")}</p>`}</div>
   ${code?`<div class="btns"><button class="btn ghost" data-ch="copy">${t("Copy the code")}</button><button class="btn ghost" data-ch="leave">${t("Leave the challenge")}</button></div>
     ${res.length?`<ol class="ptable">${res.map((r,i)=>`<li class="${r.id===XC.me||r.id==="me"?"me":""}" data-uid="${esc(r.id)}"><span class="rk">${i+1}</span><span class="nm">${esc(r.id==="me"?t("You"):xName(r.id))}</span><span class="muted">${tf("League: {p}",{p:ordL(r.pos)})} · ${r.r.toFixed(1)}</span><b>${r.t} 🏆</b></li>`).join("")}</ol>`:`<p class="fine">${t("Nobody has finished this season yet. Be the first.")}</p>`}`
   :`<div class="btns chrow"><button class="btn" data-ch="new">${t("Create a challenge")}</button><input id="chIn" placeholder="${t("Have a code? e.g. FB-17-48213")}" aria-label="${t("Challenge code")}" maxlength="14"><button class="btn ghost" data-ch="join">${t("Play this code")}</button></div><p class="msg" id="chMsg" aria-live="polite"></p>`}</section>`}
function chResults(code){const out={};Object.entries(XC.docs.challenges||{}).forEach(([id,d])=>{const x=d&&d.c&&d.c[code];if(x)out[id]=x});const mine=xChs()[code];if(mine)out[XC.me||"me"]=mine;
  return Object.entries(out).map(([id,x])=>({id,...x})).sort((a,b)=>b.t-a.t||a.pos-b.pos||b.pts-a.pts)}
function chWire(root){const on=(k,f)=>{const x=root.querySelector(`[data-ch="${k}"]`);if(x)x.onclick=f};
  on("new",()=>{const b=current,list=szAllSeasons(b),season=szS[b]&&szS[b].sel||list[list.length-1],y=season.slice(2,4),seed=10000+Math.floor(Math.random()*89999);chStart({b,season,seed,code:`${BR_CODE[b]}-${y}-${seed}`})});
  on("join",()=>{const c=chParse($("chIn").value);if(!c){$("chMsg").textContent=t("That code doesn't look right. It should look like FB-17-48213.");return}if(c.b!==current){playSel[c.b]=PLAY[c.b].find(x=>/^draft/.test(x[0]))[0];setSport(c.b,true)}chStart(c)});
  on("copy",async()=>{try{await navigator.clipboard.writeText(CH.code);xToast(t("Code copied. Send it to a friend!"))}catch(e){xToast(CH.code)}});
  on("leave",()=>{const b=CH.b;CH=null;szS[b]=null;renderPanel()})}
function chRecord(S){const tro=szTrophies(S).length,lg=S.C[0],pos=lg.pos||99,pts=(S.line&&S.line.length?S.line[S.line.length-1][0]:0),C=xChs(),prev=C[S.ch],cur={t:tro,pos,pts,r:Math.round(S.my.r*10)/10,ts:Date.now()};
  if(!prev||cur.t>prev.t||(cur.t===prev.t&&cur.pos<prev.pos)){C[S.ch]=cur;const ks=Object.keys(C);if(ks.length>30)ks.sort((a,b)=>C[a].ts-C[b].ts).slice(0,ks.length-30).forEach(k=>delete C[k]);store.set("fb-ch",C);xWrite("challenges",{c:C,ts:Date.now()})}
  store.set("fb-ch-done",store.get("fb-ch-done",0)+1)}

/* ---------- Season board, career mode, share card (all hang off the season view) ---------- */
const CR={};
const xSzBest=()=>store.get("fb-sz-rec",{});
function szBetter(a,b){return !b||a.t>b.t||(a.t===b.t&&a.pos<b.pos)}
function szRecordBest(S){const b=S.b,R=xSzBest(),cur={t:szTrophies(S).length,pos:S.C[0].pos||99,s:S.season,r:Math.round(S.my.r*10)/10,c:S.career?1:0,ts:Date.now()};if(szBetter(cur,R[b])){R[b]=cur;store.set("fb-sz-rec",R);xWrite("seasons",{b:R,ts:Date.now()})}}
function szBoard(b){const out={};Object.entries(XC.docs.seasons||{}).forEach(([id,d])=>{const x=d&&d.b&&d.b[b];if(x)out[id]=x});const m=xSzBest()[b];if(m)out[XC.me||"me"]=m;
  return Object.entries(out).map(([id,x])=>({id,...x})).sort((a,c)=>c.t-a.t||a.pos-c.pos||c.ts-a.ts).slice(0,8)}
function szLiveBoards(){const el=document.getElementById("szBoard");if(el){const b=el.dataset.b;el.outerHTML=szBoardHtml(b)}const c=document.getElementById("chBox");if(c&&CH&&CH.b===current){const w=document.createElement("div");w.innerHTML=chBox();c.replaceWith(w.firstElementChild);chWire($("chBox"))}}
function szBoardHtml(b){const rows=szBoard(b);xNames(rows.map(r=>r.id).filter(i=>i!=="me"));
  return `<article class="card szboard" id="szBoard" data-b="${b}"><span class="label">${t("Fans' best seasons")}</span>${rows.length?`<ol class="ptable">${rows.map((r,i)=>`<li class="${r.id===XC.me||r.id==="me"?"me":""}" data-uid="${esc(r.id)}"><span class="rk">${i+1}</span><span class="nm">${esc(r.id==="me"?t("You"):xName(r.id))}</span><span class="muted">${szDash(r.s)} · ${tf("League: {p}",{p:ordL(r.pos)})}${r.c?" · "+t("career"):""}</span><b>${r.t} 🏆</b></li>`).join("")}</ol>${XC.dl?`<div class="btns"><button class="btn ghost sm" data-szshare="${b}">${t("Save the board as an image")}</button></div>`:""}`:`<p class="empty">${t("Nobody is on this board yet. Finish a season and be the first.")}</p>`}</article>`}
document.addEventListener("click",e=>{const x=e.target.closest("[data-szshare]");if(!x)return;const b=x.dataset.szshare,rows=szBoard(b);xShare({title:t("Fans' best seasons"),sub:t(SPORTS[b].label),rows:rows.slice(0,8).map((r,i)=>[i+1,(r.id==="me"?t("You"):xName(r.id))+" · "+szDash(r.s),r.t+" ×"])},x)});
function crTeam(b){if(b==="football"&&dr){const info=teamInfo(dr.form,dr.picks,dr.captain);return dr.picks.map((p,i)=>({n:p.n,pos:p.pos,r:info.eff[i],r0:info.eff[i],src:p}))}
  const C=TDCFG[b],s=tdS[b];if(!C||!s)return null;const info=tdInfo(C,s.picks);return s.picks.map((p,i)=>({n:p.n,pos:p.pos,r:info.eff[i],r0:info.eff[i],src:p}))}
const crOvr=c=>c.ovr0+c.ps.reduce((a,p)=>a+(p.r-p.r0),0)/c.ps.length;
function crPool(b){return b==="football"?PLAYERS:TDCFG[b].pool}
function crOffseason(c){const age=c.hist.length;c.ch=c.ps.map(p=>{const d=Math.round((Math.random()*3.2-1.6-Math.min(age,6)*.35)*10)/10;p.r=Math.round(clamp(p.r+d,60,99)*10)/10;return {n:p.n,d}});
  const weak=c.ps.reduce((a,p,i)=>p.r<c.ps[a].r?i:a,0),wp=c.ps[weak],used=new Set(c.ps.map(p=>p.n)),pool=crPool(c.b).filter(p=>!used.has(p.n)&&p.pos===wp.pos);
  c.offer={i:weak,list:shuffle(pool).slice(0,3).map(p=>({n:p.n,pos:p.pos,r:p.r,src:p}))};c.off=true}
function crNextSeason(c){const list=szAllSeasons(c.b),i=list.indexOf(c.season);return list[i+1]||null}
function renderOffseason(b,el,myR,myName,onNew){const c=CR[b],nx=crNextSeason(c),o=c.offer;
  el.innerHTML=`<div class="szhead"><div><span class="label">${t("Career mode")} · ${t("Off-season")}</span><h3>${esc(c.name)} · ${crOvr(c).toFixed(1)}</h3></div><span class="muted">${tf(c.hist.length===1?"1 season played":"{n} seasons played",{n:c.hist.length})}</span></div>
   <div class="szgrid"><article class="card"><span class="label">${t("How your players changed")}</span><ul class="crch">${c.ch.map(x=>`<li><span>${esc(x.n)}</span><b class="${x.d>0?"good":x.d<0?"bad":""}">${x.d>0?"+":""}${x.d.toFixed(1)}</b></li>`).join("")}</ul><p class="fine">${t("Players get a little older every season. Most improve less and decline more as the years go by.")}</p></article>
    <article class="card"><span class="label">${t("Transfer window")}</span>${o&&o.list.length?`<p>${tf("Your weakest player is {n} ({r}). Bring in a replacement, or keep the squad.",{n:esc(c.ps[o.i].n),r:c.ps[o.i].r.toFixed(1)})}</p><div class="cands2">${o.list.map((p,k)=>`<button class="cand2" data-cro="${k}"><span class="r">${p.r}</span><span class="info"><b>${esc(p.n)}</b><small>${esc(p.pos)}</small></span><span></span></button>`).join("")}</div>`:`<p class="muted">${t("No new players available this summer.")}</p>`}<div class="btns"><button class="btn ghost" data-cro="keep">${t("Keep the squad")}</button></div></article>
    <article class="card"><span class="label">${t("Career so far")}</span>${crHist(c)}</article></div>
   <div class="btns">${nx?`<button class="btn" data-cr="go">${esc(tf("Start {s}",{s:szDash(nx)}))}</button>`:`<p class="msg">${t("You have reached the present day. What a career!")}</p>`}<button class="btn ghost" data-cr="end">${t("End the career")}</button></div>`;
  el.querySelectorAll("[data-cro]").forEach(x=>x.onclick=()=>{if(x.dataset.cro!=="keep"){const p=o.list[+x.dataset.cro],old=c.ps[o.i];c.ps[o.i]={n:p.n,pos:p.pos,r:p.r,r0:old.r0,src:p};xToast(tf("{a} joins, {b} leaves.",{a:p.n,b:old.n}))}c.offer=null;renderOffseason(b,el,myR,myName,onNew)});
  const on=(k,f)=>{const x=el.querySelector(`[data-cr="${k}"]`);if(x)x.onclick=f};
  on("go",()=>{c.off=false;c.season=nx;const S=szNewSeason(b,nx,crOvr(c),c.name);S.career=true;szS[b]={sel:nx,S};szRender(b,el,myR,myName,onNew)});
  on("end",()=>{const tot=c.hist.reduce((a,h)=>a+h.t,0),k=SK(b,"career-best");if(tot>store.get(k,0))store.set(k,tot);CR[b]=null;szS[b]=null;xBadgeCheck();szRender(b,el,myR,myName,onNew)})}
function crHist(c){return `<ol class="crhist">${c.hist.map(h=>`<li><span>${szDash(h.s)}</span><span class="muted">${tf("League: {p}",{p:ordL(h.pos)})}</span><b>${h.t} 🏆</b></li>`).join("")}</ol><p class="muted">${(n=>n===1?t("Total: 1 trophy"):tf("Total: {n} trophies",{n}))(c.hist.reduce((a,h)=>a+h.t,0))}</p>`}
EXT.szPre.push((b,el,myR,myName,onNew)=>{if(CR[b]&&CR[b].off){renderOffseason(b,el,myR,myName,onNew);return true}return false});
EXT.szAfter.push((...a)=>szAfter(...a));
function szAfter(b,el,myR,myName,onNew){const st=szS[b],S=st&&st.S;if(!S)return;
  if(S.career){["again","other","new"].forEach(k=>{const x=el.querySelector(`[data-sz="${k}"]`);if(x)x.remove()});const h=el.querySelector(".szhead .label");if(h)h.textContent=`${t("Career mode")} · ${szDash(S.season)}`;
    if(!S.done){const bt=el.querySelector(".btns");if(bt){bt.insertAdjacentHTML("beforeend",`<button class="btn ghost" data-cr="quit">${t("End the career")}</button>`);bt.querySelector('[data-cr="quit"]').onclick=()=>{const c=CR[b];if(c){const tot=c.hist.reduce((a,h)=>a+h.t,0),k=SK(b,"career-best");if(tot>store.get(k,0))store.set(k,tot)}CR[b]=null;szS[b]=null;szRender(b,el,myR,myName,onNew)}}}}
  if(!S.done)return;
  if(!S.recorded){S.recorded=true;szRecordBest(S);if(S.ch)chRecord(S);const c=CR[b];if(S.career&&c)c.hist.push({s:S.season,t:szTrophies(S).length,pos:S.C[0].pos||99});xBadgeCheck()}
  const c=CR[b],extra=document.createElement("div");extra.className="szextra";
  extra.innerHTML=`${S.career&&c?`<article class="card"><span class="label">${t("Career mode")}</span>${crHist(c)}<div class="btns"><button class="btn" data-cr="off">${t("Go to the off-season")}</button><button class="btn ghost" data-cr="end2">${t("End the career")}</button></div></article>`
     :!S.ch?`<article class="card"><span class="label">${t("Career mode")}</span><p>${t("Keep this team together for the next season, and the one after. Players age, and each summer you can sign a replacement.")}</p><div class="btns">${crNextSeason({b,season:S.season})?`<button class="btn" data-cr="start">${t("Start a career from here")}</button>`:`<span class="muted">${t("Careers start from an earlier season, since this is the latest one.")}</span>`}</div></article>`:""}
    ${szBoardHtml(b)}${XC.dl?`<article class="card"><span class="label">${t("Share")}</span><p>${t("Save a picture of your season to post or send.")}</p><div class="btns"><button class="btn ghost" data-cr="img">${t("Save result image")}</button></div></article>`:""}`;
  const sum=el.querySelector(".szsum");(sum||el.querySelector(".btns")).insertAdjacentElement("afterend",extra);
  const on=(k,f)=>{const x=extra.querySelector(`[data-cr="${k}"]`);if(x)x.onclick=f};
  on("start",()=>{const ps=crTeam(b);if(!ps)return;CR[b]={b,name:S.my.n,ps,ovr0:S.my.r,season:S.season,hist:[{s:S.season,t:szTrophies(S).length,pos:S.C[0].pos||99}]};crOffseason(CR[b]);szRender(b,el,myR,myName,onNew)});
  on("off",()=>{crOffseason(CR[b]);szRender(b,el,myR,myName,onNew)});
  on("end2",()=>{const tot=c.hist.reduce((a,h)=>a+h.t,0),k=SK(b,"career-best");if(tot>store.get(k,0))store.set(k,tot);CR[b]=null;szS[b]=null;xBadgeCheck();szRender(b,el,myR,myName,onNew)});
  on("img",e=>xShare(szCard(S),extra.querySelector('[data-cr="img"]')))}
function szCard(S){const tro=szTrophies(S),sc=Object.entries(S.scorers||{}).sort((a,b)=>b[1]-a[1])[0];
  return {title:`${t(SPORTS[S.b].label)} · ${szDash(S.season)}`,big:`${tro.length} 🏆`,sub:[tro.length?tro.map(x=>t(x)).join(" · "):t("No trophies this time"),tf("League: {p}",{p:ordL(S.C[0].pos||0)}),`${S.my.n} ${S.my.r.toFixed(1)}`,sc?`${t("Top scorer")}: ${sc[0]} ${sc[1]}`:"",S.ch?`${t("Challenge")} ${S.ch}`:"",S.career?t("Career mode"):""].filter(Boolean).join(" · ")}}

/* challenge box in the draft games */
EXT.play.push((p,g)=>{const ga=document.getElementById("gameArea");if(!ga||!/^draft/.test(g||""))return;const intro=ga.querySelector(".intro");
  const w=document.createElement("div");w.innerHTML=chBox();const box=w.firstElementChild;(intro||ga.querySelector("h2")).insertAdjacentElement("afterend",box);chWire(box)});

/* ---------- leaderboard, badges, helper, search ---------- */
EXT.collect.push(o=>{o.szt=Math.max(0,...HOME_BR.map(b=>store.get(SK(b,"sz-best"),0)));o.car=Math.max(0,...HOME_BR.map(b=>store.get(SK(b,"career-best"),0)))});
BOARDS.splice(BOARDS.length-1,0,["szt","Season mode · most trophies"],["car","Career mode · most trophies"]);
BADGES.push(["career","Dynasty","Win 5 or more trophies in one career.",()=>HOME_BR.some(b=>store.get(SK(b,"career-best"),0)>=5)],
 ["challenge","Game on","Finish a challenge season.",()=>store.get("fb-ch-done",0)>0],
 ["rater","Pundit","Rate the players after a match.",()=>Object.keys(xRates()).length>0]);
Object.assign(KAN_CHIPS_TAB,{records:["Who scored the most goals for the club?","What is the biggest win ever?","Who played the most games?"],europe:["What was the best European run?","How often have we played Manchester United?","What was the heaviest European defeat?"]});
EXT.kan.push((id,o)=>{if(RECORDS[id])o.records=RECORDS[id];if(id==="football")o.european_ties_fenerbahce_score_first=euRows().map(r=>r.slice(0,7).join(" | "))});
EXT.search.push(I=>{const seen=new Set();
  EU_TIES.forEach(r=>{if(seen.has(r[3]))return;seen.add(r[3]);const n=EU_TIES.filter(x=>x[3]===r[3]).length;I.push({kind:"e",label:`${r[3]} · ${t("In Europe")}`,sub:`${t(r[4])} · ${tf(n===1?"1 tie":"{n} ties",{n})}`,lab:sn(r[3]),hay:sn(r[3]+" "+r[4]+" europe avrupa "+EU_TIES.filter(x=>x[3]===r[3]).map(x=>x[0]+" "+x[5]+" "+x[6]).join(" ")),act:{b:"football",tb:"europe",i:r[3]},b:"football"})});
  Object.keys(RECORDS).forEach(b=>I.push({kind:"t",label:`${t("Records")} · ${t(SPORTS[b].label)}`,sub:RECORDS[b].facts.slice(0,2).map(f=>t(f[1])).join(" · "),lab:sn("records"),hay:sn("records rekorlar "+RECORDS[b].facts.map(f=>f[0]+" "+f[1]+" "+f[2]).join(" ")),act:{b,tb:"records"},b}))});
SKIND.e="In Europe";

/* ---------- Everyone's predictions, match by match: hidden as –:– until the match is over ---------- */
let lgM=null;
/* a match counts as over once its result is in, or two hours after kick-off (three hours for an unknown time) */
function lgOver(b,d,o,R){if(R[xKey(b,d,o)])return true;const L=LIVE[b],n=L&&L.next.find(x=>x[0]===d&&x[4]===o),[Y,M,D]=d.split("-").map(Number);
  const [h,mi]=((n&&n[1])||"21:00").split(":").map(Number);return Date.now()>=Date.UTC(Y,M-1,D,h-3,mi)+2*36e5}
function lgVenue(b,d,o){const L=LIVE[b];if(!L)return "H";const r=L.last.find(x=>x[0]===d&&x[3]===o);if(r)return r[2];const n=L.next.find(x=>x[0]===d&&x[4]===o);return n?n[3]:"H"}
function lgMatches(){const all=xAllDocs("predictions",xPreds(),"p"),R=xResults(),M={};
  Object.values(all).forEach(p=>Object.keys(p||{}).forEach(k=>{const [b,d,o]=k.split("|");if(!b||!d||!o||!SPORTS[b])return;(M[k]=M[k]||{k,b,d,o,n:0}).n++}));
  const L=Object.values(M);L.forEach(m=>m.over=lgOver(m.b,m.d,m.o,R));
  const past=L.filter(m=>m.over).sort((a,c)=>c.d.localeCompare(a.d)).slice(0,12),soon=L.filter(m=>!m.over).sort((a,c)=>a.d.localeCompare(c.d)).slice(0,8);return {past,soon}}
function lgAllHtml(){const {past,soon}=lgMatches(),list=past.concat(soon);
  if(!list.length)return `<span class="label">${t("Everyone's predictions")}</span><p class="fine">${t("Nobody has predicted a match yet.")}</p>`;
  if(!lgM||!list.some(m=>m.k===lgM))lgM=(past[0]&&(!soon[0]||past[0].d>=lgCut())?past[0]:soon[0]||past[0]).k;
  const m=list.find(x=>x.k===lgM),R=xResults(),res=R[m.k],hm=lgVenue(m.b,m.d,m.o)!=="A",all=xAllDocs("predictions",xPreds(),"p");
  const opt=x=>`<option value="${esc(x.k)}" ${x.k===lgM?"selected":""}>${esc(mDate(x.d,true)+" · "+x.o+" · "+t(SPORTS[x.b].label))}</option>`;
  const sel=`<select id="lgMSel" class="lgsel" aria-label="${esc(t("Match"))}">${past.length?`<optgroup label="${esc(t("Played"))}">${past.map(opt).join("")}</optgroup>`:""}${soon.length?`<optgroup label="${esc(t("Coming up"))}">${soon.map(opt).join("")}</optgroup>`:""}</select>`;
  const sc=v=>hm?`${v[0]}–${v[1]}`:`${v[1]}–${v[0]}`;
  const rows=Object.entries(all).filter(([,p])=>p&&p[m.k]).map(([id,p])=>({id,v:p[m.k],me:id===XC.me||id==="me",pts:res?xPoints(p[m.k],res):null}));
  xNames(rows.map(r=>r.id).filter(i=>i!=="me"));
  const nm=r=>r.me?t("You"):xName(r.id);
  if(m.over)rows.sort((a,c)=>(c.pts??-1)-(a.pts??-1)||nm(a).localeCompare(nm(c)));else rows.sort((a,c)=>(c.me-a.me)||nm(a).localeCompare(nm(c)));
  const head=`<p class="lgmhead"><b>${esc(hm?"Fenerbahçe":m.o)} – ${esc(hm?m.o:"Fenerbahçe")}</b><span class="muted">${m.over?(res?tf("Final score: {s}",{s:sc(res)}):t("Result not in yet")):t("Hidden until the final whistle")}</span></p>`;
  const note=`<p class="fine">${m.over?"":(rows.length===1?t("1 fan has predicted this match. Predictions are revealed after the final whistle."):tf("{n} fans have predicted this match. Predictions are revealed after the final whistle.",{n:rows.length}))}</p>`;
  const li=r=>{const show=m.over||r.me;return `<li class="${r.me?"me":""}" data-uid="${esc(r.id)}"><span class="nm">${esc(nm(r))}</span><b class="lgsc${show?"":" hid"}" ${show?"":`aria-label="${esc(t("Hidden until the final whistle"))}"`}>${show?sc(r.v):"–:–"}</b>${r.pts!=null?`<span class="lgpt ${r.pts===3?"good":r.pts?"":"muted"}">${tf(r.pts===1?"1 pt":"{n} pts",{n:r.pts})}</span>`:"<span></span>"}</li>`};
  return `<span class="label">${t("Everyone's predictions")}</span>${sel}${head}${rows.length?`<ul class="lgall">${rows.slice(0,40).map(li).join("")}</ul>`:`<p class="fine">${t("No predictions for this match yet.")}</p>`}${m.over?"":note}`}
function lgAddAll(){const box=$("leagueBox"),g=box&&box.querySelector(".lggrid");if(!g)return;let c=g.querySelector(".lgallc");if(!c){c=document.createElement("article");c.className="card lgallc";g.appendChild(c)}
  c.innerHTML=lgAllHtml();const s=c.querySelector("#lgMSel");if(s)s.onchange=()=>{lgM=s.value;lgAddAll();const n=$("lgMSel");if(n)n.focus()}}
{const _fl=fillLeague;fillLeague=function(){_fl();lgAddAll()}}
