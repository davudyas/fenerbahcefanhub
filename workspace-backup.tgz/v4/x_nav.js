/* ===== Finding your way: Play in groups, home page tabs, first-visit tour, settings (design, language, text size,
   quiz timer) and a plain note on which features are shared with other fans. ===== */

/* ---------- Play, in four groups ---------- */
const PLAY_GROUPS=[["quiz","Quizzes",["quiz","daily","wordle","who","which"]],["team","Teams & seasons",["draft","draft5","draft6","draft11","xi","lineup","squad"]],
 ["quick","Quick games",["penalties","ft","serve","timeline","hol","gts","memory"]],["friends","With friends",["live","board","badges"]]];
const playGrpOf=g=>(PLAY_GROUPS.find(x=>x[2].includes(g))||PLAY_GROUPS[2])[0];
const playLast=store.get("fb-playlast",{});
function playGroups(list){return PLAY_GROUPS.map(([k,l])=>[k,l,list.filter(x=>playGrpOf(x[0])===k)]).filter(x=>x[2].length)}
function pickGame(id){playSel[current]=id;playLast[current+"|"+playGrpOf(id)]=id;store.set("fb-playlast",playLast);store.set("fb-playsel",playSel);if(tab!=="play"){tab="play";syncHash();render()}else renderPanel()}
function renderPlayRaw(p){const list=PLAY[current];let g=playSel[current];if(!list.some(x=>x[0]===g))g=list[0][0];playSel[current]=g;
  const groups=playGroups(list),cur=groups.find(x=>x[0]===playGrpOf(g))||groups[0];
  p.innerHTML=`<div class="playnav"><div class="pgroups" role="tablist" aria-label="${t("Games")}">${groups.map(([k,l,xs])=>`<button role="tab" id="pg-${k}" aria-controls="pcards" aria-selected="${k===cur[0]}" tabindex="${k===cur[0]?0:-1}" data-pgrp="${k}">${esc(t(l))}<small aria-hidden="true">${xs.length}</small></button>`).join("")}</div>
   <div class="launcher" id="pcards" role="tabpanel" aria-labelledby="pg-${cur[0]}">${cur[2].map(([id,x,d])=>`<button class="lcard" aria-pressed="${id===g}" data-game="${id}"><b>${t(x)}</b><span>${t(d)}</span></button>`).join("")}</div>
   ${cur[0]==="friends"?`<p class="livenote" data-livenote></p>`:""}</div><div id="gameArea" class="gamearea"></div>`;
  p.querySelectorAll("[data-game]").forEach(x=>x.onclick=()=>{pickGame(x.dataset.game);const a=document.getElementById("gameArea");if(a&&a.getBoundingClientRect().top<0)a.scrollIntoView({block:"start"})});
  const tabsEl=[...p.querySelectorAll("[data-pgrp]")];
  tabsEl.forEach((x,i)=>{x.onclick=()=>{const G=groups.find(y=>y[0]===x.dataset.pgrp),keep=playLast[current+"|"+G[0]];pickGame(keep&&G[2].some(y=>y[0]===keep)?keep:G[2][0][0]);const f=document.querySelector(`[data-pgrp="${G[0]}"]`);if(f)f.focus()};
    x.onkeydown=e=>{const rtl=document.documentElement.dir==="rtl",d={ArrowRight:rtl?-1:1,ArrowLeft:rtl?1:-1,Home:-99,End:99}[e.key];if(d==null)return;e.preventDefault();const j=Math.max(0,Math.min(tabsEl.length-1,d===-99?0:d===99?tabsEl.length-1:i+d));tabsEl[j].click()}});
  /* keep the chosen card in view in the swipeable row (phones) without moving the page */
  const row=p.querySelector("#pcards"),on=row.querySelector('[aria-pressed="true"]');if(on&&row.scrollWidth>row.clientWidth+4){const r0=row.getBoundingClientRect(),r1=on.getBoundingClientRect();if(r1.left<r0.left||r1.right>r0.right)row.scrollLeft+=r1.left-r0.left-16}
  const ga=document.getElementById("gameArea");GAME_FN[g](ga);xAfterGame(g);paintLiveNotes()}

/* ---------- Shared features: say up front what needs signing in ---------- */
function paintLiveNotes(){const st=XC.on&&!XC.noWrite?"on":XC.tried?"off":"wait";
  const txt={on:"You're signed in, so your predictions, votes, ratings and scores are shared with other fans here. The live quiz and watch parties work with friends who open this page.",
    off:"Shared features (the prediction league, live quiz, watch parties, fan ratings and leaderboards) work with other fans when you're signed in to Claude and open this page there. Until then, what you do is saved on this device only.",
    wait:"Checking whether shared features are available…"}[st];
  document.querySelectorAll("[data-livenote]").forEach(el=>{const full=el.dataset.livenote==="full",x=full?txt:st==="off"?"Saved on this device only. Sign in to Claude to share with other fans.":"";
    el.className="livenote "+st;el.innerHTML=x?`<span class="ln-dot" aria-hidden="true"></span><span>${esc(t(x))}</span>`:""})}
setTimeout(()=>{if(!XC.tried){XC.tried=true;paintLiveNotes()}},5000);

/* ---------- Small sport icons, used where several branches share one list ---------- */
const BR_SVG={
 fb:'<circle cx="12" cy="12" r="9"/><path d="M12 7.5l3.6 2.6-1.4 4.2H9.8l-1.4-4.2z"/><path d="M12 3v4.5M15.6 10.1L20 8.6M14.2 14.3l2.6 3.9M9.8 14.3l-2.6 3.9M8.4 10.1L4 8.6"/>',
 bb:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3v18M5.6 5.6c3 2.6 3 10.2 0 12.8M18.4 5.6c-3 2.6-3 10.2 0 12.8"/>',
 vb:'<circle cx="12" cy="12" r="9"/><path d="M12 3c-1.5 4 0 8 0 9s-4 4.5-8.4 4.6M12 12c1.3.2 6 2.3 8.6-1.8M12 12c-1.8-.8-4.6-4-3.6-8.4M12 12c.5 2 1.8 6 5.6 7.8"/>'};
function brIcon(b){const k=b.includes("basketball")?"bb":b.includes("volleyball")?"vb":"fb";
  return `<svg class="bri" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" role="img" aria-label="${esc(t(SPORTS[b].label))}"><title>${esc(t(SPORTS[b].label))}</title>${BR_SVG[k]}</svg>`}
/* ---------- One way to write a match everywhere: Fenerbahçe's score first, then "vs Opponent" or "at Opponent" ---------- */
function vsOpp(ha,o){return tf(ha==="A"?"at {o}":ha==="N"?"vs {o} (neutral)":"vs {o}",{o})}
/* ---------- Home page: one scrolling page ---------- */
function homeResults(n){const out=[];HOME_BR.forEach(b=>{const L=LIVE[b];if(!L)return;L.last.forEach((r,i)=>{if(r[0])out.push({b,r,i})})});return out.sort((a,c)=>c.r[0].localeCompare(a.r[0])).slice(0,n||8)}
/* one result, newest first lists; opens the match page */
function homeResRow({b,r,i}){const o=outcome(r),away=r[2]==="A";
  return `<li class="hfrow card mclick" data-mi="${i}" data-mb="${b}" tabindex="0" role="button" aria-label="${esc(tf("Match details: Fenerbahçe {a}–{b} {o}",{a:r[4],b:r[5],o:r[3]}))}"><div class="md"><b>${mDate(r[0],true)}</b><span>${fmtDay(isoDay(r[0]),{weekday:"short"})}</span></div><div class="mm"><span class="mcomp">${brIcon(b)}${esc(t(r[1]))}</span><span class="mopp">${esc(vsOpp(r[2],r[3]))}</span></div><div class="ms"><b>${r[4]}–${r[5]}</b>${rdot(o)}</div></li>`}
function homeLines(){const today=todayISO();
  return `<h3 class="mh">${t("Every team")}</h3><ul class="hlines">${HOME_BR.map(b=>{const L=LIVE[b];if(!L)return "";const r=L.last[0],n=(L.next||[]).find(x=>!x[0]||x[0]>=today);
    const last=r?`<span class="hl-last">${rdot(outcome(r))}<b>${esc(r[4])}–${esc(r[5])}</b> ${esc(vsOpp(r[2],r[3]))}</span>`:`<span class="hl-last muted">–</span>`;
    const nx=n?`<span class="hl-next"><span class="muted">${t("Next up")}</span> ${n[0]?mDate(n[0],true):esc(t(n[5]||"TBC"))} · ${esc(vsOpp(n[3],n[4]))}</span>`:`<span class="hl-next muted">${t("No fixture listed")}</span>`;
    return `<li><button class="hline" data-gosport="${b}"><span class="hl-br">${brIcon(b)}<b>${esc(t(SPORTS[b].label))}</b></span>${last}${nx}<span class="hl-go" aria-hidden="true">›</span></button></li>`}).join("")}</ul>`}
/* ---------- Match centre: the next match first, then the latest results, before anything else ---------- */
function countdown(iso){const d=Math.round((isoDay(iso)-isoDay(todayISO()))/DAY);return d<=0?t("Today"):d===1?t("Tomorrow"):tf("In {n} days",{n:d})}
function homeCentre(){const fx=homeFixtures(),first=fx[0],res=homeResults(6);
  const next=first?(()=>{const {b,n}=first,h=n[3]==="H";return `<article class="nextup card mcnext"><span class="label">${t("Next match")} · ${esc(t(SPORTS[b].label))} · ${esc(t(n[2]))}</span>
     <div class="nx-teams"><span class="${h?"fb":""}">${esc(h?"Fenerbahçe":n[4])}</span><span class="vs">${t("vs")}</span><span class="${h?"":"fb"}">${esc(h?n[4]:"Fenerbahçe")}</span></div>
     <div class="nx-meta"><b>${mDate(n[0])}</b>${n[1]?`<span>${esc(n[1])}</span>`:""}<span class="chip">${t(h?"Home":"Away")}</span><span class="chip win">${countdown(n[0])}</span></div>${calLinks(n,true)}
     <button class="btn ghost sm" data-gosport="${b}">${esc(tf("Open {x}",{x:t(SPORTS[b].label)}))} →</button></article>`})()
    :`<article class="nextup card mcnext"><span class="label">${t("Next match")}</span><p class="muted">${t("No upcoming fixtures in this snapshot.")}</p></article>`;
  return `<section class="mcentre" aria-labelledby="mcH"><h2 class="vh" id="mcH">${esc(t("Next match and latest results"))}</h2>${next}
    <section class="mcres"><h3 class="mh">${t("Latest results")} <small>${t("newest first")}</small></h3><ol class="hfx">${res.map(homeResRow).join("")}</ol>
     <button class="linkbtn" data-gohome="fixtures">${t("Every upcoming game →")}</button></section></section>`}
/* the home page itself is laid out in x_look.js */
/* the hero's "next match" line is only needed where the match centre isn't on screen */
EXT.afterPanel.push(p=>{document.body.dataset.view=tab==="matches"?"matches":"other";fitLede();
  /* phones: the score prediction folds away so the results follow the next match straight away */
  const pb=tab==="matches"&&p.querySelector("#predBox");if(!pb||!matchMedia("(max-width:560px)").matches||p.querySelector(".predtog"))return;
  pb.hidden=true;pb.insertAdjacentHTML("beforebegin",`<button class="btn ghost sm predtog" type="button" aria-expanded="false" aria-controls="predBox">${t("Predict the score")}</button>`);
  const b=p.querySelector(".predtog");b.onclick=()=>{pb.hidden=!pb.hidden;b.setAttribute("aria-expanded",!pb.hidden)}});

/* ---------- Short intro: two lines of the description, the rest on request ---------- */
let ledeOpen=false,ledeFor="";
function paintFooter(){const w=document.querySelector("footer .wrap");if(!w)return;let a=$("aboutSite");if(!a){w.insertAdjacentHTML("afterbegin",`<p id="aboutSite" class="about"></p>`);a=$("aboutSite")}
  a.textContent=t("About this site: results and tables are updated every Sunday, Monday and Thursday morning, so scores don't change live during a match. Made by a fan (D.Y).")}
function fitLede(){paintFooter();const el=$("heroLede");if(!el)return;let b=$("ledeMore");
  let a=$("heroAsof");if(!a){el.insertAdjacentHTML("beforebegin",`<p class="asof" id="heroAsof"></p>`);a=$("heroAsof")}a.textContent=tf("Results and tables updated {d}",{d:mDate(ASOF_ISO)});
  if(ledeFor!==current){ledeFor=current;ledeOpen=false}
  if(!b){el.insertAdjacentHTML("afterend",`<button class="linkbtn ledemore" id="ledeMore" type="button" aria-controls="heroLede" hidden></button>`);b=$("ledeMore");b.onclick=()=>{ledeOpen=!ledeOpen;fitLede()}}
  el.classList.toggle("open",ledeOpen);el.classList.add("clamp");
  const over=!ledeOpen&&el.scrollHeight>el.clientHeight+2;b.hidden=!(over||ledeOpen);b.textContent=t(ledeOpen?"Show less":"Read more");b.setAttribute("aria-expanded",ledeOpen)}
window.addEventListener("resize",()=>{clearTimeout(fitLede.tm);fitLede.tm=setTimeout(fitLede,150)});
const PLAY_TEASE=[["daily","Daily Mix","Five new questions every day"],["wordle","Fenerdle","Guess the player in six tries"],["quiz","Quiz","Five levels, from Easy to Extreme"],["live","Live quiz","Play against friends in real time"]];
function homePlay(){return `<section class="hsec" id="hs-play"><h3 class="mh">${t("Play")}</h3><div class="hplay">${PLAY_TEASE.map(([g,n,d])=>`<button class="hpcard" data-hplay="${g}"><b>${esc(t(n))}</b><span>${esc(t(d))}</span></button>`).join("")}
   <button class="hpcard" data-gohome="predict"><b>${esc(t("Predict the score"))}</b><span>${esc(t("Join the fans' prediction league"))}</span></button></div></section>`}
document.addEventListener("click",e=>{const g=e.target.closest("[data-hplay]");if(g){const id=g.dataset.hplay,b=PLAY.football.some(x=>x[0]===id)?"football":Object.keys(PLAY).find(k=>PLAY[k].some(x=>x[0]===id));setSport(b);pickGame(id);const a=$("gameArea");if(a)a.scrollIntoView({block:"start"});return}
  const x=e.target.closest("[data-gohome]");if(!x)return;if(current!=="home")setSport("home");const s=$("hs-"+x.dataset.gohome);if(s)s.scrollIntoView({block:"start",behavior:matchMedia("(prefers-reduced-motion:reduce)").matches?"auto":"smooth"})});

/* ---------- Settings: design, language, text size, quiz timer, tour ---------- */
const TS_LEVELS=[["0","Normal"],["1","Large"],["2","Larger"]],QT_LEVELS=[["1","Standard"],["2","Double time"],["0","No timer"]];
const qTimeMult=()=>+store.get("fb-qtime","1");
function applyTextSize(){document.documentElement.dataset.ts=store.get("fb-ts","0")}
applyTextSize();
const GEAR='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2.2"/><circle cx="10" cy="17" r="2.2"/></svg>';
function initSettings(){const host=document.querySelector(".bar .wrap");if(!host||$("setBtn"))return;
  host.insertAdjacentHTML("beforeend",`<div class="setwrap"><button class="hset" id="setBtn" type="button" aria-expanded="false" aria-controls="setPanel">${GEAR}<span data-t="Settings">${t("Settings")}</span></button>
   <div class="setpanel" id="setPanel" role="dialog" aria-modal="false" aria-label="${esc(t("Settings"))}" hidden></div></div>`);
  const btn=$("setBtn"),pan=$("setPanel");
  const close=(back)=>{pan.hidden=true;btn.setAttribute("aria-expanded","false");if(back)btn.focus()};
  btn.onclick=()=>{if(!pan.hidden){close(false);return}fillSettings();pan.hidden=false;btn.setAttribute("aria-expanded","true");const f=pan.querySelector("select,button");if(f)f.focus()};
  document.addEventListener("click",e=>{if(!pan.hidden&&!e.target.closest(".setwrap"))close(false)});
  pan.addEventListener("keydown",e=>{if(e.key==="Escape"){e.stopPropagation();close(true)}})}
function fillSettings(){const pan=$("setPanel");if(!pan)return;pan.setAttribute("aria-label",t("Settings"));const ts=store.get("fb-ts","0"),qt=store.get("fb-qtime","1");
  const seg=(name,list,val)=>`<div class="seg" role="group" aria-labelledby="sl-${name}">${list.map(([v,l])=>`<button type="button" data-set="${name}" data-v="${v}" aria-pressed="${v===val}">${esc(t(l))}</button>`).join("")}</div>`;
  pan.innerHTML=`<h2 id="setTitle">${t("Settings")}</h2>
   <label class="setrow"><span>${t("Design")}</span><select id="setTheme">${$("theme").innerHTML}</select></label>
   <label class="setrow"><span>${t("Language")}</span><select id="setLang">${$("lang").innerHTML}</select></label>
   <div class="setrow"><span id="sl-ts">${t("Text size")}</span>${seg("ts",TS_LEVELS,ts)}</div>
   <div class="setrow"><span id="sl-qt">${t("Quiz timer")}</span>${seg("qt",QT_LEVELS,qt)}<small>${t("For the Super hard and Extreme quiz levels. The live quiz keeps the same clock for everyone.")}</small></div>
   <div class="btns"><button class="btn ghost sm" id="setTour" type="button">${t("Take the tour")}</button></div>
   <p class="livenote" data-livenote="full"></p>`;
  $("setTheme").value=$("theme").value;$("setLang").value=$("lang").value;
  $("setTheme").onchange=e=>{$("theme").value=e.target.value;$("theme").dispatchEvent(new Event("change"))};
  $("setLang").onchange=e=>{$("lang").value=e.target.value;$("lang").dispatchEvent(new Event("change"));setTimeout(()=>{if(!$("setPanel").hidden){fillSettings();const f=$("setLang");if(f)f.focus()}},400)};
  pan.querySelectorAll("[data-set]").forEach(b=>b.onclick=()=>{const k=b.dataset.set,v=b.dataset.v;
    if(k==="ts"){store.set("fb-ts",v);applyTextSize()}else{store.set("fb-qtime",v);if(tab==="play"&&playSel[current]==="quiz")renderPanel()}
    pan.querySelectorAll(`[data-set="${k}"]`).forEach(x=>x.setAttribute("aria-pressed",x.dataset.v===v));b.focus()});
  $("setTour").onclick=()=>{pan.hidden=true;$("setBtn").setAttribute("aria-expanded","false");startTour()};paintLiveNotes()}

/* ---------- First-visit tour ---------- */
const TOUR=[
 ["#brRow","Pick a branch","Football, basketball, volleyball and more. \"All branches\" brings you back to the overview."],
 [".strip","Scores at the top","The latest scores and next games from every team. Tap one to see the details."],
 ["#hs-fixtures","Everything at a glance","The next match and the latest results from every team. Scroll down for every team, games and the fans' prediction league."],
 ["#tabs","Season, club and games","Each branch has this season's matches and tables, the club's history, and games to play."],
 ["#bnav","Always one tap away","Home, matches, tables, games and search sit at the bottom of the screen."],
 ["#hSearch","Search","Find players, matches, records and seasons in any branch."],
 [".kanbtn","Ask Kanarya","The site's helper answers questions about the club from the facts on this page."],
 ["#setBtn","Make it yours","Change the design, language, text size and quiz timer. You can replay this tour here."],
 [null,"Playing with other fans","The prediction league, live quiz, watch parties, ratings and leaderboards are shared with other fans when you're signed in to Claude. Otherwise, everything is saved on this device."]];
let TR=null;
function tourSteps(){return TOUR.filter(([sel])=>{if(!sel)return true;const el=document.querySelector(sel);if(!el)return false;const r=el.getBoundingClientRect();return r.width>0&&r.height>0})}
function startTour(){endTour(false);const steps=tourSteps();if(!steps.length)return;
  const ov=document.createElement("div");ov.className="tour";ov.innerHTML=`<div class="tourring" aria-hidden="true"></div><div class="tourcard" role="dialog" aria-modal="true" aria-labelledby="tourH" aria-describedby="tourP" tabindex="-1"></div>`;
  document.documentElement.appendChild(ov);TR={ov,steps,i:0,back:document.activeElement};
  ov.addEventListener("keydown",e=>{if(e.key==="Escape"){e.preventDefault();endTour(true)}
    if(e.key==="Tab"){const f=[...ov.querySelectorAll("button")];if(!f.length)return;const a=f[0],z=f[f.length-1];if(e.shiftKey&&document.activeElement===a){e.preventDefault();z.focus()}else if(!e.shiftKey&&document.activeElement===z){e.preventDefault();a.focus()}}});
  window.addEventListener("resize",tourPlace);window.addEventListener("scroll",tourPlace,{passive:true});tourShow()}
function tourShow(){if(!TR)return;const [sel,h,d]=TR.steps[TR.i],n=TR.steps.length,last=TR.i===n-1,card=TR.ov.querySelector(".tourcard");
  card.innerHTML=`<span class="label">${esc(tf("Step {i} of {n}",{i:TR.i+1,n}))}</span><h3 id="tourH">${esc(t(h))}</h3><p id="tourP">${esc(t(d))}</p>
   <div class="btns">${TR.i?`<button class="btn ghost sm" data-tr="back">${t("Back")}</button>`:""}<button class="btn sm" data-tr="next">${t(last?"Done":"Next")}</button>${last?"":`<button class="linkbtn" data-tr="skip">${t("Skip the tour")}</button>`}</div>`;
  card.querySelectorAll("[data-tr]").forEach(b=>b.onclick=()=>{const k=b.dataset.tr;if(k==="skip")return endTour(true);if(k==="back")TR.i--;else if(last)return endTour(true);else TR.i++;tourShow()});
  const el=sel&&document.querySelector(sel);if(el){const r=el.getBoundingClientRect();if(r.top<70||r.bottom>innerHeight-200)el.scrollIntoView({block:"center",behavior:"instant"})}
  tourPlace();const nb=card.querySelector('[data-tr="next"]');(nb||card).focus()}
function tourPlace(){if(!TR)return;const [sel]=TR.steps[TR.i],el=sel&&document.querySelector(sel),ring=TR.ov.querySelector(".tourring"),card=TR.ov.querySelector(".tourcard");
  const W=innerWidth,H=innerHeight,cw=Math.min(360,W-32);card.style.width=cw+"px";
  if(!el){ring.style.cssText="left:50%;top:50%;width:0;height:0";card.style.left=(W-cw)/2+"px";card.style.top=Math.max(16,(H-card.offsetHeight)/2)+"px";return}
  const r=el.getBoundingClientRect(),pad=6;ring.style.cssText=`left:${r.left-pad}px;top:${r.top-pad}px;width:${r.width+pad*2}px;height:${r.height+pad*2}px`;
  const ch=card.offsetHeight,below=r.bottom+pad+14,above=r.top-pad-14-ch;let top=below+ch<H-8?below:above>8?above:Math.max(8,H-ch-8);
  let left=Math.min(Math.max(16,r.left+r.width/2-cw/2),W-cw-16);card.style.left=left+"px";card.style.top=top+"px"}
function endTour(done){if(!TR)return;store.set("fb-tour",1);window.removeEventListener("resize",tourPlace);window.removeEventListener("scroll",tourPlace);const back=TR.back;TR.ov.remove();TR=null;if(done&&back&&back.focus&&document.contains(back))back.focus()}
/* first visit only; automated browsers (tests, previews) never see it */
/* the tour never starts by itself: a button on the home page (and one in Settings) starts it */
function maybeTour(){}
const TOUR_ICON='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="9.5"/><path d="M15.5 8.5l-2 5-5 2 2-5z" stroke-linejoin="round"/></svg>';
function tourButton(){const lede=$("heroLede");if(!lede)return;let b=$("tourBtn");
  if(!b){(($("ledeMore"))||lede).insertAdjacentHTML("afterend",`<button class="tourbtn" id="tourBtn" type="button">${TOUR_ICON}<span></span></button>`);b=$("tourBtn");b.onclick=()=>startTour()}
  b.querySelector("span").textContent=t("New here? Take a quick tour of the site")}
