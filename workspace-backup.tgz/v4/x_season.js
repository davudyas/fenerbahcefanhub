/* ===== Season mode: take a drafted team through a real Fenerbahçe season ===== */
const SZ_KIND={football:"fb",basketball:"bb","womens-basketball":"wb",volleyball:"vb","mens-volleyball":"vb","womens-football":"fb"};
const SZ_LN={football:"Süper Lig",basketball:"BSL","womens-basketball":"KBSL",volleyball:"Sultanlar Ligi","mens-volleyball":"Efeler Ligi","womens-football":"Women's Super League"};
const szDash=s=>s.replace("-","–");
const szS={};
function poisson(l){const L=Math.exp(-l);let k=0,p=1;do{k++;p*=Math.random()}while(p>L);return k-1}

/* --- single games: ha = 1 home, -1 away, 0 neutral --- */
function szGame(kind,r1,r2,ha){
  if(kind==="fb"){const h=ha*.13,l1=1.32*Math.exp(.08*(r1-r2)+h),l2=1.32*Math.exp(.08*(r2-r1)-h);return {s:[poisson(l1),poisson(l2)]}}
  if(kind==="vb"){const q=clamp(.5+(r1-r2)*.0065+ha*.008,.4,.6),w=[0,0],sets=[];
    while(w[0]<3&&w[1]<3){const tg=w[0]+w[1]===4?15:25;let a=0,c=0;while(!((a>=tg||c>=tg)&&Math.abs(a-c)>=2)){if(Math.random()<q)a++;else c++}sets.push([a,c]);w[a>c?0:1]++}
    return {s:w,sets}}
  const base=kind==="wb"?74:80,m=(r1-r2)*1.5+ha*3;let a=Math.round(base+m/2+gauss()*8),b=Math.round(base-m/2+gauss()*8),ot=0;
  while(a===b){a+=Math.max(2,Math.round(6+gauss()*3+m*.1));b+=Math.max(2,Math.round(6+gauss()*3-m*.1));ot++}
  return {s:[a,b],ot}}
const szWin=g=>g.s[0]>g.s[1]?0:g.s[1]>g.s[0]?1:-1;
/* football knock-out decider after a level score: extra time, then penalties */
function szDecide(kind,g,r1,r2){if(kind!=="fb"||szWin(g)>=0&&!g.forceDecide)return g;
  if(Math.random()<.35){const t=Math.random()<clamp(.5+(r1-r2)*.03,.2,.8)?0:1;g.s[t]++;g.aet=true;return g}
  g.pens=Math.random()<clamp(.5+(r1-r2)*.012,.35,.65)?[5,4]:[4,5];if(Math.random()<.3)g.pens=g.pens[0]>g.pens[1]?[4,3]:[3,4];return g}
const szGW=g=>g.pens?(g.pens[0]>g.pens[1]?0:1):szWin(g);

/* --- table helpers --- */
function szRow(n,r,me){return {n,r,me:!!me,p:0,w:0,d:0,l:0,f:0,a:0,pts:0}}
function szApply(kind,A,B,g){A.p++;B.p++;A.f+=g.s[0];A.a+=g.s[1];B.f+=g.s[1];B.a+=g.s[0];const w=szWin(g);
  if(kind==="fb"){if(w===0){A.w++;B.l++;A.pts+=3}else if(w===1){B.w++;A.l++;B.pts+=3}else{A.d++;B.d++;A.pts++;B.pts++}}
  else if(kind==="vb"){const [x,y]=g.s;if(w===0){A.w++;B.l++;A.pts+=y===2?2:3;B.pts+=y===2?1:0}else{B.w++;A.l++;B.pts+=x===2?2:3;A.pts+=x===2?1:0}}
  else{if(w===0){A.w++;B.l++;A.pts+=2;B.pts+=1}else{B.w++;A.l++;B.pts+=2;A.pts+=1}}}
const szSort=rows=>rows.slice().sort((a,b)=>b.pts-a.pts||(b.f-b.a)-(a.f-a.a)||b.f-a.f||b.r-a.r);
/* circle method: list of rounds, each a list of [i,j] (i at home) */
function szRounds(n,legs){const ids=[...Array(n).keys()];if(n%2)ids.push(-1);const m=ids.length,R=[];let arr=ids.slice();
  for(let r=0;r<m-1;r++){const pr=[];for(let i=0;i<m/2;i++){const a=arr[i],b=arr[m-1-i];if(a>=0&&b>=0)pr.push(r%2?[b,a]:[a,b])}R.push(pr);arr=[arr[0],arr[m-1],...arr.slice(1,m-1)]}
  return legs===2?R.concat(R.map(pr=>pr.map(([a,b])=>[b,a]))):R}
function szDates(a,b,n){return Array.from({length:n},(_,i)=>n===1?a:a+(b-a)*i/(n-1))}

/* --- stage builders --- */
/* round robin: teams[0] is you */
function stRR(name,teams,legs,from,to,next){const R=szRounds(teams.length,legs).filter(pr=>pr.some(p=>p.includes(0)));return {t:"rr",name,rows:teams.map(x=>szRow(x.n,x.r,x.me)),R,ri:0,dates:szDates(from,to,R.length),next}}
/* league phase: you + 35 others, n games each */
function stLP(name,pool,n,from,to,next,size){const opp=shuffle(pool).slice(0,n),others=shuffle(pool.filter(x=>!opp.includes(x))).slice(0,(size||36)-1-n),all=[{n:"__me"},...opp,...others];
  return {t:"lp",name,rows:all.map((x,i)=>szRow(i?x[0]:"",i?x[1]:0,!i)),opp:opp.map((x,i)=>({o:i+1,ha:i%2?-1:1})),ri:0,dates:szDates(from,to,n),next}}
/* knock-out tie: fmt "1" | "1N" (neutral) | "2L" | "bo3" | "bo5" | "bo7" */
function stKO(name,fmt,pick,dates,next){return {t:"ko",name,fmt,pick,dates,games:[],next}}

/* --- opponent pools (club ratings are game estimates) --- */
const EU_FB=[["Real Madrid",91],["Barcelona",90],["Bayern Munich",90],["Manchester City",89],["Liverpool",88],["Paris Saint-Germain",88],["Chelsea",87],["Manchester United",87],["Juventus",87],["Inter",87],["AC Milan",86],["Arsenal",86],["Atlético Madrid",86],["Borussia Dortmund",85],["Napoli",84],["Tottenham",84],["Bayer Leverkusen",84],["Porto",83],["Benfica",83],["RB Leipzig",83],["Ajax",82],["Lyon",82],["Valencia",82],["Roma",82],["Sevilla",82],["Villarreal",81],["Lazio",81],["Sporting CP",81],["Zenit",81],["Shakhtar Donetsk",81],["PSV",81],["Marseille",80],["Monaco",80],["Atalanta",82],["Fiorentina",80],["Real Sociedad",80],["Lille",80],["Feyenoord",79],["Celtic",78],["Club Brugge",79],["Olympiacos",78],["Dynamo Kyiv",78],["Red Bull Salzburg",79],["Braga",78],["Eintracht Frankfurt",80],["West Ham",79],["Rangers",77],["Anderlecht",77],["Basel",77],["Galatasaray",80],["Dinamo Zagreb",76],["Red Star Belgrade",76],["Slavia Prague",76],["PAOK",76],["Young Boys",76],["Copenhagen",76],["AZ",77],["Gent",75],["Partizan",74],["Ferencváros",74],["Viktoria Plzeň",75],["Maccabi Tel Aviv",74],["Ludogorets",74],["Legia Warsaw",73],["Bodø/Glimt",76],["Midtjylland",75],["Molde",73],["Sheriff Tiraspol",72],["Slovan Bratislava",72],["Malmö",74],["Qarabağ",74],["Rapid Wien",74],["Sparta Prague",75],["Steaua Bucharest",74],["CSKA Moscow",78],["Spartak Moscow",78],["Lokomotiv Moscow",77],["Rennes",79],["Nice",78],["Hertha Berlin",77],["Werder Bremen",79],["Schalke",80],["Wolfsburg",79],["Stuttgart",79],["Hamburg",78],["Deportivo La Coruña",82],["Parma",80],["Leeds United",80],["Aston Villa",80],["Newcastle United",79],["Everton",78],["Twente",76],["Heerenveen",74],["Standard Liège",75],["Sion",72],["Aris",72],["AEK Athens",75],["Panathinaikos",76],["APOEL",73],["Maccabi Haifa",73],["Hapoel Tel Aviv",72],["Unirea Urziceni",71],["Dnipro",76],["Metalist Kharkiv",76],["Vitesse",74],["Mlada Boleslav",71],["Elfsborg",71],["Austria Wien",72],["Sturm Graz",73],["LASK",73]];
const EU_BB=[["Real Madrid",88],["CSKA Moscow",88],["Olympiacos",87],["Panathinaikos",87],["Barcelona",87],["Anadolu Efes",86],["Maccabi Tel Aviv",84],["Žalgiris Kaunas",83],["Virtus Bologna",83],["Olimpia Milano",84],["Baskonia",84],["Monaco",86],["Partizan",84],["Crvena zvezda",83],["Bayern Munich",83],["Valencia Basket",82],["Unicaja",82],["ALBA Berlin",80],["Paris Basketball",82],["Khimki",81],["Lokomotiv Kuban",81],["UNICS Kazan",81],["Montepaschi Siena",84],["Lietuvos rytas",80],["Cibona",79],["Real Betis",76],["Fenerbahçe B",80],["ASVEL",79],["Brose Bamberg",80],["Galatasaray",80],["Darüşşafaka",79],["Gran Canaria",80],["Budućnost",78],["Hapoel Jerusalem",79],["Lyon-Villeurbanne",79],["Pau-Orthez",77],["Prokom Trefl Sopot",77],["Union Olimpija",77],["Benetton Treviso",82],["Kinder Bologna",84],["Tau Cerámica",84],["Joventut",80],["Dynamo Moscow",79],["Le Mans",77]].filter(x=>x[0]!=="Fenerbahçe B");
const EU_WB=[["Ekaterinburg",89],["Spartak Moscow Region",88],["USK Prague",86],["Perfumerías Avenida",85],["Sopron",82],["Schio",84],["Bourges",84],["Villeneuve d'Ascq",83],["Galatasaray",84],["ÇBK Mersin",84],["Girona",82],["Lyon ASVEL Féminin",83],["Basket Landes",81],["Dynamo Kursk",86],["Sparta&K",84],["Wisła Kraków",79],["Polkowice",79],["Gdynia",80],["Valencia Basket",82],["Rivas Ecópolis",80],["Nadezhda Orenburg",82],["Beşiktaş",79],["Venezia",82],["Montpellier",80],["Salamanca",84],["Zaragoza",79],["Zabiny Brno",76],["Kayseri",76]];
const EU_VB=[["VakıfBank",89],["Imoco Conegliano",90],["Eczacıbaşı",88],["Vero Volley Milano",87],["Dinamo Kazan",87],["Rabita Baku",85],["Novara",86],["Scandicci",85],["Dinamo Moscow",85],["Chemik Police",83],["LKS Łódź",80],["Galatasaray",83],["THY",82],["Pesaro",83],["Bergamo",84],["RC Cannes",83],["Volero Zürich",83],["Uralochka",82],["Developres Rzeszów",82],["Mulhouse",78],["Béziers",76],["Dresdner SC",77],["Schwerin",78],["Maritza Plovdiv",72],["Hylo Volley Lódź",76],["Calcit Kamnik",72],["Olympiacos",74],["Budowlani Łódź",76],["Allianz Stuttgart",80],["Zeren Spor",78],["Aydın",78],["Nilüfer",76]];
const EU_MV=[["Zenit Kazan",91],["Perugia",90],["Trentino",90],["Lube Civitanova",89],["Jastrzębski Węgiel",88],["ZAKSA Kędzierzyn-Koźle",88],["Asseco Resovia",86],["Modena",86],["Halkbank",84],["Ziraat Bankkart",84],["Dynamo Moscow",85],["Kuzbass Kemerovo",84],["Berlin Recycling Volleys",82],["Piacenza",84],["Friedrichshafen",80],["Tours",80],["Chaumont",78],["ACH Volley Ljubljana",79],["Olympiacos",78],["Knack Roeselare",79],["Arkas Spor",80],["Fakel Novy Urengoy",82],["Lokomotiv Novosibirsk",83],["Bełchatów",83],["Latina",80],["Panathinaikos",76],["Budvanska Rivijera",73],["Dukla Liberec",74],["Toulouse",76],["Mladost Zagreb",72],["Hypo Tirol",75],["Vojvodina",72],["Aalst",74],["Lycurgus Groningen",73],["Benfica",77],["Sporting CP",76],["Ravenna",77],["Montpellier",77],["Prague",71],["Maribor",72]];
const EU_WF=[["Barcelona",92],["Lyon",91],["Chelsea",90],["Arsenal",89],["Wolfsburg",87],["Bayern Munich",87],["Manchester City",87],["Paris Saint-Germain",86],["Real Madrid",85],["Juventus",82],["Atlético Madrid",80],["Roma",81],["Benfica",80],["Hammarby",77],["Twente",78],["Häcken",76],["Brann",76],["Real Sociedad",76],["Ajax",76],["Slavia Prague",76],["Sparta Prague",74],["St. Pölten",74],["OH Leuven",74],["Rosengård",74],["Glasgow City",70],["Anderlecht",70],["Breiðablik",70],["Vllaznia",64],["Minsk",66],["Apollon Ladies",64],["Mura",62],["Racing Union",62],["Ferencváros",66],["Sporting CP",72],["Celtic",70],["Valur",68]];
const szPoolEU=b=>b==="football"?EU_FB:b==="basketball"?EU_BB:b==="womens-basketball"?EU_WB:b==="mens-volleyball"?EU_MV:b==="womens-football"?EU_WF:EU_VB;
function szPickEU(b,lo,hi,used){const P=szPoolEU(b).filter(x=>x[1]>=lo&&x[1]<=hi&&!used.has(x[0]));const L=P.length?P:szPoolEU(b).filter(x=>!used.has(x[0]));const x=L[Math.floor(Math.random()*L.length)];used.add(x[0]);return {n:x[0],r:x[1]}}
function szFind(b,name,def){const x=szPoolEU(b).find(y=>y[0]===name);return {n:name,r:x?x[1]:def}}

/* --- Europe formats (football) ---
   each returns a map of stage keys -> builders; the entry key comes from the season data */
function szEuroFB(S,season,eu){const y=+season.slice(0,4),used=new Set(eu.g||[]),real=eu.g||[],ko=(name,lo,hi,dates,next)=>stKO(name,"2L",()=>szPickEU("football",lo,hi,used),dates,next);
  const grp=(comp,name,pots,from,to,next)=>()=>{const opps=real.length===3?real.map((n,i)=>szFind("football",n,[84,80,76][i])):pots.map(([lo,hi])=>szPickEU("football",lo,hi,used));
    return stRR(name,[{n:"__me",me:true},...opps],2,from,to,next)};
  const UC=y<=2003?{"UC-Q2":()=>ko("UEFA Cup · Second qualifying round",70,77,[-.1,-.07],{w:"UC-R1"}),"UC-R1":()=>ko("UEFA Cup · First round",72,80,[.08,.12],{w:"UC-R2"}),"UC-R2":()=>ko("UEFA Cup · Second round",74,81,[.2,.24],{w:"UC-R3"}),"UC-R3":()=>ko("UEFA Cup · Third round",76,83,[.38,.42],{w:"UC-R4"}),"UC-R4":()=>ko("UEFA Cup · Fourth round",77,84,[.55,.58],{w:"UC-QF"}),"UC-QF":()=>ko("UEFA Cup · Quarter-final",78,85,[.7,.73],{w:"UC-SF"}),"UC-SF":()=>ko("UEFA Cup · Semi-final",79,86,[.82,.85],{w:"UC-F"}),"UC-F":()=>stKO("UEFA Cup · Final","1N",()=>szPickEU("football",80,87,used),[.995],{w:"WIN"}),"UC-R32":()=>ko("UEFA Cup · Third round",76,83,[.38,.42],{w:"UC-R4"})}
   :{"UC-Q2":()=>ko("UEFA Cup · Second qualifying round",70,77,[-.1,-.07],{w:"UC-R1"}),"UC-R1":()=>ko("UEFA Cup · First round",72,80,[.06,.1],{w:"UC-G"}),"UC-G":()=>{const opps=[[80,86],[77,82],[74,79],[71,76]].map(([lo,hi])=>szPickEU("football",lo,hi,used));return {...stRR("UEFA Cup · Group stage",[{n:"__me",me:true},...opps],1,.2,.4),next:{pos:{1:"UC-R32",2:"UC-R32",3:"UC-R32"}}}},
    "UC-R32":()=>ko("UEFA Cup · Round of 32",74,83,[.55,.58],{w:"UC-R16"}),"UC-R16":()=>ko("UEFA Cup · Round of 16",76,84,[.63,.66],{w:"UC-QF"}),"UC-QF":()=>ko("UEFA Cup · Quarter-final",78,86,[.74,.77],{w:"UC-SF"}),"UC-SF":()=>ko("UEFA Cup · Semi-final",79,87,[.84,.87],{w:"UC-F"}),"UC-F":()=>stKO("UEFA Cup · Final","1N",()=>szPickEU("football",80,88,used),[.995],{w:"WIN"})};
  const ELnew=y>=2024,EL21=y>=2021;
  const EL=ELnew?{"EL-Q3":()=>ko("Europa League · Third qualifying round",70,78,[-.1,-.07],{w:"EL-PO",l:"ECL-PO"}),"EL-PO":()=>ko("Europa League · Play-off round",72,79,[-.05,-.02],{w:"EL-LP",l:"ECL-LP"}),
     "EL-LP":()=>stLP("Europa League · League phase",EU_FB.filter(x=>x[1]<=85),8,.08,.5,{lp:true,top:"EL-R16",mid:"EL-KO"}),"EL-KO":()=>ko("Europa League · Knockout play-off",76,83,[.55,.58],{w:"EL-R16"}),
     "EL-R16":()=>ko("Europa League · Round of 16",77,85,[.65,.68],{w:"EL-QF"}),"EL-QF":()=>ko("Europa League · Quarter-final",78,86,[.75,.78],{w:"EL-SF"}),"EL-SF":()=>ko("Europa League · Semi-final",79,86,[.85,.88],{w:"EL-F"}),"EL-F":()=>stKO("Europa League · Final","1N",()=>szPickEU("football",80,87,used),[.995],{w:"WIN"})}
    :{"EL-Q3":()=>ko("Europa League · Third qualifying round",70,78,[-.1,-.07],{w:"EL-PO",l:EL21?"ECL-PO":"OUT"}),"EL-PO":()=>ko("Europa League · Play-off round",72,79,[-.05,-.02],{w:"EL-G",l:EL21?"ECL-G":"OUT"}),
     "EL-G":grp("EL","Europa League · Group stage",[[80,86],[76,82],[72,78]],.08,.42,{pos:EL21?{1:"EL-R16",2:"EL-KO",3:"ECL-KO"}:{1:"EL-R32",2:"EL-R32"}}),
     "EL-R32":()=>ko("Europa League · Round of 32",74,83,[.55,.58],{w:"EL-R16"}),"EL-KO":()=>ko("Europa League · Knockout play-off",77,84,[.55,.58],{w:"EL-R16"}),"EL-R16":()=>ko("Europa League · Round of 16",77,85,[.65,.68],{w:"EL-QF"}),
     "EL-QF":()=>ko("Europa League · Quarter-final",78,86,[.75,.78],{w:"EL-SF"}),"EL-SF":()=>ko("Europa League · Semi-final",79,86,[.85,.88],{w:"EL-F"}),"EL-F":()=>stKO("Europa League · Final","1N",()=>szPickEU("football",80,87,used),[.995],{w:"WIN"})};
  const ECL=y>=2024?{"ECL-Q3":()=>ko("Conference League · Third qualifying round",68,76,[-.1,-.07],{w:"ECL-PO"}),"ECL-PO":()=>ko("Conference League · Play-off round",70,77,[-.05,-.02],{w:"ECL-LP"}),
     "ECL-LP":()=>stLP("Conference League · League phase",EU_FB.filter(x=>x[1]<=81),6,.08,.45,{lp:true,top:"ECL-R16",mid:"ECL-KO"}),"ECL-KO":()=>ko("Conference League · Knockout play-off",72,79,[.55,.58],{w:"ECL-R16"}),
     "ECL-R16":()=>ko("Conference League · Round of 16",73,80,[.65,.68],{w:"ECL-QF"}),"ECL-QF":()=>ko("Conference League · Quarter-final",74,81,[.75,.78],{w:"ECL-SF"}),"ECL-SF":()=>ko("Conference League · Semi-final",75,82,[.85,.88],{w:"ECL-F"}),"ECL-F":()=>stKO("Conference League · Final","1N",()=>szPickEU("football",76,83,used),[.995],{w:"WIN"})}
    :{"ECL-Q2":()=>ko("Conference League · Second qualifying round",64,72,[-.16,-.13],{w:"ECL-Q3"}),"ECL-Q3":()=>ko("Conference League · Third qualifying round",67,75,[-.1,-.07],{w:"ECL-PO"}),"ECL-PO":()=>ko("Conference League · Play-off round",70,77,[-.05,-.02],{w:"ECL-G"}),"ECL-G":grp("ECL","Conference League · Group stage",[[76,81],[72,77],[69,74]],.08,.42,{pos:{1:"ECL-R16",2:"ECL-KO"}}),
     "ECL-KO":()=>ko("Conference League · Knockout play-off",72,79,[.55,.58],{w:"ECL-R16"}),"ECL-R16":()=>ko("Conference League · Round of 16",73,80,[.65,.68],{w:"ECL-QF"}),"ECL-QF":()=>ko("Conference League · Quarter-final",74,81,[.75,.78],{w:"ECL-SF"}),"ECL-SF":()=>ko("Conference League · Semi-final",75,82,[.85,.88],{w:"ECL-F"}),"ECL-F":()=>stKO("Conference League · Final","1N",()=>szPickEU("football",76,83,used),[.995],{w:"WIN"})};
  const drop3=y<=2008?"UC-R32":y<=2020?"EL-R32":"EL-KO",dropQ=y<=2008?"UC-R1":"EL-PO",dropPO=y<=2008?"UC-R1":"EL-G";
  const CL=y>=2024?{"CL-Q2":()=>ko("Champions League · Second qualifying round",70,78,[-.14,-.11],{w:"CL-Q3",l:"EL-Q3"}),"CL-Q3":()=>ko("Champions League · Third qualifying round",72,80,[-.1,-.07],{w:"CL-PO",l:"EL-PO"}),"CL-PO":()=>ko("Champions League · Play-off round",74,81,[-.05,-.02],{w:"CL-LP",l:"EL-LP"}),
     "CL-LP":()=>stLP("Champions League · League phase",EU_FB.filter(x=>x[1]>=74),8,.08,.5,{lp:true,top:"CL-R16",mid:"CL-KO"}),"CL-KO":()=>ko("Champions League · Knockout play-off",81,86,[.55,.58],{w:"CL-R16"}),
     "CL-R16":()=>ko("Champions League · Round of 16",82,90,[.65,.68],{w:"CL-QF"}),"CL-QF":()=>ko("Champions League · Quarter-final",84,91,[.75,.78],{w:"CL-SF"}),"CL-SF":()=>ko("Champions League · Semi-final",85,91,[.85,.88],{w:"CL-F"}),"CL-F":()=>stKO("Champions League · Final","1N",()=>szPickEU("football",86,91,used),[.995],{w:"WIN"})}
    :{"CL-Q2":()=>ko("Champions League · Second qualifying round",70,78,[-.14,-.11],{w:"CL-Q3",l:dropQ}),"CL-Q3":()=>ko("Champions League · Third qualifying round",72,80,[-.1,-.07],{w:y>=2009?"CL-PO":"CL-G",l:dropQ}),"CL-PO":()=>ko("Champions League · Play-off round",74,81,[-.05,-.02],{w:"CL-G",l:dropPO}),
     "CL-G":grp("CL","Champions League · Group stage",[[86,91],[80,85],[76,81]],.08,.42,{pos:y<=2002?{1:"CL-G2",2:"CL-G2",3:drop3}:{1:"CL-R16",2:"CL-R16",3:drop3}}),
     "CL-G2":()=>{const opps=[[86,91],[83,88],[80,85]].map(([lo,hi])=>szPickEU("football",lo,hi,used));return stRR("Champions League · Second group stage",[{n:"__me",me:true},...opps],2,.5,.68,{pos:{1:"CL-QF",2:"CL-QF"}})},
     "CL-R16":()=>ko("Champions League · Round of 16",82,90,[.62,.65],{w:"CL-QF"}),"CL-QF":()=>ko("Champions League · Quarter-final",84,91,[.75,.78],{w:"CL-SF"}),"CL-SF":()=>ko("Champions League · Semi-final",85,91,[.85,.88],{w:"CL-F"}),"CL-F":()=>stKO("Champions League · Final","1N",()=>szPickEU("football",86,91,used),[.995],{w:"WIN"})};
  return {...UC,...EL,...ECL,...CL}}

/* --- Europe formats (basketball and volleyball) --- */
function szEuroCourt(b,season,eu){const y=+season.slice(0,4),used=new Set(),P=(lo,hi)=>()=>szPickEU(b,lo,hi,used),grp=(name,n,lo,hi,legs,from,to,next)=>()=>{const opps=Array.from({length:n},(_,i)=>szPickEU(b,hi-(hi-lo)*i/Math.max(1,n-1)-2,hi-(hi-lo)*i/Math.max(1,n-1)+2,used));return stRR(name,[{n:"__me",me:true},...opps],legs,from,to,next)};
  if(b==="basketball")return {
    "EL-RS":y>=2016?()=>{const n=y>=2019?17:15,opps=Array.from({length:n},(_,i)=>szPickEU(b,88-i*0.7-1.5,88-i*0.7+1.5,used));return stRR("EuroLeague · Regular season",[{n:"__me",me:true},...opps],2,.04,.72,{pos:y>=2023?{1:"EL-PO",2:"EL-PO",3:"EL-PO",4:"EL-PO",5:"EL-PO",6:"EL-PO",7:"EL-PI",8:"EL-PI",9:"EL-PI",10:"EL-PI"}:{1:"EL-PO",2:"EL-PO",3:"EL-PO",4:"EL-PO",5:"EL-PO",6:"EL-PO",7:"EL-PO",8:"EL-PO"}})}
      :grp("EuroLeague · Regular season",5,78,87,2,.04,.4,{pos:{1:"EL-T16",2:"EL-T16",3:"EL-T16",4:"EL-T16"}}),
    "EL-T16":grp("EuroLeague · Top 16",3,82,88,2,.45,.65,{pos:{1:"EL-PO",2:"EL-PO"}}),
    "EL-PI":()=>stKO("EuroLeague · Play-in","1",P(82,86),[.73],{w:"EL-PO"}),
    "EL-PO":()=>stKO("EuroLeague · Playoffs","bo5",P(83,88),szDates(.74,.79,5),{w:"EL-F4"}),
    "EL-F4":()=>stKO("EuroLeague · Final Four semi-final","1N",P(84,89),[.86],{w:"EL-F"}),
    "EL-F":()=>stKO("EuroLeague · Final","1N",P(85,89),[.87],{w:"WIN"}),
    "EC-RS":grp("EuroCup · Regular season",5,74,82,2,.04,.4,{pos:{1:"EC-T16",2:"EC-T16",3:"EC-T16",4:"EC-T16"}}),
    "EC-T16":grp("EuroCup · Top 16",3,77,83,2,.45,.62,{pos:{1:"EC-QF",2:"EC-QF"}}),
    "EC-QF":()=>stKO("EuroCup · Quarter-final","bo3",P(77,83),szDates(.66,.7,3),{w:"EC-SF"}),
    "EC-SF":()=>stKO("EuroCup · Semi-final","bo3",P(78,84),szDates(.74,.78,3),{w:"EC-F"}),
    "EC-F":()=>stKO("EuroCup · Final","bo3",P(79,85),szDates(.82,.86,3),{w:"WIN"})};
  if(b==="womens-basketball")return {
    "EL-RS":grp("EuroLeague Women · Regular season",7,76,88,2,.04,.5,{pos:{1:"EL-QF",2:"EL-QF",3:"EL-QF",4:"EL-QF"}}),
    "EL-QF":()=>stKO("EuroLeague Women · Quarter-final","bo3",P(80,86),szDates(.58,.62,3),{w:"EL-F4"}),
    "EL-F4":()=>stKO(y>=2025?"EuroLeague Women · Final Six semi-final":"EuroLeague Women · Final Four semi-final","1N",P(83,89),[.8],{w:"EL-F"}),
    "EL-F":()=>stKO("EuroLeague Women · Final","1N",P(84,89),[.81],{w:"WIN"}),
    "EC-RS":grp("EuroCup Women · Group stage",3,70,80,2,.04,.3,{pos:{1:"EC-R16",2:"EC-R16"}}),
    "EC-R16":()=>stKO("EuroCup Women · Round of 16","2L",P(72,80),[.4,.42],{w:"EC-QF"}),
    "EC-QF":()=>stKO("EuroCup Women · Quarter-final","2L",P(74,81),[.5,.52],{w:"EC-SF"}),
    "EC-SF":()=>stKO("EuroCup Women · Semi-final","2L",P(75,82),[.6,.62],{w:"EC-F"}),
    "EC-F":()=>stKO("EuroCup Women · Final","2L",P(76,83),[.7,.72],{w:"WIN"})};
  return {
    "CL-G":grp("CEV Champions League · Pool phase",3,74,87,2,.08,.4,{pos:{1:"CL-QF",2:y>=2019?"CL-QF":"CL-PO"}}),
    "CL-PO":()=>stKO("CEV Champions League · Playoffs","2L",P(80,86),[.5,.52],{w:"CL-QF"}),
    "CL-QF":()=>stKO("CEV Champions League · Quarter-final","2L",P(82,88),[.6,.62],{w:"CL-SF"}),
    "CL-SF":()=>stKO(y>=2019?"CEV Champions League · Semi-final":"CEV Champions League · Final Four semi-final",y>=2019?"2L":"1N",P(84,89),y>=2019?[.72,.74]:[.85],{w:"CL-F"}),
    "CL-F":()=>stKO("CEV Champions League · Final","1N",P(85,90),[.86],{w:"WIN"}),
    "CC-R16":()=>stKO("CEV Cup · Round of 16","2L",P(70,78),[.2,.22],{w:"CC-QF"}),"CC-QF":()=>stKO("CEV Cup · Quarter-final","2L",P(72,80),[.4,.42],{w:"CC-SF"}),
    "CC-SF":()=>stKO("CEV Cup · Semi-final","2L",P(74,82),[.55,.57],{w:"CC-F"}),"CC-F":()=>stKO("CEV Cup · Final","2L",P(76,83),[.7,.72],{w:"WIN"}),
    "CH-R32":()=>stKO("CEV Challenge Cup · Round of 32","2L",P(66,74),[.12,.14],{w:"CH-R16"}),"CH-R16":()=>stKO("CEV Challenge Cup · Round of 16","2L",P(68,76),[.25,.27],{w:"CH-QF"}),
    "CH-QF":()=>stKO("CEV Challenge Cup · Quarter-final","2L",P(70,78),[.42,.44],{w:"CH-SF"}),"CH-SF":()=>stKO("CEV Challenge Cup · Semi-final","2L",P(72,80),[.56,.58],{w:"CH-F"}),"CH-F":()=>stKO("CEV Challenge Cup · Final","2L",P(74,82),[.7,.72],{w:"WIN"})}}
/* --- Europe for women's football: Champions League qualifiers, then the Women's Europa Cup if they go out --- */
function szEuroWF(b,season,eu){const used=new Set(),P=(lo,hi)=>()=>szPickEU(b,lo,hi,used);
  return {"WCL-Q1":()=>stKO("Women's Champions League · Second qualifying round, semi-final","1",P(62,70),[-.2],{w:"WCL-Q2",l:"WEC-Q2"}),
   "WCL-Q2":()=>stKO("Women's Champions League · Second qualifying round, final","1",P(70,76),[-.19],{w:"WCL-Q3",l:"WEC-Q2"}),
   "WCL-Q3":()=>stKO("Women's Champions League · Third qualifying round","2L",P(74,82),[-.12,-.1],{w:"WCL-LP",l:"WEC-R16"}),
   "WCL-LP":()=>stLP("Women's Champions League · League phase",EU_WF.filter(x=>x[1]>=74),6,.1,.4,{lp:true,top:"WCL-QF",mid:"WCL-KO",cut:[4,12]},18),
   "WCL-KO":()=>stKO("Women's Champions League · Knockout play-off","2L",P(82,87),[.5,.52],{w:"WCL-QF"}),
   "WCL-QF":()=>stKO("Women's Champions League · Quarter-final","2L",P(85,90),[.62,.64],{w:"WCL-SF"}),
   "WCL-SF":()=>stKO("Women's Champions League · Semi-final","2L",P(87,91),[.75,.77],{w:"WCL-F"}),
   "WCL-F":()=>stKO("Women's Champions League · Final","1N",P(88,92),[.97],{w:"WIN"}),
   "WEC-Q2":()=>stKO("Women's Europa Cup · Second qualifying round","2L",P(62,70),[-.05,-.03],{w:"WEC-R16"}),
   "WEC-R16":()=>stKO("Women's Europa Cup · Round of 16","2L",P(72,79),[.2,.24],{w:"WEC-QF"}),
   "WEC-QF":()=>stKO("Women's Europa Cup · Quarter-final","2L",P(74,81),[.5,.53],{w:"WEC-SF"}),
   "WEC-SF":()=>stKO("Women's Europa Cup · Semi-final","2L",P(76,83),[.7,.73],{w:"WEC-F"}),
   "WEC-F":()=>stKO("Women's Europa Cup · Final","2L",P(77,84),[.88,.91],{w:"WIN"})}}
const szEuroKeys=(b,season,eu)=>b==="football"?szEuroFB(b,season,eu):b==="womens-football"?szEuroWF(b,season,eu):szEuroCourt(b,season,eu);

/* --- build a season --- */
function szLeagueField(b,D){const kind=SZ_KIND[b],top={fb:83,bb:84,wb:84,vb:87}[kind],bot={fb:71,bb:72,wb:66,vb:70}[kind],n=D.lg.length;
  return D.lg.map((x,i)=>Array.isArray(x)?{n:x[0],r:x[1]}:{n:x,r:+(top-(top-bot)*i/Math.max(1,n-1)).toFixed(1)})}
/* challenge codes: everyone with the same code gets the same draft offers and the same luck in the games */
let CH=null;
function chWith(b,k,fn){if(!CH||CH.b!==b)return fn();const o=Math.random;Math.random=CH[k]||(CH[k]=szRng(CH.seed*13+5));try{return fn()}finally{Math.random=o}}
function szNewSeason(b,season,myR,myName){if(CH&&CH.b===b&&season===CH.season){CH.rs=szRng(CH.seed*13+5);const S=chWith(b,"rs",()=>szNewSeasonRaw(b,season,myR,myName));S.ch=CH.code;return S}return szNewSeasonRaw(b,season,myR,myName)}
function szNewSeasonRaw(b,season,myR,myName){const kind=SZ_KIND[b],D=SZ_DATA[b][season],field=szLeagueField(b,D),C=[];
  const LN=D.league||SZ_LN[b];
  const lgEnd=kind==="fb"?.97:.74;
  /* league */
  const lg={id:"lg",name:LN,kind:"league",keys:{},stage:null,path:[],status:"in"};
  lg.stage=stRR(LN,[{n:"__me",me:true,r:myR},...field],2,.02,lgEnd,kind==="fb"?null:{playoffs:true});
  C.push(lg);
  /* super cup */
  if(D.sup){const o=field.find(x=>x.n===D.sup)||{n:D.sup,r:80};C.push({id:"sup",name:{fb:"Turkish Super Cup",bb:"Presidential Cup",wb:"Turkish Super Cup",vb:"Turkish Super Cup"}[kind],kind:"cup",stage:stKO({fb:"Turkish Super Cup",bb:"Presidential Cup",wb:"Turkish Super Cup",vb:"Turkish Super Cup"}[kind]+" · Final","1N",()=>o,[-.15],{w:"WIN"}),path:[],status:"in"})}
  /* domestic cup */
  if(D.cup!==false){const used=new Set(),opp=(lo,hi)=>()=>{const L=field.filter(x=>!used.has(x.n)&&x.r>=lo&&x.r<=hi),pool=L.length?L:field.filter(x=>!used.has(x.n)),o=pool[Math.floor(Math.random()*pool.length)];used.add(o.n);return o};
    const CN=kind==="fb"?"Turkish Cup":"Turkish Cup",rs=kind==="fb"?[["Round of 16",.45,"1",65,80],["Quarter-final",.6,"1",68,82],["Semi-final",.8,"1",72,84],["Final",.985,"1N",74,84]]:[["Quarter-final",.5,"1N",70,80],["Semi-final",.505,"1N",74,84],["Final",.51,"1N",76,88]];
    const keys={};rs.forEach(([nm,d,f,lo,hi],i)=>keys["C"+i]=()=>stKO(CN+" · "+nm,f,opp(lo,hi),[d],{w:i===rs.length-1?"WIN":"C"+(i+1)}));
    C.push({id:"cup",name:CN,kind:"cup",keys,stage:keys.C0(),path:[],status:"in",needTop8:kind!=="fb"})}
  /* Europe */
  if(D.eu){const keys=szEuroKeys(b,season,D.eu);C.push({id:"eu",name:"Europe",kind:"eu",keys,stage:keys[D.eu.e](),path:[],status:"in"})}
  return {b,kind,season,D,my:{n:myName,r:myR},C,log:[],done:false,scorers:{}}}

/* --- the next match in calendar order --- */
function szNext(S){let best=null;S.C.forEach(c=>{if(c.status!=="in"||!c.stage)return;const st=c.stage;let d=null;
  if(st.t==="rr"||st.t==="lp")d=st.ri<st.dates.length?st.dates[st.ri]:null;
  else if(st.t==="ko")d=st.dates[Math.min(st.games.length,st.dates.length-1)];
  if(d!=null&&(!best||d<best.d))best={c,d}});return best}

function szPlay(S){return S.ch&&CH&&CH.code===S.ch?chWith(S.b,"rs",()=>szPlayRaw(S)):szPlayRaw(S)}
function szPlayRaw(S){const nx=szNext(S);if(!nx){S.done=true;return null}const c=nx.c,st=c.stage,kind=S.kind;let entry=null;
  if(c.id==="cup"&&c.needTop8&&!c.checked){c.checked=true;const lg=S.C[0].stage,pos=szSort(lg.rows).findIndex(r=>r.me)+1;if(pos>8){c.status="out";c.path.push({st:st.name,txt:"Not in the top eight at the halfway point",win:false});return szPlay(S)}}
  if(st.t==="rr"){const pr=st.R[st.ri],mine=pr.find(p=>p.includes(0)),others=pr.filter(p=>p!==mine);
    const [h,a]=mine,ha=h===0?1:-1,o=st.rows[h===0?a:h],g=szGame(kind,S.my.r,o.r,ha);
    const A=st.rows[0];if(h===0)szApply(kind,A,o,g);else szApply(kind,o,A,{s:[g.s[1],g.s[0]]});
    others.forEach(([x,y])=>szApply(kind,st.rows[x],st.rows[y],szGame(kind,st.rows[x].r,st.rows[y].r,1)));
    entry={c:c.id,comp:st.name,round:st.ri+1,opp:o.n,ha,g};st.ri++;
    if(c.id==="lg"){S.line=S.line||[];S.line.push([A.pts,Math.max(...st.rows.map(r=>r.pts))])}
    if(st.ri>=st.R.length)szFinishRR(S,c,st)}
  else if(st.t==="lp"){const sl=st.opp[st.ri],o=st.rows[sl.o],g=szGame(kind,S.my.r,o.r,sl.ha);szApply(kind,st.rows[0],o,sl.ha===1?g:g);
    const others=shuffle(st.rows.slice(1).filter(r=>r!==o));for(let i=0;i+1<others.length;i+=2)szApply(kind,others[i],others[i+1],szGame(kind,others[i].r,others[i+1].r,1));
    entry={c:c.id,comp:st.name,round:st.ri+1,opp:o.n,ha:sl.ha,g};st.ri++;if(st.ri>=st.opp.length)szFinishRR(S,c,st)}
  else{if(!st.opp)st.opp=st.pick();const o=st.opp,i=st.games.length,f=st.fmt;
    const hi=st.homeFirst!==false,seq=f==="bo3"?[1,-1,1]:[1,1,-1,-1,1,-1,1],ha=f==="1N"?0:f==="1"?(st.ha1!=null?st.ha1:(st.ha1=Math.random()<.5?1:-1)):f==="2L"?(i===0?-1:1):seq[i]*(hi?1:-1);
    let g=szGame(kind,S.my.r,o.r,ha);
    if(f==="1"||f==="1N")g=szDecide(kind,g,S.my.r,o.r);
    if(f==="2L"&&i===1){const ag=[st.games[0].s[0]+g.s[0],st.games[0].s[1]+g.s[1]];
      if(kind==="vb"){const wins=[0,0];[st.games[0],g].forEach(x=>wins[szWin(x)]++);if(wins[0]===wins[1]){g.golden=Math.random()<clamp(.5+(S.my.r-o.r)*.02,.2,.8)?0:1}}
      else if(ag[0]===ag[1]){if(kind==="fb"){g.forceDecide=true;const t=szDecide("fb",{s:[0,0],forceDecide:true},S.my.r,o.r);if(t.aet){g.s[szWin(t)]++;g.aet=true}else g.pens=t.pens}else{g.s[Math.random()<.5?0:1]+=3;g.ot=1}}}
    st.games.push(g);entry={c:c.id,comp:st.name,opp:o.n,ha,g,leg:f==="2L"?i+1:f.startsWith("bo")?i+1:0,fmt:f};
    const res=szTieDone(kind,st);if(res!=null){entry.tie=res;szFinishKO(S,c,st,res)}}
  if(kind==="fb"&&entry)szScore(S,entry.g.s[0]);
  S.log.unshift(entry);if(!szNext(S))S.done=true;return entry}
/* tie state: null = still running, 0 = you went through, 1 = out */
function szTieDone(kind,st){const G=st.games,f=st.fmt;
  if(f==="1"||f==="1N")return szGW(G[0]);
  if(f==="2L"){if(G.length<2)return null;const L=G[1];if(L.golden!=null)return L.golden;if(L.pens)return L.pens[0]>L.pens[1]?0:1;
    if(kind==="vb"){const w=[0,0];G.forEach(x=>w[szWin(x)]++);return w[0]>w[1]?0:1}
    const a=G[0].s[0]+G[1].s[0],b=G[0].s[1]+G[1].s[1];return a>b?0:1}
  const need={bo3:2,bo5:3,bo7:4}[f],w=[0,0];G.forEach(x=>w[szWin(x)]++);return w[0]>=need?0:w[1]>=need?1:null}
function szFinishRR(S,c,st){const tab=szSort(st.rows),pos=tab.findIndex(r=>r.me)+1;st.final=tab;if(c.id==="lg")c.lastTab=tab;
  c.path.push({st:st.name,txt:`pos:${pos}/${tab.length}`,pos,win:true,table:true});
  if(c.id==="lg"){c.pos=pos;if(st.next&&st.next.playoffs){const n=tab.length,cut=Math.min(8,n);if(pos<=cut){c.po={tab,pos,cut};c.stage=szPlayoff(S,c,"QF");return}c.status="done";c.stage=null;return}
    c.status=pos===1?"won":"done";c.stage=null;return}
  const nx=st.next||{};let key=null;
  if(nx.lp){const [c1,c2]=nx.cut||[8,24];key=pos<=c1?nx.top:pos<=c2?nx.mid:null}else key=(nx.pos||{})[pos]||null;
  szGo(S,c,key)}
function szFinishKO(S,c,st,res){const w=res===0;c.path.push({st:st.name,opp:st.opp.n,games:st.games.slice(),win:w});
  if(c.id==="lg"){if(!w){c.status="done";c.stage=null;return}c.stage=c.poNext?c.poNext():null;if(!c.stage){c.status="won";c.poWon=true}return}
  const key=w?st.next.w:(st.next.l||null);if(key==="WIN"){c.status="won";c.stage=null;return}szGo(S,c,key)}
function szGo(S,c,key){if(!key||key==="OUT"||!c.keys[key]){c.status="out";c.stage=null;return}c.stage=c.keys[key]()}
/* league play-offs: seeds from the final table */
function szPlayoff(S,c,rd){const {tab,pos}=c.po,kind=S.kind,mirror=tab[tab.length>=8?8-pos:Math.max(0,tab.length-pos)]||tab[tab.length-1];
  const fmt={bb:{QF:"bo3",SF:"bo5",F:"bo7"},wb:{QF:"bo3",SF:"bo3",F:"bo5"},vb:{QF:"bo3",SF:"bo3",F:"bo3"}}[kind],used=new Set([mirror.n]);
  const pick=r=>()=>{if(r==="QF")return mirror;const L=tab.filter(x=>!x.me&&!used.has(x.n)).slice(0,r==="SF"?4:3);const o=pickW(L,x=>Math.pow(1.35,x.r-70));used.add(o.n);return o};
  const dates={QF:szDates(.78,.82,3),SF:szDates(.84,.88,5),F:szDates(.9,.96,7)},nm={QF:"Quarter-final",SF:"Semi-final",F:"Final"};
  const order=["QF","SF","F"],i=order.indexOf(rd);c.poNext=i<2?()=>szPlayoff(S,c,order[i+1]):null;
  const k=stKO(c.name+" · Play-off "+nm[rd].toLowerCase(),fmt[rd],pick(rd),dates[rd],{});k.homeFirst=rd==="QF"?pos<=4:pos===1;return k}
/* football scorers for the season summary */
function szScore(S,n){if(!n)return;let L=null;
  if(S.b==="football"){if(!dr||!dr.picks)return;const info=teamInfo(dr.form,dr.picks,dr.captain);L=dr.picks.map((p,j)=>({n:p.n,w:SCW[slotRole(dr.form,j)]*info.eff[j]/80}))}
  else{const s=tdS[S.b],C=TDCFG[S.b];if(!s||!C)return;const W={FW:6,MF:2.2,DF:.6,GK:0};L=s.picks.map((p,j)=>({n:p.n,w:(W[C.slots[j][0]]||1)*p.r/80}))}
  L=L.filter(x=>x.w>0);for(let k=0;k<n;k++){const nm=pickW(L,x=>x.w).n;S.scorers[nm]=(S.scorers[nm]||0)+1}}
function szRun(S,n){for(let i=0;i<n&&!S.done;i++)szPlay(S)}

/* --- results and trophies --- */
function szTrophies(S){const out=[];S.C.forEach(c=>{if(c.status!=="won")return;out.push(c.id==="lg"?(c.poWon||S.kind==="fb"?S.C[0].name:S.C[0].name):c.id==="eu"?c.path[c.path.length-1].st.split(" · ")[0]:c.name)});return out}
function szScoreTxt(S,e){const g=e.g;let s=`${g.s[0]}–${g.s[1]}`;if(g.ot)s+=" (OT)";if(g.aet)s+=" (aet)";if(g.pens)s+=` (${g.pens[0]}–${g.pens[1]} pens)`;if(g.golden!=null)s+=` · ${t(g.golden===0?"golden set won":"golden set lost")}`;return s}
function szStageName(st){const p=st.split(" · ");return p.map(x=>t(x)).join(" · ")}

/* --- UI --- */
const szReal=x=>typeof x==="number"?(x===1?t("Champions"):tf("Finished {p}",{p:ordL(x)})):t(x);
function szAllSeasons(b){return Object.keys(SZ_DATA[b]||{}).sort()}
function szSeasons(b){return CH&&CH.b===b?[CH.season]:szAllSeasons(b)}
function szEntryText(b,season,D){const parts=[t(D.league||SZ_LN[b])];if(D.cup!==false)parts.push(t("Turkish Cup"));if(D.sup)parts.push(t(SZ_KIND[b]==="bb"?"Presidential Cup":"Turkish Super Cup"));
  if(D.eu){const k=szEuroKeys(b,season,{e:D.eu.e,g:[]});const st=(k[D.eu.e]||(()=>({name:D.eu.e})))();parts.push(szStageName(st.name))}return parts.join(" · ")}
function szRender(b,el,myR,myName,onNew){if(EXT.szPre.some(f=>f(b,el,myR,myName,onNew)))return;szRenderRaw(b,el,myR,myName,onNew);runExt("szAfter",b,el,myR,myName,onNew)}
function szRenderRaw(b,el,myR,myName,onNew){const s=szS[b];
  if(!s||!s.S){const list=szSeasons(b),sel=s&&s.sel||list[list.length-1];szS[b]={sel};const D=SZ_DATA[b][sel];
    el.innerHTML=`<div class="szpick card"><span class="label">${t("Season mode")}</span><h3>${t("Pick a season to play")}</h3><p class="muted">${t("Your team replaces Fenerbahçe and plays every competition the club entered that season, game by game.")}</p>
      <div class="szyears" role="group" aria-label="${t("Season")}">${list.map(x=>`<button data-szy="${x}" aria-pressed="${x===sel}">${szDash(x)}</button>`).join("")}</div>
      ${D?`<div class="szinfo"><b>${szDash(sel)}</b><span>${esc(szEntryText(b,sel,D))}</span>${D.real!=null?`<span class="muted">${esc(tf("The real Fenerbahçe: {x}",{x:szReal(D.real)}))}</span>`:""}</div>`:""}
      <div class="btns"><button class="btn" data-sz="start">${t("Start the season")}</button>${onNew?`<button class="btn ghost" data-sz="new">${t("New draft")}</button>`:""}</div></div>`;
    el.querySelectorAll("[data-szy]").forEach(x=>x.onclick=()=>{szS[b].sel=x.dataset.szy;szRender(b,el,myR,myName,onNew)});
    el.querySelector('[data-sz="start"]').onclick=()=>{szS[b].S=szNewSeason(b,szS[b].sel,myR,myName);szRender(b,el,myR,myName,onNew)};
    const nw=el.querySelector('[data-sz="new"]');if(nw)nw.onclick=onNew;return}
  const S=s.S,kind=S.kind,lg=S.C[0],last=S.log[0],nx=szNext(S),played=S.log.length;
  const tblRows=st=>{const tab=st.final||szSort(st.rows),me=tab.findIndex(r=>r.me),show=tab.length>12&&!s.full?tab.map((r,i)=>i<6||Math.abs(i-me)<=2||i>=tab.length-2?i:-1).filter(i=>i>=0):tab.map((_,i)=>i);
    let prev=-1;return show.map(i=>{const r=tab[i],gap=prev>=0&&i>prev+1?`<tr class="gap"><td colspan="6">…</td></tr>`:"";prev=i;return gap+`<tr class="${r.me?"fbrow":""}"><td class="pos">${i+1}</td><td class="tm">${esc(r.me?S.my.n:r.n)}</td><td>${r.p}</td><td>${kind==="fb"?`${r.w}-${r.d}-${r.l}`:`${r.w}-${r.l}`}</td><td class="hm">${r.f}:${r.a}</td><td class="kc">${r.pts}</td></tr>`}).join("")};
  const table=(st,title)=>`<div class="tscroll"><table class="stand sztab"><thead><tr><th class="pos">#</th><th class="tm">${t("Team")}</th><th>${t("col:P")}</th><th>${t(kind==="fb"?"W-D-L":"W-L")}</th><th class="hm">${t(kind==="vb"?"Sets":kind==="fb"?"Goals":"Points")}</th><th class="kc">${t("col:Pts")}</th></tr></thead><tbody>${tblRows(st)}</tbody></table></div>`;
  const pathLi=p=>p.table?`<li class="w"><span class="label">${esc(szStageName(p.st))}</span><b>${tf("Finished {p} of {n}",{p:ordL(p.pos),n:p.txt.split("/")[1]})}</b></li>`
    :p.games?`<li class="${p.win?"w":"l"}"><span class="label">${esc(szStageName(p.st))}</span><b>${esc(p.opp)}</b><span class="res">${p.games.map(g=>szScoreTxt(S,{g})).join(", ")}</span></li>`:`<li class="l"><span class="label">${esc(szStageName(p.st))}</span><b>${esc(t(p.txt))}</b></li>`;
  const compCard=c=>{const live=c.stage&&(c.stage.t==="rr"||c.stage.t==="lp")&&c.id!=="lg"?table(c.stage):"";const st=c.status==="won"?`<span class="chip win">${t("Winners")}</span>`:c.status==="out"?`<span class="chip loss">${t("Out")}</span>`:c.status==="done"?"":`<span class="chip">${t("Still in")}</span>`;
    return `<article class="card szcomp"><header><h3>${esc(c.id==="eu"?szStageName((c.stage?c.stage.name:c.path[c.path.length-1].st).split(" · ")[0]):t(c.name))}</h3>${st}</header><ol class="szpath">${c.path.filter(p=>c.id!=="lg"||!p.table).map(pathLi).join("")}${c.stage&&c.stage.t==="ko"?`<li class="next"><span class="label">${esc(szStageName(c.stage.name))}</span><b>${c.stage.opp?esc(c.stage.opp.n):t("Draw to come")}</b></li>`:""}</ol>${live}</article>`};
  const lastCard=last?`<article class="card szlast"><span class="label">${esc(szStageName(last.comp))}${last.round?` · ${tf("Matchday {n}",{n:last.round})}`:""}${last.leg&&last.fmt==="2L"?` · ${tf("Leg {n}",{n:last.leg})}`:last.leg?` · ${tf("Game {n}",{n:last.leg})}`:""}</span>
     <div class="szscore"><span class="${last.ha!==-1?"fb":""}">${esc(last.ha===-1?last.opp:S.my.n)}</span><b>${last.ha===-1?`${last.g.s[1]}–${last.g.s[0]}`:`${last.g.s[0]}–${last.g.s[1]}`}</b><span class="${last.ha===-1?"fb":""}">${esc(last.ha===-1?S.my.n:last.opp)}</span></div>
     ${(()=>{const ex=[],g=last.g;if(g.ot)ex.push(t("Overtime"));if(g.aet)ex.push(t("After extra time"));if(g.pens)ex.push(tf("{a}–{b} on penalties",{a:g.pens[0],b:g.pens[1]}));if(g.sets)ex.push((last.ha===-1?g.sets.map(x=>[x[1],x[0]]):g.sets).map(x=>x.join("–")).join(", "));if(g.golden!=null)ex.push(t(g.golden===0?"golden set won":"golden set lost"));if(last.tie!=null)ex.push(`<b>${t(last.tie===0?"Through":"Knocked out")}</b>`);return ex.length?`<p class="muted">${ex.join(" · ")}</p>`:""})()}</article>`:"";
  const tro=szTrophies(S),scorers=Object.entries(S.scorers).sort((a,b)=>b[1]-a[1]).slice(0,3);
  const summary=S.done?`<article class="card szsum"><span class="label">${tf("Season {s} · final whistle",{s:szDash(S.season)})}</span><h3>${tro.length===1?t("1 trophy"):tro.length?tf("{n} trophies",{n:tro.length}):t("No trophies this time")}</h3>
     ${tro.length?`<div class="cups">${CUP.repeat(tro.length)}</div><p>${tro.map(x=>esc(t(x))).join(" · ")}</p>`:""}
     <p class="muted">${tf("League: {p}",{p:ordL(lg.pos||0)})}${S.D.real!=null?` · ${esc(tf("The real Fenerbahçe: {x}",{x:szReal(S.D.real)}))}`:""}</p>${scorers.length?`<p class="muted">${t("Top scorers")}: ${scorers.map(([n,g])=>`${esc(n)} ${g}`).join(", ")}</p>`:""}</article>`:"";
  if(S.done&&!S.saved){S.saved=true;const k=SK(b,"sz-best"),best=store.get(k,0);if(tro.length>best)store.set(k,tro.length);store.set(SK(b,"sz-titles"),store.get(SK(b,"sz-titles"),0)+tro.length);
    if(b==="football"&&S.C[0].status==="won")store.set("fb-cups",store.get("fb-cups",0)+1);if(S.C.some(c=>c.id==="eu"&&c.status==="won"))store.set(SK(b,"cups"),store.get(SK(b,"cups"),0)+1);if(typeof xBadgeCheck==="function")xBadgeCheck()}
  el.innerHTML=`<div class="szhead"><div><span class="label">${t("Season mode")} · ${szDash(S.season)}</span><h3>${esc(S.my.n)} · ${S.my.r.toFixed(1)}</h3></div><span class="muted">${tf("{n} games played",{n:played})}</span></div>
    ${summary}
    <div class="btns">${S.done?`<button class="btn" data-sz="again">${t("Play this season again")}</button><button class="btn ghost" data-sz="other">${t("Pick another season")}</button>`:`<button class="btn" data-sz="one">${nx?esc(tf("Next: {x}",{x:szStageName(nx.c.stage.name)})):t("Next match")}</button><button class="btn ghost" data-sz="five">${t("Play 5 games")}</button><button class="btn ghost" data-sz="all">${t("Play to the end")}</button><button class="btn ghost" data-sz="other">${t("Pick another season")}</button>`}${onNew?`<button class="btn ghost" data-sz="new">${t("New draft")}</button>`:""}</div>
    ${lastCard}
    <div class="szgrid"><article class="card szcomp szleague"><header><h3>${esc(t(lg.name))}</h3>${lg.status==="won"?`<span class="chip win">${t("Champions")}</span>`:""}</header>${typeof seasonLine==="function"?seasonLine(S):""}${table(lg.stage&&lg.stage.t==="rr"?lg.stage:{rows:[],final:lg.lastTab||[]})}
      ${lg.path.some(p=>!p.table)||lg.stage&&lg.stage.t==="ko"?`<ol class="szpath">${lg.path.filter(p=>!p.table).map(pathLi).join("")}${lg.stage&&lg.stage.t==="ko"?`<li class="next"><span class="label">${esc(szStageName(lg.stage.name))}</span><b>${lg.stage.opp?esc(lg.stage.opp.n):t("Draw to come")}</b></li>`:""}</ol>`:""}
      <button class="linkbtn" data-sz="full">${s.full?t("Show fewer"):t("Show the full table")}</button></article>
      ${S.C.slice(1).map(compCard).join("")}</div>
    <details class="szlog"><summary>${tf("All results ({n})",{n:played})}</summary><ol>${S.log.map(e=>`<li><span class="label">${esc(szStageName(e.comp))}</span><span>${t(e.ha===1?"ha:H":e.ha===-1?"ha:A":"ha:N")} ${esc(e.opp)}</span><b>${szScoreTxt(S,e)}</b></li>`).join("")}</ol></details>
    <p class="gnote">${t("Rivals and their strengths are estimates made for this game, and formats are simplified. Cup and European draws are random among clubs of a similar level.")}</p>`;
  const on=(k,f)=>{const x=el.querySelector(`[data-sz="${k}"]`);if(x)x.onclick=f},re=()=>szRender(b,el,myR,myName,onNew);
  on("one",()=>{szPlay(S);re()});on("five",()=>{szRun(S,5);re()});on("all",()=>{szRun(S,400);re()});on("full",()=>{s.full=!s.full;re()});
  on("again",()=>{s.S=szNewSeason(b,S.season,myR,myName);re()});on("other",()=>{s.sel=S.season;s.S=null;re()});if(onNew)on("new",onNew)}

/* --- hook into the drafts: replaces the Legends Cup and the Final Four --- */
function szArea(host){let a=document.getElementById("szArea");if(!a){a=document.createElement("div");a.id="szArea";a.className="szarea";host.insertAdjacentElement("afterend",a)}return a}
function renderCupBox(){const el=document.getElementById("cupBox");if(!el||!dr)return;const info=teamInfo(dr.form,dr.picks,dr.captain);
  el.innerHTML=`<span class="label">${t("Your XI")}</span><h3 style="margin-top:4px">${t(tier(info.ovr))}</h3><p class="gnote">${t("Pick a season below and play it through.")}</p>`;
  const host=el.closest(".draft");if(!host)return;szRender("football",szArea(host),info.ovr,t("Your XI"),()=>{szS.football=null;newDraft(dr.form);renderPanel()})}
function tdCupRender(b){const el=document.getElementById("tdCup"),C=TDCFG[b],s=tdS[b];if(!el||!s)return;const me=tdInfo(C,s.picks);
  el.innerHTML=`<span class="label">${t(C.unit==="five"?"Your five":C.unit==="eleven"?"Your XI":"Your six")}</span><h3 style="margin-top:4px">${t(me.ovr>=88?"A dynasty in the making.":me.ovr>=85?"Title favourites.":me.ovr>=82?"Contenders.":"Underdogs, but anything can happen.")}</h3><p class="gnote">${t("Pick a season below and play it through.")}</p>`;
  const host=el.closest(".draft");if(!host)return;szRender(b,szArea(host),me.ovr,t(C.unit==="five"?"Your five":C.unit==="eleven"?"Your XI":"Your six"),()=>{szS[b]=null;newTD(b);rerender()})}
