const {chromium}=require('playwright');
const LANG=process.argv[2]||'en';
(async()=>{const b=await chromium.launch();const errs=[];
for(const [w,h,tag] of [[1280,900,'d'],[390,844,'m']]){const pg=await b.newPage({viewport:{width:w,height:h}});pg.on('pageerror',e=>errs.push(tag+': '+e.message));
 await pg.goto('file://'+process.cwd()+'/fenerbahce.html#football');await pg.waitForTimeout(200);if(LANG!=='en'){await pg.selectOption('#lang',LANG);await pg.waitForTimeout(100)}
 const shot=async n=>{await pg.waitForTimeout(150);await pg.locator('#panel').screenshot({path:`n_${tag}_${LANG}_${n}.png`})};
 for(const tb of ['derbies','squad','venue','history']){await pg.evaluate(x=>{tab=x;syncHash();render()},tb);await shot('fb_'+tb)}
 await pg.evaluate(x=>{tab=x;syncHash();render()},'matches');if(await pg.$('.predtog'))await pg.click('.predtog');await pg.fill('#pFb','2');await pg.fill('#pOp','1');await pg.click('#pSave');await pg.selectOption('#mSel',{index:3});await pg.click('#mVote');await shot('fb_matches');
 await pg.selectOption('#sport','womens-football');await pg.evaluate(x=>{tab=x;syncHash();render()},'matches');await shot('more_matches');await pg.evaluate(x=>{tab=x;syncHash();render()},'standings');await shot('more_stand');
 await pg.selectOption('#sport','volleyball');await pg.evaluate(x=>{tab=x;syncHash();render()},'squad');await shot('vb_squad');await pg.evaluate(x=>{tab=x;syncHash();render()},'venue');await shot('vb_venue');
 await pg.selectOption('#sport','football');await pg.evaluate(x=>{tab=x;syncHash();render()},'play');
 await pg.evaluate(g=>pickGame(g),'daily');for(let i=0;i<5;i++){await pg.click('[data-do]');await pg.waitForTimeout(1000)}await shot('daily');
 await pg.evaluate(g=>pickGame(g),'hol');for(let i=0;i<4;i++){const x=await pg.$('[data-hl=hi]');if(x){await x.click();await pg.waitForTimeout(50)}const n=await pg.$('[data-hl=next]');if(n)await n.click()}await shot('hol');
 await pg.evaluate(g=>pickGame(g),'gts');for(let i=0;i<8;i++){await pg.fill('#gH','1');await pg.fill('#gA','0');await pg.click('[data-g=go]');await pg.click('[data-g=next]')}await shot('gts');
 await pg.evaluate(g=>pickGame(g),'board');await shot('board');await pg.evaluate(g=>pickGame(g),'badges');await shot('badges');
 console.log(tag,'sw',await pg.evaluate(()=>document.documentElement.scrollWidth));await pg.close()}
console.log('errors',JSON.stringify(errs));await b.close()})();
