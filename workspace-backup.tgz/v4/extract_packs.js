const {chromium}=require('playwright');const fs=require('fs');
(async()=>{const b=await chromium.launch();const pg=await b.newPage();await pg.goto('file://'+process.cwd()+'/v4/fenerbahce_full.html');await pg.waitForTimeout(400);
for(const L of ['tr','de','es','fr','ar']){const p=await pg.evaluate(L=>{const D=DICT[L],Lo=LOWER[L],sim={};Object.keys(D).forEach(en=>{const k=en.toLowerCase();if(!sim[k])sim[k]=[en,D[en]]});
  const o=[];Object.entries(Lo).forEach(([k,v])=>{const s=sim[k];if(!s||s[0]!==v[0]||s[1]!==v[1])o.push([k,v[0],v[1]])});return {d:D,o}},L);
  const js=`LANGPACK(${JSON.stringify(L)},${JSON.stringify(p)});\n`;fs.writeFileSync(`v4/lang-${L}.js`,js);console.log(L,Object.keys(p.d).length,'overrides',p.o.length,js.length)}
await b.close()})();
