const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();
for(const [w,h,tag] of [[1280,900,'d'],[390,844,'m']]){const pg=await b.newPage({viewport:{width:w,height:h}});const errs=[];pg.on('pageerror',e=>errs.push(e.message));
await pg.goto('file://'+process.cwd()+'/fenerbahce.html#football');await pg.waitForTimeout(300);
await pg.selectOption('#lang','ar');await pg.waitForTimeout(200);
await pg.screenshot({path:`../s_ar_${tag}_top.png`});
await pg.click('[data-tab=standings]');await pg.waitForTimeout(150);await pg.evaluate(()=>document.querySelector('.tabs').scrollIntoView());await pg.screenshot({path:`../s_ar_${tag}_stand.png`});
await pg.click('[data-tab=history]');await pg.waitForTimeout(150);await pg.evaluate(()=>document.querySelector('.tabs').scrollIntoView());await pg.screenshot({path:`../s_ar_${tag}_hist.png`});
await pg.click('[data-tab=play]');await pg.waitForTimeout(150);await pg.click('[data-game=hol]').catch(()=>{});await pg.waitForTimeout(150);await pg.evaluate(()=>document.querySelector('#gameArea').scrollIntoView());await pg.screenshot({path:`../s_ar_${tag}_hol.png`});
for(const L of ['es','fr']){await pg.selectOption('#lang',L);await pg.waitForTimeout(150);await pg.evaluate(()=>scrollTo(0,0));await pg.screenshot({path:`../s_${L}_${tag}_top.png`,clip:{x:0,y:0,width:w,height:Math.min(h,500)}})}
console.log(tag,errs, await pg.evaluate(()=>document.documentElement.scrollWidth));await pg.close()}
await b.close()})();
