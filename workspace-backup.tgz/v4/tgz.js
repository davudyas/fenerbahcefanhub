const {chromium}=require('playwright');const gzAuto=require('./gzauto.js');
(async()=>{const b=await chromium.launch();const errs=[];
for(const [w,h,dv,rm] of [[1366,900,'d','no-preference'],[390,844,'m','reduce']]){const ctx=await b.newContext({viewport:{width:w,height:h},reducedMotion:rm});const pg=await ctx.newPage();pg.on('pageerror',e=>errs.push(e.message));
 await pg.goto('file://'+process.cwd()+'/fenerbahce.html#football-play');await pg.waitForTimeout(400);await pg.evaluate(()=>pickGame('draft'));await pg.waitForTimeout(200);
 await pg.screenshot({path:`../gz_${dv}_0.png`});
 if(dv==='d'||dv==='m'){await pg.click('[data-gz="form"]');await pg.waitForTimeout(700);await pg.screenshot({path:'../gz_d_spin.png'});await pg.waitForSelector('[data-gz="season"]');await pg.click('[data-gz="season"]');await pg.waitForSelector('.gzsq');await pg.screenshot({path:'../gz_d_squad.png'});
   const b2=await pg.$('.gzp:not([disabled])');await b2.click();await pg.waitForTimeout(100);await pg.screenshot({path:'../gz_d_sel.png'});await pg.evaluate(()=>{newDraft();renderPanel()})}
 const k=await gzAuto(pg,async()=>pg.screenshot({path:`../gz_${dv}_sq.png`,fullPage:false}));
 console.log(dv,'steps',k,await pg.evaluate(()=>[dr.form,dr.picks.map(p=>p.short+":"+p.r).join(","),gzStrength(dr.picks).str.toFixed(1),dr.rerolls,dr.spun.join(" ")]));
 await pg.screenshot({path:`../gz_${dv}_done.png`,fullPage:true});
 await pg.click('[data-sz="start"]').catch(e=>console.log('nostart'));await pg.waitForTimeout(300);await pg.click('[data-sz="all"]').catch(()=>{});await pg.waitForTimeout(300);
 await pg.screenshot({path:`../gz_${dv}_season.png`,fullPage:false});
 console.log(dv,'sw',await pg.evaluate(()=>document.documentElement.scrollWidth));await ctx.close()}
console.log('errs',errs);await b.close()})();
