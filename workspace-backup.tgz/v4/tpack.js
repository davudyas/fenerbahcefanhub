const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const snap=async f=>{const pg=await b.newPage({viewport:{width:1280,height:900}});const errs=[];pg.on('pageerror',e=>errs.push(e.message));
 await pg.goto('file://'+process.cwd()+'/'+f);await pg.waitForTimeout(400);const out={};
 for(const L of ['tr','de','es','fr','ar']){await pg.selectOption('#lang',L);await pg.waitForTimeout(250);
  for(const br of ['home','football','basketball','womens-basketball','volleyball','mens-volleyball','womens-football','more']){const tabs=br==='home'?['x']:await pg.evaluate(br=>tabsFor(br).map(x=>x[0]),br);
   for(const tb of tabs){out[L+'/'+br+'/'+tb]=await pg.evaluate(([br,tb])=>{setSport(br);if(tb!=='x'){tab=tb;render()}return document.body.innerText},[br,tb])}}}
 await pg.close();return [out,errs]};
const [A,ea]=await snap('fenerbahce_full.html'),[B,eb]=await snap('fenerbahce.html');let diff=0;
for(const k in A){if(A[k]!==B[k]){diff++;const a=A[k].split('\n'),c=B[k].split('\n');const d=a.filter((x,i)=>x!==c[i]).slice(0,2);console.log('DIFF',k,JSON.stringify(d).slice(0,300),'|',JSON.stringify(c.filter((x,i)=>x!==a[i]).slice(0,2)).slice(0,300))}}
console.log('pages',Object.keys(A).length,'diffs',diff,ea,eb);await b.close()})();
