/* ===== Title race: simulate the rest of the league thousands of times from the current table.
   Fenerbahçe's own upcoming league games can be set to win, draw or loss. All odds are estimates. ===== */
const RACE_NEXT={"Basketbol Süper Ligi":"BSL"};
function raceTables(b){const L=LIVE[b];if(!L||!L.tables)return [];return L.tables.map((T,i)=>({T,i})).filter(({T})=>T.rows&&T.rows.length>=4&&T.cols.includes("P")&&T.rows.some(r=>r[0]==="Fenerbahçe"))}
function raceKind(T){return T.cols.includes("D")?"fb":/Sultanlar|Efeler/.test(T.comp)?"vb":"bb"}
let RS={};
function raceState(b){const tabs=raceTables(b);if(!tabs.length)return null;let s=RS[b];if(!s||!tabs[s.ti]){s=RS[b]={ti:0,fix:{},form:0}}return s}
/* table names can differ from result names by a sponsor ("Galatasaray" / "Galatasaray Daikin") */
function raceTeamIdx(teams,name){let j=teams.findIndex(x=>x.n===name);if(j<0)j=teams.findIndex(x=>name.startsWith(x.n+" ")||x.n.startsWith(name+" "));return j}
function raceData(b,s){const {T}=raceTables(b)[s.ti],kind=raceKind(T),ci=c=>T.cols.indexOf(c),P=ci("P"),W=ci("W"),D=ci("D"),Lc=ci("L"),n=T.rows.length,total=2*(n-1);
  const teams=T.rows.map(r=>{const p=+r[P+1],w=+r[W+1],d=D>=0?+r[D+1]:0,l=+r[Lc+1],pts=kind==="bb"&&ci("Pts")<0?w:+r[T.key+1];return {n:r[0],p,w,d,l,pts,left:Math.max(0,total-p)}});
  const nextComp=RACE_NEXT[T.comp]||T.comp,fx=(LIVE[b].next||[]).filter(x=>x[2]===nextComp).slice(0,8),fb=teams.findIndex(x=>x.n==="Fenerbahçe");
  /* Fenerbahçe's remaining league games: everyone twice, once at home and once away, minus the games already played.
     Only used when the results list covers every game in the table, so the opponents and venues are exact. */
  let rem=null;if(fb>=0){const played=LIVE[b].last.filter(r=>r[1]===T.comp||r[1]===nextComp);
    if(played.length===teams[fb].p){const need=new Map();teams.forEach((x,j)=>{if(j!==fb){need.set(j+"H",1);need.set(j+"A",1)}});let ok=true;
      played.forEach(r=>{const j=raceTeamIdx(teams,r[3]),k=j+(r[2]==="A"?"A":"H");if(j<0||!need.has(k)){ok=false;return}need.delete(k)});
      if(ok){rem=[];fx.forEach((f,k)=>{const j=raceTeamIdx(teams,f[4]),key=j+(f[3]==="A"?"A":"H");if(j>=0&&need.has(key)){need.delete(key);rem.push({j,home:f[3]!=="A",fx:k})}});
        [...need.keys()].forEach(key=>rem.push({j:parseInt(key,10),home:key.endsWith("H"),fx:null}));if(rem.length!==teams[fb].left)rem=null}}}
  return {T,kind,teams,total,fx,n,fb,rem}}
/* home advantage on the log-odds scale: about 60% home wins in basketball, a little less in football and volleyball */
const RACE_HOME={fb:.3,bb:.4,vb:.2};
/* one season run: returns final order of team indexes */
function raceRun(D,s,str){const pts=D.teams.map(x=>x.pts),wins=D.teams.map(x=>x.w),left=D.teams.map(x=>x.left),n=D.n,fb=D.fb,HA=RACE_HOME[D.kind];
  const award=(i,j,res)=>{/* res: 1 i wins, 0 draw, -1 j wins */
    if(D.kind==="fb"){if(res>0)pts[i]+=3;else if(res<0)pts[j]+=3;else{pts[i]++;pts[j]++}}
    else if(D.kind==="vb"){const tie=Math.random()<.25;if(res>0){pts[i]+=tie?2:3;if(tie)pts[j]+=1;wins[i]++}else{pts[j]+=tie?2:3;if(tie)pts[i]+=1;wins[j]++}}
    else{const ptsMode=D.T.cols.includes("Pts");if(res>0){wins[i]++;pts[i]+=ptsMode?2:1;if(ptsMode)pts[j]+=1}else{wins[j]++;pts[j]+=ptsMode?2:1;if(ptsMode)pts[i]+=1}}};
  const lg=x=>Math.log(x/(1-x));
  /* result from the home side's point of view */
  const play=(h,a)=>{const pw=1/(1+Math.exp(-(lg(str[h])-lg(str[a])+HA)));if(D.kind==="fb"){const dr=.26,r=Math.random();return r<dr?0:(r<dr+(1-dr)*pw?1:-1)}return Math.random()<pw?1:-1};
  const game=(i,j,iHome)=>iHome?play(i,j):-play(j,i);
  const setRes=k=>{const v=k!=null&&s.fix[k];return v?(v==="W"?1:v==="D"?0:-1):null};
  if(fb>=0&&D.rem){D.rem.forEach(g=>{const r=setRes(g.fx),res=r!=null?r:game(fb,g.j,g.home);award(fb,g.j,res);left[fb]--;if(left[g.j]>0)left[g.j]--})}
  else if(fb>=0){D.fx.forEach((f,k)=>{const r=setRes(k);if(r==null||left[fb]<=0)return;const j=raceTeamIdx(D.teams,f[4]);
    if(j>=0&&left[j]>0){award(fb,j,r);left[j]--}else{const o=(fb+1+Math.floor(Math.random()*(n-1)))%n;award(fb,o,r)}left[fb]--})}
  /* everyone else: random opponents among teams that still have games, random venue */
  for(let i=0;i<n;i++)while(left[i]>0){const c=[];for(let j=0;j<n;j++)if(j!==i&&left[j]>0&&!(D.rem&&j===fb))c.push(j);
    let j;if(c.length){j=c[Math.floor(Math.random()*c.length)];left[j]--}else{j=Math.floor(Math.random()*(n-1));if(j>=i)j++}
    left[i]--;award(i,j,game(i,j,Math.random()<.5))}
  return {order:[...Array(n).keys()].sort((a,c)=>pts[c]-pts[a]||wins[c]-wins[a]||Math.random()-.5),pts}}
function raceSim(b,s,N=3000){const D=raceData(b,s),n=D.n,fb=D.teams.findIndex(x=>x.n==="Fenerbahçe");
  const gdI=D.T.cols.indexOf("GD"),str=D.teams.map((x,i)=>{const g=Math.max(1,x.p);let v;
    if(D.kind==="fb"){const gd=gdI>=0?parseInt(String(D.T.rows.find(r=>r[0]===x.n)[gdI+1]).replace("−","-"),10)||0:0,r=((x.pts/g-1.4)*.6+(gd/g)*.25)*g/(g+8);v=1/(1+Math.exp(-1.6*r))}
    else v=(x.w+.5*8)/(g+8);
    if(i===fb)v=clamp(v+s.form*.05,.05,.95);return clamp(v,.06,.94)});
  const pos=D.teams.map(()=>new Array(n).fill(0)),sum=D.teams.map(()=>0);
  for(let r=0;r<N;r++){const {order,pts}=raceRun(D,s,str);order.forEach((ti,p)=>{pos[ti][p]++;sum[ti]+=pts[ti]})}
  return {D,N,fb,rows:D.teams.map((x,i)=>({n:x.n,now:x.pts,proj:sum[i]/N,pos:pos[i].map(v=>v/N)})).sort((a,c)=>c.proj-a.proj)}}
const pct=v=>v>=.995?"99%+":v<.005&&v>0?"<1%":Math.round(v*100)+"%";
function renderRace(p){const b=current,s=raceState(b);if(!s){p.innerHTML=`<h2>${t("Title race")}</h2><p class="muted">${t("There's no league table for this branch yet.")}</p>`;return}
  const tabs=raceTables(b),R=raceSim(b,s),D=R.D,me=R.rows.find(r=>r.n==="Fenerbahçe"),n=D.n,top=Math.min(4,n-1),bottom=D.kind==="fb"&&n>=14?3:0;
  const chartRows=R.rows.slice().sort((a,c)=>c.pos[0]-a.pos[0]).filter((r,i)=>i<8&&(r.pos[0]>0||r.n==="Fenerbahçe"));
  const lbl=x=>D.kind==="fb"?{W:t("Win"),D:t("Draw"),L:t("Loss")}[x]:{W:t("Win"),L:t("Loss")}[x];
  p.innerHTML=`<h2>${t("Title race")} ${dchip("est")}</h2><p class="intro">${tf("We play out the rest of the {c} {n} times from today's table, using each team's results so far. Change Fenerbahçe's next games and watch the odds move.",{c:t(D.T.comp),n:R.N.toLocaleString()})}</p>
   ${tabs.length>1?`<div class="filter" role="group" aria-label="${t("Competition")}">${tabs.map((x,k)=>`<button data-rti="${k}" aria-pressed="${k===s.ti}">${esc(t(x.T.comp))}</button>`).join("")}</div>`:""}
   <div class="racegrid">
    <article class="card racebig"><span class="label">${t("Fenerbahçe")}</span><div class="raceodds"><div><b>${pct(me.pos[0])}</b><span>${t("finish first")}</span></div><div><b>${pct(me.pos.slice(0,top).reduce((a,v)=>a+v,0))}</b><span>${tf("top {n}",{n:top})}</span></div>${n>=12?`<div><b>${pct(me.pos.slice(0,8).reduce((a,v)=>a+v,0))}</b><span>${tf("top {n}",{n:8})}</span></div>`:""}<div><b>${me.proj.toFixed(0)}</b><span>${t("projected points")}</span></div></div>
     <span class="label" style="margin-top:12px">${t("Where Fenerbahçe finish")}</span>${raceHist(me.pos)}</article>
    <article class="card"><span class="label">${t("Fenerbahçe's next league games")}</span>${D.fx.length?`<ul class="racefx">${D.fx.map((f,k)=>`<li><div><span class="muted">${f[0]?mDate(f[0],true):esc(t(f[5]||""))}</span><b>${esc(f[3]==="H"?"Fenerbahçe – "+f[4]:f[4]+" – Fenerbahçe")}</b></div><div class="seg" role="group" aria-label="${esc(f[4])}">${["","W",...(D.kind==="fb"?["D"]:[]),"L"].map(x=>`<button data-rfx="${k}|${x}" aria-pressed="${(s.fix[k]||"")===x}" class="${x?"r"+x:""}">${x?lbl(x):t("Sim")}</button>`).join("")}</div></li>`).join("")}</ul>`:`<p class="muted">${t("No league fixtures listed yet.")}</p>`}
     ${D.rem&&D.rem.some(g=>g.fx==null)?`<details class="racerest"><summary>${esc(tf("All {n} remaining league games",{n:D.rem.length}))}</summary><p class="muted">${D.rem.map(g=>`${esc(D.teams[g.j].n)} <small>(${t(g.home?"home":"away")})</small>`).join(", ")}</p></details>`:""}
     <label class="raceform"><span>${t("Fenerbahçe's form for the rest of the season")}</span><input type="range" min="-3" max="3" step="1" value="${s.form}" id="raceForm"><span class="muted">${esc(t(["Poor","Shaky","Off the pace","As now","Good","Strong","Unstoppable"][s.form+3]))}</span></label>
     <div class="btns"><button class="btn ghost" data-race="reset">${t("Reset")}</button><button class="btn ghost" data-race="again">${t("Run again")}</button></div></article></div>
   <figure class="card racechart"><figcaption class="label">${t("Chance of finishing first")}</figcaption>${chartRows.map(r=>`<div class="rcrow ${r.n==="Fenerbahçe"?"me":""}"><span>${esc(r.n)}</span><div class="rcbar"><i style="width:${(r.pos[0]*100).toFixed(1)}%"></i></div><b>${pct(r.pos[0])}</b></div>`).join("")}</figure>
   <div class="tscroll card racetable"><table class="stand"><thead><tr><th>#</th><th>${t("Team")}</th><th>${t("Now")}</th><th>${t("Projected")}</th><th>${t("1st")}</th><th>${tf("Top {n}",{n:top})}</th>${bottom?`<th>${tf("Bottom {n}",{n:bottom})}</th>`:""}</tr></thead><tbody>${R.rows.map((r,i)=>`<tr class="${r.n==="Fenerbahçe"?"fb":""}"><td>${i+1}</td><td>${esc(r.n)}</td><td>${r.now}</td><td>${r.proj.toFixed(1)}</td><td>${pct(r.pos[0])}</td><td>${pct(r.pos.slice(0,top).reduce((a,v)=>a+v,0))}</td>${bottom?`<td>${pct(r.pos.slice(n-bottom).reduce((a,v)=>a+v,0))}</td>`:""}</tr>`).join("")}</tbody></table></div>
   <p class="fine">${D.rem?tf("Fenerbahçe's {r} remaining league games use the real opponents and venues. The other teams play out the rest of their {g}-game season against random opponents. Win chances come from results so far, with an edge for the home side. It doesn't know injuries or transfers, so treat it as a rough guide.",{r:D.rem.length,g:D.total}):tf("Each team plays out the rest of its {g}-game season against random opponents, with win chances based on results so far and an edge for the home side. It doesn't know injuries, transfers or the real fixture list, so treat it as a rough guide.",{g:D.total})}</p>`;
  p.querySelectorAll("[data-rti]").forEach(x=>x.onclick=()=>{s.ti=+x.dataset.rti;s.fix={};renderRace(p)});
  p.querySelectorAll("[data-rfx]").forEach(x=>x.onclick=()=>{const [k,v]=x.dataset.rfx.split("|");if(v)s.fix[k]=v;else delete s.fix[k];renderRace(p);const f=p.querySelector(`[data-rfx="${k}|${v}"]`);if(f)f.focus()});
  const fr=$("raceForm");let tm;fr.oninput=()=>{clearTimeout(tm);tm=setTimeout(()=>{s.form=+fr.value;renderRace(p);$("raceForm").focus()},120)};
  p.querySelector('[data-race="reset"]').onclick=()=>{RS[b]=null;renderRace(p)};p.querySelector('[data-race="again"]').onclick=()=>renderRace(p)}
function raceHist(pos){const W=600,H=120,n=pos.length,bw=W/n,mx=Math.max(...pos,.01);
  return `<svg class="racehist" viewBox="0 0 ${W} ${H+18}" role="img" aria-label="${t("Where Fenerbahçe finish")}">${pos.map((v,i)=>{const h=v/mx*(H-6);return `<rect x="${(i*bw+2).toFixed(1)}" y="${(H-h).toFixed(1)}" width="${(bw-4).toFixed(1)}" height="${Math.max(h,v>0?2:0).toFixed(1)}" rx="3" class="${i===0?"s1":"s2"}"><title>${ordL(i+1)}: ${pct(v)}</title></rect>`}).join("")}${pos.map((v,i)=>n<=20||i%2===0?`<text x="${(i*bw+bw/2).toFixed(1)}" y="${H+14}" text-anchor="middle" class="ax">${i+1}</text>`:"").join("")}</svg>`}
/* tab wiring */
EXT.tabs.push((id,T)=>{if(id==="more"||!raceTables(id).length)return;const i=T.findIndex(x=>x[0]==="standings");T.splice(i+1,0,["race","Title race"])});
EXT.panels.race=p=>renderRace(p);
KAN_CHIPS_TAB.race=["Can we still win the league?","Who is our main rival?","How many points do we need?"];
