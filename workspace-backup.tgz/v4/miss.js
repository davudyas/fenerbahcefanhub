const {chromium}=require('playwright');const fs=require('fs');
(async()=>{const b=await chromium.launch();const pg=await b.newPage();await pg.goto('file://'+process.cwd()+'/fenerbahce.html#football');await pg.waitForTimeout(300);
const r=await pg.evaluate(()=>{const keys=new Set([...Object.keys(DICT.tr),...Object.keys(DICT.de)]);const cat=new Set(I18N_CAT);return [...keys].filter(k=>!cat.has(k))});
fs.writeFileSync('../miss.json',JSON.stringify(r,null,0));console.log(r.length);r.slice(0,400).forEach((s,i)=>console.log(i+"\t"+s.slice(0,200)));await b.close()})();
