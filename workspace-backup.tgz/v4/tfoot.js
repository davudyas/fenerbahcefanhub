const {chromium}=require('playwright');const path=require('path');
(async()=>{const b=await chromium.launch();const pg=await b.newPage({viewport:{width:900,height:800}});await pg.route('**/*',r=>r.request().url().startsWith('file:')?r.continue():r.abort());
for(const f of ['site/index.html','v4/fenerbahce.html']){await pg.goto('file://'+path.resolve(__dirname,'..',f));await pg.waitForTimeout(800);console.log(f,JSON.stringify(await pg.evaluate(()=>document.querySelector('footer').innerText)))}
await pg.evaluate(()=>{$('lang').value='tr';$('lang').dispatchEvent(new Event('change'))});await pg.waitForTimeout(800);console.log('tr',JSON.stringify(await pg.evaluate(()=>document.querySelector('footer').innerText)));
await pg.locator('footer').screenshot({path:path.resolve(__dirname,'../foot.png')});await b.close()})();
