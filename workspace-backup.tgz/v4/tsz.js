const gzAuto=require('./gzauto.js');
const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const pg=await b.newPage({viewport:{width:1280,height:900}});const errs=[];pg.on('pageerror',e=>errs.push(e.message+' '+e.stack.split('\n')[1]));
await pg.goto('file://'+process.cwd()+'/fenerbahce.html#football-play');await pg.waitForTimeout(300);
await pg.evaluate(()=>pickGame('draft'));await pg.waitForTimeout(100);await gzAuto(pg);await pg.waitForTimeout(150);
await pg.click('[data-sz="start"]');for(let i=0;i<3;i++){await pg.click('[data-sz="one"]');await pg.waitForTimeout(30)}
await pg.evaluate(()=>document.getElementById('szArea').scrollIntoView());await pg.screenshot({path:'../sz1.png'});
await pg.click('[data-sz="all"]');await pg.waitForTimeout(200);await pg.evaluate(()=>document.getElementById('szArea').scrollIntoView());await pg.screenshot({path:'../sz2.png',fullPage:false});
for(const br of ['basketball','womens-basketball','volleyball']){await pg.selectOption('#sport',br);await pg.click('[data-tab=play]');await pg.click(`[data-game=${br==='volleyball'?'draft6':'draft5'}]`);while(await pg.$('[data-tc="0"]')){await pg.click('[data-tc="0"]');await pg.waitForTimeout(20)}
 await pg.click('[data-sz="start"]');await pg.click('[data-sz="all"]');await pg.waitForTimeout(200);console.log(br,await pg.evaluate(()=>document.querySelector('.szsum')?.innerText.replace(/\n+/g,' | ')))}
await pg.evaluate(()=>document.getElementById('szArea').scrollIntoView());await pg.screenshot({path:'../sz3.png'});
console.log(errs);await b.close()})();
