/* ===== New branches: women's football and men's volleyball ===== */
SPORTS["womens-football"]={
  label:"Women's Football",tr:"Kadın Futbol",title:"Women's Football",num:"21",
  nick:"Fenerbahçe arsaVev, champions of Turkey",
  lede:"Founded in 1995, closed, then brought back in 2021, the women's team went from semi-finals to the title in five seasons. They won their first Super League in 2025–26 and played in Europe for the first time in 2026–27.",
  stats:[["1","Super League titles"],["1995","Team founded"],["2021","Team refounded"],["2026","First European season"]],
  home:["Home ground","Lefter Küçükandonyadis Stadium, Dereağzı, Kadıköy"],
  history:[
    ["1995","The first women's team","Fenerbahçe form a women's football team on 4 April 1995."],
    ["1996","A short first life","After finishing third in their group in 1995–96, the team is later closed for financial reasons."],
    ["2021","Back for good","The club announces the return of women's football on 26 August 2021. The new team tops its group and reaches the semi-finals."],
    ["2023","A first final","Fenerbahçe reach the Super League play-off final."],
    ["2024","Third place","Third in the Super League."],
    ["2025","Runners-up","Second place, one step from the title."],
    ["2026","Champions of Turkey","A 7–0 win at Giresun Sanayispor in May clinches the first league title with two rounds to spare."],
    ["2026","Europe for the first time","Out of the Champions League qualifiers on penalties against OH Leuven in August, then a 5–1 aggregate win over Minsk and a place in the last 16 of the Women's Europa Cup."],
    ["2026","Derby winner","Ece Türkoğlu's 89th-minute goal beats Galatasaray 1–0 on 7 November, Galatasaray's first league defeat of the season."]],
  games:[
    {date:"2026-11-07",comp:"Women's Super League",home:"Fenerbahçe",away:"Galatasaray",res:"1–0",out:"win",tag:"Derby",note:"Ece Türkoğlu scored in the 89th minute. It was Galatasaray's first league defeat of the season.",where:"Lefter Küçükandonyadis Stadium, Istanbul"},
    {date:"2025-12-07",comp:"Women's Super League",home:"Fenerbahçe",away:"Galatasaray",res:"1–0",out:"win",tag:"Derby",note:"Marta Cox scored a 64th-minute penalty on the way to the first title.",where:"Şükrü Saracoğlu, Istanbul"},
    {date:"2026-05",comp:"Women's Super League",home:"Giresun Sanayispor",away:"Fenerbahçe",res:"0–7",out:"win",tag:"League",note:"The win that sealed the first championship, with two rounds still to play.",where:"Çotanak Arena, Giresun"},
    {date:"2026-09-30",comp:"Women's Europa Cup",home:"Fenerbahçe",away:"Minsk",res:"1–0",out:"win",tag:"Europe",note:"Busem Şeker's goal completed a 5–1 aggregate win and a place in the last 16.",where:"Yusuf Ziya Öniş Stadium, Istanbul"},
    {date:"2026-08-08",comp:"Women's Champions League",home:"OH Leuven",away:"Fenerbahçe",res:"1–1",out:"loss",tag:"Europe",note:"Konya Plummer scored early, but Leuven equalised and won the shootout 4–2.",where:"Den Dreef, Leuven"}],
  filters:["All","Derby","League","Europe"],
  trophies:[["1","Super League","2025–26"]],
  legends:[
    ["Yağmur Uraz","Forward · captain","Club captain and one of the leaders of the first title-winning side.",["Captain of the 2025–26 champions."]],
    ["Ece Türkoğlu","Midfielder · vice-captain","Scored the 89th-minute winner against Galatasaray in November 2026.",["Vice-captain of the 2025–26 champions."]],
    ["Andrea Stašková","Forward","Czech striker and the leading scorer of the first title season.",["16 league goals by the day the title was won.","Hat-trick in the 12–0 win over Şile BilgiDoğa in September 2026."]],
    ["Marta Cox","Midfielder","Panama international who scored the penalty that beat Galatasaray in December 2025.",[]],
    ["Konya Plummer","Defender","Jamaica international who scored against OH Leuven in the 2026 Champions League qualifiers.",[]],
    ["Gökhan Bozkaya","Head coach · 2023–","Took over in 2023: third, then second, then the first league title.",["2025–26 Super League champion."]]],
  quiz:[
    {q:"In which year was Fenerbahçe's first women's football team founded?",o:["1995","2007","2015","2021"],a:0,e:"1995. The team was later closed and came back in 2021."},
    {q:"Which season brought the first Super League title?",o:["2022–23","2023–24","2024–25","2025–26"],a:3,e:"2025–26, clinched with a 7–0 win at Giresun Sanayispor."},
    {q:"Who scored the winner against Galatasaray on 7 November 2026?",o:["Ece Türkoğlu","Yağmur Uraz","Andrea Stašková","Marta Cox"],a:0,e:"Ece Türkoğlu, in the 89th minute."},
    {q:"Who knocked Fenerbahçe out of the 2026–27 Champions League qualifiers?",o:["OH Leuven","Minsk","Real Sociedad","Slavia Prague"],a:0,e:"OH Leuven, 4–2 on penalties after a 1–1 draw."},
    {q:"Who is the head coach?",o:["Gökhan Bozkaya","Nihan Su","Özkan Beceren","Serhat Deniz"],a:0,e:"Gökhan Bozkaya, in charge since 2023."},
    {q:"Where does the team play most home games?",o:["Lefter Küçükandonyadis Stadium","Ülker Sports and Event Hall","Burhan Felek Sport Hall","Atatürk Olympic Stadium"],a:0,e:"At the Lefter Küçükandonyadis Stadium in Dereağzı, Kadıköy."}]};

SPORTS["mens-volleyball"]={
  label:"Men's Volleyball",tr:"Erkek Voleybol",title:"Men's Volleyball",num:"14",
  nick:"Fenerbahçe Medicana, the men's team",
  lede:"Five-time champions of Turkey and winners of the CEV Challenge Cup in 2014. The team was refounded in 1976, reached the top flight in 1985 and won its first league title in 2008.",
  stats:[["5","Turkish league titles"],["5","Turkish Cups"],["4","Turkish Super Cups"],["1","CEV Challenge Cup"]],
  home:["Home court","Burhan Felek Sport Hall, Üsküdar · 7,000 seats"],
  history:[
    ["1927","The first team","Fenerbahçe start a men's volleyball team, which comes and goes over the following decades."],
    ["1976","A fresh start","The team is refounded in its present form and starts in Istanbul's fourth division."],
    ["1985","Into the top flight","After three promotions, Fenerbahçe win the Istanbul First League and step up to the national league."],
    ["2008","First league title","Under György Demeter, Fenerbahçe win the Turkish league and the Turkish Cup."],
    ["2009","Balkan Cup","The first international trophy for the men's team."],
    ["2012","Three in a row","A third straight league title, together with the Turkish Cup."],
    ["2014","European champions","Fenerbahçe beat Andreoli Latina 3–0 in Istanbul to win the CEV Challenge Cup, on the same day the women won the CEV Cup."],
    ["2019","League and cup double","The fifth league title arrives together with the Turkish Cup."],
    ["2025","Cup winners again","Fenerbahçe win the 2024–25 Turkish Cup, their fifth."],
    ["2026","New coach","Taner Atik takes over as head coach in January 2026."]],
  games:[
    {date:"2014-03-29",comp:"CEV Challenge Cup Final",home:"Fenerbahçe",away:"Andreoli Latina",res:"3–0",out:"win",tag:"Europe",note:"25–22, 25–19, 25–17 in front of 6,500 fans, after a five-set defeat in the first leg in Italy.",where:"Istanbul"},
    {date:"2014-03-26",comp:"CEV Challenge Cup Final",home:"Andreoli Latina",away:"Fenerbahçe",res:"3–2",out:"loss",tag:"Europe",note:"A five-set defeat in the first leg left everything to play for in Istanbul.",where:"Italy"},
    {date:"2026-10-31",comp:"Efeler Ligi",home:"İBB Spor Kulübü",away:"Fenerbahçe",res:"1–3",out:"win",tag:"League",note:"After losing the first set, Fenerbahçe won the next three 25–18, 25–21 and 25–15.",where:"Cebeci Sports Complex, Istanbul"},
    {date:"2026-10-24",comp:"Efeler Ligi",home:"Gaziantep Gençlik Spor",away:"Fenerbahçe",res:"2–3",out:"win",tag:"League",note:"The first win of the season, in five sets.",where:"Gaziantep"}],
  filters:["All","Europe","League"],
  trophies:[["5","Turkish League","2008, 2010, 2011, 2012, 2019"],["5","Turkish Cup","2008, 2012, 2017, 2019, 2025"],["4","Turkish Super Cup","2011, 2012, 2017, 2020"],["2","Balkan Cup","2009, 2013"],["1","CEV Challenge Cup","2014"]],
  legends:[
    ["İsmail Vuran","Head coach · 1985–1990, 1993–2001","Coached the team through its first years in the top flight, then again for most of the 1990s.",[]],
    ["György Demeter","Head coach · 2007–2011","Brought the first league title in 2008, then two more in 2010 and 2011.",[]],
    ["Daniel Castellani","Head coach · three spells","In charge in 2011–12, 2013–15 and 2021–23, including the 2012 title and the 2014 CEV Challenge Cup.",[]],
    ["Slobodan Kovač","Head coach · 2024–2026","Coached the team before Taner Atik took over in January 2026.",[]],
    ["Taner Atik","Head coach · 2026–","Appointed in January 2026.",[]],
    ["Matt Anderson","Outside hitter","US international in the 2026–27 squad.",[]],
    ["Mirza Lagumdžija","Outside hitter","Turkey international in the 2026–27 squad.",[]],
    ["Adis Lagumdžija","Opposite","Turkey international in the 2026–27 squad.",[]]],
  quiz:[
    {q:"In which season did the men win the CEV Challenge Cup?",o:["2009–10","2011–12","2013–14","2018–19"],a:2,e:"2013–14, beating Andreoli Latina in the final."},
    {q:"How many Turkish league titles have the men won?",o:["3","5","7","9"],a:1,e:"Five: 2008, 2010, 2011, 2012 and 2019."},
    {q:"Who coached the first league title in 2008?",o:["György Demeter","Daniel Castellani","İsmail Vuran","Veljko Basić"],a:0,e:"György Demeter, coach from 2007 to 2011."},
    {q:"In which year was today's men's team refounded?",o:["1927","1959","1976","1985"],a:2,e:"1976, starting in Istanbul's fourth division."},
    {q:"Who became head coach in January 2026?",o:["Taner Atik","Slobodan Kovač","Daniel Castellani","Veljko Basić"],a:0,e:"Taner Atik, who followed Slobodan Kovač."},
    {q:"How many Balkan Cups have the men won?",o:["1","2","3","4"],a:1,e:"Two, in 2009 and 2013."}]};

/* Squads and venues */
/* the 2025–26 title-winning squad stays for the Name the Squad game */
const WF_CHAMP=[["Goalkeepers",[[25,"Zeynep Akdeniz","Turkey"],[71,"Natalia Munteanu","Moldova"]]],
   ["Defenders",[[2,"Konya Plummer","Jamaica"],[5,"Yaşam Göksu","Turkey"],[14,"Ümran Özev","Turkey"],[17,"İpek Kaya","Turkey"]]],
   ["Midfielders",[[6,"Regina Otu","Nigeria"],[8,"Cansu Gürel","Turkey"],[9,"Busem Şeker","Turkey"],[10,"Ece Türkoğlu","Turkey"],[16,"Peritan Bozdağ","Azerbaijan"],[19,"Mesude Alayont","Turkey"],[20,"Marta Cox","Panama"],[23,"Fatoş Yıldırım","Turkey"],[29,"Mevlüde Okuyan","Turkey"]]],
   ["Forwards",[[11,"Yağmur Uraz","Turkey"],[13,"Zeynep Kerimoğlu","Turkey"],[22,"Flourish Sabastine","Nigeria"],[77,"Andrea Stašková","Czech Republic"],[93,"Maria Alves","Brazil"]]]];
SQUADS["womens-football"]={coach:"Gökhan Bozkaya",asof:"UEFA squad list for the 2026–27 Women's Europa Cup",
  groups:[["Goalkeepers",[[21,"Soledad Belotto","Paraguay"],[40,"İlayda Demir","Turkey"],[71,"Natalia Munteanu","Moldova"]]],
   ["Defenders",[[2,"Konya Plummer","Jamaica"],[5,"Yaşam Göksu","Turkey"],[8,"Cansu Gürel","Turkey"],[14,"Katie Bowen","New Zealand"],[17,"İpek Kaya","Turkey"],[19,"Mesude Alayont","Turkey"],[24,"Fatma Şakar","Turkey"],[33,"Esmanur Teke","Turkey"],[38,"Edanur Gökçe","Turkey"]]],
   ["Midfielders",[[6,"Regina Otu","Nigeria"],[9,"Busem Şeker","Turkey"],[10,"Ece Türkoğlu","Turkey"],[13,"Zeynep Kerimoğlu","Turkey"],[16,"Peritan Bozdağ","Azerbaijan"],[26,"Suliat Abideen","Nigeria"],[32,"İdil Nas Acar","Turkey"],[34,"Belinay Tuğla","Turkey"],[35,"Rabia Akbaba","Turkey"]]],
   ["Forwards",[[11,"Yağmur Uraz","Turkey"],[30,"Marie Ngah","Cameroon"],[55,"Zsanett Kaján","Hungary"],[77,"Andrea Stašková","Czech Republic"],[93,"Maria Alves","Brazil"]]]]};
SQUADS["mens-volleyball"]={coach:"Taner Atik",coachNote:"Head coach since January 2026.",asof:"Squad list as of June 2026",
  groups:[["Setters",[[14,"Fernando Kreling","Brazil"],[17,"Muhammed Kaya","Turkey"]]],
   ["Outside hitters",[[7,"Mirza Lagumdžija","Turkey"],[8,"Burutay Subaşı","Turkey"],[13,"Yiğit Gülmezoğlu","Turkey"],[22,"Matt Anderson","United States"]]],
   ["Opposites",[[1,"Kaan Gürbüz","Turkey"],[12,"Adis Lagumdžija","Turkey"]]],
   ["Middle blockers",[[2,"Barthélémy Chinenyeze","France"],[5,"Mert Matić","Turkey"],[10,"Bedirhan Bülbül","Turkey"]]],
   ["Liberos",[[11,"Beytullah Hatipoğlu","Turkey"],[21,"Caner Dengin","Turkey"]]]]};
VENUES["womens-football"]={name:"Lefter Küçükandonyadis Stadium",area:"Dereağzı, Kadıköy, Istanbul",cap:"",
  facts:["Part of the club's Dereağzı complex, named after Lefter Küçükandonyadis, the club's record goalscorer.","The women's team play most home league games here, including the 1–0 win over Galatasaray in November 2026.","Bigger games sometimes move to the Şükrü Saracoğlu Stadium: the December 2025 derby was played there."],
  travel:["Dereağzı is in Kadıköy, close to the Şükrü Saracoğlu Stadium and Söğütlüçeşme station."]};
VENUES["mens-volleyball"]={name:"Burhan Felek Sport Hall",area:"Üsküdar, Istanbul",cap:"7,000 seats",
  facts:["Opened on 19 November 2010.","Both Fenerbahçe volleyball teams play their league matches here."],travel:[]};
/* runs after buildI18n(): the women's volleyball page gets its own name and loses the men's cup */
function mergeNew(){const V=SPORTS.volleyball;V.label="Women's Volleyball";V.title="Women's Volleyball";V.tr="Kadın Voleybol";
  V.trophies=V.trophies.filter(x=>!/\(men\)/.test(x[1]));V.games=V.games.filter(g=>g.tag!=="Men");V.filters=["All","Women"]}

/* People for the games */
Object.assign(BPOS,{GK:"goalkeeper",DF:"defender",MF:"midfielder",FW:"forward"});
Object.assign(NAT2,{JAM:"Jamaica",MDA:"Moldova",NGR:"Nigeria",AZE:"Azerbaijan",PAN:"Panama",PAR:"Paraguay",NZL:"New Zealand",CMR:"Cameroon",HUN:"Hungary"});
const WF_POOL=[["Zeynep Akdeniz","GK","",70,"TUR","Akdeniz",""],["Natalia Munteanu","GK","",72,"MDA","Munteanu",""],["Konya Plummer","DF","",80,"JAM","Plummer",""],["Yaşam Göksu","DF","",74,"TUR","Göksu",""],["Ümran Özev","DF","",72,"TUR","Özev",""],["İpek Kaya","DF","",74,"TUR","Kaya",""],
 ["Regina Otu","MF","",76,"NGR","Otu",""],["Cansu Gürel","MF","",72,"TUR","Gürel",""],["Busem Şeker","MF","",76,"TUR","Şeker",""],["Ece Türkoğlu","MF","",80,"TUR","Türkoğlu",""],["Peritan Bozdağ","MF","",70,"AZE","Bozdağ",""],["Mesude Alayont","MF","",70,"TUR","Alayont",""],["Marta Cox","MF","",80,"PAN","Cox",""],["Fatoş Yıldırım","MF","",72,"TUR","Yıldırım",""],["Mevlüde Okuyan","MF","",70,"TUR","Okuyan",""],
 ["Yağmur Uraz","FW","",82,"TUR","Uraz",""],["Zeynep Kerimoğlu","FW","",72,"TUR","Kerimoğlu",""],["Flourish Sabastine","FW","",78,"NGR","Sabastine",""],["Andrea Stašková","FW","",84,"CZE","Stašková",""],["Maria Alves","FW","",78,"BRA","Alves",""],
 ["Soledad Belotto","GK","",72,"PAR","Belotto",""],["İlayda Demir","GK","",66,"TUR","Demir",""],["Katie Bowen","DF","",80,"NZL","Bowen",""],["Fatma Şakar","DF","",68,"TUR","Şakar",""],["Esmanur Teke","DF","",66,"TUR","Teke",""],["Edanur Gökçe","DF","",66,"TUR","Gökçe",""],
 ["Suliat Abideen","MF","",76,"NGR","Abideen",""],["İdil Nas Acar","MF","",66,"TUR","Acar",""],["Belinay Tuğla","MF","",66,"TUR","Tuğla",""],["Rabia Akbaba","MF","",66,"TUR","Akbaba",""],["Marie Ngah","FW","",76,"CMR","Ngah",""],["Zsanett Kaján","FW","",78,"HUN","Kaján",""]];
const MV_POOL=[["Fernando Kreling","S","",84,"BRA","Kreling",""],["Muhammed Kaya","S","",72,"TUR","Kaya",""],["Mirza Lagumdžija","OH","",82,"TUR","Mirza",""],["Burutay Subaşı","OH","",76,"TUR","Subaşı",""],["Yiğit Gülmezoğlu","OH","",74,"TUR","Gülmezoğlu",""],["Matt Anderson","OH","",86,"USA","Anderson",""],
 ["Kaan Gürbüz","OP","",76,"TUR","Gürbüz",""],["Adis Lagumdžija","OP","",84,"TUR","Adis",""],["Barthélémy Chinenyeze","MB","",84,"FRA","Chinenyeze",""],["Mert Matić","MB","",78,"TUR","Matić",""],["Bedirhan Bülbül","MB","",78,"TUR","Bülbül",""],["Beytullah Hatipoğlu","L","",74,"TUR","Hatipoğlu",""],["Caner Dengin","L","",72,"TUR","Dengin",""]];
const WF_SQUADS=[{id:"2026-27",label:"2026–27 squad",title:"Women's Europa Cup",note:"UEFA squad list",sq:SQUADS["womens-football"].groups.flatMap(([g,l])=>l.map(([n,name])=>[n,name,WF_POOL.find(p=>p[0]===name)[1]]))},
 {id:"2026",label:"2025–26 champions",title:"Women's Super League",note:"First league title, won with two rounds to spare",sq:WF_CHAMP.flatMap(([g,l])=>l.map(([n,name])=>[n,name,WF_POOL.find(p=>p[0]===name)[1]]))}];
const MV_SQUADS=[{id:"2026-27",label:"2026–27 squad",title:"Efeler Ligi",note:"Coach Taner Atik",sq:SQUADS["mens-volleyball"].groups.flatMap(([g,l])=>l.map(([n,name])=>[n,name,MV_POOL.find(p=>p[0]===name)[1]]))},
 {id:"ibb",label:"Line-up at İBB, October 2026",title:"Efeler Ligi",note:"Starting line-up and libero in the 3–1 win on 31 October 2026",sq:[[1,"Kaan Gürbüz","OP"],[5,"Mert Matić","MB"],[10,"Bedirhan Bülbül","MB"],[8,"Burutay Subaşı","OH"],[22,"Matt Anderson","OH"],[14,"Fernando Kreling","S"],[11,"Beytullah Hatipoğlu","L"]]}];
BPEOPLE["womens-football"]=buildPeople(toPeople(WF_POOL),null,WF_SQUADS);
BPEOPLE["mens-volleyball"]=buildPeople(toPeople(MV_POOL),null,MV_SQUADS);
Object.assign(SPECIAL_B,{"Ece Türkoğlu":"I scored the 89th-minute winner against Galatasaray in November 2026.","Andrea Stašková":"I was the leading scorer of the first title season.","Marta Cox":"I scored the penalty that beat Galatasaray in December 2025.","Konya Plummer":"I scored against OH Leuven in the Champions League qualifiers.","Yağmur Uraz":"I captained the first title-winning team.","Busem Şeker":"My goal against Minsk took the team into the last 16 of the Europa Cup."});
const WF_EVENTS=[[1995,"Fenerbahçe form a women's football team","Firsts"],[2021,"The women's football team is refounded","Firsts"],[2023,"A first Super League play-off final","Titles"],[2025,"Runners-up in the Super League","Titles"],[2026,"First Super League title","Titles"],[2026,"First Champions League campaign","Europe"],[2026,"Into the last 16 of the Women's Europa Cup","Europe"],[2023,"Gökhan Bozkaya becomes head coach","Coaches"],[2021,"Nihan Su becomes head coach","Coaches"]];
const MV_EVENTS=[[1927,"Fenerbahçe start a men's volleyball team","Firsts"],[1976,"The men's team is refounded","Firsts"],[1985,"Promotion to the national top flight","Firsts"],[2008,"First Turkish league title","Titles"],[2010,"Second Turkish league title","Titles"],[2011,"Third Turkish league title","Titles"],[2012,"Fourth Turkish league title","Titles"],[2019,"Fifth Turkish league title","Titles"],[2009,"Men win the Balkan Cup","Europe"],[2013,"Men win a second Balkan Cup","Europe"],[2014,"Men win the CEV Challenge Cup","Europe"],[2017,"Turkish Cup winners","Cups"],[2025,"Turkish Cup winners","Cups"],[2007,"György Demeter becomes head coach","Coaches"],[2011,"Daniel Castellani becomes head coach","Coaches"],[2024,"Slobodan Kovač becomes head coach","Coaches"],[2026,"Taner Atik becomes head coach","Coaches"],[1985,"İsmail Vuran becomes head coach","Coaches"]];

/* Game configs */
WCFG["womens-football"]={pool:()=>wPool(BPEOPLE["womens-football"]),hints:bHints,done:x=>x.pos?`, ${BPOS[x.pos]}`:""};
WCFG["mens-volleyball"]={pool:()=>wPool(BPEOPLE["mens-volleyball"]),hints:bHints,done:x=>x.pos?`, ${BPOS[x.pos]}`:""};
WHOCFG["womens-football"]=()=>bWho("womens-football");WHOCFG["mens-volleyball"]=()=>bWho("mens-volleyball");
LUCFG["womens-football"]={items:WF_SQUADS,kind:"vb",title:"Name the Squad",note:"Squads come from the club's squad lists and match reports."};
LUCFG["mens-volleyball"]={items:MV_SQUADS,kind:"vb",title:"Name the Squad",note:"Squads come from the club's squad lists and match reports."};
TLCFG["womens-football"]={title:"Timeline",intro:"Women's football from 1995 to today: titles, coaches and the first European nights.",deck:()=>branchDeck("womens-football",WF_EVENTS)};
TLCFG["mens-volleyball"]={title:"Timeline",intro:"Men's volleyball from 1927 to today: titles, cups, coaches and the 2014 European win.",deck:()=>branchDeck("mens-volleyball",MV_EVENTS)};
PLAY["womens-football"]=[["quiz","Quiz","Six questions"],XTRA[0],["wordle","Fenerdle","Guess the player"],["squad","Name the Squad","The first champions"],["who","Who Am I?","Ten mystery players"],["timeline","Timeline","1995 to today"],...XTRA.slice(1)];
PLAY["mens-volleyball"]=[["quiz","Quiz","Six questions"],XTRA[0],["wordle","Fenerdle","Guess the player"],["squad","Name the Squad","This season's team"],["who","Who Am I?","Ten mystery players"],["timeline","Timeline","1927 to today"],...XTRA.slice(1)];
BRS.push("womens-football","mens-volleyball");
HOL_BY["womens-football"]=()=>[{key:"goals",label:"goals Fenerbahçe scored in that game",items:LIVE["womens-football"].last.map(r=>[`${r[3]} (${r[2]==="H"?"home":r[2]==="A"?"away":"neutral"})`,+r[4]])},evYears(WF_EVENTS,"year it happened")];
HOL_BY["mens-volleyball"]=()=>[evYears(MV_EVENTS,"year it happened"),{key:"titles",label:"titles",items:[["Turkish league titles",5],["Turkish Cups",5],["Turkish Super Cups",4],["Balkan Cups",2],["CEV Challenge Cups",1]]}];
HOL_BY.volleyball=()=>[evYears(VB_EVENTS,"year it happened"),{key:"titles",label:"titles",items:[["Turkish league titles",15],["Turkish Cups",5],["CEV Champions League titles",1],["Club World titles",1],["CEV Cups",1]]}];

/* Player of the match: everyone in the branch, plus a free choice */
const MOTM_GONE=["Sevgi Uzun","Tilbe Şenyürek"];
function motmNames(b){const S=SQUADS[b],out=new Set();(S&&S.groups||[]).forEach(g=>g[1].forEach(x=>out.add(x[1])));
  if(b==="womens-basketball"){const L=WB_LINEUPS.find(x=>x.id==="2026F")||WB_LINEUPS[0];if(L){L.st.forEach(x=>out.add(x[1]));L.bench.forEach(x=>out.add(x[0]))}}
  if(b==="womens-football")out.add("Divine Manga");
  MOTM_GONE.forEach(n=>out.delete(n));return [...out].sort((a,c)=>a.localeCompare(c,"tr"))}

/* The banner at the top: the next match of the branch being viewed */
function nextFixture(b){const L=LIVE[b];if(!L)return null;const today=todayISO(),list=L.next.filter(n=>!n[0]||n[0]>=today);return list[0]?{b,n:list[0]}:null}
function renderNextBanner(){let hit=nextFixture(current),other=false;
  if(!hit){other=true;const all=Object.keys(LIVE).map(nextFixture).filter(x=>x&&x.n[0]).sort((a,c)=>(a.n[0]+a.n[1]).localeCompare(c.n[0]+c.n[1]));hit=all[0]||null}
  const box=$("otd");if(!hit){box.hidden=true;return}
  const n=hit.n,h=n[3]==="H",teams=h?`Fenerbahçe – ${n[4]}`:`${n[4]} – Fenerbahçe`,when=n[0]?`${mDate(n[0])}${n[1]?", "+n[1]:""}`:t(n[5]||"TBC");
  $("otdLabel").textContent=t("Next match");$("otdText").textContent=`${when}: ${teams} (${t(n[2])}${other?", "+t(SPORTS[hit.b].label):""})`;box.hidden=false}

/* Drafts for the two new branches: they play a season like the others */
TDCFG["womens-football"]={pool:toPeople(WF_POOL),court:"fb",slots:[["GK",50,88],["DF",13,67],["DF",37,72],["DF",63,72],["DF",87,67],["MF",24,46],["MF",50,50],["MF",76,46],["FW",17,22],["FW",50,16],["FW",83,22]],rounds:[],cup:"Season",unit:"eleven",sim:"fb"};
TDCFG["mens-volleyball"]={pool:toPeople(MV_POOL),court:"vb",slots:[["OH",18,26],["MB",50,26],["OP",82,26],["OH",18,64],["MB",50,64],["S",82,64],["L",50,88]],rounds:[],cup:"Season",unit:"six",sim:"vb"};
PLAY["womens-football"].splice(2,0,["draft11","XI Draft","Draft an XI, play a season"]);
PLAY["mens-volleyball"].splice(2,0,["draft6","Starting Six","Draft a six, play a season"]);
