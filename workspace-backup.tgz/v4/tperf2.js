const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844}});const pg=await ctx.newPage();const cdp=await ctx.newCDPSession(pg);await cdp.send('Emulation.setCPUThrottlingRate',{rate:4});
for(let k=0;k<2;k++){await pg.goto('file://'+process.cwd()+'/perf.html#all');await pg.waitForTimeout(300)}
console.log(await pg.evaluate(()=>JSON.stringify({scriptStart:Math.round(window.__T0),steps:window.__T.map(x=>[x[0],Math.round(x[1])])})));
await b.close()})();
