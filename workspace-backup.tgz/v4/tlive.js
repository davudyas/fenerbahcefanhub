const {chromium}=require('playwright');const fs=require('fs');const mock=fs.readFileSync('mockroom.js','utf8');
(async()=>{const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:1100,height:900}});const errs=[];
const mk=async(uid,nm)=>{const pg=await ctx.newPage();pg.on('pageerror',e=>errs.push(uid+': '+e.message));
 await pg.addInitScript(([mock,uid,nm])=>{eval(mock);const user={id:async()=>uid,profiles:async ids=>Object.fromEntries(ids.map(i=>[i,{name:i==="u1"?"Ali":"Ayşe"}]))};let room=null;
  window.claude={use:async n=>n==="room"?(room||(room=window.__mkMock(uid))):n==="user"?user:null}},[mock,uid,nm]);
 await pg.goto('file://'+process.cwd()+'/fenerbahce.html#football-play');await pg.waitForTimeout(500);return pg};
const A=await mk("u1"),B=await mk("u2");
for(const pg of [A,B]){await pg.evaluate(()=>{playSel.football='live';render()});await pg.waitForTimeout(400)}
await A.selectOption('#lqLv0','easy');await A.click('[data-lq0="host"]');await A.waitForTimeout(400);
const code=await A.evaluate(()=>LQ.code);await B.waitForTimeout(300);
console.log('B sees open room:',await B.evaluate(()=>document.querySelector('.lqopen')?document.querySelector('.lqopen').innerText:'none'));
await B.fill('#lqIn',code);await B.click('[data-lq0="join"]');await B.waitForTimeout(500);
await A.screenshot({path:'../l_lobby.png'});
console.log('A players',await A.evaluate(()=>document.querySelector('.lqboard').innerText.replace(/\n/g,' ')));
await A.click('[data-lq="start"]');await A.waitForTimeout(2600);
console.log('A q',await A.evaluate(()=>document.querySelector('#lqArea h3').textContent),'| B q',await B.evaluate(()=>document.querySelector('#lqArea h3').textContent));
await A.click('[data-lqa="0"]');await B.waitForTimeout(300);await B.screenshot({path:'../l_q.png'});await B.click('[data-lqa="1"]');await A.waitForTimeout(600);
await A.screenshot({path:'../l_rev.png'});console.log('phase after both answered',await A.evaluate(()=>LQ.phase),await B.evaluate(()=>LQ.phase));
for(let i=1;i<7;i++){await A.waitForTimeout(5000);await A.click('[data-lqa="0"]').catch(()=>{});await B.click('[data-lqa="0"]').catch(()=>{});await A.waitForTimeout(500)}
await A.waitForTimeout(5200);console.log('end',await A.evaluate(()=>[LQ.phase,JSON.stringify(LQ.scores)]),await B.evaluate(()=>[LQ.phase,JSON.stringify(LQ.scores)]));
await B.screenshot({path:'../l_end.png'});
// watch party
for(const pg of [A,B]){await pg.evaluate(()=>{setSport('football');tab='matches';render()});await pg.waitForTimeout(200)}
console.log('wp card',await A.evaluate(()=>!!document.getElementById('wpCard')));
await A.click('[data-wp="open"]');await B.click('[data-wp="open"]');await A.waitForTimeout(500);
await B.click('[data-wpr="goal"]');await A.waitForTimeout(100);await A.fill('#wpIn','Hadi Fener!');await A.click('#wpForm .btn');await A.waitForTimeout(800);await B.click('[data-wpr="chance"]');await A.waitForTimeout(900);
await A.screenshot({path:'../l_wp.png'});console.log('A feed',await A.evaluate(()=>document.getElementById('wpFeed').innerText.replace(/\n/g,' | ')),await A.evaluate(()=>document.getElementById('wpN').textContent));
console.log('B stored',await B.evaluate(()=>JSON.stringify(store.get('fb-watch',{}))));
// race
await A.keyboard.press('Escape');await A.evaluate(()=>{tab='race';render()});await A.waitForTimeout(300);await A.locator('#panel').screenshot({path:'../l_race.png'});
const odds0=await A.evaluate(()=>document.querySelector('.raceodds b').textContent);
for(let k=0;k<4;k++){await A.click(`[data-rfx="${k}|W"]`);await A.waitForTimeout(150)}
const odds1=await A.evaluate(()=>document.querySelector('.raceodds b').textContent);
for(let k=0;k<4;k++){await A.click(`[data-rfx="${k}|L"]`);await A.waitForTimeout(150)}
const odds2=await A.evaluate(()=>document.querySelector('.raceodds b').textContent);console.log('race odds now/4 wins/4 losses',odds0,odds1,odds2);
for(const br of ['basketball','womens-basketball','volleyball','mens-volleyball','womens-football']){await A.evaluate(br=>{setSport(br);tab='race';render()},br);await A.waitForTimeout(200);console.log(br,await A.evaluate(()=>tab+' '+(document.querySelector('.raceodds b')||{}).textContent))}
console.log('errs',errs);await b.close()})();
