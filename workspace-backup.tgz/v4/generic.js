/* ================= SHARED GAME ENGINES ================= */
const gauss=()=>{let u=0,v=0;while(!u)u=Math.random();while(!v)v=Math.random();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v)};
const localDay=()=>Math.floor((Date.now()-new Date().getTimezoneOffset()*6e4)/864e5);
const DAY0=Math.floor(Date.UTC(2026,10,1)/864e5);
const SK=(b,k)=>`fb-${b}-${k}`;
const stars3=s=>"★".repeat(s)+"☆".repeat(3-s);
function rerender(){renderPanel()}

/* ---------- People for basketball and volleyball ---------- */
const PERSON_MAP={"Ali Muhammed":"Bobby Dixon","Eda Erdem":"Eda Erdem Dündar","Seda Aslanyürek":"Seda Tokatlıoğlu","Meliha Diken":"Meliha İsmailoğlu","Naz Aydemir":"Naz Aydemir"};
function buildPeople(pool,lineups,squads){const M={};pool.forEach(p=>M[p.n]={...p,apps:[],squads:[]});
  (lineups||[]).forEach(L=>{L.st.forEach(([pos,n,pts])=>add(n,{L,pts,starter:true,pos}));L.bench.forEach(([n,pts])=>add(n,{L,pts,starter:false,pos:null}))});
  (squads||[]).forEach(S=>S.sq.forEach(([num,n,pos])=>{const k=PERSON_MAP[n]||n;if(!M[k])M[k]={n:k,pos,alt:[],r:75,nat:null,short:k.split(" ").slice(-1)[0],ten:"",apps:[],squads:[]};if(!M[k].pos&&pos)M[k].pos=pos;M[k].squads.push({S,num,as:n})}));
  function add(n,a){const k=PERSON_MAP[n]||n;if(!M[k])M[k]={n:k,pos:a.pos,alt:[],r:75,nat:null,short:k.split(" ").slice(-1)[0],ten:"",apps:[],squads:[]};if(!M[k].pos&&a.pos)M[k].pos=a.pos;M[k].apps.push({...a,as:n})}
  return M}
const BPEOPLE={basketball:buildPeople(MB_P,MB_LINEUPS),"womens-basketball":buildPeople(WB_P,WB_LINEUPS),volleyball:buildPeople(VB_P,null,VB_SQUADS)};
function aliasB(n){const parts=norm(n).split(" "),al=new Set([norm(n),parts[parts.length-1]]);if(parts.length>2)al.add(parts.slice(-2).join(" "));if(parts[0].length>=4)al.add(parts[0]);
  const real=PERSON_MAP[n]||n;[n,real].forEach(k=>(ALIAS2[k]||[]).forEach(a=>al.add(norm(a))));const per=Object.values(BPEOPLE).map(M=>M[real]).find(Boolean);if(per)al.add(norm(per.short));return [...al].filter(x=>x.length>=2)}
function uniqueAliases(names){const all=names.map(aliasB),cnt={};all.forEach(a=>a.forEach(x=>cnt[x]=(cnt[x]||0)+1));return all.map((a,i)=>a.filter(x=>cnt[x]===1||x===norm(names[i])))}

/* ---------- QUIZ ---------- */
const quizS={};


/* ---------- FENERDLE (any branch) ---------- */
function wPool(M){const seen=new Set(),out=[];Object.values(M).forEach(x=>{const w=norm(x.short).toUpperCase(),L=w.replace(/ /g,"").length;if(L>=3&&L<=14&&w.split(" ").length<=3&&!seen.has(w)){seen.add(w);out.push({x,w})}});return out.sort((a,b)=>a.w<b.w?-1:1)}
const bEra=x=>x.ten?x.ten:x.apps&&x.apps.length?`In the ${[...new Set(x.apps.map(a=>a.L.label.slice(0,4)))].join(", ")} box score${x.apps.length>1?"s":""}`:x.squads&&x.squads.length?`${x.squads.map(s=>s.S.id).join(", ")} squad${x.squads.length>1?"s":""}`:"–";
const bHints={pos:["Position",x=>x.pos?BPOS[x.pos][0].toUpperCase()+BPOS[x.pos].slice(1):"–"],era:["Era",bEra],nat:["Country",x=>x.nat?NAT2[x.nat].replace(/^the /,"The "):`Starts with ${x.short[0]}`]};
const WCFG={
 football:{pool:()=>WP_FB,hints:{pos:["Position",x=>x.line?LINE_NAME[x.line][0].toUpperCase()+LINE_NAME[x.line].slice(1):"–"],era:["Era",x=>x.seasons.length?`Regular from ${seasonLabel(x.seasons[0])}`:x.p?`Joined around ${x.p.from}`:"–"],nat:["Country",x=>x.p?NAT[x.p.nat].replace(/^the /,"The "):`Starts with ${x.short[0]}`]},
   done:x=>x.seasons.length?`, a regular in ${x.seasons.length} season${x.seasons.length>1?"s":""}`:x.p?` (${yrs(x.p)})`:""},
 basketball:{pool:()=>wPool(BPEOPLE.basketball),hints:bHints,done:x=>x.pos?`, ${BPOS[x.pos]}`:""},
 "womens-basketball":{pool:()=>wPool(BPEOPLE["womens-basketball"]),hints:bHints,done:x=>x.pos?`, ${BPOS[x.pos]}`:""},
 volleyball:{pool:()=>wPool(BPEOPLE.volleyball),hints:bHints,done:x=>x.pos?`, ${BPOS[x.pos]}`:""}
};
let WP_FB=null;
const LENS={any:["Any length",()=>true],short:["Short · up to 5",n=>n<=5],mid:["Medium · 6–8",n=>n>=6&&n<=8],long:["Long · 9+",n=>n>=9]};
const letters=w=>w.replace(/ /g,"");
const wdS={};
function newWordle(b,daily,len){const C=WCFG[b],P=C.pool(),prev=wdS[b];len=len||(prev?prev.len:"any");const d=localDay(),salt=b.length*131;
  const pool=daily?P:P.filter(e=>LENS[len][1](letters(e.w).length)),e=daily?P[(d*7919+salt)%P.length]:pool[Math.floor(Math.random()*pool.length)];
  const wd={b,x:e.x,word:e.w,ans:letters(e.w),daily,len,day:d,num:d-DAY0+1,rows:[],hints:[],cur:"",done:false,won:false,msg:"",flip:-1,hard:store.get("fb-wd-hard",false),copied:"",size:P.length};
  if(daily){const s=store.get(SK(b,"wd-day"),null);if(s&&s.day===d&&s.word===e.w)Object.assign(wd,{rows:s.rows,hints:s.hints,done:s.done,won:s.won,hard:s.hard})}wdS[b]=wd;return wd}
function saveDaily(wd){if(wd.daily)store.set(SK(wd.b,"wd-day"),{day:wd.day,word:wd.word,rows:wd.rows,hints:wd.hints,done:wd.done,won:wd.won,hard:wd.hard})}
function scoreGuess(g,a){const r=Array(a.length).fill("absent"),c={};for(let i=0;i<a.length;i++){if(g[i]===a[i])r[i]="correct";else c[a[i]]=(c[a[i]]||0)+1}for(let i=0;i<a.length;i++){if(r[i]!=="correct"&&c[g[i]]>0){r[i]="present";c[g[i]]--}}return r}
function hardBreak(wd,g){for(const r of wd.rows){const sc=scoreGuess(r,wd.ans);for(let i=0;i<r.length;i++)if(sc[i]==="correct"&&g[i]!==r[i])return `Hard mode: letter ${i+1} must be ${r[i]}.`;
  const need={};[...r].forEach((c,i)=>{if(sc[i]!=="absent")need[c]=(need[c]||0)+1});for(const c in need)if([...g].filter(x=>x===c).length<need[c])return `Hard mode: your guess must use ${c}.`}return null}
function wdFinish(wd){if(!wd.daily)return;const k=SK(wd.b,"wd-stats"),st=store.get(k,{played:0,wins:0,streak:0,max:0,dist:[0,0,0,0,0,0],last:null});if(st.last===wd.day)return;
  st.played++;if(wd.won){st.wins++;st.streak=(st.last===wd.day-1?st.streak:0)+1;st.max=Math.max(st.max,st.streak);st.dist[wd.rows.length-1]++}else st.streak=0;st.last=wd.day;store.set(k,st)}
function wordleKey(k){const wd=wdS[current];if(!wd||wd.done)return;const L=wd.ans.length;wd.msg="";
  if(k==="ENTER"){if(wd.cur.length<L)wd.msg=`The name has ${L} letters.`;else{const hb=wd.hard?hardBreak(wd,wd.cur):null;if(hb)wd.msg=hb;else{wd.rows.push(wd.cur);wd.flip=wd.rows.length-1;const g=wd.cur;wd.cur="";if(g===wd.ans)wd.done=wd.won=true;else if(wd.rows.length>=6)wd.done=true;if(wd.done)wdFinish(wd);saveDaily(wd)}}}
  else if(k==="BACK")wd.cur=wd.cur.slice(0,-1);else if(/^[A-Z]$/.test(k)&&wd.cur.length<L)wd.cur+=k;rerender()}
function shareText(wd){const em={correct:"🟨",present:"🟦",absent:"⬛"};return `Fenerdle ${SPORTS[wd.b].label} #${wd.num} ${wd.won?wd.rows.length:"X"}/6${wd.hard?"*":""}${wd.hints.length?` (${wd.hints.length} hint${wd.hints.length>1?"s":""})`:""}\n`+wd.rows.map(r=>scoreGuess(r,wd.ans).map(s=>em[s]).join("")).join("\n")}
function gWordle(el){const b=current,C=WCFG[b];let wd=wdS[b]||newWordle(b,true);
  const chars=[...wd.word],n=chars.length,L=wd.ans.length,ks={},rank={absent:1,present:2,correct:3};
  const t=Math.max(22,Math.min(54,Math.floor((Math.min(window.innerWidth||600,620)-48-(n-1)*6)/n))),g=t<34?4:6;
  wd.rows.forEach(r=>scoreGuess(r,wd.ans).forEach((s,i)=>{if(!ks[r[i]]||rank[s]>rank[ks[r[i]]])ks[r[i]]=s}));
  const rowHTML=(lt,sc,flip)=>{let k=0;return chars.map(c=>{if(c===" ")return `<div class="tile sp"></div>`;const i=k++,ch=lt[i]||"";return `<div class="tile ${sc?sc[i]:ch?"filled":""} ${flip?"flip":""}" style="${flip?`animation-delay:${i*90}ms`:""}">${ch}</div>`}).join("")};
  let grid="";for(let r=0;r<6;r++){let inner;if(r<wd.rows.length)inner=rowHTML(wd.rows[r],scoreGuess(wd.rows[r],wd.ans),r===wd.flip);else if(r===wd.rows.length&&!wd.done)inner=rowHTML(wd.cur,null,false);else inner=rowHTML("",null,false);grid+=`<div class="wrow">${inner}</div>`}
  wd.flip=-1;
  const kb=["QWERTYUIOP","ASDFGHJKL","^ZXCVBNM<"].map(r=>`<div class="kbr">${[...r].map(c=>c==="^"?`<button class="key wide" data-k="ENTER">Enter</button>`:c==="<"?`<button class="key wide" data-k="BACK" aria-label="Delete">⌫</button>`:`<button class="key ${ks[c]||""}" data-k="${c}">${c}</button>`).join("")}</div>`).join("");
  const hintBtns=Object.entries(C.hints).map(([k,[lab,f]])=>wd.hints.includes(k)||wd.done?`<div class="hint on"><span class="label">${lab}</span><b>${esc(f(wd.x))}</b></div>`:`<button class="hint" data-h="${k}"><span class="label">${lab}</span><b>Reveal</b></button>`).join("");
  const st=store.get(SK(b,"wd-stats"),{played:0,wins:0,streak:0,max:0,dist:[0,0,0,0,0,0]}),mx=Math.max(1,...st.dist);
  const words=wd.word.split(" ").map(w=>w.length).join(" + ");
  const status=wd.done?`<p class="msg ${wd.won?"good":"bad"}">${wd.won?`Got it in ${wd.rows.length}!`:"Out of guesses."} It was <b>${esc(wd.x.n)}</b>${esc(C.done(wd.x))}.</p>`
    :`<p class="msg ${wd.msg?"bad":""}">${wd.msg?esc(wd.msg):`${L} letters${n>L?` (${words})`:""} · ${6-wd.rows.length} guesses left · ${wd.daily?`daily puzzle #${wd.num}`:"practice round"}`}</p>`;
  el.innerHTML=`<h2>Fenerdle</h2><p class="intro">Guess the ${esc(SPORTS[b].label.toLowerCase())} player in six tries. Names can be from three to fourteen letters, and some have two or three words. You only type the letters; the gaps fill themselves. Turkish letters are written without accents (Ş becomes S).</p>
  <div class="wtop"><div class="filter" role="group" aria-label="Mode"><button data-wm="daily" aria-pressed="${wd.daily}">Daily</button>${Object.entries(LENS).map(([k,[lab]])=>`<button data-wl="${k}" aria-pressed="${!wd.daily&&wd.len===k}">${lab}</button>`).join("")}</div>
    <label class="toggle"><input type="checkbox" id="wdHard" ${wd.hard?"checked":""} ${wd.rows.length?"disabled":""}> Hard mode</label></div>
  <div class="wcenter" style="margin-top:12px">${status}</div>
  <div class="wgame"><div class="wgrid" translate="no" style="--t:${t}px;--g:${g}px">${grid}</div>
   <div class="wside"><span class="label">Hints · they show in your shared result</span><div class="hints">${hintBtns}</div>
   ${wd.done?`<div class="btns">${wd.daily?`<button class="btn" data-w="share">Copy result</button>`:""}<button class="btn ${wd.daily?"ghost":""}" data-w="new">${wd.daily?"Practice round":"Next player"}</button></div>${wd.copied?`<p class="msg good">${esc(wd.copied)}</p>`:""}<textarea id="wdShare" class="sharebox" readonly hidden>${esc(shareText(wd))}</textarea>`:""}
   <div class="box wstats"><span class="label">Daily stats · ${esc(SPORTS[b].label)}</span><div class="wnums"><div><b>${st.played}</b><span>Played</span></div><div><b>${st.played?Math.round(st.wins/st.played*100):0}</b><span>Win %</span></div><div><b>${st.streak}</b><span>Streak</span></div><div><b>${st.max}</b><span>Best</span></div></div>
   <div class="dist">${st.dist.map((c,i)=>`<div><span>${i+1}</span><i style="width:${Math.max(6,c/mx*100)}%" class="${wd.daily&&wd.won&&wd.rows.length===i+1?"hl":""}">${c}</i></div>`).join("")}</div></div></div></div>
  <div class="legendrow"><span><i style="background:var(--yellow)"></i>Right spot</span><span><i style="background:var(--present)"></i>In the name, wrong spot</span><span><i style="background:var(--absent)"></i>Not in the name</span></div>
  <div class="kb" translate="no">${kb}</div><p class="gnote wcenter">${wd.size} possible players.</p>`;
  el.querySelectorAll("[data-k]").forEach(x=>x.onclick=()=>wordleKey(x.dataset.k));
  el.querySelectorAll("[data-h]").forEach(x=>x.onclick=()=>{wd.hints.push(x.dataset.h);saveDaily(wd);rerender()});
  el.querySelector('[data-wm="daily"]').onclick=()=>{newWordle(b,true);rerender()};
  el.querySelectorAll("[data-wl]").forEach(x=>x.onclick=()=>{newWordle(b,false,x.dataset.wl);rerender()});
  el.querySelector("#wdHard").onchange=e=>{if(wd.rows.length)return;wd.hard=e.target.checked;store.set("fb-wd-hard",wd.hard);rerender()};
  const nw=el.querySelector('[data-w="new"]');if(nw)nw.onclick=()=>{newWordle(b,false);rerender()};
  const sh=el.querySelector('[data-w="share"]');if(sh)sh.onclick=()=>{const tx=shareText(wd),fb=()=>{wd.copied="Copy the text below.";rerender();const ta=document.getElementById("wdShare");if(ta){ta.hidden=false;ta.select()}};
    try{navigator.clipboard.writeText(tx).then(()=>{wd.copied="Copied to your clipboard.";rerender()},fb)}catch(e){fb()}}}

/* ---------- WHO AM I? (any branch) ---------- */
const SPECIAL_B={"Mirsad Türkcan":"My number 6 was retired by the club in 2012.","Ömer Onan":"My number 7 was retired by the club in 2014.","İbrahim Kutluay":"The club retired my shirt in December 2025.","Birsel Vardarlı":"I was captain from 2012 to 2019, and my number 7 is retired.","Alperi Onar":"I became club captain in 2023.","Tuğçe Canıtez":"I was club captain from 2019 to 2022.","Olcay Çakır":"I was captain in 2022–23 and had three separate spells at the club.","Ekpe Udoh":"I was MVP of the 2017 Final Four.","Nigel Hayes-Davis":"I was MVP of the 2025 Final Four.","Kayla McBride":"I was MVP of the 2024 Final Four.","Julie Allemand":"I was MVP of the 2026 Final Six.","Breanna Stewart":"I was MVP of the 2023 Final Four."};
function bClues(x,b){const app=x.apps.length?x.apps[Math.floor(Math.random()*x.apps.length)]:null,sq=x.squads.length?x.squads[Math.floor(Math.random()*x.squads.length)]:null;
  const c1=app?`In the ${app.L.label.toLowerCase()} against ${app.L.opp} I ${app.starter?"started":"was on the bench"}${app.pts==null?" but didn't get on the court":app.pts===0?" and didn't score":` and scored ${app.pts}`}.`
    :sq?`I ${sq.num?`wore number ${sq.num}`:"was"} in the ${sq.S.label.toLowerCase()} squad${sq.as!==x.n?` (listed as ${sq.as})`:""}.`:`My Fenerbahçe years: ${x.ten}.`;
  let c2;
  if(app){const ids=[...new Set(x.apps.map(a=>a.L.label))];c2=ids.length>1?`I appear in ${ids.length} of these box scores: ${ids.join(", ")}.`:"That's my only appearance in these box scores.";if(x.ten)c2+=` My Fenerbahçe years: ${x.ten}.`}
  else if(sq)c2=x.squads.length>1?`I was in ${x.squads.length} of these squads: ${x.squads.map(s=>s.S.id).join(", ")}.`:"That's the only one of these squads I was in.";
  const sp=SPECIAL_B[x.n]||VB_AWARDS[x.n]||(sq&&VB_AWARDS[sq.as])||"",pn=`I'm a ${BPOS[x.pos]}${x.nat?` from ${NAT2[x.nat]}`:""}.`;
  if(!app&&!sq)return [c1,sp||`I played as a ${BPOS[x.pos]}.`,x.nat?`I'm from ${NAT2[x.nat]}${sp?` and I played as a ${BPOS[x.pos]}`:""}.`:`I played as a ${BPOS[x.pos]}.`,`My initials are ${initialsOf(x.n)}`];
  return [c1,c2,sp?`${sp} ${pn}`:pn,`My initials are ${initialsOf(x.n)}`]}
const WHOCFG={
 football:()=>{const seasonPool=Object.values(PEOPLE).filter(x=>x.seasons.length),legends=Object.values(PEOPLE).filter(x=>!x.seasons.length&&x.p&&x.p.from<2000);
   return shuffle(shuffle(seasonPool).slice(0,8).concat(shuffle(legends).slice(0,2))).map(x=>({name:x.n,al:aliasesOf(x.n),clues:whoClues(x)}))},
 basketball:()=>bWho("basketball"),"womens-basketball":()=>bWho("womens-basketball"),volleyball:()=>bWho("volleyball")};
function bWho(b){const M=BPEOPLE[b],pool=Object.values(M).filter(x=>(x.apps.length||x.squads.length||x.ten)&&x.pos);return shuffle(pool).slice(0,10).map(x=>({name:x.n,al:aliasB(x.n),clues:bClues(x,b)}))}
const whoS={};
function gWho(el){const b=current;let w=whoS[b];if(!w)w=whoS[b]={q:WHOCFG[b](),i:0,shown:1,score:0,state:null,msg:"",guesses:[]};const N=w.q.length;
  const head=`<h2>Who Am I?</h2><p class="intro">${N} mystery ${esc(SPORTS[b].label.toLowerCase())} players. You start with one clue, and the next one only appears when you ask or guess wrong. Each player is worth 4 points with one clue, down to 1 with all four. Type the name. Small typos are fine.</p>`;
  if(w.i>=N){const best=store.get(SK(b,"who"),0);if(w.score>best)store.set(SK(b,"who"),w.score);
    el.innerHTML=head+`<div class="quiz"><span class="label">Final score</span><div class="final">${w.score}/${N*4}</div><p style="font-size:18px;margin-top:6px">${w.score>=N*3?"Encyclopedic. The club museum should hire you.":w.score>=N*1.8?"Proper Fenerbahçeli.":"Tough one. The lineup games will teach you the squads."}</p><p class="gnote">Best: ${Math.max(best,w.score)}/${N*4}</p><button class="btn" data-wh="again" style="margin-top:14px">Play again</button></div>`;
    el.querySelector('[data-wh="again"]').onclick=()=>{whoS[b]=null;rerender()};return}
  const r=w.q[w.i],pts=5-w.shown,done=w.state!=null;
  el.innerHTML=head+`<div class="quiz"><div class="top"><span class="label">Player ${w.i+1} of ${N}</span><span class="label">Score ${w.score}</span></div><div class="progress"><i style="width:${w.i/N*100}%"></i></div>
    <ol class="clues">${r.clues.map((c,i)=>i<w.shown||done?`<li><span>${i+1}</span><div>${esc(c)}</div></li>`:`<li class="locked"><span>${i+1}</span><div>Hidden clue</div></li>`).join("")}</ol>
    ${done?`<p class="explain"><b>${w.state==="win"?`Correct, +${w.got}.`:"Not this time."}</b> It was ${esc(r.name)}.</p><button class="btn" data-wh="next" style="margin-top:14px">${w.i+1<N?"Next player":"See score"}</button>`:
    `<form class="guessbar" id="whoForm" autocomplete="off"><input id="whoGuess" placeholder="Who am I?" aria-label="Your guess"><button class="btn">Guess</button></form><p class="msg bad">${esc(w.msg)}</p>
     <div class="btns">${w.shown<4?`<button class="btn ghost" data-wh="more">Next clue (−1)</button>`:""}<button class="btn ghost" data-wh="give">Give up</button></div><p class="gnote">Worth ${pts} point${pts>1?"s":""} right now.${w.guesses.length?` Tried: ${w.guesses.map(esc).join(", ")}`:""}</p>`}</div>`;
  const on=(k,f)=>{const x=el.querySelector(`[data-wh="${k}"]`);if(x)x.onclick=f};
  on("more",()=>{w.shown++;w.msg="";rerender()});on("give",()=>{w.state="lose";rerender()});on("next",()=>{w.i++;w.shown=1;w.state=null;w.msg="";w.guesses=[];rerender()});
  const f=el.querySelector("#whoForm");if(f)f.onsubmit=e=>{e.preventDefault();const raw=el.querySelector("#whoGuess").value,v=norm(raw);if(!v)return;
    if(r.al.some(a=>closeEnough(v,a))){w.state="win";w.got=pts;w.score+=pts}else{w.guesses.push(raw);if(w.shown>=4)w.state="lose";else{w.shown++;w.msg=`Not ${raw}. Here's another clue.`}}
    rerender();const i=document.getElementById("whoGuess");if(i)i.focus()}}

/* ---------- TIMELINE (any branch) ---------- */
function branchDeck(b,extra){const ev=[],seen=new Set(),add=(y,t,s)=>{if(!seen.has(t)){seen.add(t);ev.push({y,t,s})}},S=SPORTS[b];
  (S.history||[]).forEach(([y,t])=>{if(/^\d{4}$/.test(y))add(+y,t,"History")});(S.games||[]).forEach(g=>add(+g.date.slice(0,4),g.res?`${g.home} ${g.res} ${g.away} (${g.comp})`:`${g.title} (${g.comp})`,"Big games"));
  extra.forEach(([y,t,s])=>add(y,t,s));return shuffle(ev)}
const TLCFG={football:{title:"Timeline",intro:"Club football moments, famous signings, and the first season each regular broke into the XI.",deck:()=>tlDeck()},
 basketball:{title:"Timeline",intro:"Titles, cups, coaches, Final Fours and retired shirts from the men's basketball team.",deck:()=>branchDeck("basketball",MB_EVENTS)},
 "womens-basketball":{title:"Timeline",intro:"Twenty league titles, European finals, coaches and captains from the women's basketball team.",deck:()=>branchDeck("womens-basketball",WB_EVENTS)},
 volleyball:{title:"Timeline",intro:"Volleyball from 1928 to today: titles, coaches, captains and European nights, men's team included.",deck:()=>branchDeck("volleyball",VB_EVENTS)},
 more:{title:"Club Timeline",intro:"Nearly 120 years across every branch, from the founding in 1907 to women's football's first league title.",deck:()=>shuffle(CLUB_EVENTS.map(([y,t,s])=>({y,t,s})))}};
const tlS={};
function tlNext(tl){const D=tl.deck;if(!D.length)return null;const ys=tl.placed.map(e=>e.y);let bi=0,bs=1e9;
  for(let i=0;i<Math.min(D.length,18);i++){const d=Math.min(...ys.map(y=>Math.abs(y-D[i].y))),sc=d===0?6:d<=3?d:10+d;if(sc<bs){bs=sc;bi=i}}return D.splice(bi,1)[0]}
function newTL(b,expert){const deck=TLCFG[b].deck(),prev=tlS[b],tl={b,deck,placed:[deck.shift()],lives:2,score:0,last:null,over:false,expert:expert!=null?expert:(prev?prev.expert:false),moves:0};tl.cur=tlNext(tl);tlS[b]=tl;return tl}
function gTimeline(el){const b=current,C=TLCFG[b];let tl=tlS[b]||newTL(b,false);
  const hide=tl.expert&&!tl.over,slot=k=>tl.over?"":`<li class="ins"><button data-ins="${k}">Place it here</button></li>`;
  let list=slot(0);tl.placed.forEach((e,i)=>{list+=`<li class="card ${e.st||""} ${tl.last&&tl.last.c.t===e.t?"just":""}"><span class="y ${hide?"q":""}">${hide?"????":e.y}</span><span class="t"><small>${esc(e.s)}</small>${esc(e.t)}</span></li>`+slot(i+1)});
  const best=store.get(SK(b,"tl"),0);
  el.innerHTML=`<h2>${C.title}</h2><p class="intro">${C.intro} Place each new card where it belongs, oldest at the top. New cards tend to land close in time to ones already placed. You have two lives. Expert mode hides the years until the end and doubles your points.</p>
  <div class="wtop"><div class="tlhead"><div><b class="count">${tl.score}</b><span class="label">points</span></div><div class="lives" aria-label="${tl.lives} lives left">${[0,1].map(i=>`<i class="${i<tl.lives?"on":""}"></i>`).join("")}</div><div><b class="count">${best}</b><span class="label">record</span></div></div>
   <label class="toggle"><input type="checkbox" id="tlExp" ${tl.expert?"checked":""} ${tl.moves?"disabled":""}> Expert mode</label></div>
  ${tl.over?`<div class="box" style="margin-top:16px"><h3>${tl.record?"New record! ":""}You scored ${tl.score}.</h3><div class="btns"><button class="btn" data-tl="new">Play again</button></div></div>`:`<div class="tlcur"><span class="label">Where does this go?</span><p><small>${esc(tl.cur.s)}</small>${esc(tl.cur.t)}</p></div>`}
  ${tl.last&&!tl.over?`<p class="msg ${tl.last.ok?"good":"bad"}">${tl.last.ok?"Correct.":`Not quite${hide?"":`. That was ${tl.last.c.y}`}.`}</p>`:""}
  <ol class="tl2">${list}</ol>`;
  el.querySelectorAll("[data-ins]").forEach(x=>x.onclick=()=>{const k=+x.dataset.ins,c=tl.cur,P=tl.placed,ok=(k===0||P[k-1].y<=c.y)&&(k===P.length||c.y<=P[k].y);tl.moves++;
    if(ok){P.splice(k,0,{...c,st:"ok"});tl.score+=tl.expert?2:1}else{tl.lives--;let j=P.findIndex(e=>e.y>c.y);if(j<0)j=P.length;P.splice(j,0,{...c,st:"no"})}
    tl.last={ok,c};tl.cur=tlNext(tl);if(tl.lives<=0||!tl.cur){tl.over=true;if(tl.score>store.get(SK(b,"tl"),0)){store.set(SK(b,"tl"),tl.score);tl.record=true}}rerender()});
  const n=el.querySelector('[data-tl="new"]');if(n)n.onclick=()=>{newTL(b);rerender()};
  el.querySelector("#tlExp").onchange=e=>{if(tl.moves)return;newTL(b,e.target.checked);rerender()}}

/* ---------- NAME THE LINEUP / SQUAD ---------- */
const LUCFG={basketball:{items:MB_LINEUPS,kind:"bb",title:"Name the Lineup",note:DATA_NOTE.MB},"womens-basketball":{items:WB_LINEUPS,kind:"bb",title:"Name the Lineup",note:DATA_NOTE.WB},volleyball:{items:VB_SQUADS,kind:"vb",title:"Name the Squad",note:DATA_NOTE.VB}};
const luS={};
function luSlots(C,it){if(C.kind==="bb"){const out=it.st.map(([pos,n,pts],i)=>({n,lab:pos,sub:pts==null?"":`${pts} pts`,starter:true,i}));it.bench.forEach(([n,pts],i)=>out.push({n,lab:"Bench",sub:pts==null?"DNP":`${pts} pts`,starter:false,i:5+i}));return out}
  return it.sq.map(([num,n,pos],i)=>({n,lab:num!=null?`#${num}`:"",sub:pos?BPOS[pos]:"",starter:false,i}))}
function gLineup(el){const b=current,C=LUCFG[b];let s=luS[b];if(!s)s=luS[b]={id:C.items[0].id,found:new Set(),hints:new Set(),wrong:0,ended:false,msg:"",cls:""};
  const it=C.items.find(x=>x.id===s.id),slots=luSlots(C,it),al=uniqueAliases(slots.map(x=>x.n)),N=slots.length,best=store.get(SK(b,"lu"),{});
  const score=()=>Math.max(0,s.found.size*10-s.hints.size*4-s.wrong*2),stars=()=>s.found.size===N&&!s.hints.size&&s.wrong<=2?3:s.found.size===N?2:s.found.size>=Math.ceil(N/2)?1:0;
  const end=msg=>{s.ended=true;const bb=best[s.id]||{stars:0};best[s.id]={stars:Math.max(bb.stars,stars())};store.set(SK(b,"lu"),best);s.msg=msg;s.cls=s.found.size===N?"good":""};
  const slotHTML=x=>{const f=s.found.has(x.i),show=f||s.ended,hint=s.hints.has(x.i)?x.n.split(/[\s-]+/).map(w=>w[0]+"·".repeat(Math.min(w.length-1,6))).join(" "):"";return `<div class="ps ${f?"filled":s.ended?"missed":""}" style="${x.pos||""}"><span class="disc">${f?"✓":esc(x.lab||"?")}</span><span class="nm ${show?"":"dim"}">${show?esc(x.n):esc(hint||x.sub)}</span></div>`};
  let visual;
  if(C.kind==="bb"){const P=[[50,82],[17,58],[83,58],[30,28],[70,28]];slots.filter(x=>x.starter).forEach((x,k)=>x.pos=`left:${P[k][0]}%;top:${P[k][1]}%`);
    visual=`<div class="court bb">${courtBB()}${slots.filter(x=>x.starter).map(slotHTML).join("")}</div>${it.bench.length?`<div class="bench"><span class="label">Bench · ${it.bench.length} more in the box score</span><div class="benchgrid">${slots.filter(x=>!x.starter).map(x=>slotHTML({...x,pos:""})).join("")}</div></div>`:`<p class="gnote">Only the starting five are on record for this game.</p>`}`}
  else visual=`<div class="squadgrid">${slots.map(x=>slotHTML({...x,pos:""})).join("")}</div>`;
  el.innerHTML=`<h2>${C.title}</h2><p class="intro">${C.kind==="bb"?"Pick a big game and name everyone in Fenerbahçe's box score: the starting five by position, then the bench. Points scored are shown as a clue.":"Pick a famous squad and name every player. Shirt numbers and positions are shown as clues."} Each player is worth 10 points, a hint costs 4 and a wrong guess costs 2.</p>
  <div class="seasons" role="group" aria-label="Game">${C.items.map(x=>`<button data-lu="${x.id}" aria-pressed="${x.id===s.id}"><b>${esc(x.label)}</b><span class="stars">${stars3((best[x.id]||{}).stars||0)}</span></button>`).join("")}</div>
  <div class="draft"><div>${visual}</div><div class="side"><div class="box">
    <span class="label">${esc(it.title)}${it.date?` · ${esc(it.date)}`:""}</span><h3 style="margin-top:4px">${it.opp?`vs ${esc(it.opp)}, ${esc(it.score)}`:esc(it.label)}</h3>
    <p class="gnote">${it.where?`${esc(it.where)} · coach ${esc(it.coach)}`:esc(it.note)}</p>
    <form class="guessbar" id="luForm" autocomplete="off"><input id="luGuess" placeholder="Type a player…" aria-label="Player name" ${s.ended?"disabled":""}><button class="btn" ${s.ended?"disabled":""}>Guess</button></form>
    <p class="msg ${s.cls}">${esc(s.msg)}</p>
    <div class="xinums"><div><b class="count">${s.found.size}</b><span class="label">of ${N}</span></div><div><b class="count">${score()}</b><span class="label">points</span></div></div>
    ${s.ended?`<p style="margin-top:10px;font-size:22px;color:var(--yellow)">${stars3(stars())}</p>`:""}
    <div class="btns"><button class="btn ghost" data-l="hint" ${s.ended?"disabled":""}>Hint (−4)</button><button class="btn ghost" data-l="give" ${s.ended?"disabled":""}>Give up</button><button class="btn ghost" data-l="reset">Start over</button></div>
    <p class="gnote">${esc(C.note)}</p></div></div></div>`;
  el.querySelectorAll("[data-lu]").forEach(x=>x.onclick=()=>{luS[b]={id:x.dataset.lu,found:new Set(),hints:new Set(),wrong:0,ended:false,msg:"",cls:""};rerender()});
  el.querySelector("#luForm").onsubmit=e=>{e.preventDefault();if(s.ended)return;const raw=el.querySelector("#luGuess").value,v=norm(raw);if(!v)return;
    const k=slots.findIndex((x,i)=>!s.found.has(x.i)&&al[i].some(a=>closeEnough(v,a))),k2=k<0?slots.findIndex((x,i)=>al[i].some(a=>closeEnough(v,a))):k;
    if(k2<0){s.wrong++;s.msg=`${raw} isn't in this one (−2).`;s.cls="bad"}else if(s.found.has(slots[k2].i)){s.msg=`You already have ${slots[k2].n}.`;s.cls=""}
    else{s.found.add(slots[k2].i);s.msg=`Yes: ${slots[k2].n}.`;s.cls="good";if(s.found.size===N)end("Everyone named!")}
    rerender();const i=document.getElementById("luGuess");if(i&&!i.disabled)i.focus()};
  const on=(k,f)=>{const x=el.querySelector(`[data-l="${k}"]`);if(x)x.onclick=f};
  on("hint",()=>{const left=slots.filter(x=>!s.found.has(x.i)&&!s.hints.has(x.i));if(left.length){s.hints.add(left[Math.floor(Math.random()*left.length)].i);s.msg="Hint: first letters of one player.";s.cls=""}rerender()});
  on("give",()=>{end(`You named ${s.found.size} of ${N}.`);rerender()});on("reset",()=>{luS[b]={id:s.id,found:new Set(),hints:new Set(),wrong:0,ended:false,msg:"",cls:""};rerender()})}
function courtBB(){return `<svg class="lines" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true"><rect x="34" y="0" width="32" height="38" class="key"/><path d="M34 38 A16 12 0 0 0 66 38"/><path d="M6 0 V14 A44 44 0 0 0 94 14 V0"/><circle cx="50" cy="7" r="2.2"/><path d="M45 3 H55"/><path d="M38 100 A12 9 0 0 1 62 100"/></svg>`}
function courtFB(){return `<svg class="lines" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true"><path d="M0 50 H100"/><circle cx="50" cy="50" r="10"/><rect x="28" y="0" width="44" height="13"/><rect x="28" y="87" width="44" height="13"/></svg>`}
function courtVB(){return `<svg class="lines" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true"><path d="M0 9 H100" class="net"/><path d="M0 40 H100"/></svg>`}

/* ---------- TEAM DRAFT (basketball five + sixth man, volleyball six + libero) ---------- */
const TDCFG={
 basketball:{pool:MB_P,court:"bb",slots:[["PG",50,70],["SG",17,52],["SF",83,52],["PF",30,26],["C",70,26],["6TH",50,89]],rounds:[["Semi-final","Lacivert Select"],["Final","Legends Select"]],cup:"Final Four",unit:"five",sim:"bb"},
 "womens-basketball":{pool:WB_P,court:"bb",slots:[["PG",50,70],["SG",17,52],["SF",83,52],["PF",30,26],["C",70,26],["6TH",50,89]],rounds:[["Quarter-final","Sarı Select"],["Semi-final","Lacivert Select"],["Final","Legends Select"]],cup:"Final Six",unit:"five",sim:"bb"},
 volleyball:{pool:VB_P,court:"vb",slots:[["OH",18,26],["MB",50,26],["OP",82,26],["OH",18,64],["MB",50,64],["S",82,64],["L",50,88]],rounds:[["Semi-final","Lacivert Select"],["Final","Legends Select"]],cup:"Final Four",unit:"six",sim:"vb"}};
const SLOTNAME={GK:"goalkeeper",DF:"defender",MF:"midfielder",FW:"forward","6TH":"sixth man",PG:"point guard",SG:"shooting guard",SF:"small forward",PF:"power forward",C:"center",S:"setter",OP:"opposite",OH:"outside hitter",MB:"middle blocker",L:"libero"};
const tdS={};

const tdEff=(sp,p)=>p.r-(sp==="6TH"||p.pos===sp?0:3);
function tdInfo(C,picks){const idx=picks.map((p,i)=>p?i:-1).filter(i=>i>=0),eff=picks.map((p,i)=>p?tdEff(C.slots[i][0],p):null);if(!idx.length)return{eff,ovr:0};
  const w=i=>C.slots[i][0]==="6TH"?.5:C.slots[i][0]==="L"?.7:1;let sw=0,s=0;idx.forEach(i=>{s+=eff[i]*w(i);sw+=w(i)});return{eff,ovr:s/sw}}
function newTD(b){const C=TDCFG[b];tdS[b]={picks:Array(C.slots.length).fill(null),offers:{},active:0,rerolls:3,phase:"pick",cup:null};return tdS[b]}
function tdOffers(C,s,i){return chWith(current,"rd",()=>tdOffersRaw(C,s,i))}
function tdOffersRaw(C,s,i){const used=new Set(s.picks.filter(Boolean));if(!s.offers[i]){const sp=C.slots[i][0],nat=shuffle(C.pool.filter(p=>!used.has(p)&&(sp==="6TH"?p.pos!=="L":p.pos===sp))),alt=sp==="6TH"?[]:shuffle(C.pool.filter(p=>!used.has(p)&&p.pos!==sp&&p.alt.includes(sp)));
  const list=nat.slice(0,4);if(alt.length)list.push(alt[0]);else if(nat[4])list.push(nat[4]);s.offers[i]=shuffle(list)}return s.offers[i].filter(p=>!used.has(p))}




function gTeamDraft(el){const b=current,C=TDCFG[b];let s=tdS[b]||newTD(b);const info=tdInfo(C,s.picks),filled=s.picks.filter(Boolean).length,best=store.get(SK(b,"td"),null);
  const vis=`<div class="court ${C.court}">${C.court==="bb"?courtBB():C.court==="fb"?courtFB():courtVB()}${C.slots.map(([sp,x,y],i)=>{const p=s.picks[i],oop=p&&sp!=="6TH"&&p.pos!==sp;
    return `<button type="button" class="ps ${p?"filled":""} ${s.phase==="pick"&&s.active===i?"active":""} ${oop?"oop":""} ${sp==="6TH"||sp==="L"?"extra":""}" style="left:${x}%;top:${y}%" data-ts="${i}" aria-label="${SLOTNAME[sp]}${p?": "+esc(p.n):", empty"}"><span class="disc">${p?info.eff[i]:(sp==="6TH"?"6th":sp)}</span><span class="nm">${p?esc(p.short):""}</span></button>`}).join("")}</div>`;
  let side;
  if(s.phase==="pick"){const i=s.active,sp=C.slots[i][0];side=`<div class="box"><span class="label">Pick ${filled+1} of ${C.slots.length} · tap any empty spot to switch</span><h3 style="margin-top:4px">${SLOTNAME[sp][0].toUpperCase()+SLOTNAME[sp].slice(1)}</h3>
    <div class="cands2">${tdOffers(C,s,i).map((c,k)=>`<button class="cand2" data-tc="${k}"><span class="r">${c.r}</span><span class="info"><b>${esc(c.n)}</b><small>${c.nat||""} · ${c.pos}${c.ten?` · ${esc(c.ten)}`:""}</small></span>${sp!=="6TH"&&c.pos!==sp?'<em class="tag bad">Out of position −3</em>':'<span></span>'}</button>`).join("")}</div>
    <div class="btns"><button class="btn ghost" data-t="reroll" ${s.rerolls?"":"disabled"}>New options (${s.rerolls} left)</button></div></div>`}
  else side=`<div class="box" id="tdCup"></div>`;
  const sum=`<div class="box"><span class="label">${s.phase==="pick"?"Team so far":"Your team"}</span><div class="ovr" style="margin-top:8px"><span class="big">${filled?info.ovr.toFixed(1):"–"}</span><dl><dt>Players</dt><dd>${filled}/${C.slots.length}</dd><dt>Best ever</dt><dd>${best!=null?Number(best).toFixed(1):"–"}</dd><dt>Most trophies in a season</dt><dd>${store.get(SK(b,"sz-best"),0)}</dd></dl></div></div>`;
  el.innerHTML=`<h2>${C.unit==="eleven"?"XI Draft":C.unit==="five"?"Starting Five Draft":"Starting Six Draft"}</h2><p class="intro">${C.unit==="eleven"?"Fill a 4-3-3 from Fenerbahçe players, a few options at a time. Playing someone out of position costs 3 points.":C.unit==="five"?"Fill a starting five and a sixth man from Fenerbahçe greats, five options at a time. Playing someone out of position costs 3 points.":"Fill a starting six plus a libero from Fenerbahçe greats, five options at a time. Playing someone out of position costs 3 points."} Then pick a season and play it through, game by game, in every competition the club entered that year.</p>
  <div class="draft"><div>${vis}</div><div class="side">${side}${sum}</div></div><p class="gnote">Ratings are fan ratings made for this game, not official numbers.</p>`;
  el.querySelectorAll("[data-ts]").forEach(x=>x.onclick=()=>{const i=+x.dataset.ts;if(s.phase==="pick"&&!s.picks[i]){s.active=i;rerender()}});
  el.querySelectorAll("[data-tc]").forEach(x=>x.onclick=()=>{s.picks[s.active]=tdOffers(C,s,s.active)[+x.dataset.tc];const nx=s.picks.findIndex(p=>!p);
    if(nx<0){s.phase="done";const o=tdInfo(C,s.picks).ovr,bs=store.get(SK(b,"td"),null);if(bs==null||o>bs)store.set(SK(b,"td"),Math.round(o*10)/10);s.cup={}}else s.active=nx;rerender()});
  const rr=el.querySelector('[data-t="reroll"]');if(rr)rr.onclick=()=>{if(!s.rerolls)return;s.rerolls--;delete s.offers[s.active];rerender()};
  if(s.phase==="done")tdCupRender(b)}


/* ---------- FREE THROWS (basketball) ---------- */
const FT_DEF={basketball:["Bogdan Bogdanović","Luigi Datome","Kostas Sloukas","Nando De Colo","Nigel Hayes-Davis","Marko Gudurić"],"womens-basketball":["Kayla McBride","Diana Taurasi","Breanna Stewart","Emma Meesseman","Julie Allemand","Kelsey Plum"]};
const ftS={};let ftRAF=null;
function ftPool(b){const C=TDCFG[b],s=tdS[b],P=C.pool,def=FT_DEF[b].map(n=>P.find(p=>p.n===n)).filter(Boolean);if(s&&s.picks.every(Boolean))return s.picks.concat(def.filter(d=>!s.picks.includes(d))).slice(0,9);return def}
function newFT(b,shooter){ftS[b]={shooter,shots:[],streak:0,score:0,phase:shooter?"aim":"pick",t0:performance.now(),val:0,res:null,anim:null};return ftS[b]}
const ftZone=s=>Math.max(3,6+(s.shooter.r-75)*.5-s.streak*.9),ftPer=s=>Math.max(520,1150-s.streak*55);
function ftLoop(){const s=ftS[current];if(!s||s.phase!=="aim"){ftRAF=null;return}const m=document.getElementById("ftMark");if(!m){ftRAF=null;return}const t=performance.now()-s.t0,per=ftPer(s),ph=(t%(2*per))/per;s.val=(ph<1?ph:2-ph)*100;m.style.left=s.val+"%";ftRAF=requestAnimationFrame(ftLoop)}
function ftShoot(){const b=current,s=ftS[b];if(!s||s.phase!=="aim")return;const d=Math.abs(s.val-50),w=ftZone(s);let r;
  if(d<=w*.4)r=["Swish!",3,true];else if(d<=w)r=["Good!",2,true];else if(d<=w+4)r=Math.random()<.45?["Rolled in!",1,true]:["Rim out!",0,false];else r=s.val<50?["Short!",0,false]:["Long!",0,false];
  s.phase="anim";s.res=r;s.anim={t0:performance.now(),make:r[2],kind:r[0],side:s.val<50?-1:1};rerender();
  setTimeout(()=>{s.shots.push(r[2]);s.score+=r[1]*(r[2]&&s.streak>=4?2:1);s.streak=r[2]?s.streak+1:0;if(s.shots.length>=10){s.phase="over";const k=SK(b,"ft"),bs=store.get(k,0);if(s.score>bs){store.set(k,s.score);s.rec=true}}else{s.phase="aim";s.t0=performance.now()}rerender()},1250)}
function gFT(el){const b=current;let s=ftS[b]||newFT(b,null);cancelAnimationFrame(ftRAF);ftRAF=null;
  if(s.phase==="pick"){el.innerHTML=`<h2>Free Throws</h2><p class="intro">Ten free throws, one shooter. Stop the marker inside the yellow zone. Better shooters get a wider zone, but it shrinks with every make in a row and the marker speeds up. A swish is worth 3, a clean make 2, a lucky roll 1, and every make from five in a row on counts double.</p>
    <span class="label">Choose your shooter${tdS[b]&&tdS[b].picks.every(Boolean)?" · your drafted team is listed first":""}</span><div class="shooters">${ftPool(b).map((p,i)=>`<button class="cand2" data-fs="${i}"><span class="r">${p.r}</span><span class="info"><b>${esc(p.n)}</b><small>${p.pos} · ${p.nat||""}</small></span><span></span></button>`).join("")}</div><p class="gnote">Best score: ${store.get(SK(b,"ft"),0)}. Shooter ratings are made up for this game.</p>`;
    el.querySelectorAll("[data-fs]").forEach(x=>x.onclick=()=>{newFT(b,ftPool(b)[+x.dataset.fs]);rerender()});return}
  const w=ftZone(s),dots=s.shots.map(v=>`<i class="dot ${v?"g":"m"}"></i>`).join("")+Array(10-s.shots.length).fill('<i class="dot"></i>').join("");
  el.innerHTML=`<h2>Free Throws</h2><p class="intro">Stop the marker in the yellow zone. Tap the court, press Space, or use the button.</p>
  <div class="pk-wrap"><div><div class="ftcourt" id="ftc"><svg viewBox="0 0 400 260" aria-hidden="true"><rect x="0" y="232" width="400" height="28" class="floor"/><rect x="352" y="40" width="8" height="110" class="board"/><rect x="330" y="72" width="22" height="26" class="board2"/><path d="M300 100 H352" class="rim"/><path d="M302 100 L310 128 H342 L350 100" class="net2"/>
    <circle cx="70" cy="196" r="26" class="shooter"/><text x="70" y="202" text-anchor="middle" class="shnum">${esc(String(s.shooter.r))}</text><circle id="ftBall" cx="96" cy="176" r="10" class="ball"/></svg>
    ${s.res&&s.phase!=="aim"?`<div class="pk-banner" style="top:8%">${esc(s.res[0])}</div>`:""}</div>
    <div class="meter"><div class="zone" style="left:${50-w}%;width:${2*w}%"></div><div class="zone in" style="left:${50-w*.4}%;width:${.8*w}%"></div>${s.phase==="aim"?`<div class="mark" id="ftMark" style="left:${s.val}%"></div>`:""}</div></div>
  <div class="side"><div class="box"><span class="label">${s.phase==="over"?"Finished":`Shot ${s.shots.length+1} of 10`}</span><h3 style="margin-top:4px">${esc(s.shooter.n)}</h3>
    <div class="xinums"><div><b class="count">${s.score}</b><span class="label">points</span></div><div><b class="count">${s.streak}</b><span class="label">in a row</span></div></div>
    <div class="dots" style="margin-top:12px">${dots}</div>
    ${s.phase==="aim"?`<div class="btns"><button class="btn" data-f="shoot">Shoot</button></div>`:""}
    ${s.phase==="over"?`<p class="msg good">${s.rec?"New record! ":""}You scored ${s.score}.</p><div class="btns"><button class="btn" data-f="again">Same shooter again</button><button class="btn ghost" data-f="pick">Change shooter</button></div>`:`<div class="btns"><button class="btn ghost" data-f="pick">Change shooter</button></div>`}
    <p class="gnote">Best: ${store.get(SK(b,"ft"),0)}</p></div></div></div>`;
  const on=(k,f)=>{const x=el.querySelector(`[data-f="${k}"]`);if(x)x.onclick=f};on("shoot",ftShoot);on("again",()=>{newFT(b,s.shooter);rerender()});on("pick",()=>{newFT(b,null);rerender()});
  el.querySelector("#ftc").onpointerdown=e=>{if(s.phase==="aim"){e.preventDefault();ftShoot()}};
  if(s.phase==="aim")ftRAF=requestAnimationFrame(ftLoop);
  if(s.phase==="anim"&&s.anim){const A=s.anim,ball=document.getElementById("ftBall"),reduce=matchMedia("(prefers-reduced-motion: reduce)").matches;
    const end=A.make?[326,104]:A.kind==="Short!"?[296,110]:A.kind==="Long!"?[352,92]:[302,98];
    const step=now=>{const k=Math.min(1,(now-A.t0)/(reduce?200:820)),x0=96,y0=176,cx=210,cy=-30;const t=k,x=(1-t)*(1-t)*x0+2*(1-t)*t*cx+t*t*end[0],y=(1-t)*(1-t)*y0+2*(1-t)*t*cy+t*t*end[1];
      if(ball){ball.setAttribute("cx",x);ball.setAttribute("cy",y)}if(k<1&&ball&&ftS[current]===s)requestAnimationFrame(step);else if(ball){const fy=A.make?150:200,fx=A.make?326:(A.kind==="Long!"?380:270);setTimeout(()=>{ball.style.transition="cx .35s, cy .35s";ball.setAttribute("cx",fx);ball.setAttribute("cy",fy)},60)}};
    requestAnimationFrame(step)}}

/* ---------- SERVE (volleyball) ---------- */
const SV_DEF=["Melissa Vargas","Kim Yeon-koung","Katarzyna Skowrońska","Magdalena Stysiak","Arina Fedorovtseva","Eda Erdem Dündar"];
const svS={};let svRAF=null;
const svX=x=>30+x/9*240,svY=d=>290-d/9*250;
function svPool(){const s=tdS.volleyball,def=SV_DEF.map(n=>VB_P.find(p=>p.n===n));if(s&&s.picks.every(Boolean))return s.picks.filter(p=>p.pos!=="L").concat(def.filter(d=>!s.picks.includes(d))).slice(0,9);return def}
function newSV(server){svS.v={server,n:0,score:0,log:[],phase:server?"aimX":"pick",t0:performance.now(),cx:4.5,cd:5,hist:[],res:null,def:[[1.5,2.6],[4.5,2.6],[7.5,2.6],[1.5,6.6],[4.5,6.6],[7.5,6.6]]};return svS.v}
const svTri=(t,per)=>{const ph=(t%(2*per))/per;return ph<1?ph:2-ph};
function svLoop(){const s=svS.v;if(!s||(s.phase!=="aimX"&&s.phase!=="aimD")){svRAF=null;return}const m=document.getElementById("svAim");if(!m){svRAF=null;return}const r=s.server.r,t=performance.now()-s.t0;
  if(s.phase==="aimX"){s.cx=-1+svTri(t,(0.9+(r-75)*.04)*1000)*11;s.cd=8}else s.cd=svTri(t,(0.8+(r-75)*.035)*1000)*10.6;m.setAttribute("cx",svX(s.cx));m.setAttribute("cy",svY(s.cd));svRAF=requestAnimationFrame(svLoop)}
function svLock(){const s=svS.v;if(!s)return;if(s.phase==="aimX"){s.ax=s.cx;s.phase="aimD";s.t0=performance.now();rerender()}else if(s.phase==="aimD"){s.ad=s.cd;svServe()}}
function svServe(){const s=svS.v,x=s.ax,d=s.ad;let r;
  if(d<0.6)r=["Into the net!",0];else if(x<0||x>9)r=["Wide! Out.",0];else if(d>9)r=["Long! Out.",0];
  else{const md=Math.min(...s.def.map(([px,pd])=>Math.hypot(px-x,pd-d)));r=md>1.8?["ACE!",3]:md>1?["Tough serve, shanked pass",2]:["Passed well",1];s.hist.push([x,d])}
  s.phase="anim";s.res=r;s.land=[x,Math.min(Math.max(d,0.2),10.4)];rerender();
  setTimeout(()=>{s.n++;s.score+=r[1];s.log.push(r[1]);
    if(s.hist.length){const h=s.hist.slice(-4),mx=h.reduce((a,v)=>a+v[0],0)/h.length,md=h.reduce((a,v)=>a+v[1],0)/h.length;s.def=s.def.map(([px,pd])=>[px+(mx-px)*.18,pd+(md-pd)*.12])}
    if(s.n>=12){s.phase="over";const bs=store.get("fb-volleyball-sv",0);if(s.score>bs){store.set("fb-volleyball-sv",s.score);s.rec=true}}else{s.phase="aimX";s.t0=performance.now()}rerender()},1300)}
function gServe(el){let s=svS.v||newSV(null);cancelAnimationFrame(svRAF);svRAF=null;
  if(s.phase==="pick"){el.innerHTML=`<h2>Serve</h2><p class="intro">Twelve serves at the opponent's court. Time two taps: one for direction, one for depth. Land it far from every receiver for an ace (3 points). A tough serve that forces a bad pass is worth 2, and a serve that's passed well is worth 1. Serve into the net or out and you get nothing. The receivers shift toward where you've been serving.</p>
    <span class="label">Choose your server${tdS.volleyball&&tdS.volleyball.picks.every(Boolean)?" · your drafted six are listed first":""}</span><div class="shooters">${svPool().map((p,i)=>`<button class="cand2" data-sv="${i}"><span class="r">${p.r}</span><span class="info"><b>${esc(p.n)}</b><small>${p.pos} · ${p.nat||""}</small></span><span></span></button>`).join("")}</div><p class="gnote">Best score: ${store.get("fb-volleyball-sv",0)} of 36. Server ratings are made up for this game.</p>`;
    el.querySelectorAll("[data-sv]").forEach(x=>x.onclick=()=>{newSV(svPool()[+x.dataset.sv]);rerender()});return}
  const aim=s.phase==="aimX"||s.phase==="aimD";
  el.innerHTML=`<h2>Serve</h2><p class="intro">Step 1 sets the direction, step 2 the depth. Tap the court, press Space, or use the button.</p>
  <div class="pk-wrap"><div class="svcourt" id="svc"><svg viewBox="0 0 300 330" aria-hidden="true"><rect x="30" y="40" width="240" height="250" class="vfloor"/><path d="M30 207 H270" class="vline"/><rect x="22" y="288" width="256" height="6" class="vnet"/>
    ${s.def.map(([px,pd])=>`<circle cx="${svX(px)}" cy="${svY(pd)}" r="11" class="rcv"/>`).join("")}
    ${s.hist.slice(-6).map(([x,d])=>`<circle cx="${svX(x)}" cy="${svY(d)}" r="3" class="trail"/>`).join("")}
    ${aim?`${s.phase==="aimD"?`<path d="M${svX(s.ax)} 30 V300" class="guide"/>`:""}<circle id="svAim" cx="${svX(s.cx)}" cy="${svY(s.cd)}" r="9" class="aim"/>`:""}
    ${s.phase==="anim"||s.phase==="over"&&s.land?`<circle cx="${svX(s.land[0])}" cy="${svY(s.land[1])}" r="7" class="vball"/>`:""}
    </svg>${s.res&&!aim?`<div class="pk-banner" style="top:42%">${esc(s.res[0])}</div>`:""}</div>
  <div class="side"><div class="box"><span class="label">${s.phase==="over"?"Finished":`Serve ${s.n+1} of 12`}</span><h3 style="margin-top:4px">${esc(s.server.n)}</h3>
    <div class="xinums"><div><b class="count">${s.score}</b><span class="label">points</span></div><div><b class="count">${s.log.filter(v=>v===3).length}</b><span class="label">aces</span></div></div>
    <div class="dots" style="margin-top:12px">${s.log.map(v=>`<i class="dot ${v===3?"g":v===0?"m":"half"}"></i>`).join("")}${Array(12-s.log.length).fill('<i class="dot"></i>').join("")}</div>
    ${aim?`<div class="btns"><button class="btn" data-s="lock">${s.phase==="aimX"?"Set direction":"Serve"}</button></div>`:""}
    ${s.phase==="over"?`<p class="msg good">${s.rec?"New record! ":""}You scored ${s.score} of 36.</p><div class="btns"><button class="btn" data-s="again">Serve again</button><button class="btn ghost" data-s="pick">Change server</button></div>`:`<div class="btns"><button class="btn ghost" data-s="pick">Change server</button></div>`}
    <p class="gnote">Best: ${store.get("fb-volleyball-sv",0)} · green = ace, red = error</p></div></div></div>`;
  const on=(k,f)=>{const x=el.querySelector(`[data-s="${k}"]`);if(x)x.onclick=f};on("lock",svLock);on("again",()=>{newSV(s.server);rerender()});on("pick",()=>{newSV(null);rerender()});
  el.querySelector("#svc").onpointerdown=e=>{if(aim){e.preventDefault();svLock()}};if(aim)svRAF=requestAnimationFrame(svLoop)}

/* ---------- WHICH BRANCH? and MEMORY (other branches) ---------- */
let whS=null;
function gWhich(el){if(!whS)whS={q:shuffle(BR_FACTS).slice(0,10).map(([f,a])=>({f,a,o:shuffle([a,...shuffle(BR_NAMES.filter(x=>x!==a)).slice(0,3)])})),i:0,score:0,picked:null};const s=whS;
  if(s.i>=s.q.length){const bs=store.get("fb-more-which",0);if(s.score>bs)store.set("fb-more-which",s.score);
    el.innerHTML=`<h2>Which Branch?</h2><div class="quiz"><span class="label">Final score</span><div class="final">${s.score}/10</div><p class="gnote">Best: ${Math.max(bs,s.score)}/10</p><button class="btn" data-wb="again" style="margin-top:14px">Play again</button></div>`;el.querySelector('[data-wb="again"]').onclick=()=>{whS=null;rerender()};return}
  const r=s.q[s.i];el.innerHTML=`<h2>Which Branch?</h2><p class="intro">Ten facts from across the club. Pick the department each one belongs to.</p>
  <div class="quiz"><div class="top"><span class="label">Fact ${s.i+1} of 10</span><span class="label">Score ${s.score}</span></div><div class="progress"><i style="width:${s.i*10}%"></i></div><h3>${esc(r.f)}</h3>
  <div class="opts">${r.o.map(o=>{let c="opt";if(s.picked!=null){if(o===r.a)c+=" right";else if(o===s.picked)c+=" wrong"}return `<button class="${c}" data-wo="${esc(o)}" ${s.picked!=null?"disabled":""}>${esc(o)}</button>`}).join("")}</div>
  ${s.picked!=null?`<p class="explain"><b>${s.picked===r.a?"Correct.":"Not quite."}</b> It's ${esc(r.a.toLowerCase())}.</p><button class="btn qnext" data-wb="next">${s.i<9?"Next fact":"See score"}</button>`:""}</div>`;
  el.querySelectorAll("[data-wo]").forEach(x=>x.onclick=()=>{s.picked=x.dataset.wo;if(s.picked===r.a)s.score++;rerender()});const n=el.querySelector('[data-wb="next"]');if(n)n.onclick=()=>{s.i++;s.picked=null;rerender()}}
let memS=null,memT=null;
function gMemory(el){if(!memS){const pairs=shuffle(MEM_PAIRS).slice(0,8);memS={cards:shuffle(pairs.flatMap(([a,b],i)=>[{t:a,p:i,k:"clue"},{t:b,p:i,k:"branch"}])),open:[],got:new Set(),moves:0,start:null,lock:false}}const s=memS,done=s.got.size===8;
  if(done&&!s.best){const bs=store.get("fb-more-mem",null);s.best=bs;if(bs==null||s.moves<bs)store.set("fb-more-mem",s.moves);s.secs=Math.round((Date.now()-s.start)/1000)}
  el.innerHTML=`<h2>Memory</h2><p class="intro">Sixteen cards, eight pairs. Match each athlete or achievement to its branch in as few moves as you can.</p>
  <div class="tlhead"><div><b class="count">${s.moves}</b><span class="label">moves</span></div><div><b class="count">${s.got.size}/8</b><span class="label">pairs</span></div><div><b class="count">${store.get("fb-more-mem","–")}</b><span class="label">best</span></div></div>
  ${done?`<p class="msg good">All pairs found in ${s.moves} moves and ${s.secs} seconds.</p><div class="btns"><button class="btn" data-m="again">Play again</button></div>`:""}
  <div class="memgrid">${s.cards.map((c,i)=>{const up=s.open.includes(i)||s.got.has(c.p);return `<button class="mem ${up?"up":""} ${s.got.has(c.p)?"got":""} mk-${c.k}" data-mc="${i}" ${up?"disabled":""} aria-label="${up?esc(c.t):"Hidden card"}"><span>${up?esc(c.t):"FB"}</span></button>`}).join("")}</div>`;
  el.querySelectorAll("[data-mc]").forEach(x=>x.onclick=()=>{if(s.lock)return;const i=+x.dataset.mc;if(!s.start)s.start=Date.now();s.open.push(i);
    if(s.open.length===2){s.moves++;const [a,b]=s.open.map(k=>s.cards[k]);if(a.p===b.p&&a.k!==b.k){s.got.add(a.p);s.open=[]}else{s.lock=true;clearTimeout(memT);memT=setTimeout(()=>{s.open=[];s.lock=false;rerender()},900)}}rerender()});
  const ag=el.querySelector('[data-m="again"]');if(ag)ag.onclick=()=>{memS=null;rerender()}}

/* ---------- PLAY TAB ---------- */
const PLAY={
 football:[["quiz","Quiz","Seven questions"],["draft","XI Draft","Spin the wheel, build an XI, play a season"],["wordle","Fenerdle","Guess the player"],["xi","Name the XI","Every season since 2000"],["penalties","Penalties","Spin the wheel, win the shootout"],["who","Who Am I?","Ten mystery players"],["timeline","Timeline","Put history in order"]],
 basketball:[["quiz","Quiz","Seven questions"],["draft5","Starting Five","Draft a five, play a season"],["wordle","Fenerdle","Guess the player"],["lineup","Name the Lineup","Final Four box scores"],["ft","Free Throws","Ten shots under pressure"],["who","Who Am I?","Ten mystery players"],["timeline","Timeline","Titles, coaches, Final Fours"]],
 "womens-basketball":[["quiz","Quiz","Seven questions"],["draft5","Starting Five","Draft a five, play a season"],["wordle","Fenerdle","Guess the player"],["lineup","Name the Lineup","EuroLeague final box scores"],["ft","Free Throws","Ten shots under pressure"],["who","Who Am I?","Ten mystery players"],["timeline","Timeline","Twenty titles in order"]],
 volleyball:[["quiz","Quiz","Six questions"],["draft6","Starting Six","Draft a six, play a season"],["wordle","Fenerdle","Guess the player"],["squad","Name the Squad","Four famous squads"],["serve","Serve","Twelve serves, hunt for aces"],["who","Who Am I?","Ten mystery players"],["timeline","Timeline","1928 to today"]],
 more:[["quiz","Quiz","Six questions"],["which","Which Branch?","Match facts to departments"],["memory","Memory","Pair athletes and branches"],["timeline","Club Timeline","Every branch, 1907 to today"]]};
const XTRA=[["daily","Daily Mix","Five questions a day"],["hol","Higher or Lower","Club records head to head"],["gts","Guess the Score","Name the real result"],["board","Leaderboard","Fans' best scores"],["badges","Badges","Your achievements"]];
Object.keys(PLAY).forEach(k=>{PLAY[k].splice(1,0,XTRA[0]);PLAY[k].push(...XTRA.slice(1))});
const GAME_FN={daily:gDaily,hol:gHoL,gts:gGTS,board:gBoard,badges:gBadges,quiz:gQuiz,draft:p=>renderDraft(p),wordle:gWordle,xi:p=>renderXI(p),penalties:p=>renderPK(p),who:gWho,timeline:gTimeline,draft5:gTeamDraft,draft6:gTeamDraft,draft11:gTeamDraft,lineup:gLineup,squad:gLineup,ft:gFT,serve:gServe,which:gWhich,memory:gMemory};
const playSel=(()=>{try{return JSON.parse(localStorage.getItem("fb-playsel")||"{}")}catch(e){return {}}})();
function renderPlay(p){renderPlayRaw(p);runExt("play",p,playSel[current])}

function xAfterGame(g){const ga=document.getElementById("gameArea");if(!ga)return;const old=document.getElementById("shareRow");if(old)old.remove();
  const r=xResultFor(g);if(r&&XC.dl){const d=document.createElement("div");d.id="shareRow";d.className="btns";d.innerHTML=`<button class="btn ghost" id="shareBtn">${t("Save result image")}</button>`;ga.appendChild(d);d.querySelector("button").onclick=e=>xShare(r,e.currentTarget)}
  xBadgeCheck();xSyncScores()}
document.addEventListener("keydown",e=>{
  if(tab!=="play"||e.metaKey||e.ctrlKey||e.altKey)return;
  if(e.target.closest&&e.target.closest("input,select,textarea"))return;
  if(e.target.closest&&e.target.closest("button")&&(e.key===" "||e.key==="Enter"))return;
  const g=playSel[current];
  if(g==="wordle"){if(e.key==="Enter"){e.preventDefault();wordleKey("ENTER")}else if(e.key==="Backspace"){e.preventDefault();wordleKey("BACK")}else if(e.key.length===1){const c=norm(e.key).toUpperCase();if(/^[A-Z]$/.test(c))wordleKey(c)}return}
  if(e.key!==" "&&e.key!=="Enter")return;
  if(g==="penalties"&&current==="football"&&pk&&(pk.phase==="aimX"||pk.phase==="aimY")){e.preventDefault();pkLock()}
  if(g==="ft"&&ftS[current]&&ftS[current].phase==="aim"){e.preventDefault();ftShoot()}
  if(g==="serve"&&svS.v&&(svS.v.phase==="aimX"||svS.v.phase==="aimD")){e.preventDefault();svLock()}
});
let rzT;window.addEventListener("resize",()=>{clearTimeout(rzT);rzT=setTimeout(()=>{const g=playSel[current];if(tab==="play"&&(g==="wordle"||(g==="penalties"&&pk&&pk.phase==="setup"&&!pk.spinning)))renderPanel()},200)});
