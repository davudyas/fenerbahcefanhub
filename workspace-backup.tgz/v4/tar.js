const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();
for(const [w,h,tag] of [[1280,900,'d'],[390,844,'m']]){const pg=await b.newPage({viewport:{width:w,height:h}});const errs=[];pg.on('pageerror',e=>errs.push(e.message));
await pg.goto('file://'+process.cwd()+'/fenerbahce.html');await pg.waitForTimeout(300);await pg.selectOption('#lang','ar');await pg.waitForTimeout(200);
await pg.screenshot({path:`../a_${tag}_home.png`,fullPage:true});
await pg.evaluate(()=>{setSport('basketball');tab='trophies';render()});await pg.waitForTimeout(150);await pg.locator('#panel').screenshot({path:`../a_${tag}_tro.png`});
await pg.evaluate(()=>{tab='legends';render()});await pg.click('.legend2 .lname');await pg.waitForTimeout(150);await pg.screenshot({path:`../a_${tag}_pp.png`});
await pg.keyboard.press('Escape');await pg.keyboard.press('/');await pg.waitForTimeout(100);await pg.keyboard.type('obradovic');await pg.waitForTimeout(300);await pg.screenshot({path:`../a_${tag}_s.png`});
console.log(tag,errs,await pg.evaluate(()=>document.documentElement.scrollWidth));await pg.close()}
await b.close()})();
