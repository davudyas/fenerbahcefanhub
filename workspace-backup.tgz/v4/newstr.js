const {chromium}=require('playwright');const fs=require('fs');
(async()=>{const b=await chromium.launch();const pg=await b.newPage();await pg.goto('file://'+process.cwd()+'/fenerbahce.html');await pg.waitForTimeout(400);
const r=await pg.evaluate(()=>{const out=new Set(),skipK=new Set(["date","home","away","res","out","where_"]);
 const NAMES=new Set();Object.values(BPEOPLE).forEach(M=>Object.keys(M).forEach(n=>NAMES.add(n)));
 const add=s=>{if(typeof s!=="string")return;s=s.trim();if(!s||!/[A-Za-z]{2}/.test(s)||NAMES.has(s)||/^https?:/.test(s))return;out.add(s)};
 const walk=(x,k)=>{if(x==null)return;if(typeof x==="string"){if(!skipK.has(k))add(x);return}if(Array.isArray(x)){x.forEach(v=>walk(v,k));return}if(typeof x==="object")Object.entries(x).forEach(([kk,v])=>walk(v,kk))};
 ["womens-football","mens-volleyball"].forEach(id=>{walk(SPORTS[id]);walk(SQUADS[id]);walk(VENUES[id]);walk(LIVE[id]);walk(LUCFG[id]);walk({t:TLCFG[id].intro});walk(PLAY[id])});
 walk(WF_EVENTS);walk(MV_EVENTS);walk(SPORTS.football.trophies);walk(SPORTS.football.history);walk(SPORTS.football.quiz);walk(SPORTS.football.stats);walk(SPORTS.volleyball.label);
 ["goals Fenerbahçe scored in that game","Balkan Cups","CEV Challenge Cups","Turkish league titles","Turkish Cups","Turkish Super Cups","Next match","Someone else…","Player name","Goalkeepers","Women's Volleyball","Squads come from the club's squad lists and match reports.",
  "Ask Kanarya","Fan helper","Close","Ask a question…","Your question","Send","Stop","Answers come from Claude and use your own Claude usage. They can be wrong.","Hi! I'm Kanarya. Ask me anything about Fenerbahçe: matches, titles, legends or how this site works.","Thinking…",
  "When is the next match?","How many titles does this branch have?","Who are the legends here?","Something went wrong. Try again.","The helper can't answer in this view.","Too many questions right now. Try again in a little while.","Please sign in to Claude again.",
  "Jamaica","Moldova","Azerbaijan","Panama","Czech Republic","Nigeria","Setters","Outside hitters","Opposites","Middle blockers","Liberos","TBC"].forEach(add);
 Object.values(SPECIAL_B).forEach(add);
 const miss={};["tr","de","es","fr","ar"].forEach(L=>{LANG=L;TCACHE.clear();miss[L]=[...out].filter(s=>trText(s)==null)});LANG="en";return {all:[...out],miss}});
const u=[...new Set(Object.values(r.miss).flat())];fs.writeFileSync('../new_miss.json',JSON.stringify(u,null,1));console.log(r.all.length,u.length);Object.entries(r.miss).forEach(([k,v])=>console.log(k,v.length));
u.forEach((s,i)=>console.log(i+"\t"+s));await b.close()})();
