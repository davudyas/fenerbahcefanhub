const {chromium}=require('playwright');const path=require('path');
(async()=>{const b=await chromium.launch();const L=process.argv[2]||'it';const pg=await b.newPage({viewport:{width:1100,height:800}});const errs=[];pg.on('pageerror',e=>errs.push(e.message));
await pg.route('**/*',r=>r.request().url().startsWith('file:')?r.continue():r.abort());
await pg.goto('file://'+path.resolve(__dirname,'../site/index.html')+'#all');await pg.waitForTimeout(800);
await pg.evaluate(L=>{$('lang').value=L;$('lang').dispatchEvent(new Event('change'))},L);await pg.waitForTimeout(1500);
console.log(L,'lang/dir',await pg.evaluate(()=>document.documentElement.lang+' '+document.documentElement.dir));
console.log('samples:',await pg.evaluate(()=>[t("Matches"),t("Week 7"),t("After week 6 · 2 points for a win, 1 for a loss"),tf("In {n} days",{n:3}),t("League phase, matchday 4"),t("Fenerbahçe have two games in hand"),t("Pool phase starts on 24 November."),t("Göztepe v Kocaelispor still to play")].join(' | ')));
// untranslated English visible on several pages
const pages=['all','football-matches','football-standings','basketball-play','volleyball-history','more','football-legends'];const left={};
for(const h of pages){await pg.evaluate(h=>{location.hash=h},h);await pg.waitForTimeout(700);
 const en=await pg.evaluate(()=>{const out=[];const w=document.createTreeWalker(document.querySelector('main')||document.body,NodeFilter.SHOW_TEXT);let n;while(n=w.nextNode()){const s=n.textContent.trim();if(s.length>12&&/^[A-Z][a-z]+( [a-z]+){2,}/.test(s)&&!n.parentElement.closest('script,style'))out.push(s.slice(0,70))}return out.slice(0,6)});left[h]=en}
console.log('english-looking text left:',JSON.stringify(left,null,0).slice(0,1500));
await pg.evaluate(()=>{location.hash='all'});await pg.waitForTimeout(600);await pg.screenshot({path:path.resolve(__dirname,'../xl_'+L+'.png')});console.log('errs',errs);await b.close()})();
