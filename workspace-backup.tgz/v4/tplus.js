const gzAuto=require('./gzauto.js');
const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();
for(const [w,h,tag] of [[1280,900,'d'],[390,844,'m']]){
const pg=await b.newPage({viewport:{width:w,height:h}});const errs=[];pg.on('pageerror',e=>errs.push(e.message+' '+(e.stack||'').split('\n')[1]));pg.on('console',m=>{if(m.type()==='error'&&!m.text().includes('ERR_'))errs.push(m.text())});
await pg.addInitScript(()=>{const DB={challenges:{u2:{c:{}}},seasons:{u2:{b:{football:{t:3,pos:1,s:"2010-11",r:84,c:0,ts:1}}}},predictions:{u2:{p:{"football|2026-11-04|Liverpool":[3,2],"football|2026-10-31|Göztepe":[2,0]}}},ratings:{u2:{r:{"football|2026-11-04|Liverpool":{"Vedat Muriqi":9}}}},motm:{},scores:{}},subs={};window.__saved=[];
 const db={collection:c=>({onSnapshot:cb=>{(subs[c]=subs[c]||[]).push(cb);setTimeout(()=>cb({docs:Object.entries(DB[c]||{}).map(([id,d])=>({id,exists:true,data:()=>d}))}),50);return ()=>{}}}),doc:p=>({set:async d=>{const [c,id]=p.split('/');DB[c]=DB[c]||{};DB[c][id]=d;(subs[c]||[]).forEach(cb=>cb({docs:Object.entries(DB[c]).map(([id,d])=>({id,exists:true,data:()=>d}))}))}})};
 const user={id:async()=>"u1",profiles:async ids=>Object.fromEntries(ids.map(i=>[i,{name:i==="u2"?"Ayşe":"Me"}]))};
 const dl={save:async o=>{window.__saved.push([o.filename,typeof o.data==='string'?o.data.slice(0,400):'blob']);return {status:"saved"}}};
 window.claude={use:async n=>n==="db"?db:n==="user"?user:n==="downloads"?dl:null}});
const go=async(br,tb)=>{await pg.evaluate(([br,tb])=>{setSport(br);if(tb){tab=tb;render()}},[br,tb]);await pg.waitForTimeout(150)};
const shot=async n=>{await pg.screenshot({path:`../p_${tag}_${n}.png`})};const shotEl=async(sel,n)=>{await pg.locator(sel).first().screenshot({path:`../p_${tag}_${n}.png`})};
await pg.goto('file://'+process.cwd()+'/fenerbahce.html');await pg.waitForTimeout(600);
console.log(tag,'num visible',await pg.evaluate(()=>getComputedStyle(document.getElementById('kitNum')).display));
await shotEl('#leagueBox','league');
// predict via league
await pg.evaluate(()=>{const ins=[...document.querySelectorAll('[data-lgk]')].slice(0,2);ins[0].value=2;ins[1].value=1});await pg.click('#lgSave');await pg.waitForTimeout(200);
console.log(tag,'league msg',await pg.evaluate(()=>[$("lgMsg")&&$("lgMsg").textContent,document.querySelectorAll('#leagueBox .ptable li').length]));
await pg.click('[data-hm=upcoming]');await pg.click('[data-calcsv="all"]');await pg.click('[data-hm=results]');await pg.waitForTimeout(150);
// home result click -> match page
await pg.evaluate(()=>document.querySelector('#hmList .mclick').click());await pg.waitForTimeout(150);await shot('mp_home');await pg.keyboard.press('Escape');
await go('football','matches');await pg.waitForTimeout(200);
await pg.click('.mrow.mclick');await pg.waitForTimeout(150);await shot('mp');
console.log(tag,'mp',await pg.evaluate(()=>document.querySelector('.mp')&&document.querySelector('.mp').innerText.slice(0,300).replace(/\n/g,' | ')));
await pg.click('[data-mpgo]');await pg.waitForTimeout(100);await pg.keyboard.press('Escape');
await pg.click('[data-calcsv="football"]');await pg.waitForTimeout(150);
// ratings
await pg.evaluate(()=>{const s=[...document.querySelectorAll('[data-rate]')].slice(0,3);s.forEach((x,i)=>x.value=String(7+i))});await pg.click('#rSave');await pg.waitForTimeout(200);
await shotEl('.ratecard','rate');
await go('football','records');await shotEl('#panel','rec');
await go('football','europe');await shotEl('#panel','eu');
await pg.fill('#euQ','manchester');await pg.waitForTimeout(400);console.log(tag,'eu search',await pg.evaluate(()=>[document.querySelectorAll('.eut tbody tr').length,(document.querySelector('#panel .msg')||{}).textContent]));
for(const br of ['basketball','womens-basketball','volleyball','mens-volleyball','womens-football']){await go(br,'records');}
await shotEl('#panel','rec_wf');
// challenge flow football
await go('football','play');await pg.evaluate(()=>{playSel.football='draft';render()});await pg.waitForTimeout(150);
await pg.click('[data-ch="new"]');await pg.waitForTimeout(150);const code=await pg.evaluate(()=>CH&&CH.code);

await gzAuto(pg);const offers1=await pg.evaluate(()=>dr.form+'|'+dr.spun.join(','));await pg.waitForTimeout(100);
await pg.click('[data-sz="start"]');await pg.click('[data-sz="all"]');await pg.waitForTimeout(200);
const res1=await pg.evaluate(()=>document.querySelector('.szsum').innerText.replace(/\n/g,' | '));
await shot('chdone');
// replay same code: same offers and same result
await pg.click('[data-ch="leave"]');await pg.waitForTimeout(100);await pg.fill('#chIn',code.toLowerCase());await pg.click('[data-ch="join"]');await pg.waitForTimeout(150);

await gzAuto(pg);const offers2=await pg.evaluate(()=>dr.form+'|'+dr.spun.join(','));await pg.waitForTimeout(100);
await pg.click('[data-sz="start"]');await pg.click('[data-sz="all"]');await pg.waitForTimeout(200);
const res2=await pg.evaluate(()=>document.querySelector('.szsum').innerText.replace(/\n/g,' | '));
console.log(tag,'challenge',code,'same offers',offers1===offers2,'same result',res1===res2,'|',res1.slice(0,120));
console.log(tag,'chbox',await pg.evaluate(()=>document.getElementById('chBox').innerText.replace(/\n/g,' | ').slice(0,200)));
await shotEl('#chBox','chbox');
// career: leave challenge, new season then career
await pg.click('[data-ch="leave"]');await pg.waitForTimeout(100);
await gzAuto(pg);await pg.waitForTimeout(100);
await pg.click('[data-szy="2015-16"]');await pg.click('[data-sz="start"]');await pg.click('[data-sz="all"]');await pg.waitForTimeout(150);
await pg.click('[data-cr="start"]');await pg.waitForTimeout(150);await shotEl('#szArea','off');
await pg.click('[data-cro="0"]');await pg.waitForTimeout(100);await pg.click('[data-cr="go"]');await pg.waitForTimeout(100);await pg.click('[data-sz="all"]');await pg.waitForTimeout(150);
console.log(tag,'career',await pg.evaluate(()=>document.querySelector('.szextra').innerText.replace(/\n/g,' | ').slice(0,300)));
await pg.click('[data-cr="off"]');await pg.waitForTimeout(100);await pg.click('[data-cro="keep"]');await pg.click('[data-cr="go"]');await pg.waitForTimeout(100);await pg.click('[data-sz="five"]');await pg.waitForTimeout(100);
await pg.click('[data-cr="quit"]');await pg.waitForTimeout(100);
await pg.click('[data-sz="start"]');await pg.click('[data-sz="all"]');await pg.waitForTimeout(150);await pg.click('[data-cr="img"]');await pg.waitForTimeout(400);
// team draft branch challenge
await go('volleyball','play');await pg.evaluate(()=>{playSel.volleyball='draft6';render()});await pg.waitForTimeout(100);await pg.click('[data-ch="new"]');let n=0;while(await pg.$('[data-tc="0"]')&&n<20){await pg.click('[data-tc="0"]');n++}
await pg.click('[data-sz="start"]');await pg.click('[data-sz="all"]');await pg.waitForTimeout(150);console.log(tag,'vb ch',await pg.evaluate(()=>document.querySelector('.szsum').innerText.split('\n')[1]));
// search
await pg.keyboard.press('/');await pg.keyboard.type('benfica');await pg.waitForTimeout(300);console.log(tag,'search',await pg.evaluate(()=>[...document.querySelectorAll('#sres b')].slice(0,5).map(x=>x.textContent)));
await pg.evaluate(()=>{const x=[...document.querySelectorAll('#sres [data-sr]')].find(b=>/In Europe/.test(b.textContent));x&&x.click()});await pg.waitForTimeout(300);console.log(tag,'after',await pg.evaluate(()=>[current,tab,euQ,document.querySelectorAll('.eut tbody tr').length]));
console.log(tag,'saved',JSON.stringify(await pg.evaluate(()=>window.__saved.map(x=>[x[0],x[1].slice(0,160)]))));
console.log(tag,'errs',errs,'sw',await pg.evaluate(()=>document.documentElement.scrollWidth));await pg.close()}
await b.close()})();
