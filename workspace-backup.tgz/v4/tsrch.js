const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const pg=await b.newPage();const errs=[];pg.on('pageerror',e=>errs.push(e.message));
await pg.goto('file://'+process.cwd()+'/fenerbahce.html#football');await pg.waitForTimeout(400);
await pg.click('#hSearch');await pg.fill('#sq','benfica');await pg.waitForTimeout(300);console.log(await pg.evaluate(()=>[...document.querySelectorAll('#sres b')].slice(0,5).map(x=>x.textContent)));
await pg.evaluate(()=>{const x=[...document.querySelectorAll('#sres [data-sr]')].find(b=>/In Europe/.test(b.textContent));x&&x.click()});await pg.waitForTimeout(300);console.log(await pg.evaluate(()=>[current,tab,euQ,document.querySelectorAll('.eut tbody tr').length]));
await pg.click('#hSearch');await pg.fill('#sq','records');await pg.waitForTimeout(300);console.log(await pg.evaluate(()=>[...document.querySelectorAll('#sres b')].slice(0,5).map(x=>x.textContent)));
console.log(errs);await b.close()})();
