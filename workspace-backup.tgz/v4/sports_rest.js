  basketball: {
    label:"Men's Basketball", tr:"Erkek Basketbol", title:"Basketball", num:"25",
    nick:"Fenerbahçe Tarfin",
    lede:"Two-time champions of Europe. Fenerbahçe won the EuroLeague at home in Istanbul in 2017 and again in Abu Dhabi in 2025, when they also completed Turkey's first Triple Crown. In 2025–26 they reached an eighth Final Four and won the league and cup at home.",
    stats:[["2","EuroLeague titles"],["8","Final Fours"],["16","Turkish league titles"],["10","Turkish Cups"]],
    home:["Home court","Ülker Sports and Event Hall, Ataşehir · 13,800 seats"],
    history:[
      ["1913","The basketball department opens","One of the oldest basketball sections in Turkey."],
      ["1991","Champions again","The first Turkish league title of the modern league era, ending a long wait."],
      ["2012","A win over an NBA team","On 5 October 2012 Fenerbahçe became the first Turkish club to beat an NBA side. The same year they moved into the Ülker Sports Arena."],
      ["2013","Obradović arrives","Željko Obradović, Europe's most decorated coach, takes over and builds a contender."],
      ["2016","First EuroLeague final","Fenerbahçe reach the final in Berlin and lose to CSKA Moscow in overtime."],
      ["2017","Champions of Europe","At the Final Four in Istanbul they beat Real Madrid, then Olympiacos 80–64. Ekpe Udoh is Final Four MVP."],
      ["2018","Back in the final","A second straight final, this time lost to Real Madrid in Belgrade."],
      ["2025","Second star and a Triple Crown","Under Šarūnas Jasikevičius they beat Panathinaikos and Monaco in Abu Dhabi, then add the league and cup: the first Triple Crown by a Turkish team."],
      ["2026","Eighth Final Four","A semi-final loss to Olympiacos in Athens, but the season still ends with the Turkish league title and the Turkish Cup."]
    ],
    games:[
      {date:"2017-05-21",comp:"EuroLeague Final",home:"Fenerbahçe",away:"Olympiacos",res:"80–64",out:"win",tag:"Final",note:"The first European title, won in front of a home crowd. Bogdanović and Kalinić scored 17 each.",where:"Sinan Erdem Dome, Istanbul"},
      {date:"2017-05-19",comp:"EuroLeague Semi-final",home:"Fenerbahçe",away:"Real Madrid",res:"84–75",out:"win",tag:"Final Four",note:"Ekpe Udoh scored 18 as Fenerbahçe beat the favourites.",where:"Sinan Erdem Dome, Istanbul"},
      {date:"2025-05-25",comp:"EuroLeague Final",home:"Fenerbahçe",away:"Monaco",res:"81–70",out:"win",tag:"Final",note:"Title number two. Nigel Hayes-Davis scored 23 and was named Final Four MVP.",where:"Etihad Arena, Abu Dhabi"},
      {date:"2025-05-23",comp:"EuroLeague Semi-final",home:"Fenerbahçe",away:"Panathinaikos",res:"82–76",out:"win",tag:"Final Four",note:"Devon Hall scored 18 to knock out the defending champions.",where:"Etihad Arena, Abu Dhabi"},
      {date:"2016-05-15",comp:"EuroLeague Final",home:"Fenerbahçe",away:"CSKA Moscow",res:"96–101",out:"loss",tag:"Final",note:"So close in their first final. It went to overtime before CSKA pulled away.",where:"Mercedes-Benz Arena, Berlin"},
      {date:"2018-05-20",comp:"EuroLeague Final",home:"Real Madrid",away:"Fenerbahçe",res:"85–80",out:"loss",tag:"Final",note:"Nicolò Melli scored 28 but Real Madrid held on in Belgrade.",where:"Štark Arena, Belgrade"}
    ],
    filters:["All","Final","Final Four"],
    legends:[
      ["Željko Obradović","Head coach · 2013–2020","Brought the first EuroLeague title and five straight Final Fours."],
      ["Šarūnas Jasikevičius","Head coach · 2023–","Coached the 2025 Triple Crown team."],
      ["Mirsad Türkcan","Power forward · 2006–2012","His number 6 was retired by the club in 2012."],
      ["Ömer Onan","Shooting guard · 2004–2014","His number 7 was retired in 2014."],
      ["Ekpe Udoh","Center · 2014–2017","Final Four MVP in 2017, a defensive anchor."],
      ["Bogdan Bogdanović","Guard · 2014–2017","Scoring guard of the 2017 team, later an NBA player."],
      ["Jan Veselý","Forward · 2014–2022","Started three straight EuroLeague finals."],
      ["Nigel Hayes-Davis","Forward · 2022–2025","Final Four MVP in 2025."]
    ],
    trophies:[
      ["2","EuroLeague","2017, 2025"],
      ["16","Turkish Super League","Most recently 2024, 2025 and 2026"],
      ["10","Turkish Cup","Most recently 2024, 2025 and 2026"],
      ["9","Presidential Cup","Most recently 2025 and 2026"],
      ["8","Final Four appearances","Most recent: Athens 2026"]
    ],
    quiz:[
      {q:"In which city did Fenerbahçe win their first EuroLeague?",o:["Berlin","Istanbul","Belgrade","Madrid"],a:1,e:"Istanbul, 2017, at a home Final Four."},
      {q:"Who did Fenerbahçe beat in the 2025 EuroLeague final?",o:["Real Madrid","Olympiacos","Monaco","Barcelona"],a:2,e:"Monaco, 81–70 in Abu Dhabi."},
      {q:"Who coached the 2025 title team?",o:["Željko Obradović","Ergin Ataman","Šarūnas Jasikevičius","Dimitris Itoudis"],a:2,e:"Šarūnas Jasikevičius."},
      {q:"Who was the 2017 Final Four MVP?",o:["Ekpe Udoh","Bogdan Bogdanović","Kostas Sloukas","Jan Veselý"],a:0,e:"Ekpe Udoh."},
      {q:"Whose number 6 shirt is retired by the club?",o:["Ömer Onan","Mirsad Türkcan","İbrahim Kutluay","Semih Erden"],a:1,e:"Mirsad Türkcan, retired in 2012. Ömer Onan's 7 followed in 2014."},
      {q:"Who scored 28 points for Fenerbahçe in the 2018 final?",o:["Nicolò Melli","Brad Wanamaker","Luigi Datome","Kostas Sloukas"],a:0,e:"Nicolò Melli, in an 85–80 loss to Real Madrid."},
      {q:"What did Fenerbahçe complete in 2024–25 that no Turkish team had done before?",o:["An unbeaten season","The Triple Crown","Three straight EuroLeagues","A win in the NBA"],a:1,e:"The Triple Crown: EuroLeague, Turkish league and Turkish Cup."}
    ]
  },

  "womens-basketball": {
    label:"Women's Basketball", tr:"Kadın Basketbol", title:"Women's Basketball", num:"26",
    nick:"Potanın Kraliçeleri — Queens of the Hoop",
    lede:"The most successful team in the club right now. Three EuroLeague Women titles since 2023, a record 20 Turkish league titles, and a 2025–26 season of 46 wins and one defeat in which they won every competition they entered.",
    stats:[["3","EuroLeague Women"],["20","Turkish league titles"],["2","Triple Crowns"],["15","Turkish Cups"]],
    home:["Home court","Metro Enerji Sports Hall, Istanbul"],
    history:[
      ["1954","The team is formed","Women's basketball becomes a permanent part of the club."],
      ["1999","First Super League title","The first of a record 20 Turkish Super League titles."],
      ["2005","A first European final","Runners-up in the EuroCup."],
      ["2013","First EuroLeague final","The first of four runner-up finishes before the breakthrough."],
      ["2019","Number 7 retired","Birsel Vardarlı, captain from 2012 to 2019, has her shirt retired."],
      ["2023","Champions of Europe","Breanna Stewart scores 35 in a 99–60 final win over ÇBK Mersin in Prague."],
      ["2024","Perfect season","35 wins from 35 league games, plus the EuroLeague (won in Mersin), the Turkish Cup and the SuperCup."],
      ["2026","Third star","An all-Turkish final against Galatasaray in Zaragoza, part of a 46–1 season and a clean sweep of every trophy."]
    ],
    games:[
      {date:"2023-04",comp:"EuroLeague Women Final",home:"Fenerbahçe",away:"ÇBK Mersin",res:"99–60",out:"win",tag:"Europe",note:"After four lost finals, Fenerbahçe finally lift the trophy. Breanna Stewart scored 35 and was MVP.",where:"Královka Arena, Prague"},
      {date:"2024-04",comp:"EuroLeague Women Final",title:"Back-to-back",out:"win",tag:"Europe",note:"Fenerbahçe beat Villeneuve d'Ascq in the final. Napheesa Collier scored 33 and Kayla McBride was MVP.",where:"Servet Tazegül Arena, Mersin"},
      {date:"2024",comp:"Turkish Super League",title:"35–0",out:"win",tag:"League",note:"A perfect league season: every one of 35 games won.",where:"Turkey"},
      {date:"2026-04-19",comp:"EuroLeague Women Final",title:"Number three",out:"win",tag:"Europe",note:"An all-Turkish final won against Galatasaray. Julie Allemand was Final Six MVP with 13 points, 8 rebounds and 10 assists.",where:"Pabellón Príncipe Felipe, Zaragoza"},
      {date:"2026",comp:"Turkish Super League",title:"27–0",out:"win",tag:"League",note:"Another unbeaten league season on the way to a 46–1 year.",where:"Turkey"}
    ],
    filters:["All","Europe","League"],
    legends:[
      ["Emma Meesseman","Forward · 2022–","Belgian star, EuroLeague Women MVP three years in a row (2023–2025) and one of the most decorated players in the competition."],
      ["Breanna Stewart","Forward · 2022–23, 2025–","Scored 35 in the 2023 final and came back for the third title."],
      ["Birsel Vardarlı","Point guard · 2006–2019","Captain from 2012 to 2019. Her number 7 is retired."],
      ["Kayla McBride","Guard · 2020–","MVP of the 2024 Final Four."],
      ["Julie Allemand","Point guard · 2024–","MVP of the 2026 Final Six."],
      ["Alperi Onar","Point guard · 2021–","Club captain since 2023."]
    ],
    trophies:[
      ["3","EuroLeague Women","2023, 2024, 2026"],
      ["20","Turkish Super League","1999 to 2026, a record"],
      ["15","Turkish Cup","Most recently 2024 and 2026"],
      ["3","FIBA Europe SuperCup Women","2023, 2024, 2026"],
      ["2","Triple Crowns","2024, 2026"]
    ],
    quiz:[
      {q:"When did Fenerbahçe win their first EuroLeague Women title?",o:["2013","2019","2023","2026"],a:2,e:"2023, after four lost finals."},
      {q:"What was the team's league record in 2023–24?",o:["33–2","35–0","30–5","34–1"],a:1,e:"35–0, a perfect season."},
      {q:"Who did Fenerbahçe beat in the 2026 final?",o:["Galatasaray","Valencia","ÇBK Mersin","Schio"],a:0,e:"Galatasaray, in an all-Turkish final in Zaragoza."},
      {q:"What does 'Potanın Kraliçeleri' mean?",o:["Yellow Angels","Queens of the Hoop","Lady Canaries","Kadıköy Stars"],a:1,e:"Queens of the Hoop."},
      {q:"How many points did Breanna Stewart score in the 2023 final?",o:["21","28","35","41"],a:2,e:"35, in a 99–60 win over ÇBK Mersin."},
      {q:"Whose number 7 is retired?",o:["Birsel Vardarlı","Olcay Çakır","Tuğçe Canıtez","Nevriye Yılmaz"],a:0,e:"Birsel Vardarlı, captain from 2012 to 2019."},
      {q:"Who was MVP of the 2026 Final Six?",o:["Emma Meesseman","Julie Allemand","Gabby Williams","Breanna Stewart"],a:1,e:"Julie Allemand, with 13 points, 8 rebounds and 10 assists in the final."}
    ]
  },

  volleyball: {
    label:"Volleyball", tr:"Voleybol", title:"Volleyball", num:"10",
    nick:"Sarı Melekler — the Yellow Angels",
    lede:"The first Turkish club to become world champions in an Olympic team sport. The women's team won the Club World Championship undefeated in 2010 and the CEV Champions League in 2012, and the men added a European cup of their own in 2014.",
    stats:[["1","Club World title"],["1","CEV Champions League"],["15","Turkish league titles"],["1928","Women's team founded"]],
    home:["Home court","Burhan Felek Sport Hall, Istanbul · 7,000 seats"],
    history:[
      ["1928","A pioneer starts the team","Sabiha Gürayman founds and captains the women's volleyball team. She later became Turkey's first female civil engineer."],
      ["1954","Back for good","The women's team is refounded with help from Çamlıca Girls' High School."],
      ["2010","World champions","Fenerbahçe win the FIVB Club World Championship in Doha without losing a match, beating Sollys Osasco 3–0 in the final."],
      ["2012","Champions of Europe","They beat RC Cannes in three straight sets in Baku. Kim Yeon-koung is MVP and top scorer."],
      ["2014","Two European cups in one day","The women win the CEV Cup and the men win the CEV Challenge Cup on the same day, a first for a Turkish club."],
      ["2024","A league and cup double","Fenerbahçe win the 2023–24 Turkish League and the Turkish Cup."]
    ],
    games:[
      {date:"2012-03-25",comp:"CEV Champions League Final",home:"Fenerbahçe",away:"RC Cannes",res:"3–0",out:"win",tag:"Women",note:"25–14, 25–22, 25–20. Kim Yeon-koung was MVP and Naz Aydemir best setter.",where:"Baku, Azerbaijan"},
      {date:"2012-03-24",comp:"CEV Champions League Semi-final",home:"Fenerbahçe",away:"Dinamo Kazan",res:"3–1",out:"win",tag:"Women",note:"Fenerbahçe lost the first set 17–25, then won the next three.",where:"Baku, Azerbaijan"},
      {date:"2014-03-29",comp:"CEV Cup Final",home:"Fenerbahçe",away:"Uralochka",res:"3–0",out:"win",tag:"Women",note:"25–11, 28–26, 25–22, in front of a home crowd.",where:"Istanbul"},
      {date:"2010-12",comp:"FIVB Club World Championship Final",home:"Fenerbahçe",away:"Sollys Osasco",res:"3–0",out:"win",tag:"Women",note:"World champions without dropping a match. Katarzyna Skowrońska was MVP.",where:"Doha, Qatar"},
      {date:"2014-03-29",comp:"CEV Challenge Cup",title:"Men's European title",out:"win",tag:"Men",note:"The men's team won its European trophy on the same day as the women's CEV Cup.",where:"Europe"}
    ],
    filters:["All","Women","Men"],
    legends:[
      ["Sabiha Gürayman","Founder · 1928","Founded the women's team, captained it, and later became Turkey's first female civil engineer."],
      ["Eda Erdem Dündar","Middle blocker · captain since 2014","In the 2010 world champion squad and still leading the team."],
      ["Kim Yeon-koung","Outside hitter · 2011–2017","MVP and top scorer of the 2012 Champions League Final Four."],
      ["Katarzyna Skowrońska","Opposite · 2010","MVP and top scorer of the 2010 Club World Championship."],
      ["Naz Aydemir","Setter","Best setter of the 2012 Champions League Final Four."],
      ["Melissa Vargas","Opposite · 2018–","Top scorer for Turkey's national team and MVP of a title-winning season."]
    ],
    trophies:[
      ["1","FIVB Club World Championship","2010"],
      ["1","CEV Champions League","2012"],
      ["1","CEV Cup (women)","2014"],
      ["15","Turkish League","7 in the current format: 2009, 2010, 2011, 2015, 2017, 2023, 2024"],
      ["5","Turkish Cup","2010, 2015, 2017, 2024, 2025"],
      ["1","CEV Challenge Cup (men)","2014"]
    ],
    quiz:[
      {q:"Who founded Fenerbahçe's women's volleyball team in 1928?",o:["Sabiha Gürayman","Halide Edib","Sabiha Gökçen","Eda Erdem"],a:0,e:"Sabiha Gürayman, later Turkey's first female civil engineer."},
      {q:"Who did Fenerbahçe beat in the 2010 Club World Championship final?",o:["VakıfBank","Sollys Osasco","Dinamo Kazan","Rabita Baku"],a:1,e:"Sollys Osasco of Brazil, 3–0 in Doha."},
      {q:"Who did they beat in the 2012 Champions League final?",o:["VakıfBank","Dynamo Moscow","RC Cannes","Imoco Conegliano"],a:2,e:"RC Cannes, 3–0."},
      {q:"Who was MVP of the 2012 Champions League Final Four?",o:["Logan Tom","Kim Yeon-koung","Eda Erdem","Fabiana Claudino"],a:1,e:"Kim Yeon-koung, who was also top scorer."},
      {q:"What is the volleyball team's nickname?",o:["Sarı Melekler","Sarı Kanaryalar","File Sultanları","Potanın Kraliçeleri"],a:0,e:"Sarı Melekler, the Yellow Angels."},
      {q:"Who has captained the team since 2014?",o:["Seda Tokatlıoğlu","Naz Aydemir","Eda Erdem Dündar","Çiğdem Can Rasna"],a:2,e:"Eda Erdem Dündar."}
    ]
  },

  more: {
    label:"Other Branches", tr:"Diğer Branşlar", title:"More Sports", num:"∞",
    nick:"One club, many sports",
    lede:"Fenerbahçe is a true multi-sport club, with European titles in six departments. Beyond football, basketball and volleyball it has world-class athletics, Turkey's most successful rowing and boxing sections, sailors, swimmers, table tennis, wheelchair basketball, women's football and esports.",
    stats:[["10+","Active branches"],["6","Branches with European titles"],["44","Turkish rowing titles"],["1907","Club founded"]],
    home:["Base","Kadıköy, Istanbul, with facilities across the city"],
    branches:[
      ["Athletics","Founded in 1913. Record 20 men's league titles and eight European Champion Clubs' Cups for the women. Ramil Guliyev won 200 m world gold in 2017."],
      ["Rowing","Founded in 1910. A record 44 Turkish championships. Tonguç Türsan's 1955 Mediterranean Games silver was Turkey's first international success in the sport."],
      ["Sailing","Founded in 1910. Won the 1917 Heybeliada races, Turkey's first official sailing competition. Tuğçe Subaşı became Laser 4.7 world champion in 2002."],
      ["Swimming","Founded in 1913, with a record 33 women's national championships."],
      ["Table Tennis","Founded in 1928. The women won the ETTU Cup in 2012 and 2013 and the European Champions League in 2015."],
      ["Boxing","Founded in 1914 and the most successful boxing section in Turkey, with nine world championship golds."],
      ["Wheelchair Basketball","European champions three times over: EuroCup 3 in 2019, EuroCup 2 in 2023 and EuroCup 1 in 2024."],
      ["Women's Football","Founded in 1995 and refounded in 2021. Turkish Super League champions in 2025–26."],
      ["Men's Volleyball","CEV Challenge Cup winners in 2014 and Balkan Cup winners in 2009 and 2013."],
      ["Esports","Founded in 2016, with three League of Legends Championship League titles."]
    ],
    quiz:[
      {q:"Which athlete won the 200 m world title in 2017 while at Fenerbahçe?",o:["Ramil Guliyev","Eşref Apak","Yasmani Copello","Ruhi Sarıalp"],a:0,e:"Ramil Guliyev. He added the European title in 2018."},
      {q:"How many Turkish rowing championships has Fenerbahçe won?",o:["12","25","44","60"],a:2,e:"44, a record."},
      {q:"In which year did the women's table tennis team win the European Champions League?",o:["2009","2015","2019","2023"],a:1,e:"2015, without losing a match."},
      {q:"Which branch won EuroCup 1 in 2024?",o:["Men's volleyball","Wheelchair basketball","Women's football","Swimming"],a:1,e:"Wheelchair basketball, after EuroCup 3 in 2019 and EuroCup 2 in 2023."},
      {q:"What did the sailing branch win in 1917?",o:["The Heybeliada races","An Olympic medal","The Bosphorus Cup","A world title"],a:0,e:"The Heybeliada races, Turkey's first official sailing competition."},
      {q:"Who designed the club badge in 1910?",o:["Ziya Songülen","Hikmet Topuzer","Necip Okaner","Ayetullah Bey"],a:1,e:"Hikmet Topuzer. The design has kept its core ever since."}
    ]
  }
};
