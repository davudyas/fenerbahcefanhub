const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844}});const pg=await ctx.newPage();const cdp=await ctx.newCDPSession(pg);await cdp.send('Emulation.setCPUThrottlingRate',{rate:4});
await cdp.send('Profiler.enable');await cdp.send('Profiler.setSamplingInterval',{interval:100});await cdp.send('Profiler.start');
await pg.goto('file://'+process.cwd()+'/'+(process.argv[2]||'fenerbahce.html')+'#all');await pg.waitForTimeout(400);
const {profile}=await cdp.send('Profiler.stop');const self={},byId={};profile.nodes.forEach(n=>byId[n.id]=n);const dt={};profile.samples.forEach((s,i)=>{dt[s]=(dt[s]||0)+(profile.timeDeltas[i]||0)});
profile.nodes.forEach(n=>{const k=(n.callFrame.functionName||'(anon)')+(n.callFrame.url?'':'');self[k]=(self[k]||0)+(dt[n.id]||0)/1000});
// inclusive time
const incl={};const kids=n=>(n.children||[]).map(c=>byId[c]);const tot=n=>{let s=(dt[n.id]||0)/1000;kids(n).forEach(c=>s+=tot(c));return s};
profile.nodes.forEach(n=>{const k=n.callFrame.functionName||'(anon)';incl[k]=Math.max(incl[k]||0,tot(n))});
console.log('SELF',Object.entries(self).sort((a,c)=>c[1]-a[1]).slice(0,18).map(([k,v])=>k+' '+v.toFixed(0)).join(' | '));
console.log('INCL',Object.entries(incl).sort((a,c)=>c[1]-a[1]).slice(0,30).map(([k,v])=>k+' '+v.toFixed(0)).join(' | '));
await b.close()})();
