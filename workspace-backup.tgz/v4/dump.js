// load page JS in node with a fake DOM-less env to dump strings needing translation
const fs=require('fs');const html=fs.readFileSync('fenerbahce.html','utf8');const js=html.slice(html.indexOf('<script>')+8,html.lastIndexOf('</script>'));
const cut=js.indexOf('\nWP_FB=wPool(PEOPLE);');const body=js.slice(0,cut);
const stub=`var document={getElementById:()=>({addEventListener(){},setAttribute(){},style:{},options:[],querySelectorAll:()=>[]}),addEventListener(){},querySelectorAll:()=>[],documentElement:{dataset:{}}};var window={addEventListener(){},innerWidth:1200};var localStorage={getItem:()=>null,setItem(){}};var navigator={language:'en'};var matchMedia=()=>({matches:false});var requestAnimationFrame=()=>0;var getComputedStyle=()=>({getPropertyValue:()=>''});var performance={now:()=>0};var MutationObserver=function(){this.observe=()=>{};this.disconnect=()=>{};this.takeRecords=()=>{}};`;
const out=new Function(stub+body+`;buildI18n();return {tr:DICT.tr,de:DICT.de,SPORTS,LEG_ADD,HIST_ADD,TROPHY_PRE,LEG_FACTS,HOL_BY,MB_LINEUPS,WB_LINEUPS}`)();
const keys=new Set();
const walk=(o)=>{if(typeof o==='string'){if(/[A-Za-z]{3}/.test(o))keys.add(o);return}if(Array.isArray(o))o.forEach(walk);else if(o&&typeof o==='object')Object.values(o).forEach(walk)};
walk(out.LEG_ADD.football.map(l=>[l[1],l[2],l[3]]));['basketball','womens-basketball','volleyball','more'].forEach(b=>walk(out.LEG_ADD[b].map(l=>[l[1],l[2],l[3]])));
walk(out.HIST_ADD);walk(out.TROPHY_PRE.map(x=>[x[1]]));walk(Object.values(out.LEG_FACTS));
Object.values(out.HOL_BY).forEach(f=>f().forEach(s=>{keys.add(s.label);if(!s.year&&s.key!=="pts")s.items.forEach(i=>keys.add(i[0]))}));
['Before the Süper Lig (1959)','The club counts 28 national championships: 19 Süper Lig titles, 6 National Division titles and 3 Turkish Football Championships.','National titles counted by the club','Did the second event happen later than the first? Higher means a later year.','Later','Earlier','Points','Years','Points come from the box scores in Name the Lineup.','Years and titles as shown on this site.','No results with scores yet for this branch.','Eight real Fenerbahçe results with the score hidden. The right winner earns 1 point, and 3 if both scores are within 5 points.','Real Fenerbahçe results with the score in sets hidden. 3 points for the exact score, 1 for the right winner.','Design','Kadıköy Night','Matchday','Canary','1907 Retro','Floodlights','Titles','Goals'].forEach(k=>keys.add(k));
const miss=[...keys].filter(k=>out.tr[k]==null);
fs.writeFileSync('../miss2.json',JSON.stringify(miss,null,0));console.log(miss.length);
// full catalog for new languages: everything TR translates
const cat=[...new Set(Object.keys(out.tr).concat(Object.keys(out.de)))].filter(k=>/[A-Za-z]/.test(k));fs.writeFileSync('../catalog.json',JSON.stringify(cat));console.log('catalog',cat.length,cat.join('').length);
