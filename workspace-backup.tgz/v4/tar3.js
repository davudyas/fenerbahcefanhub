const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const errs=[];
for(const [w,tag] of [[390,'m'],[1280,'d']]){const ctx=await b.newContext({viewport:{width:w,height:w<500?844:900}});const pg=await ctx.newPage();pg.on('pageerror',e=>errs.push(e.message));
await pg.goto('file://'+process.cwd()+'/fenerbahce.html#all');await pg.waitForTimeout(500);await pg.addStyleTag({content:'html{scroll-behavior:auto!important}'});
await pg.evaluate(()=>setLang('ar'));await pg.waitForTimeout(800);
await pg.evaluate(()=>startTour());await pg.waitForTimeout(300);await pg.click('[data-tr=next]');await pg.waitForTimeout(300);await pg.screenshot({path:`../ar_${tag}_tour.png`});await pg.keyboard.press('Escape');
await pg.click('#setBtn');await pg.waitForTimeout(200);await pg.evaluate(()=>scrollTo(0,0));await pg.screenshot({path:`../ar_${tag}_set.png`});await pg.keyboard.press('Escape');
await pg.evaluate(()=>{setSport('volleyball');tab='play';render()});await pg.waitForTimeout(300);await pg.evaluate(()=>{document.querySelector('.playnav').scrollIntoView();scrollBy(0,-80)});await pg.screenshot({path:`../ar_${tag}_play.png`});
await ctx.close()}console.log(errs);await b.close()})();
