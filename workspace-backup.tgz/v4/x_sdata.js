/* ===== Season data for Season mode, 2000–01 onwards =====
   lg: league rivals [name, strength]; cup: domestic cup; sup: Super Cup opponent; eu: European entry stage; real: what the real team did.
   European entry points for football follow the club's actual route; other branches use the usual qualification rules.
   Rival line-ups and strengths are estimates made for this game. */
const SZ_POOLS={
 football:[["Galatasaray",83],["Beşiktaş",81],["Trabzonspor",80],["Başakşehir",78,2007],["Bursaspor",77,2006,2018],["Kayserispor",75,2004],["Sivasspor",75,2005],["Konyaspor",74,2003],["Antalyaspor",73],["Kasımpaşa",73,2007],["Gaziantepspor",74,2000,2016],["Gaziantep FK",72,2019],["Gençlerbirliği",74,2000,2018],["Ankaragücü",72,2000,2011],["Denizlispor",72,2000,2009],["Samsunspor",73],["Rizespor",72,2008],["Malatyaspor",72,2000,2005],["Yeni Malatyaspor",72,2017,2021],["Kocaelispor",72,2000,2008],["Göztepe",74,2017],["Alanyaspor",75,2016],["Eskişehirspor",74,2008,2015],["Manisaspor",71,2005,2012],["Sakaryaspor",71,2000,2006],["İstanbulspor",71,2000,2004],["Eyüpspor",73,2024],["Hatayspor",72,2020,2024],["Adana Demirspor",75,2021,2024],["Karagümrük",73,2020,2025],["Akhisarspor",72,2012,2018],["Mersin İdmanyurdu",71,2011,2015],["Diyarbakırspor",70,2000,2009],["Kocaelispor 2025",72,2025]],
 basketball:[["Anadolu Efes",86],["Galatasaray",80],["Beşiktaş",79],["Türk Telekom",76],["Darüşşafaka",77,2014],["Karşıyaka",78],["Tofaş",77],["Bahçeşehir Koleji",79,2018],["Bursaspor",75,2014],["Manisa",75,2021],["Aliağa Petkimspor",75,2014],["Büyükçekmece",73,2015,2022],["Trabzonspor",74,2011,2018],["Mersin",73,2009],["Merkezefendi",73,2019],["Banvit",76,2005,2018],["Bandırma",74,2019],["Gaziantep",73,2013,2022],["Ülker",80,2000,2005],["Erdemir",72,2000,2014],["Oyak Renault",72,2000,2010],["Tüyap",72,2000,2008],["Esenler",73,2025],["Antalya",72,2000,2013],["Kepez",70,2006,2012]],
 "womens-basketball":[["Galatasaray",83],["ÇBK Mersin",83,2018],["Beşiktaş",78],["Botaş",74],["Hatay BB",77,2011,2020],["Bellona Kayseri",75,2008],["Nesibe Aydın",75,2016],["Emlak Konut",75,2018],["İzmit Belediyespor",72,2017,2023],["Mersin BB",74,2008,2017],["Abdullah Gül Üniversitesi",73,2016],["Ormanspor",70,2012,2018],["Kayseri Kaski",74,2010,2016],["Tarsus",70,2014,2018],["Edremit",70,2023],["Danilos Pizza",71,2023],["Migrosspor",72,2000,2008],["Ceyhan",71,2000,2010],["İstanbul Üniversitesi",72,2000,2012],["Burhaniye",70,2005,2014],["Melikgazi",72,2023],["Bursa",71,2020]],
 volleyball:[["VakıfBank",88],["Eczacıbaşı",87],["Galatasaray",80],["Türk Hava Yolları",81,2014],["Beşiktaş",75],["Nilüfer",76],["Aras Kargo",76,2018],["Kuzeyboru",74,2021],["Zeren Spor",73,2022],["İlbank",73],["Karayolları",72],["Bursa BBSK",74,2009,2021],["Manisa BB",74,2018],["Göztepe",74,2022],["Sarıyer",74,2015,2020],["Yeşilyurt",74,2009,2018],["Çanakkale",72,2016,2020],["Seramiksan",70,2015,2018],["PTT",73,2014,2021],["İdmanocağı",71,2009,2014],["Afyon",72,2023],["Türk Telekom",74,2000,2013],["Karşıyaka",72,2005,2015],["Erdemir",72,2000,2011]],
 "mens-volleyball":[["Halkbank",82],["Ziraat Bankkart",82,2012],["Arkas Spor",78],["Galatasaray",78],["İstanbul BBSK",74,2006],["Afyon",74,2018],["Maliye Milli Piyango",75,2006],["Spor Toto",75],["Alanya Belediyespor",76,2016],["Cizre",74,2020,2025],["Gebze Belediyespor",76,2021],["Altekma",74,2018],["Sorgun",72,2016,2021],["Akkuş",72,2015,2023],["Bursa BBSK",74,2013,2019],["Erdemir",73,2000,2014],["Tokat",72,2010,2019],["Jeopark Kula",72,2014,2019],["İnegöl",72,2014,2019],["Sungurlu",71,2023],["Sultanbeyli",70,2024],["Gaziantep Gençlik",72,2024],["Netaş",72,2000,2010],["Emlak Toki",71,2000,2012],["Ankara PTT",71,2000,2012]],
 "womens-football":[["Galatasaray",79],["Beşiktaş",76],["Ankara BB Fomget",78],["Trabzonspor",74],["Hakkarigücü",72],["Yüksekova",72,2023],["Kayseri",69],["Sultanbeyli Gücü",70,2024],["Amed",74],["Ünye",70],["Antalyaspor",70,2023],["Haymana",70,2024],["Bakırköy",68],["Şile Bilgidoğa",64,2025],["Giresun Sanayispor",62,2025],["ALG Spor",77,2021,2022],["Beylerbeyi",70,2021,2023],["Konak Belediyespor",72,2021,2022],["Kireçburnu",68,2021,2023],["Fatih Vatan",70,2021,2023],["Dudullu",68,2021,2023],["Altay",68,2021,2022]]};
const SZ_SIZE={football:17,basketball:15,"womens-basketball":13,volleyball:13,"mens-volleyball":13,"womens-football":15};
const SZ_FIRST={football:2000,basketball:2000,"womens-basketball":2000,volleyball:2000,"mens-volleyball":2000,"womens-football":2021};
/* titles by the calendar year the season ended */
const SZ_HIST={
 basketball:{t:[2007,2008,2010,2011,2014,2016,2017,2018,2022,2024,2025,2026],c:[2010,2011,2013,2016,2019,2020,2024,2025,2026]},
 "womens-basketball":{t:[1999,2002,2004,2006,2007,2008,2009,2010,2011,2012,2013,2016,2018,2019,2021,2022,2023,2024,2025,2026],c:[2000,2001,2004,2005,2006,2007,2008,2009,2015,2016,2019,2020,2024,2026]},
 volleyball:{t:[2009,2010,2011,2015,2017,2023,2024],c:[2010,2015,2017,2024,2025]},
 "mens-volleyball":{t:[2008,2010,2011,2012,2019],c:[2008,2012,2017,2019,2025],p2:[2004,2006,2009,2014,2021,2024],p3:[2007,2017,2022,2023,2025]},
 "womens-football":{t:[2026],p2:[2023,2025],p3:[2024]}};
/* football: the club's real European route and Super Cups */
const SZ_EU_FB={2001:"CL-Q3",2002:"CL-Q3",2004:"CL-G",2005:"CL-G",2006:"CL-Q2",2007:"CL-Q3",2008:"CL-Q2",2009:"EL-Q3",2010:"CL-Q3",2012:"CL-Q3",2013:"CL-Q3",2015:"CL-Q3",2016:"CL-Q3",2017:"EL-Q3",2018:"CL-Q3",2021:"EL-PO",2022:"CL-Q2",2023:"ECL-Q2",2024:"CL-Q2",2025:"CL-Q3",2026:"CL-Q2"};
const SZ_GROUPS_FB={2001:["Barcelona","Bayer Leverkusen","Lyon"],2004:["Manchester United","Lyon","Sparta Prague"],2007:["Inter","PSV","CSKA Moscow"]};
const SZ_SUP_FB={2007:"Beşiktaş",2009:"Beşiktaş",2012:"Galatasaray",2013:"Galatasaray",2014:"Galatasaray",2023:"Galatasaray",2025:"Galatasaray"};
function szRng(seed){let a=seed>>>0;return ()=>{a=(a+0x6D2B79F5)>>>0;let t=Math.imul(a^(a>>>15),1|a);t=(t+Math.imul(t^(t>>>7),61|t))^t;return ((t^(t>>>14))>>>0)/4294967296}}
function szRivals(b,y){const P=SZ_POOLS[b].filter(x=>(x[2]==null||y>=x[2])&&(x[3]==null||y<=x[3])).map(x=>[x[0].replace(/ 2025$/,""),x[1]]),seen=new Set(),U=P.filter(x=>!seen.has(x[0])&&seen.add(x[0]));
  const big=U.slice(0,b==="football"?3:2),rest=U.slice(big.length),r=szRng(y*31+b.length*7);rest.sort(()=>r()-.5);
  return big.concat(rest.slice(0,SZ_SIZE[b]-big.length)).sort((a,c)=>c[1]-a[1])}
const SZ_DATA=(()=>{const D={};Object.keys(SZ_POOLS).forEach(b=>{D[b]={};for(let y=SZ_FIRST[b];y<=2026;y++){const key=`${y}-${String(y+1).slice(2)}`,H=SZ_HIST[b]||{},prevT=(H.t||[]).includes(y),prevC=(H.c||[]).includes(y);
  const d={lg:szRivals(b,y),cup:b!=="womens-football"};
  if(b==="football"){if(SZ_EU_FB[y])d.eu={e:SZ_EU_FB[y],g:SZ_GROUPS_FB[y]||[]};if(SZ_SUP_FB[y])d.sup=SZ_SUP_FB[y];const fp=SEASON_POS.find(x=>x[0]===seaKey(y));if(fp)d.real=fp[1]}
  else{const top=d.lg[0][0];if((prevT||prevC)&&b!=="womens-football")d.sup=top;
    if(b==="basketball")d.eu={e:y>=2006?"EL-RS":"EC-RS"};
    else if(b==="womens-basketball")d.eu={e:"EL-RS"};
    else if(b==="volleyball")d.eu={e:y>=2008?"CL-G":"CC-R16"};
    else if(b==="mens-volleyball")d.eu={e:prevT?"CL-G":(H.p2.includes(y)||H.p3.includes(y))?"CC-R16":"CH-R32"};
    else if(b==="womens-football"&&prevT)d.eu={e:"WCL-Q1"};
    d.real=(H.t||[]).includes(y+1)?1:(H.p2||[]).includes(y+1)?2:(H.p3||[]).includes(y+1)?3:null}
  D[b][key]=d}});return D})();
function seaKey(y){return y===1999?"1999–2000":`${y}–${String(y+1).slice(2)}`}
