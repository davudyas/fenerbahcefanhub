/* Stand-alone site test: two fans in separate browsers, Supabase replaced by an in-memory hub */
const {chromium}=require('playwright');const fs=require('fs'),path=require('path');
const SITE=path.resolve(__dirname,'../site');
let html=fs.readFileSync(SITE+'/index.html','utf8');
html=html.replace(/window\.FB_SB=\{[^<]*\};/,'window.FB_SB={"url":"https://mock.supabase.co","key":"anon"};').replace(/<script src="https:\/\/cdn\.jsdelivr[^"]*"><\/script>/,'<script src="mocksb.js"></script>');
fs.writeFileSync(SITE+'/_t.html',html);fs.copyFileSync(__dirname+'/mocksb.js',SITE+'/mocksb.js');
const docs=new Map(),profiles=new Map(),subs=new Map(),pres={},uidOf=new Map();let rls=0;
const push=(cid,k,a)=>{const s=subs.get(cid);if(s)s.page.evaluate(([c,k,a])=>window.__mockRecv&&window.__mockRecv(c,k,a),[cid,k,a]).catch(()=>{})};
const presPush=name=>{for(const [cid,s] of subs)if(s.name===name)push(cid,'pres',pres[name]||{})};
const users=new Map(),leagues=new Map(),members=[],reports=[];
const anonOf=new Map(),BANS=new Set(),REG=new Set();
function rpc(page,name,a){const me=uidOf.get(page);
 if(name==='create_league'){const c='ABC'+(234+leagues.size);leagues.set(c,{code:c,name:a.league_name,owner:me});members.push({code:c,id:me});pushPg('league_members',{code:c,id:me});return {data:c}}
 if(name==='join_league'){const l=leagues.get(a.league_code);if(!l)return {error:{message:'no such league'}};if(!members.some(m=>m.code===l.code&&m.id===me)){members.push({code:l.code,id:me});pushPg('league_members',{code:l.code,id:me})}return {data:{code:l.code,name:l.name}}}
 if(name==='leave_league'){const i=members.findIndex(m=>m.code===a.league_code&&m.id===me);if(i>=0)members.splice(i,1);return {data:null}}
 if(name==='is_admin')return {data:me===global.ADMIN};
 if(name==='banned_ids')return {data:[...BANS]};
 if(name.startsWith('admin_')&&me!==global.ADMIN)return {error:{message:'not allowed'}};
 if(name==='admin_users'){const ids=new Set([...uidOf.values()]);return {data:[...ids].map(id=>{const D=c=>(docs.get(c+'|'+id)||{}).data||{};const reg=!!REG.has(id);
   return {id,username:reg?'user'+id.slice(0,3):null,name:(profiles.get(id)||{}).name||'',registered:reg,banned:BANS.has(id),admin:id===global.ADMIN,created_at:'2026-11-12T10:00:00Z',last_sign_in_at:null,last_active:'2026-11-13T09:00:00Z',
   predictions:Object.keys(D('predictions').p||{}).length,motm:Object.keys(D('motm').v||{}).length,ratings:Object.keys(D('ratings').r||{}).length,games:docs.has('scores|'+id),leagues:members.filter(m=>m.id===id).map(m=>(leagues.get(m.code)||{}).name),reports:new Set(reports.filter(r=>r.target===id).map(r=>r.reporter)).size}}).filter(x=>a.include_guests||x.registered)}}
 if(name==='admin_reports'){const g={};reports.forEach(r=>{const k=r.target+'|'+r.kind;(g[k]=g[k]||{target:r.target,kind:r.kind,rs:new Set(),samples:[],last:'2026-11-13T00:00:00Z'}).rs.add(r.reporter);g[k].samples.push(r.content)});
   return {data:Object.values(g).map(x=>({target:x.target,kind:x.kind,reporters:x.rs.size,last:x.last,samples:x.samples,name:(profiles.get(x.target)||{}).name||'',registered:false,banned:BANS.has(x.target)}))}}
 if(name==='admin_ban'){BANS.add(a.target);const p=profiles.get(a.target);if(p)p.name='';return {data:null}}
 if(name==='admin_unban'){BANS.delete(a.target);return {data:null}}
 if(name==='admin_reset_name'){const p=profiles.get(a.target);if(p)p.name='';return {data:null}}
 if(name==='admin_clear_data'){for(const k of [...docs.keys()])if(k.endsWith('|'+a.target))docs.delete(k);return {data:null}}
 if(name==='admin_dismiss'){for(let i=reports.length-1;i>=0;i--)if(reports[i].target===a.target&&reports[i].kind===a.k)reports.splice(i,1);return {data:null}}
 if(name==='admin_find'){return {data:[...profiles.values()].filter(p=>(p.name||'').toLowerCase().includes(a.q.toLowerCase())).map(p=>({id:p.id,name:p.name,registered:false,banned:BANS.has(p.id),created_at:'2026-11-12T10:00:00Z'}))}}
 if(name==='admin_leagues')return {data:[...leagues.values()].map(l=>({code:l.code,name:l.name,created_at:'2026-11-12',members:members.filter(m=>m.code===l.code).length,owner_name:(profiles.get(l.owner)||{}).name}))};
 if(name==='admin_delete_league'){leagues.delete(a.c);return {data:null}}
 if(name==='hidden_names'){const c={};reports.filter(r=>r.kind==='name').forEach(r=>{(c[r.target]=c[r.target]||new Set()).add(r.reporter)});return {data:Object.entries(c).filter(([,s])=>s.size>=3).map(([k])=>k).concat([...BANS])}}
 return {error:{message:'unknown rpc'}}}
function pushPg(table,row){for(const [cid,s] of subs){if(s.pg&&s.pg.table===table)push(cid,'pg',{eventType:'INSERT',new:row,old:{}})}}
function hub(page,st){
 if(st.op==='auth'){uidOf.set(page,st.uid);return {}}
 if(st.op==='upd'){if(st.email){for(const [e,u] of users)if(e===st.email&&u.id!==st.uid)return {error:{message:'A user with this email address has already been registered',code:'email_exists',status:422}};users.set(st.email,{id:st.uid,pw:null})}
   if(st.password){const e=[...users].find(([e,u])=>u.id===st.uid);if(!e)return {error:{message:'email not confirmed'}};e[1].pw=st.password}return {}}
 if(st.op==='login'){const u=users.get(st.email);if(!u||u.pw!==st.password)return {error:{message:'Invalid login credentials',code:'invalid_credentials',status:400}};return {uid:u.id}}
 if(st.op==='sub'){subs.set(st.cid,{page,name:st.name,pg:st.pg});if(pres[st.name])setTimeout(()=>presPush(st.name),20);return {}}
 if(st.op==='unsub'){subs.delete(st.cid);if(pres[st.name]&&st.key){delete pres[st.name][st.key];presPush(st.name)}return {}}
 if(st.op==='send'){for(const [cid,s] of subs)if(s.name===st.name)push(cid,'bc',{event:st.event,payload:st.payload});return {}}
 if(st.op==='track'){(pres[st.name]=pres[st.name]||{})[st.key]=[{...st.meta,presence_ref:'r'}];presPush(st.name);return {}}
 if(st.op==='untrack'){if(pres[st.name]){delete pres[st.name][st.key];presPush(st.name)}return {}}
 if(st.op==='rpc')return rpc(page,st.name,st.args||{});
 if(st.table==='leagues'){const me=uidOf.get(page);return {data:[...leagues.values()].filter(l=>members.some(m=>m.code===l.code&&m.id===me))}}
 if(st.table==='league_members'){const me=uidOf.get(page);const mine=new Set(members.filter(m=>m.id===me).map(m=>m.code));return {data:members.filter(m=>mine.has(m.code))}}
 if(st.table==='reports'){const me=uidOf.get(page);if(st.row.reporter!==me)return {error:{message:'rls'}};if(reports.some(r=>r.reporter===me&&r.target===st.row.target&&r.kind===st.row.kind))return {error:{code:'23505',message:'dup'}};reports.push(st.row);return {data:null}}
 const T=st.table==='docs'?docs:profiles;
 if(st.op==='upsert'){const me=uidOf.get(page)||null;if(st.row.id!==me){rls++;return {error:{message:'violates row-level security'}}}
  const key=st.table==='docs'?st.row.col+'|'+st.row.id:st.row.id;T.set(key,st.row);
  for(const [cid,s] of subs){if(!s.pg||s.pg.table!==st.table)continue;if(s.pg.filter){const [k,v]=s.pg.filter.split('=eq.');if(String(st.row[k])!==v)continue}push(cid,'pg',{eventType:'UPDATE',new:st.row,old:{}})}
  return {data:null}}
 let rows=[...T.values()];for(const [op,k,v] of st.f)rows=rows.filter(r=>op==='eq'?r[k]===v:v.includes(r[k]));
 return {data:st.single?(rows[0]||null):rows}}
(async()=>{const b=await chromium.launch();const errs=[];const out=[];const log=(...a)=>{out.push(a.join(' '));console.log(...a)};
const mk=async()=>{const ctx=await b.newContext({viewport:{width:1100,height:900},acceptDownloads:true});await ctx.exposeBinding('__hub',(src,st)=>hub(src.page,st));const pg=await ctx.newPage();
 pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error')errs.push('console: '+m.text())});
 await pg.goto('file://'+SITE+'/_t.html#football-matches');await pg.waitForFunction(()=>window.XC&&XC.on||(typeof XC!=='undefined'&&XC.on),null,{timeout:8000});return pg};
const A=await mk(),B=await mk();
const ida=await A.evaluate(()=>XC.me),idb=await B.evaluate(()=>XC.me);log('signed in as',ida,idb,'different:',ida!==idb);
log('Kanarya hidden:',await A.evaluate(()=>{const k=document.getElementById('kan')||document.querySelector('.kan,[id^=kan]');return !k||k.hidden||getComputedStyle(k).display==='none'}));
log('live note:',await A.evaluate(()=>{const n=[...document.querySelectorAll('.livenote,.fine,.muted')].map(x=>x.textContent).find(s=>/shared with other fans|Pick a fan name/.test(s));return n||'(not on this page)'}));
// fan name via Settings
await A.click('#setBtn');await A.waitForTimeout(200);log('name row:',await A.evaluate(()=>!!document.getElementById('setName')));
await A.fill('#setName','  Kadıköy   Kanaryası  ');await A.click('#setNameOk');await A.waitForTimeout(400);
await A.locator('#setPanel').screenshot({path:path.resolve(__dirname,'../sb_set.png')});await B.evaluate(()=>{setLang&&0});log('saved profile:',JSON.stringify(profiles.get(ida)&&profiles.get(ida).name),'toast:',await A.evaluate(()=>{const t=document.querySelector('.xtoast,.toast,[role=status]');return t?t.textContent:''}));
await A.keyboard.press('Escape');
// prediction league: A predicts, B sees it, B's name lookup
await A.evaluate(()=>xWrite('predictions',{p:{'football|2026-11-22|Test':[2,1]}}));await B.waitForTimeout(400);
log('B sees A prediction:',await B.evaluate(id=>JSON.stringify(XC.docs.predictions[id]),ida));
await B.waitForTimeout(300);log('B name for A:',await B.evaluate(id=>xName(id),ida));
// rename and see it live on B
if(await A.evaluate(()=>$('setPanel').hidden))await A.click('#setBtn');log('reopened value:',await A.inputValue('#setName'));await A.fill('#setName','Sarı Lacivert');await A.click('#setNameOk');await A.waitForTimeout(400);await A.keyboard.press('Escape');
log('B name for A after rename:',await B.evaluate(id=>xName(id),ida));
// RLS: B can't write A's doc
log('B writing A doc rejected:',await B.evaluate(async id=>{try{await XC.db.doc('predictions/'+id).set({p:{}});return false}catch(e){return true}},ida));
// motm, ratings, scores through the same path
for(const c of ['motm','ratings','scores','seasons','challenges','watch'])await B.evaluate(c=>xWrite(c,{t:1}),c);await A.waitForTimeout(400);
log('A sees B docs in:',await A.evaluate(id=>Object.keys(XC.docs).filter(c=>XC.docs[c][id]).join(','),idb));
// downloads
await A.evaluate(()=>{setSport('football');tab='matches';render()});await A.waitForTimeout(300);
const btn=await A.$('button:has-text("Download fixtures (CSV)"),button:has-text("Download all fixtures (CSV)")');
if(btn){const [dl]=await Promise.all([A.waitForEvent('download',{timeout:4000}),btn.click()]);const p=await dl.path();log('download:',dl.suggestedFilename(),fs.readFileSync(p,'utf8').split('\n').length,'lines')}else log('download: button not found');
// live quiz
for(const pg of [A,B]){await pg.evaluate(()=>{setSport('football');tab='play';playSel.football='live';render()});await pg.waitForTimeout(600)}
await A.selectOption('#lqLv0','easy');await A.click('[data-lq0="host"]');await A.waitForTimeout(600);
const code=await A.evaluate(()=>LQ.code);await B.waitForTimeout(500);
log('B sees open room:',await B.evaluate(()=>document.querySelector('.lqopen')?document.querySelector('.lqopen').innerText.replace(/\n/g,' '):'none'));
await B.fill('#lqIn',code);await B.click('[data-lq0="join"]');await B.waitForTimeout(800);
log('A players:',await A.evaluate(()=>document.querySelector('.lqboard').innerText.replace(/\n/g,' ')));
await A.click('[data-lq="start"]');await A.waitForTimeout(2800);
log('A q / B q same:',await A.evaluate(()=>document.querySelector('#lqArea h3').textContent)===await B.evaluate(()=>document.querySelector('#lqArea h3').textContent));
const ca=await A.evaluate(()=>LQ.qs[LQ.i].a);await A.click('[data-lqa="'+ca+'"]');await B.click('[data-lqa="'+((ca+1)%(await B.$$('[data-lqa]')).length)+'"]');await A.waitForTimeout(900);
log('phase after both answered:',await A.evaluate(()=>LQ.phase),await B.evaluate(()=>LQ.phase),await B.evaluate(()=>JSON.stringify(LQ.scores)));
await A.screenshot({path:path.resolve(__dirname,'../sb_quiz.png')});
await B.evaluate(()=>LQ.nr.leave());await A.evaluate(()=>LQ.nr.leave());
// watch party
for(const pg of [A,B]){await pg.evaluate(()=>{LQ=null;setSport('football');tab='matches';render()});await pg.waitForTimeout(300)}
log('wp card:',await A.evaluate(()=>!!document.getElementById('wpCard')));
await A.click('[data-wp="open"]');await B.click('[data-wp="open"]');await A.waitForTimeout(700);
await B.click('[data-wpr="goal"]');await A.fill('#wpIn','Hadi Fener!');await A.click('#wpForm .btn');await A.waitForTimeout(900);
log('B feed:',await B.evaluate(()=>document.getElementById('wpFeed').innerText.replace(/\n/g,' | ')),'| count',await B.evaluate(()=>document.getElementById('wpN').textContent));
await B.screenshot({path:path.resolve(__dirname,'../sb_wp.png')});
log('rls rejections',rls);log('errs',JSON.stringify(errs));
// offline / empty config: real index.html, CDN unreachable
const ctx3=await b.newContext();const C=await ctx3.newPage();const e3=[];C.on('pageerror',e=>e3.push(e.message));
await ctx3.route('**/*',r=>r.request().url().startsWith('file:')?r.continue():r.abort());
await C.goto('file://'+SITE+'/index.html#football-matches');await C.waitForTimeout(2500);
log('offline: XC.on',await C.evaluate(()=>XC.on),'tried',await C.evaluate(()=>XC.tried),'errs',JSON.stringify(e3));
log('offline note:',await C.evaluate(()=>[...document.querySelectorAll('p,small,div')].map(x=>x.childElementCount?'':x.textContent).find(s=>/couldn.t connect/.test(s))||'none'));
await C.evaluate(()=>{tab='play';playSel.football='live';render()});await C.waitForTimeout(600);log('offline live quiz:',await C.evaluate(()=>(document.getElementById('lqArea')||{}).innerText));
await b.close();fs.unlinkSync(SITE+'/_t.html');fs.unlinkSync(SITE+'/mocksb.js')})().catch(e=>{console.error('FAIL',e);process.exit(1)});
