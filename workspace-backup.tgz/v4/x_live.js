/* ===== Real time: live quiz rooms and the match-night watch party (room capability) ===== */
const RT={room:null,user:null,names:{},tried:false};
async function rtRoom(){if(RT.room||RT.tried)return RT.room;RT.tried=true;try{const c=window.claude;if(!c||!c.use)return null;RT.room=await c.use("room");RT.user=await c.use("user")}catch(e){RT.room=null}return RT.room}
async function rtNames(ids){ids=ids.filter(i=>i&&!(i in RT.names));if(!ids.length||!RT.user||!RT.user.profiles)return false;ids.forEach(i=>RT.names[i]="");try{const ps=await RT.user.profiles(ids);ids.forEach(i=>RT.names[i]=(ps[i]&&ps[i].name)||"")}catch(e){}return true}
let rtName=(peer)=>{if(!peer)return t("Someone");if(peer.isMe)return t("You");const n=peer.by&&RT.names[peer.by];return n||(peer.presence&&typeof peer.presence.nick==="string"&&peer.presence.nick.slice(0,24))||t("A fan")};
const rtNoRoom=()=>`<p class="msg">${t("Live features need the page open in Claude while signed in. You can still play everything else here.")}</p>`;

/* ---------------- Live quiz ---------------- */
const LQT={start:"qstart",q:"qq",ans:"qans",rev:"qrev",end:"qend",sync:"qsync"};
let LQ=null;
function lqSeeded(seed,b,lv){const o=Math.random;Math.random=szRng(seed);try{return qRound(b,lv)}finally{Math.random=o}}
function lqCode(){const A="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";let s="";for(let i=0;i<5;i++)s+=A[Math.floor(Math.random()*A.length)];return s}
async function lqJoin(code,host,lv){const R=await rtRoom();if(!R)return false;code=code.toUpperCase().replace(/[^A-Z0-9]/g,"").slice(0,6);if(code.length<4)return false;
  let nr;try{nr=await R.join("lq-"+code.toLowerCase())}catch(e){xToast(t("Couldn't join that room. Try again."));return false}
  if(LQ&&LQ.nr&&LQ.nr!==nr){try{LQ.nr.leave()}catch(e){}}
  LQ={nr,code,host,lv:lv||"normal",b:current,phase:"lobby",i:-1,qs:[],scores:{},ans:{},mine:{},hostPeer:null,un:[],dur:20000};
  nr.presence({role:host?"host":"player",at:Date.now()}).catch(()=>{});
  const on=(tp,f)=>LQ.un.push(nr.on(tp,f));
  on(LQT.start,m=>{if(!lqFromHost(m))return;const d=m.data||{};LQ.b=d.b;LQ.lv=d.lv;LQ.seed=d.seed;LQ.dur=d.dur;LQ.qs=lqSeeded(d.seed,d.b,d.lv);LQ.scores={};LQ.ans={};LQ.mine={};LQ.phase="wait";LQ.i=-1;lqDraw()});
  on(LQT.q,m=>{if(!lqFromHost(m))return;const d=m.data||{};if(!LQ.qs.length)return;LQ.i=d.i;LQ.phase="q";LQ.t0=Date.now();LQ.left=d.dur||LQ.dur;lqDraw();lqTick()});
  on(LQT.ans,m=>{const d=m.data||{};if(typeof d.i!=="number"||typeof d.a!=="number")return;(LQ.ans[d.i]=LQ.ans[d.i]||{})[m.peer]={a:d.a,ms:+d.ms||0,by:m.by};if(LQ.host)lqMaybeReveal();lqDrawAnswers()});
  on(LQT.rev,m=>{if(!lqFromHost(m))return;const d=m.data||{};LQ.phase="rev";if(d.scores&&typeof d.scores==="object")LQ.scores=d.scores;clearInterval(LQ.tick);lqDraw()});
  on(LQT.end,m=>{if(!lqFromHost(m))return;const d=m.data||{};if(d.scores)LQ.scores=d.scores;LQ.phase="end";clearInterval(LQ.tick);lqDraw();lqSaveBest()});
  on(LQT.sync,m=>{if(LQ.host||!lqFromHost(m))return;const d=m.data||{};if(LQ.phase!=="lobby"&&LQ.seed===d.seed)return;LQ.b=d.b;LQ.lv=d.lv;LQ.seed=d.seed;LQ.dur=d.dur;LQ.qs=d.seed?lqSeeded(d.seed,d.b,d.lv):[];LQ.scores=d.scores||{};LQ.i=d.i;LQ.phase=d.phase==="q"||d.phase==="rev"?"wait":d.phase||"lobby";lqDraw()});
  LQ.un.push(nr.onPeers(ch=>{const P=ch.peers;rtNames(P.map(p=>p.by)).then(n=>{if(n)lqDraw()});const h=P.find(p=>p.presence&&p.presence.role==="host");
    if(h)LQ.hostPeer=h.peer;else if(LQ.hostPeer&&!LQ.host&&LQ.phase!=="end"){LQ.phase="gone"}
    if(LQ.host&&ch.joined.some(p=>!p.isMe))lqSync();lqDraw()}));
  if(host){const R2=RT.room;R2.presence({lq:{c:code,b:current,lv:LQ.lv}}).catch(()=>{})}
  lqDraw();return true}
function lqFromHost(m){if(LQ.host)return m.isMe&&m.sameTab;const P=LQ.nr.peers().find(p=>p.peer===m.peer);return !!(P&&P.presence&&P.presence.role==="host")}
function lqSync(){LQ.nr.emit(LQT.sync,{seed:LQ.seed||0,b:LQ.b,lv:LQ.lv,dur:LQ.dur,i:LQ.i,phase:LQ.phase,scores:LQ.scores}).catch(()=>{})}
function lqScore(){const S={};Object.entries(LQ.ans).forEach(([i,M])=>{const q=LQ.qs[+i];if(!q)return;Object.entries(M).forEach(([peer,x])=>{S[peer]=S[peer]||0;if(x.a===q.a)S[peer]+=500+Math.round(500*Math.max(0,1-x.ms/LQ.dur))})});return S}
let lqRevTimer=null;
function lqMaybeReveal(){const n=LQ.nr.peers().filter(p=>p.kind==="viewer").length,got=Object.keys(LQ.ans[LQ.i]||{}).length;if(LQ.phase==="q"&&got>=n)lqReveal()}
function lqReveal(){if(!LQ.host||LQ.phase!=="q")return;clearTimeout(lqRevTimer);LQ.scores=lqScore();LQ.nr.emit(LQT.rev,{i:LQ.i,scores:LQ.scores}).catch(()=>{});
  lqRevTimer=setTimeout(()=>{if(!LQ||!LQ.host)return;if(LQ.i+1<LQ.qs.length)lqAsk(LQ.i+1);else{LQ.nr.emit(LQT.end,{scores:LQ.scores}).catch(()=>{});RT.room&&RT.room.presence({lq:null}).catch(()=>{})}},4500)}
function lqAsk(i){LQ.nr.emit(LQT.q,{i,dur:LQ.dur}).catch(()=>{});clearTimeout(lqRevTimer);lqRevTimer=setTimeout(lqReveal,LQ.dur+600)}
function lqStart(){const lv=LQ.lv,L=QLV.find(x=>x[0]===lv);LQ.dur=(L[3]||20)*1000;const seed=1+Math.floor(Math.random()*2e9);
  LQ.nr.emit(LQT.start,{seed,b:current,lv,dur:LQ.dur}).catch(()=>{});setTimeout(()=>lqAsk(0),1800)}
function lqLeave(){if(!LQ)return;clearInterval(LQ.tick);clearTimeout(lqRevTimer);LQ.un.forEach(u=>{try{u()}catch(e){}});try{LQ.nr.leave()}catch(e){}if(LQ.host&&RT.room)RT.room.presence({lq:null}).catch(()=>{});LQ=null}
function lqTick(){clearInterval(LQ.tick);LQ.tick=setInterval(()=>{const bar=$("lqBar");if(!LQ||LQ.phase!=="q"||!bar){clearInterval(LQ&&LQ.tick);return}const ms=LQ.left-(Date.now()-LQ.t0);bar.style.width=Math.max(0,ms/LQ.left*100)+"%";bar.classList.toggle("low",ms<5000)},150)}
function lqSaveBest(){const me=LQ.nr.peers().find(p=>p.isMe&&p.sameTab);if(!me)return;const S=Object.entries(LQ.scores).sort((a,c)=>c[1]-a[1]),rank=S.findIndex(x=>x[0]===me.peer)+1;if(rank===1&&S.length>1)store.set("fb-lq-wins",store.get("fb-lq-wins",0)+1);if(typeof xBadgeCheck==="function")xBadgeCheck()}
function lqBoard(){const P=LQ.nr.peers().filter(p=>p.kind==="viewer"),rows=P.map(p=>({p,s:LQ.scores[p.peer]||0})).sort((a,c)=>c.s-a.s);
  return `<ol class="ptable lqboard">${rows.map((r,i)=>`<li class="${r.p.isMe&&r.p.sameTab?"me":""}"><span class="rk">${i+1}</span><span class="nm">${esc(rtName(r.p))}${r.p.presence&&r.p.presence.role==="host"?` <small class="muted">${t("host")}</small>`:""}</span><b>${r.s}</b></li>`).join("")}</ol>`}
function lqDrawAnswers(){const el=$("lqGot");if(el&&LQ&&LQ.phase==="q"){const n=LQ.nr.peers().filter(p=>p.kind==="viewer").length;el.textContent=tf("{a} of {n} answered",{a:Object.keys(LQ.ans[LQ.i]||{}).length,n})}}
function lqDraw(){const el=$("lqArea");if(!el)return;if(!LQ){gLive(el.parentElement);return}
  const L=QLV.find(x=>x[0]===LQ.lv),head=`<div class="lqhead"><div><span class="label">${t("Room code")}</span><b class="lqcode">${esc(LQ.code)}</b></div><div class="muted">${esc(t(SPORTS[LQ.b]?SPORTS[LQ.b].label:""))} · ${esc(t(L[1]))}</div><button class="btn ghost" data-lq="leave">${t("Leave")}</button></div>`;
  let body="";
  if(LQ.phase==="gone")body=`<p class="msg">${t("The host has left, so this game is over.")}</p>`;
  else if(LQ.phase==="lobby")body=LQ.host?`<p>${t("Tell your friends to open the Live quiz and enter this code. Start when everyone is in.")}</p><label class="lqlv"><span>${t("Level")}</span><select id="lqLv">${QLV.map(([id,lab])=>`<option value="${id}" ${id===LQ.lv?"selected":""}>${esc(t(lab))}</option>`).join("")}</select></label><div class="btns"><button class="btn" data-lq="start">${t("Start the quiz")}</button><button class="btn ghost" data-lq="copy">${t("Copy the code")}</button></div>`
     :`<p class="muted">${t("Waiting for the host to start…")}</p>`;
  else if(LQ.phase==="wait")body=`<p class="muted">${t("Get ready…")}</p>`;
  else if((LQ.phase==="q"||LQ.phase==="rev")&&LQ.qs[LQ.i]){const q=LQ.qs[LQ.i],my=LQ.mine[LQ.i],rev=LQ.phase==="rev";
    body=`<div class="quiz"><div class="top"><span class="label">${tf("Question {i} of {n}",{i:LQ.i+1,n:LQ.qs.length})}</span><span class="label" id="lqGot"></span></div>${!rev?`<div class="qtimer"><i id="lqBar"></i></div>`:""}
     <h3>${esc(q.q)}</h3><div class="opts">${q.o.map((o,k)=>{let c="opt";if(rev){if(k===q.a)c+=" right";else if(k===my)c+=" wrong"}else if(k===my)c+=" picked";return `<button class="${c}" data-lqa="${k}" ${my!=null||rev?"disabled":""}>${esc(o)}</button>`}).join("")}</div>
     ${rev?`<p class="explain"><b>${my===q.a?t("Correct."):my==null?t("Time's up."):t("Not quite.")}</b> ${esc(tf("The answer is {a}.",{a:q.o[q.a]}))}</p>`:my!=null?`<p class="muted">${t("Locked in. Waiting for the others…")}</p>`:""}</div>`}
  else if(LQ.phase==="end"){const P=LQ.nr.peers(),S=Object.entries(LQ.scores).sort((a,c)=>c[1]-a[1]),w=P.find(p=>S[0]&&p.peer===S[0][0]);
    body=`<div class="lqwin"><span class="label">${t("Winner")}</span><b>${esc(w?rtName(w):t("Someone"))}</b><span>${S[0]?S[0][1]:0} ${t("points")}</span></div>${LQ.host?`<div class="btns"><button class="btn" data-lq="again">${t("Play another round")}</button></div>`:`<p class="muted">${t("The host can start another round.")}</p>`}`}
  el.innerHTML=head+`<div class="lqmain"><div>${body}</div><aside><span class="label">${tf("Players ({n})",{n:LQ.nr.peers().filter(p=>p.kind==="viewer").length})}</span>${lqBoard()}</aside></div>`;
  lqDrawAnswers();if(LQ.phase==="q")lqTick();
  const on=(k,f)=>{const x=el.querySelector(`[data-lq="${k}"]`);if(x)x.onclick=f};
  on("leave",()=>{lqLeave();lqDraw()});on("start",()=>{const s=$("lqLv");if(s)LQ.lv=s.value;lqStart()});on("again",()=>{LQ.phase="lobby";LQ.scores={};lqSync();lqDraw()});
  on("copy",async()=>{try{await navigator.clipboard.writeText(LQ.code);xToast(t("Code copied. Send it to a friend!"))}catch(e){xToast(LQ.code)}});
  const lvS=$("lqLv");if(lvS)lvS.onchange=()=>{LQ.lv=lvS.value;RT.room&&RT.room.presence({lq:{c:LQ.code,b:current,lv:LQ.lv}}).catch(()=>{});lqDraw()};
  el.querySelectorAll("[data-lqa]").forEach(x=>x.onclick=()=>{if(LQ.mine[LQ.i]!=null||LQ.phase!=="q")return;const a=+x.dataset.lqa;LQ.mine[LQ.i]=a;LQ.nr.emit(LQT.ans,{i:LQ.i,a,ms:Date.now()-LQ.t0}).catch(()=>{});lqDraw()})}
function gLive(el){el.innerHTML=`<h2>${t("Live quiz")}</h2><p class="intro">${t("Play the quiz against friends in real time. Everyone gets the same questions in their own language. Faster right answers score more.")}</p><div id="lqArea" class="card lqarea"></div>`;
  const area=$("lqArea");if(LQ){lqDraw();return}area.innerHTML=`<p class="muted">${t("Connecting…")}</p>`;
  rtRoom().then(R=>{if(!$("lqArea"))return;if(!R){area.innerHTML=rtNoRoom();return}
    const open=()=>R.peers().filter(p=>p.presence&&p.presence.lq&&p.presence.lq.c&&!p.isMe).map(p=>({p,...p.presence.lq}));
    const draw=()=>{if(LQ||!$("lqArea"))return;const O=open();rtNames(O.map(o=>o.p.by)).then(n=>{if(n)draw()});
      area.innerHTML=`<div class="lqstart"><article><span class="label">${t("Host a game")}</span><p>${t("Create a room, share the code, and start when your friends are in.")}</p><label class="lqlv"><span>${t("Level")}</span><select id="lqLv0">${QLV.map(([id,lab])=>`<option value="${id}" ${id==="normal"?"selected":""}>${esc(t(lab))}</option>`).join("")}</select></label><div class="btns"><button class="btn" data-lq0="host">${t("Create a room")}</button></div></article>
       <article><span class="label">${t("Join a game")}</span><div class="btns chrow"><input id="lqIn" placeholder="${t("Room code")}" aria-label="${t("Room code")}" maxlength="6"><button class="btn ghost" data-lq0="join">${t("Join")}</button></div><p class="msg" id="lqMsg" aria-live="polite"></p>
       ${O.length?`<span class="label">${t("Open rooms")}</span><ul class="lqopen">${O.map(o=>`<li><span>${esc(rtName(o.p))} · ${esc(t(SPORTS[o.b]?SPORTS[o.b].label:""))}</span><button class="btn ghost" data-lqj="${esc(o.c)}">${t("Join")} ${esc(o.c)}</button></li>`).join("")}</ul>`:`<p class="fine">${t("No open rooms right now.")}</p>`}</article></div>`;
      area.querySelector('[data-lq0="host"]').onclick=()=>lqJoin(lqCode(),true,$("lqLv0").value);
      area.querySelector('[data-lq0="join"]').onclick=async()=>{const ok=await lqJoin($("lqIn").value,false);if(!ok&&$("lqMsg"))$("lqMsg").textContent=t("Enter the 5-character code from the host.")};
      area.querySelectorAll("[data-lqj]").forEach(x=>x.onclick=()=>lqJoin(x.dataset.lqj,false))};
    draw();const un=R.onPeers(()=>{if(!$("lqArea")||LQ){un();return}const f=document.activeElement;if(f&&f.id==="lqIn")return;draw()})})}
GAME_FN.live=gLive;
Object.keys(PLAY).forEach(b=>{const i=PLAY[b].findIndex(x=>x[0]==="quiz");PLAY[b].splice(i+1,0,["live","Live quiz","Play against friends in real time"])});

/* ---------------- Match-night watch party ---------------- */
const WP_REACT=[["goal","⚽","Goal!"],["chance","😱","What a chance"],["save","🧤","Great save"],["card","🟨","Card"],["wow","🔥","Atmosphere"],["sad","😩","Oh no"]];
let WP=null;
function wpFixture(b){const L=LIVE[b];if(!L)return null;const now=Date.now();const list=L.next.filter(n=>n[0]).map(n=>{const [Y,M,D]=n[0].split("-").map(Number),[h,mi]=(n[1]||"18:00").split(":").map(Number);return {n,ko:Date.UTC(Y,M-1,D,h-3,mi)}});
  return list.find(x=>now<x.ko+150*60000)||null}
const wpKey=(b,f)=>xKey(b,f.n[0],f.n[4]);
const wpRoomName=(b,f)=>("wp-"+BR_CODE[b]+"-"+f.n[0].replace(/-/g,"")+"-"+sn(f.n[4]).replace(/[^a-z0-9]/g,"").slice(0,16)).toLowerCase();
const wpMin=f=>Math.floor((Date.now()-f.ko)/60000);
const xWatch=()=>store.get("fb-watch",{});
function wpCard(b){const f=wpFixture(b);if(!f)return "";const m=wpMin(f),live=m>=-30&&m<150,opp=f.n[4],title=f.n[3]==="H"?`Fenerbahçe – ${opp}`:`${opp} – Fenerbahçe`;
  return `<article class="card wpcard ${live?"live":""}" id="wpCard"><div><span class="label">${live?(m<0?t("Watch party · starting soon"):t("Watch party · live now")):t("Match-night watch party")}</span><h3>${esc(title)}</h3><p class="muted">${live?t("Join other fans on the page: react to every chance and chat while the game is on."):tf("Opens 30 minutes before kick-off, {d}. You can drop in early to chat.",{d:mDate(f.n[0],true)+(f.n[1]?" · "+f.n[1]:"")})}</p></div><button class="btn ${live?"":"ghost"}" data-wp="open">${t(live?"Join the watch party":"Open it now")}</button></article>`}
async function wpOpen(b){const f=wpFixture(b);if(!f)return;const R=await rtRoom();
  if(!R){ovOpen(`<article class="wp"><h2>${t("Watch party")}</h2>${rtNoRoom()}</article>`,t("Watch party"));return}
  let nr;try{nr=await R.join(wpRoomName(b,f))}catch(e){xToast(t("Couldn't join that room. Try again."));return}
  if(WP&&WP.nr!==nr){try{WP.nr.leave()}catch(e){}}
  WP={b,f,nr,key:wpKey(b,f),feed:[],counts:{},un:[],last:0,pend:false};nr.presence({w:1}).catch(()=>{});
  WP.un.push(nr.on("react",m=>{const d=m.data||{};const R0=WP_REACT.find(x=>x[0]===d.k);if(!R0)return;WP.counts[d.k]=(WP.counts[d.k]||0)+1;WP.feed.unshift({k:"r",r:R0,p:m,min:+d.m||0,ts:Date.now()});WP.feed=WP.feed.slice(0,60);wpFloat(R0[1]);wpDraw()}));
  WP.un.push(nr.on("chat",m=>{const d=m.data||{};if(typeof d.x!=="string")return;const x=d.x.replace(/[\u0000-\u001f​-‏‪-‮]/g,"").slice(0,140).trim();if(!x)return;WP.feed.unshift({k:"c",x,p:m,min:+d.m||0,ts:Date.now()});WP.feed=WP.feed.slice(0,60);wpDraw()}));
  WP.un.push(nr.onPeers(ch=>{rtNames(ch.peers.map(p=>p.by)).then(n=>{if(n)wpDraw()});const c=$("wpN");if(c)c.textContent=tf(ch.peers.length===1?"1 fan here":"{n} fans here",{n:ch.peers.length})}));
  const title=f.n[3]==="H"?`Fenerbahçe – ${f.n[4]}`:`${f.n[4]} – Fenerbahçe`;
  ovOpen(`<article class="wp"><span class="label">${t("Watch party")} · ${esc(t(f.n[2]))}</span><h2>${esc(title)}</h2><p class="muted"><span id="wpN"></span> · <span id="wpClock"></span></p>
    <div class="wpreact">${WP_REACT.map(([k,e,l])=>`<button data-wpr="${k}" aria-label="${esc(t(l))}"><span class="e">${e}</span><span class="l">${esc(t(l))}</span><b id="wpc-${k}">0</b></button>`).join("")}</div>
    <form class="wpchat" id="wpForm"><input id="wpIn" maxlength="140" placeholder="${t("Say something…")}" aria-label="${t("Message")}" autocomplete="off"><button class="btn">${t("Send")}</button></form>
    <ol class="wpfeed" id="wpFeed" aria-live="polite"></ol><div class="wpfloat" id="wpFloat" aria-hidden="true"></div>
    <p class="fine">${t("Messages are only seen by fans on the page right now and aren't saved. Your reactions are saved so the match page can show the loudest moments.")}</p></article>`,title);
  const ov=$("ov"),obs=new MutationObserver(()=>{if(ov.hidden){wpClose();obs.disconnect()}});obs.observe(ov,{attributes:true,attributeFilter:["hidden"]});
  document.querySelectorAll("[data-wpr]").forEach(x=>x.onclick=()=>wpReact(x.dataset.wpr));
  $("wpForm").onsubmit=e=>{e.preventDefault();const v=$("wpIn").value.trim();if(!v||Date.now()-WP.last<1500)return;if(modBad(v)){xToast(t("Please keep it friendly. That message wasn't sent."));return}WP.last=Date.now();WP.nr.emit("chat",{x:v.slice(0,140),m:wpMin(WP.f)}).catch(()=>xToast(t("Messages can't be sent from this view.")));$("wpIn").value=""};
  WP.clock=setInterval(()=>{const c=$("wpClock");if(!c||!WP){clearInterval(WP&&WP.clock);return}const m=wpMin(WP.f);c.textContent=m<0?tf("Kick-off in {n} min",{n:-m}):m<130?tf("About {n}' played",{n:Math.min(m,120)}):t("Full time")},1000);wpDraw()}
function wpClose(){if(!WP)return;clearInterval(WP.clock);WP.un.forEach(u=>{try{u()}catch(e){}});try{WP.nr.leave()}catch(e){}wpFlush();WP=null}
let wpRT=0;
function wpReact(k){if(!WP||Date.now()-wpRT<700)return;wpRT=Date.now();const m=wpMin(WP.f);WP.nr.emit("react",{k,m}).catch(()=>xToast(t("Messages can't be sent from this view.")));
  const W=xWatch(),M=W[WP.key]=W[WP.key]||{},bk=String(Math.max(-30,Math.min(130,Math.floor(m/5)*5)));(M[bk]=M[bk]||{})[k]=(M[bk][k]||0)+1;
  const ks=Object.keys(W);if(ks.length>20)ks.slice(0,ks.length-20).forEach(x=>delete W[x]);store.set("fb-watch",W);WP.pend=true;clearTimeout(WP.ft);WP.ft=setTimeout(wpFlush,5000)}
function wpFlush(){if(!WP||!WP.pend)return;WP.pend=false;xWrite("watch",{w:xWatch(),ts:Date.now()})}
function wpFloat(e){const f=$("wpFloat");if(!f)return;const s=document.createElement("span");s.textContent=e;s.style.left=(10+Math.random()*80)+"%";f.appendChild(s);setTimeout(()=>s.remove(),2200)}
function wpDraw(){if(!WP)return;WP_REACT.forEach(([k])=>{const c=$("wpc-"+k);if(c)c.textContent=WP.counts[k]||0});const F=$("wpFeed");if(!F)return;
  F.innerHTML="";WP.feed.slice(0,40).forEach(x=>{const li=document.createElement("li");const who=document.createElement("b");who.textContent=rtName(x.p);const mn=document.createElement("span");mn.className="muted";mn.textContent=x.min<0?t("pre-match"):`${x.min}'`;
    const body=document.createElement("span");if(x.p&&x.p.by)li.dataset.uid=x.p.by;if(x.k==="c")li.dataset.msg=x.x;body.textContent=x.k==="c"?modClean(x.x):`${x.r[1]} ${t(x.r[2])}`;li.append(mn," ",who," ",body);if(x.k==="r")li.className="r";F.appendChild(li)})}
/* loudest moments on the match page, from everyone's saved reactions */
function wpMoments(key){const all=xAllDocs("watch",xWatch(),"w"),B={};Object.values(all).forEach(W=>{const M=W&&W[key];if(!M)return;Object.entries(M).forEach(([bk,o])=>{B[bk]=B[bk]||{};Object.entries(o||{}).forEach(([k,v])=>{v=+v;if(v>0&&v<500)B[bk][k]=(B[bk][k]||0)+v})})});return B}
function wpMomentsHtml(key){const B=wpMoments(key),ks=Object.keys(B).map(Number).sort((a,c)=>a-c);if(!ks.length)return "";const tot=k=>Object.values(B[k]).reduce((a,v)=>a+v,0),mx=Math.max(...ks.map(tot)),peak=ks.reduce((a,k)=>tot(k)>tot(a)?k:a,ks[0]),top=Object.entries(B[peak]).sort((a,c)=>c[1]-a[1])[0],R0=WP_REACT.find(x=>x[0]===top[0]);
  return `<section><h4 class="mh">${t("Watch party")}</h4><p>${tf("The loudest moment came around {m}: {e} {l}.",{m:peak<0?t("pre-match"):`${peak}'–${peak+5}'`,e:R0?R0[1]:"",l:R0?t(R0[2]):""})}</p><div class="wpspark">${ks.map(k=>`<i style="height:${Math.max(6,tot(k)/mx*100)}%" title="${k<0?t("pre-match"):k+"'"}: ${tot(k)}"></i>`).join("")}</div></section>`}
/* hooks: matches tab card, match page, home */
EXT.afterPanel.push(p=>{if(tab!=="matches")return;const h=p.querySelector("h2"),c=wpCard(current);if(c&&h&&!$("wpCard")){const intro=p.querySelector(".intro"),later=!c.includes("wpcard live")&&(p.querySelector(".mgrid")||p.querySelector(".mcols"));
  /* a party that hasn't started waits below the results; a live one goes to the top */
  if(later)later.insertAdjacentHTML("afterend",c);else (intro||h).insertAdjacentHTML("afterend",c)}});
document.addEventListener("click",e=>{const w=e.target.closest('[data-wp="open"]');if(w)wpOpen(w.dataset.wpb||current)});
EXT.matchPage.push((b,i)=>{const r=LIVE[b]&&LIVE[b].last[i];if(!r)return;const h=wpMomentsHtml(xKey(b,r[0],r[3]));if(h){const nav=document.querySelector(".mp .mpnav");if(nav)nav.insertAdjacentHTML("beforebegin",h)}});
EXT.home.push(p=>{const live=HOME_BR.map(b=>{const f=wpFixture(b);if(!f)return null;const m=wpMin(f);return m>=-30&&m<150?{b,f}:null}).filter(Boolean);
  if(live.length){const h=p.querySelector(".intro");h.insertAdjacentHTML("afterend",live.map(({b,f})=>`<article class="card wpcard live"><div><span class="label">${t("Watch party · live now")} · ${esc(t(SPORTS[b].label))}</span><h3>${esc(f.n[3]==="H"?"Fenerbahçe – "+f.n[4]:f.n[4]+" – Fenerbahçe")}</h3></div><button class="btn" data-wp="open" data-wpb="${b}">${t("Join the watch party")}</button></article>`).join(""))}});
BADGES.push(["live","Quizmaster","Win a live quiz against friends.",()=>store.get("fb-lq-wins",0)>0]);
