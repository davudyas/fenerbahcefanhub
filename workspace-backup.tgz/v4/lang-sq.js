LANGPACK("sq",{"d":{},"o":[],"p":[]});
