const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const pg=await b.newPage();await pg.goto('file://'+process.cwd()+'/fenerbahce_full.html');await pg.waitForTimeout(400);
console.log(await pg.evaluate(()=>Object.keys(SPORTS).map(b=>"### "+b+"\n"+SPORTS[b].quiz.map(q=>q.q+" | "+q.o.join(" / ")+" | A="+q.o[q.a]).join("\n")).join("\n")));
console.log(await pg.evaluate(()=>JSON.stringify({seasons:SEASONS.slice(0,3),pby:Object.keys(PBY).length,players:PLAYERS.slice(0,2),seasonpos:SEASON_POS.length,mb:MB_LINEUPS.map(l=>l.id+" "+l.label+" "+l.opp+" "+l.score),wb:WB_LINEUPS.map(l=>l.id+" "+l.label+" "+l.opp+" "+l.score),vb:VB_SQUADS.map(s=>s.id+" "+s.label)})));
await b.close()})();
