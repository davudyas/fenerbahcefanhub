// usage: node mvfn.js from.js to.js name... -> moves top-level function declarations into another file
const ts=require('typescript'),fs=require('fs');const [,,from,to,...names]=process.argv;let src=fs.readFileSync(from,'utf8');
const sf=ts.createSourceFile(from,src,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);const cuts=[];
sf.statements.forEach(st=>{if(ts.isFunctionDeclaration(st)&&st.name&&names.includes(st.name.text))cuts.push([st.getStart(sf),st.end,st.name.text])});
if(cuts.length!==names.length){console.error('missing',names.filter(n=>!cuts.some(c=>c[2]===n)));process.exit(1)}
const moved=cuts.sort((a,b)=>a[0]-b[0]).map(([a,b])=>src.slice(a,b)).join('\n');cuts.sort((a,b)=>b[0]-a[0]).forEach(([a,b])=>{src=src.slice(0,a)+src.slice(b)});
fs.writeFileSync(from,src);fs.writeFileSync(to,(fs.existsSync(to)?fs.readFileSync(to,'utf8')+'\n':'')+moved+'\n');console.log('moved',cuts.map(c=>c[2]).join(','),'->',to);
