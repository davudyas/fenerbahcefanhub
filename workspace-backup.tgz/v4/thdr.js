const {chromium}=require('playwright');const path=require('path');
(async()=>{const b=await chromium.launch();const pg=await b.newPage({viewport:{width:375,height:800}});await pg.route('**/*',r=>r.request().url().startsWith('file:')?r.continue():r.abort());
await pg.goto('file://'+path.resolve(__dirname,'../site/index.html'));await pg.waitForTimeout(800);
await pg.evaluate(()=>{const w=document.querySelector('.bar .wrap'),lp=w.querySelector('.langpick');const d=document.createElement('div');d.className='acwrap';d.innerHTML='<button class="hset hacct" id="acBtn"><svg></svg><span class="aclab">Log in</span></button>';w.insertBefore(d,lp)});
for(const W of [320,360,375,414,640,800]){await pg.setViewportSize({width:W,height:800});await pg.waitForTimeout(100);
console.log(W,await pg.evaluate(()=>{const w=document.querySelector('.bar .wrap');const cs=getComputedStyle(w);return 'gap='+cs.gap+' pad='+cs.paddingLeft+' over='+(w.scrollWidth-w.clientWidth)+' | '+[...w.children].filter(e=>e.getBoundingClientRect().width>1).map(e=>e.className.split(' ')[0]+':'+Math.round(e.getBoundingClientRect().width)).join(' ')}))}
await b.close()})();
