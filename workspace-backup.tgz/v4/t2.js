const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const F='file://'+process.cwd()+'/fenerbahce.html';
const errs=[];
for(const [w,h,tag] of [[1280,900,'d'],[390,844,'m']]){
 const pg=await b.newPage({viewport:{width:w,height:h}});pg.on('pageerror',e=>errs.push(e.message));
 for(const br of ['football','basketball','womens-basketball','volleyball']){
  await pg.goto(F+'#'+br);await pg.waitForTimeout(300);
  const tabs=await pg.$$eval('.tab',x=>x.map(t=>t.textContent.trim()));
  const sel=await pg.$eval('.tab[aria-selected=true]',x=>x.textContent);
  await pg.click('[data-tab=matches]');await pg.waitForTimeout(150);await pg.locator('#panel').screenshot({path:`s_${tag}_${br}_m.png`});
  await pg.click('[data-tab=standings]');await pg.waitForTimeout(200);
  await pg.locator('#panel').screenshot({path:`s_${tag}_${br}_s.png`});
  const sw=await pg.evaluate(()=>document.documentElement.scrollWidth);
  console.log(tag,br,sel,tabs.join('|'),'sw',sw);
 }
 await pg.goto(F+'#football');await pg.waitForTimeout(200);await pg.click('[data-tab=matches]');await pg.click('[data-mf="Champions League"]');await pg.click('[data-mall]').catch(()=>{});await pg.locator('#panel').screenshot({path:`s_${tag}_ucl.png`});
 await pg.goto(F+'#more');await pg.waitForTimeout(200);console.log('more',await pg.$$eval('.tab',x=>x.map(t=>t.textContent.trim()).join('|')));
}
console.log('errors',JSON.stringify(errs));await b.close()})();
