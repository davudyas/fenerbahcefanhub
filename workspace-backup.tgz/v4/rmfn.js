// usage: node rmfn.js file.js name1 name2 ... -> removes top-level function declarations or const/let arrow functions with these names
const ts=require('typescript'),fs=require('fs');const [,,file,...names]=process.argv;let src=fs.readFileSync(file,'utf8');
const sf=ts.createSourceFile(file,src,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);const cuts=[];
sf.statements.forEach(st=>{if(ts.isFunctionDeclaration(st)&&st.name&&names.includes(st.name.text))cuts.push([st.getStart(sf),st.end,st.name.text]);
  if(ts.isVariableStatement(st)){const ds=st.declarationList.declarations;if(ds.length===1&&ts.isIdentifier(ds[0].name)&&names.includes(ds[0].name.text))cuts.push([st.getStart(sf),st.end,ds[0].name.text]);
    else ds.forEach(d=>{if(ts.isIdentifier(d.name)&&names.includes(d.name.text))console.error('shared declaration, skipped:',d.name.text)})}});
const miss=names.filter(n=>!cuts.some(c=>c[2]===n));if(miss.length){console.error('NOT FOUND',miss);process.exit(1)}
cuts.sort((a,b)=>b[0]-a[0]).forEach(([a,b,n])=>{src=src.slice(0,a)+src.slice(b);console.log('removed',n,b-a,'chars from',file)});fs.writeFileSync(file,src);
