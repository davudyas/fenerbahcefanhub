const TABS_FULL=[["matches","Matches"],["standings","Standings"],["games","Big Games"],["trophies","Trophies"],["legends","Legends"],["history","History"],["play","Play"]];
const TABS_MORE=[["branches","Branches"],["legends","Legends"],["history","History"],["play","Play"]];
/* ===== Extension points =====
   Features plug in here instead of wrapping core functions:
   tabs(id, list)      add or reorder tabs for a branch
   panels[tab](p, s)   draw a whole tab
   afterPanel(p, s)    adjust a tab after it is drawn
   home(p)             add sections to the All branches page
   play(p, game)       adjust a Play game after it is drawn
   matchPage(b, i)     add sections to a match page
   comm()              add cards to the fan community box
   collect(o)          add numbers to the leaderboard sync
   result(game)        result-image text for a game (return null to pass)
   kan(id, o)          add data for Kanarya about a branch
   search(list)        add entries to the search index
   szPre(b, el, ...)   take over the season view (return true)
   szAfter(b, el, ...) add cards under a simulated season */
const EXT={szPre:[],tabs:[],panels:{},afterPanel:[],home:[],play:[],matchPage:[],comm:[],collect:[],result:[],kan:[],search:[],szAfter:[]};
const runExt=(k,...a)=>EXT[k].forEach(f=>f(...a));
function tabsFor(id){const base=id==="more"?TABS_MORE.slice():TABS_FULL.filter(x=>x[0]!=="play");
  if(id!=="more"){if(id==="football")base.push(["derbies","Derbies"]);base.push(["squad","Squad"],["venue","Venue"],["play","Play"])}
  if(SPORTS[id])runExt("tabs",id,base);return base}
const $=id=>document.getElementById(id);
/* date formatting: one Intl formatter per language and format, reused (building one per date was slow) */
const DTF=new Map();
function fmtDay(d,opts){if(!(d instanceof Date)||isNaN(d))return "";const k=LOC()+JSON.stringify(opts);let f=DTF.get(k);if(!f){f=new Intl.DateTimeFormat(LOC(),opts);DTF.set(k,f)}return f.format(d)}
let current="football",tab="matches",gameFilter="All",mFilter="All",mAll=false;
function esc(s){return String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]))}
function fmtDate(iso){if(iso.length===4)return iso;const full=iso.length>7;const d=new Date((full?iso:iso+"-01")+"T12:00:00");return fmtDay(d,full?{day:"numeric",month:"short",year:"numeric"}:{month:"short",year:"numeric"})}
const CUP='<svg viewBox="0 0 20 24" aria-hidden="true"><path d="M4 1h12v2h3v3c0 3-2 5-4.5 5.4C13.6 13.5 12 14.6 11 15v3h3v2H6v-2h3v-3c-1-.4-2.6-1.5-3.5-3.6C3 11 1 9 1 6V3h3V1zm-1 4v1c0 1.6.9 2.8 2.2 3.3C5 8.4 4.9 7.3 4.9 5H3zm14 0h-1.9c0 2.3-.1 3.4-.3 4.3C16.1 8.8 17 7.6 17 6V5zM5 22h10v2H5z"/></svg>';
function render(){if(current==="home"){renderHome();return}const s=SPORTS[current];applyHero(current);
  $("sport").value=current;$("heroTr").textContent=LANG==="tr"?s.label:s.tr;$("heroTitle").textContent=t(s.title);$("heroNick").textContent=t(s.nick);$("heroLede").textContent=t(s.lede);$("kitNum").textContent=s.num;
  $("stats").innerHTML=s.stats.map(([v,k])=>`<div class="stat"><span class="v">${esc(t(v))}</span><span class="k">${esc(t(k))}</span></div>`).join("");
  $("home").innerHTML=`<span class="label">${esc(t(s.home[0]))}</span><b>${esc(t(s.home[1]))}</b>`;
  const tabs=tabsFor(current);if(!tabs.some(t=>t[0]===tab))tab=tabs[0][0];
  renderTabs(tabs);$("panel").setAttribute("aria-labelledby","tab-"+tab);renderPanel();renderNextBanner()}
/* tabs come in three groups: This season, Club, Play */
/* one row of sections; Standings and Club hold a few pages each, shown as small links under the row */
const TAB_GROUP={matches:"matches",standings:"table",race:"table",squad:"squad",games:"club",trophies:"club",records:"club",europe:"club",legends:"club",history:"club",derbies:"club",venue:"club",branches:"club",play:"play"};
const GROUP_NAME={matches:"Matches",table:"Standings",squad:"Squad",club:"Club",play:"Play"},GROUP_ORDER=["matches","table","squad","club","play"];
const lastTabOf={};
function renderTabs(tabs){const el=$("tabs");el.removeAttribute("role");el.classList.add("grouped");
  const groups=GROUP_ORDER.filter(g=>tabs.some(x=>TAB_GROUP[x[0]]===g)),cur=TAB_GROUP[tab]||groups[0],sub=tabs.filter(x=>TAB_GROUP[x[0]]===cur);lastTabOf[current+cur]=tab;
  el.innerHTML=`<div class="tgroups" role="tablist" aria-label="${t("Sections")}">${groups.map(g=>`<button class="tg ${g==="play"?"play":""}" role="tab" aria-selected="${g===cur}" data-tg="${g}">${g==="play"?`<span class="ball" aria-hidden="true"></span>`:""}${t(GROUP_NAME[g])}</button>`).join("")}</div>
   ${sub.length>1?`<div class="tsub" role="tablist" aria-label="${esc(t(GROUP_NAME[cur]))}" data-grp="${cur}">${sub.map(([id,l])=>`<button class="tab" role="tab" id="tab-${id}" aria-selected="${id===tab}" tabindex="${id===tab?0:-1}" data-tab="${id}">${t(l)}</button>`).join("")}</div>`:`<span id="tab-${sub[0][0]}" hidden></span>`}`}
function renderPanel(){if(current==="home")return;const s=SPORTS[current],p=$("panel");
  if(EXT.panels[tab])EXT.panels[tab](p,s);
  else if(tab==="play")renderPlay(p);
  else if(tab==="matches")renderMatches(p);
  else if(tab==="standings")renderStandings(p);
  else if(tab==="squad")renderSquad(p);
  else if(tab==="venue")renderVenue(p);
  else if(tab==="derbies")renderDerbies(p);
  else if(tab==="history")p.innerHTML=`<h2>${t("History")}</h2><p class="intro">${esc(tf("The milestones that made {x} at Fenerbahçe what it is.",{x:lbl(s)}))}</p>${current==="football"?seasonChart():""}<ol class="timeline">${s.history.map(([y,h,x])=>`<li><span class="yr">${y}</span><div><h3>${esc(t(h))}</h3><p>${esc(t(x))}</p></div></li>`).join("")}</ol>`;
  else if(tab==="games"){const list=s.games.filter(g=>gameFilter==="All"||g.tag===gameFilter);
    p.innerHTML=`<h2>${t("Big Games")}</h2><p class="intro">${t("Wins to remember, and one or two that still hurt.")}</p><div class="filter" role="group" aria-label="${t("Filter games")}">${s.filters.map(f=>`<button data-filter="${f}" aria-pressed="${f===gameFilter}">${esc(t(f))}</button>`).join("")}</div><div class="games">${list.map(gameCard).join("")}</div>`}
  else if(tab==="legends")renderLegends(p,s);
  else if(tab==="trophies")p.innerHTML=`<h2>${t("Trophy Cabinet")}</h2><p class="intro">${t("Major honours, with one cup drawn for every title.")}</p><div class="cabinet">${s.trophies.map(([c,n,y,era],ti)=>{const hd="";const k=parseInt(c,10),cups=(k&&k<=30)?`<div class="cups">${CUP.repeat(k)}</div>`:"";return hd+`<div class="trophy card"><span class="count">${c}</span><div><h3>${esc(t(n))}</h3><p class="years">${esc(t(y))}</p>${cups}</div></div>`}).join("")}</div>`;
  else if(tab==="branches")p.innerHTML=`<h2>${t("Branches")}</h2><p class="intro">${t("The rest of the Fenerbahçe family.")}</p><div class="branches">${s.branches.map(([n,x])=>`<article class="branch card"><h3>${esc(t(n))}</h3><p>${esc(t(x))}</p></article>`).join("")}</div>`;
  runExt("afterPanel",p,s)}
function gameCard(g){const fbHome=g.home==="Fenerbahçe",chip=g.out==="win"?`<span class="chip win">${t("Win")}</span>`:g.out==="loss"?`<span class="chip loss">${t("Loss")}</span>`:`<span class="chip loss">${t("Draw")}</span>`;
  const center=g.res?`<div class="score"><span class="team ${fbHome?"fb":""}">${esc(g.home)}</span><span class="res">${esc(g.res)}</span><span class="team ${!fbHome?"fb":""}">${esc(g.away)}</span></div>`:`<div class="title">${esc(t(g.title))}</div>`;
  return `<article class="game card"><div class="meta"><span class="label">${fmtDate(g.date)}</span>${chip}</div><span class="label" style="color:var(--ink)">${esc(t(g.comp))}</span>${center}<p>${esc(t(g.note))}</p><div class="where">${esc(t(g.where))}</div></article>`}
function renderOnThisDay(){renderNextBanner()}
function syncHash(){const h=current==="home"?"all":current+(tab==="play"?"-play":"");if(location.hash.slice(1)!==h){try{history.replaceState(null,"","#"+h)}catch(e){}}}
function setSport(id,toPlay){if(id!=="home"&&!SPORTS[id])id="home";current=id;if(id==="home"){syncHash();render();return}gameFilter="All";mFilter="All";mAll=false;if(toPlay)tab="play";if(!tabsFor(id).some(x=>x[0]===tab))tab="matches";syncHash();render()}
function fromHash(){let h=location.hash.slice(1);if(h==="games")return ["football",true];const play=h.endsWith("-play");if(play)h=h.slice(0,-5);return [!h||h==="all"||h==="home"?"home":h,play]}
$("sport").addEventListener("change",e=>setSport(e.target.value));
$("tabs").addEventListener("click",e=>{const b=e.target.closest("[data-tab]");if(!b)return;tab=b.dataset.tab;syncHash();render()});
$("tabs").addEventListener("click",e=>{const g=e.target.closest("[data-tg]");if(!g)return;const tabs=tabsFor(current),grp=g.dataset.tg,first=tabs.find(x=>TAB_GROUP[x[0]]===grp);
  const keep=lastTabOf[current+grp];tab=keep&&tabs.some(x=>x[0]===keep)?keep:first[0];syncHash();render();const f=$("tabs").querySelector(`[data-tg="${grp}"]`);if(f)f.focus()});
$("tabs").addEventListener("keydown",e=>{if(e.key!=="ArrowRight"&&e.key!=="ArrowLeft")return;const btns=[...$("tabs").querySelectorAll(".tab")],i=btns.findIndex(b=>b.dataset.tab===tab),n=btns[(i+(e.key==="ArrowRight"?1:-1)+btns.length)%btns.length];tab=n.dataset.tab;syncHash();render();$("tab-"+tab).focus()});
$("panel").addEventListener("click",e=>{const f=e.target.closest("[data-filter]");if(f){gameFilter=f.dataset.filter;renderPanel();return}
  const m=e.target.closest("[data-mf]");if(m){mFilter=m.dataset.mf;mAll=false;renderPanel();return}
  if(e.target.closest("[data-mall]")){mAll=!mAll;renderPanel();return}
  const g=e.target.closest("[data-goto]");if(g){tab=g.dataset.goto;syncHash();render();$("tabs").scrollIntoView({block:"nearest"})}});
window.addEventListener("hashchange",()=>{const [h,play]=fromHash();if((SPORTS[h]||h==="home")&&(h!==current||(play&&tab!=="play")))setSport(h,play)});

/* ---------- Matches & Standings (season snapshot) ---------- */
const DAY=864e5;
/* result marker: coloured dot, with the word for screen readers */
function rdot(o){return `<span class="rdot ${o}" role="img" aria-label="${esc(t({W:"Win",D:"Draw",L:"Loss"}[o]))}" title="${esc(t({W:"Win",D:"Draw",L:"Loss"}[o]))}"></span>`}
function isoDay(iso){return new Date(iso+"T12:00:00")}
function mDate(iso,short){if(!iso)return "";if(iso.length===7)return fmtDay(new Date(iso+"-15T12:00:00"),{month:"short",year:"numeric"});return fmtDay(isoDay(iso),short?{day:"numeric",month:"short"}:{weekday:"short",day:"numeric",month:"short",year:"numeric"})}
function outcome(r){const a=+r[4],b=+r[5];return a>b?"W":a<b?"L":"D"}
function compKey(c){return c.replace(/\s+/g,"-").toLowerCase()}
function todayISO(){const d=new Date();return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0")}
function renderMatches(p){const L=LIVE[current];if(!L){p.innerHTML="";return}
  const comps=["All",...new Set([...L.last.map(r=>r[1]),...L.next.map(r=>r[2])])];
  const today=todayISO(),fut=L.next.filter(n=>!n[0]||n[0]>=today),past=L.next.filter(n=>n[0]&&n[0]<today);
  const nx=fut[0],form=L.last.slice(0,5).reverse();
  const res=L.last.filter(r=>mFilter==="All"||r[1]===mFilter),shown=mAll?res:res.slice(0,8);
  const up=fut.filter(n=>mFilter==="All"||n[2]===mFilter);
  const wdl=L.last.reduce((a,r)=>(a[outcome(r)]++,a),{W:0,D:0,L:0});
  const hero=nx?(()=>{const days=Math.round((isoDay(nx[0])-isoDay(today))/DAY);return `<article class="nextup card"><span class="label">${t("Next up")} · ${esc(t(nx[2]))}</span>
      <div class="nx-teams"><span class="${nx[3]==="H"?"fb":""}">${esc(nx[3]==="H"?"Fenerbahçe":nx[4])}</span><span class="vs">${t("vs")}</span><span class="${nx[3]==="A"?"fb":""}">${esc(nx[3]==="A"?"Fenerbahçe":nx[4])}</span></div>
      <div class="nx-meta"><b>${mDate(nx[0])}</b>${nx[1]?`<span>${esc(nx[1])}</span>`:""}<span class="chip">${t(nx[3]==="H"?"Home":"Away")}</span><span class="chip win">${days===0?t("Today"):days===1?t("Tomorrow"):tf("In {n} days",{n:days})}</span></div>${calLinks(nx,true)}<div id="predBox" class="predbox"></div></article>`})():`<article class="nextup card"><span class="label">${t("Next up")}</span><p class="muted">${t("No upcoming fixtures in this snapshot.")}</p></article>`;
  const intro="",
    msum=`<div class="msum">${L.summary.map(([v,k])=>`<div class="mstat"><b>${esc(t(v))}</b><span>${esc(t(k))}</span></div>`).join("")}</div>`;
  const formCard=`<article class="formcard card"><span class="label">${t("Form · last five, latest on the right")}</span><div class="form">${form.map(r=>{const o=outcome(r);return `<span class="fo ${o}" title="${esc(r[3]+" "+r[4]+"-"+r[5])}">${t("res:"+o)}</span>`}).join("")}</div>
    <p class="muted">${tf(wdl.D?"{n} competitive games: <b>{w}</b> won, <b>{d}</b> drawn, <b>{l}</b> lost.":"{n} competitive games: <b>{w}</b> won, <b>{l}</b> lost.",{n:L.last.length,w:wdl.W,d:wdl.D,l:wdl.L})}</p></article>`;
  p.innerHTML=`<h2 class="vh">${t("Matches")}</h2>
  <div class="mgrid"><div class="mmain">
   <div class="mtop">${hero}</div>
   <section class="card mcard"><header class="mch"><h3>${t("Latest results")}</h3>${res.length>8?`<button class="linkbtn" data-mall>${mAll?t("Show fewer"):tf("Show all {n} results",{n:res.length})}</button>`:""}</header>
    <div class="filter mf" role="group" aria-label="${t("Filter by competition")}">${comps.map(c=>`<button data-mf="${esc(c)}" aria-pressed="${c===mFilter}">${esc(t(c))}</button>`).join("")}</div>
    <ol class="mlist srows">${shown.map(r=>srowResult(current,r,L.last.indexOf(r))).join("")||`<li class="muted">${t("Nothing in this competition yet.")}</li>`}</ol></section>
   <section class="card mcard"><header class="mch"><h3>${t("Coming up")}</h3></header><ol class="mlist srows">${up.map(n=>srowFixture(current,n,false)).join("")||`<li class="muted">${t("No fixtures listed in this competition.")}</li>`}</ol>
    <p class="fine">${esc(t(L.timeNote))}${past.length?" "+tf(past.length>1?"{n} listed fixtures have been played since this snapshot.":"1 listed fixture has been played since this snapshot.",{n:past.length}):""}</p></section>
  </div><aside class="mside">${formCard}${miniTable(current)}${miniSquad(current)}
   <section class="card mcard"><header class="mch"><h3>${t("Season so far")}</h3></header>${msum}</section></aside></div>
  ${intro}<div id="commBox"></div>${srcLine(L)}`;xMatchesExtras(L,nx)}
/* ---------- Stacked match rows (home team on top, each score next to its team) ---------- */
function sides(r){const away=r[2]==="A";return away?[[r[3],r[5]],["Fenerbahçe",r[4]]]:[["Fenerbahçe",r[4]],[r[3],r[5]]]}
function srowTeams(pair,o,withScore){const a=parseFloat(pair[0][1]),b=parseFloat(pair[1][1]);
  return `<div class="tm">${pair.map(([n,sc],k)=>{const fb=n==="Fenerbahçe",lost=withScore&&!isNaN(a)&&!isNaN(b)&&(k===0?a<b:b<a);return `<span class="tl${fb?" fb":""}">${teamBadge(n)}<span class="tn">${esc(n)}</span>${withScore?`<b class="ts${lost?" lo":""}">${esc(sc)}</b>`:""}</span>`}).join("")}</div>`}
function srowResult(b,r,i,showBr){const o=outcome(r);
  return `<li class="srow mrow ${o} mclick" data-mi="${i}" data-mb="${b}" tabindex="0" role="button" aria-label="${esc(tf("Match details: Fenerbahçe {a}–{b} {o}",{a:r[4],b:r[5],o:r[3]}))}">
    <div class="st">${showBr?`<b>${t("FT")}</b>`:`<b>${r[0]?mDate(r[0],true):esc(t(r[6]||""))}</b><span>${t("FT")}</span>`}</div>
    <div class="sm"><span class="cm">${showBr?brIcon(b):""}${esc(t(r[1]))}${r[6]&&r[0]?` · ${esc(t(r[6])).replace(/(\d)-(\d)/g,"$1\u2011$2")}`:""}</span>${srowTeams(sides(r),o,true)}</div>
    <div class="rx">${rdot(o)}</div></li>`}
function srowFixture(b,n,showBr){const pair=n[3]==="A"?[[n[4]],["Fenerbahçe"]]:[["Fenerbahçe"],[n[4]]];
  return `<li class="srow mrow fx"${showBr?` data-gosport="${b}" tabindex="0" role="button"`:""}>
    <div class="st">${showBr?`<b>${n[1]?esc(n[1]):t("TBC")}</b>`:`<b>${n[0]?mDate(n[0],true):esc(t(n[5]||""))}</b><span>${n[1]?esc(n[1]):t("TBC")}</span>`}</div>
    <div class="sm"><span class="cm">${showBr?brIcon(b):""}${esc(t(n[2]))}</span>${srowTeams(pair,"",false)}</div>
    <div class="rx">${showBr?`<span class="hl-go" aria-hidden="true">›</span>`:calLinks(n,false)}</div></li>`}
/* ---------- Small cards for the side column ---------- */
function tNs(ns,k){const r=t(ns+k);return r===ns+k?t(k):r}
function miniTable(b){const L=LIVE[b];const T=L&&L.tables.find(x=>x.rows&&x.cols.includes("P")&&x.rows.some(r=>r[0]==="Fenerbahçe"));if(!T)return "";
  const fi=T.rows.findIndex(r=>r[0]==="Fenerbahçe"),st=Math.max(0,Math.min(fi-2,T.rows.length-5)),rows=T.rows.slice(st,st+5),P=T.cols.indexOf("P"),K=T.key;
  return `<section class="card mcard mini"><header class="mch"><h3>${esc(t(T.comp))}</h3><button class="linkbtn" data-goto="standings">${t("Full table")} ›</button></header>
   <table class="mtab"><thead><tr><th>#</th><th>${t("Team")}</th><th>${esc(tNs("col:","P"))}</th><th>${esc(tNs("col:",T.cols[K]||"Pts"))}</th></tr></thead><tbody>${rows.map((r,j)=>`<tr class="${r[0]==="Fenerbahçe"?"fb":""}"><td>${st+j+1}</td><td><span class="tl">${teamBadge(r[0])}<span class="tn">${esc(r[0])}</span></span></td><td>${esc(r[P+1])}</td><td><b>${esc(r[K+1])}</b></td></tr>`).join("")}</tbody></table></section>`}
function miniSquad(b){const S=SQUADS[b];if(!S||!S.groups||!tabsFor(b).some(x=>x[0]==="squad"))return "";const n=S.groups.reduce((a,g)=>a+g[1].length,0);
  return `<section class="card mcard mini"><header class="mch"><h3>${t("Squad")}</h3><button class="linkbtn" data-goto="squad">${t("Full squad")} ›</button></header>
   <p class="muted">${S.coach?`${t("Head coach")}: <b>${esc(S.coach)}</b><br>`:""}${tf("{n} players",{n})}</p></section>`}
function srcLine(L){return `<details class="srcs"><summary>${t("Sources")}</summary><p class="fine">${L.sources.map(([x,u])=>`<a href="${esc(u)}" target="_blank" rel="noopener">${esc(t(x))}</a>`).join(" · ")}</p></details>`}
function renderStandings(p){const L=LIVE[current];if(!L){p.innerHTML="";return}
  p.innerHTML=`<h2>${t("Standings")}</h2><p class="intro">${t("Every competition Fenerbahçe are in this season. Our row is highlighted.")}</p>
  <nav class="tjump" aria-label="${t("Competitions")}">${L.tables.map((x,i)=>`<a href="#" data-tj="${i}">${esc(t(x.comp))}</a>`).join("")}</nav>
  <div class="tables">${L.tables.map((x,i)=>tableCard(x,i)).join("")}</div>${srcLine(L)}`;
  p.querySelectorAll("[data-tj]").forEach(a=>a.addEventListener("click",e=>{e.preventDefault();document.getElementById("tb-"+a.dataset.tj).scrollIntoView({behavior:"smooth",block:"start"})}))}
const tt=x=>t(x);
function tableCard(T,i){const t=T,head=`<header><h3>${esc(tt(t.comp))}</h3><span class="label">${esc(tt(t.sub||""))}</span></header>`;
  if(!t.rows)return `<article class="tcard card" id="tb-${i}">${head}<p class="tnote">${esc(tt(t.note))}</p></article>`;
  const hide=c=>["GF","GA","PF","PA"].includes(c)?' class="hm"':"";
  const ranks=t.rows.map((r,k)=>t.tied?1+t.rows.filter(x=>x[t.key+1]>r[t.key+1]).length:k+1);
  const zoneOf=pos=>t.zones?t.zones.findIndex(z=>pos>=z[0]&&pos<=z[1]):-1;
  const body=t.rows.map((r,k)=>{const pos=ranks[k],tie=t.tied&&ranks.filter(x=>x===pos).length>1,fb=r[0]==="Fenerbahçe",z=zoneOf(k+1);
    return `<tr class="${fb?"fbrow":""} ${z>=0?"z"+z:""}"><td class="pos">${pos}${tie?"=":""}</td><td class="tm">${esc(r[0])}</td>${t.cols.map((c,j)=>`<td${hide(c)}${j===t.key?' class="kc"':""}>${esc(r[j+1])}</td>`).join("")}</tr>`}).join("");
  const legend=t.zones?`<div class="zleg">${t.zones.map((z,k)=>`<span><i class="z${k}"></i>${esc(tt(z[2]))} (${z[0]}–${z[1]})</span>`).join("")}</div>`:"";
  const fbi=t.rows.findIndex(r=>r[0]==="Fenerbahçe"),fbPos=fbi>=0?ranks[fbi]:null;
  return `<article class="tcard card" id="tb-${i}">${head}${fbPos&&t.rows.some(r=>+r[1]>0)?`<div class="tpos"><b>${ordL(fbPos)}</b><span>${tf("of {n}",{n:t.rows.length})}</span></div>`:""}
   <div class="tscroll"><table class="stand"><thead><tr><th class="pos">#</th><th class="tm">${tt("Team")}</th>${t.cols.map((c,j)=>`<th${hide(c)}${j===t.key?' class="kc"':""} title="${esc(tt("colt:"+c))}">${esc(tt("col:"+c))}</th>`).join("")}</tr></thead><tbody>${body}</tbody></table></div>${legend}${t.note?`<p class="tnote">${esc(tt(t.note))}</p>`:""}</article>`}
function ordL(n){return LANG==="en"?n+ordSfx(n):LANG==="es"?n+".º":LANG==="fr"?n+(n===1?"er":"e"):RTL_LANGS.includes(LANG)?String(n):n+"."}
function ordSfx(n){const s=["th","st","nd","rd"],v=n%100;return s[(v-20)%10]||s[v]||s[0]}
