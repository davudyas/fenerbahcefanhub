const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const pg=await b.newPage({viewport:{width:1280,height:900}});
await pg.goto('file://'+process.cwd()+'/fenerbahce.html');await pg.waitForTimeout(500);
console.log(await pg.evaluate(()=>[scrollY,location.hash,document.querySelector('.hero').getBoundingClientRect().height,getComputedStyle(document.querySelector('.hero')).display,document.activeElement&&document.activeElement.id]));
await b.close()})();
