const SPORTS = {
  football: {
    label:"Football", tr:"Futbol", title:"Football", num:"07",
    nick:"Sarı Kanaryalar — the Yellow Canaries",
    lede:"The heart of the club. Fenerbahçe were the first champions of Turkey's national league in 1959 and have stayed one of the Big Three of Turkish football ever since. Latest silverware: the 2025 Super Cup, won 2–0 against Galatasaray in January 2026.",
    stats:[["19","Süper Lig titles"],["7","Turkish Cups"],["10","Super Cups"],["2nd","2025–26 league finish"]],
    home:["Home ground","Şükrü Saracoğlu Stadium, Kadıköy · 47,911 seats"],
    history:[
      ["1907","The club is founded","Ziya Songülen, Ayetullah Bey and Necip Okaner start the club in Kadıköy, on the Asian side of Istanbul. The name comes from the lighthouse (fener) at Fenerbahçe point."],
      ["1910s","Yellow and navy","The club settles on yellow and navy blue. The story goes that the colours came from daffodils growing around the lighthouse."],
      ["1923","General Harington Cup","Fenerbahçe beat a team from the British forces occupying Istanbul, a win remembered as a point of national pride."],
      ["1959","First national champions","Fenerbahçe win the first edition of the new nationwide Turkish league."],
      ["2002","The 6–0","A 6–0 home win over Galatasaray on 6 November, still the biggest margin in the derby's modern era."],
      ["2008","Champions League quarter-finals","A shootout win over Sevilla takes Fenerbahçe to the last eight, where they beat Chelsea 2–1 in the first leg."],
      ["2014","Title number 19","Fenerbahçe win the Süper Lig for the 19th time, their most recent league crown."],
      ["2026","Super Cup at the Olympic Stadium","Guendouzi and Oosterwolde score in a 2–0 final win over Galatasaray, the club's first Super Cup since 2014. The team finishes the season second, back in the Champions League."]
    ],
    games:[
      {date:"2002-11-06",comp:"Süper Lig",home:"Fenerbahçe",away:"Galatasaray",res:"6–0",out:"win",tag:"Derby",note:"The most famous night in the Intercontinental Derby. Fenerbahçe ran riot at home and the scoreline became a chant for a generation.",where:"Şükrü Saracoğlu, Istanbul"},
      {date:"2026-01-10",comp:"Super Cup final",home:"Galatasaray",away:"Fenerbahçe",res:"0–2",out:"win",tag:"Derby",note:"Guendouzi (28') and Oosterwolde (48') won the final in front of 58,397 fans. Guendouzi was man of the match.",where:"Atatürk Olympic Stadium, Istanbul"},
      {date:"2008-03-04",comp:"Champions League · Round of 16",home:"Sevilla",away:"Fenerbahçe",res:"3–2",out:"win",tag:"Europe",note:"5–5 on aggregate, then penalties. Volkan Demirel became a hero in the shootout and Fenerbahçe reached the quarter-finals.",where:"Ramón Sánchez Pizjuán, Seville"},
      {date:"2008-04",comp:"Champions League · Quarter-final",home:"Fenerbahçe",away:"Chelsea",res:"2–1",out:"win",tag:"Europe",note:"Fenerbahçe came from behind to beat Chelsea in Kadıköy. Chelsea turned it round in the return leg.",where:"Şükrü Saracoğlu, Istanbul"},
      {date:"2013-04-25",comp:"Europa League · Semi-final",home:"Fenerbahçe",away:"Benfica",res:"1–0",out:"win",tag:"Europe",note:"A first-leg win that put Fenerbahçe one step from a European final. Benfica won the second leg in Lisbon.",where:"Şükrü Saracoğlu, Istanbul"},
      {date:"2010-05-16",comp:"Süper Lig · Final day",home:"Fenerbahçe",away:"Trabzonspor",res:"1–1",out:"draw",tag:"Heartbreak",note:"A win would have sealed the title. The draw handed the championship to Bursaspor. Every club has a day it would rather forget.",where:"Şükrü Saracoğlu, Istanbul"}
    ],
    filters:["All","Derby","Europe","Heartbreak"],
    legends:[
      ["Lefter Küçükandonyadis","Forward · 1947–1964","Known as 'Ordinaryüs', the Professor. One of the greatest scorers in the club's history and a symbol of Kadıköy."],
      ["Can Bartu","Forward · 1950s–1970s","Played both football and basketball for Fenerbahçe, and later starred in Italy with Fiorentina."],
      ["Cemil Turan","Striker · 1970s","A prolific centre-forward in the title-winning sides of the 1970s."],
      ["Rıdvan Dilmen","Playmaker · 1980s–1990s","A gifted attacking midfielder, later one of Turkey's best-known football commentators."],
      ["Alex de Souza","No. 10 · 2004–2012","The Brazilian captain who led the 2011 title team. Probably the most loved foreign player in the club's history."],
      ["Volkan Demirel","Goalkeeper · 2002–2019","Spent almost two decades in goal, including the 2008 shootout against Sevilla."]
    ],
    trophies:[
      ["19","Süper Lig","1959, 1961, 1964, 1965, 1968, 1970, 1974, 1975, 1978, 1983, 1985, 1989, 1996, 2001, 2004, 2005, 2007, 2011, 2014"],
      ["7","Turkish Cup","1968, 1974, 1979, 1983, 2012, 2013, 2023"],
      ["10","Turkish Super Cup","Most recent: 2025 edition, won January 2026 against Galatasaray"],
      ["1","Balkans Cup","1968"]
    ],
    quiz:[
      {q:"In which Istanbul district was Fenerbahçe founded?",o:["Kadıköy","Beşiktaş","Taksim","Üsküdar"],a:0,e:"Kadıköy, on the Asian side. The stadium is still there."},
      {q:"What was the score in the derby against Galatasaray on 6 November 2002?",o:["4–0","6–0","3–1","5–2"],a:1,e:"6–0 at Şükrü Saracoğlu."},
      {q:"How many Süper Lig titles has Fenerbahçe won?",o:["17","21","19","24"],a:2,e:"19 since the national league started in 1959. The club also counts nine national titles from before 1959, which is why it speaks of 28."},
      {q:"What is the football team's nickname?",o:["Kara Kartallar","Sarı Kanaryalar","Cimbom","Bordo-Mavililer"],a:1,e:"Sarı Kanaryalar, the Yellow Canaries. Kara Kartallar is Beşiktaş, Cimbom is Galatasaray."},
      {q:"Who scored first in the 2025 Super Cup final?",o:["Oosterwolde","En-Nesyri","Guendouzi","Szymański"],a:2,e:"Guendouzi in the 28th minute. Oosterwolde added the second."}
    ]
  },

