const {chromium,devices}=require('playwright');
(async()=>{const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},deviceScaleFactor:1,hasTouch:true});const pg=await ctx.newPage();
const errs=[];pg.on('pageerror',e=>errs.push(e.message));
const h=process.argv[2]||'all';await pg.goto('file://'+process.cwd()+'/fenerbahce.html#'+h);await pg.waitForTimeout(700);
for(const [i,y] of [[0,0],[1,700],[2,1400]]){await pg.evaluate(y=>scrollTo(0,y),y);await pg.waitForTimeout(150);await pg.screenshot({path:`../m_${h.replace(/\W/g,'_')}_${i}.png`})}
console.log(errs);await b.close()})();
