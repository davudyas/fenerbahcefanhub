const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const pg=await b.newPage({viewport:{width:390,height:844}});const errs=[];pg.on('pageerror',e=>errs.push(e.message));
await pg.goto('file://'+process.cwd()+'/fenerbahce.html#volleyball');await pg.waitForTimeout(300);await pg.selectOption('#lang','tr');await pg.waitForTimeout(300);
await pg.evaluate(()=>{tab='race';render()});await pg.waitForTimeout(300);await pg.evaluate(()=>document.getElementById('tabs').scrollIntoView());await pg.screenshot({path:'../m_race.png'});
await pg.evaluate(()=>{setSport('football');tab='matches';render()});await pg.waitForTimeout(200);await pg.evaluate(()=>document.getElementById('wpCard').scrollIntoView({block:'center'}));await pg.screenshot({path:'../m_wpcard.png'});
await pg.evaluate(()=>{tab='play';playSel.football='live';render()});await pg.waitForTimeout(800);await pg.evaluate(()=>document.getElementById('lqArea').scrollIntoView({block:'center'}));await pg.screenshot({path:'../m_live.png'});
console.log(errs,await pg.evaluate(()=>document.documentElement.scrollWidth));await b.close()})();
