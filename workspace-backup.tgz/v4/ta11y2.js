const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const pg=await b.newPage({viewport:{width:1280,height:900}});const errs=[];pg.on('pageerror',e=>errs.push(e.message));
await pg.goto('file://'+process.cwd()+'/fenerbahce.html#all');await pg.waitForTimeout(500);
const issues=new Map();
async function check(where){const r=await pg.evaluate(()=>{const out=[];const vis=e=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0&&getComputedStyle(e).visibility!=='hidden'};
  const name=e=>(e.getAttribute('aria-label')||'').trim()||(e.getAttribute('aria-labelledby')||'').split(' ').map(i=>{const x=document.getElementById(i);return x?x.textContent:''}).join('').trim()||(e.textContent||'').trim()||(e.getAttribute('title')||'').trim()||(e.querySelector('img[alt]')||{}).alt||'';
  document.querySelectorAll('button,[role=button],a[href]').forEach(e=>{if(vis(e)&&!name(e))out.push('no name: '+e.outerHTML.slice(0,120))});
  document.querySelectorAll('input:not([type=hidden]),select,textarea').forEach(e=>{if(!vis(e))return;const lab=e.id&&document.querySelector(`label[for="${e.id}"]`);if(!e.getAttribute('aria-label')&&!e.getAttribute('aria-labelledby')&&!lab&&!e.closest('label'))out.push('unlabelled field: '+e.outerHTML.slice(0,120))});
  const ids={};document.querySelectorAll('[id]').forEach(e=>{ids[e.id]=(ids[e.id]||0)+1});Object.entries(ids).forEach(([k,v])=>{if(v>1)out.push('duplicate id: '+k)});
  document.querySelectorAll('[aria-controls],[aria-labelledby],[aria-describedby]').forEach(e=>['aria-controls','aria-labelledby','aria-describedby'].forEach(a=>{const v=e.getAttribute(a);if(v)v.split(' ').forEach(i=>{if(i&&!document.getElementById(i))out.push(a+' missing #'+i)})}));
  document.querySelectorAll('[role=tab]').forEach(e=>{if(!e.closest('[role=tablist]'))out.push('tab outside tablist: '+e.outerHTML.slice(0,80))});
  document.querySelectorAll('[aria-selected]').forEach(e=>{const r=e.getAttribute('role');if(!['tab','option','gridcell','row'].includes(r))out.push('aria-selected on role '+r+': '+e.outerHTML.slice(0,80))});
  document.querySelectorAll('svg').forEach(e=>{if(!vis(e))return;if(e.getAttribute('aria-hidden')==='true'||e.closest('[aria-hidden=true]'))return;if(!e.getAttribute('role')&&!e.closest('button,a,[role=img]'))out.push('svg without role/aria-hidden: '+(e.getAttribute('class')||'')+' in '+(e.parentElement.className||e.parentElement.tagName))});
  document.querySelectorAll('img').forEach(e=>{if(!e.hasAttribute('alt'))out.push('img without alt')});
  const hs=[...document.querySelectorAll('main h1,main h2,main h3,main h4')].filter(vis).map(h=>+h.tagName[1]);for(let i=1;i<hs.length;i++)if(hs[i]>hs[i-1]+1)out.push('heading skip h'+hs[i-1]+'→h'+hs[i]);
  return out});r.forEach(x=>{if(!issues.has(x))issues.set(x,where)})}
await check('home');for(const k of ['fixtures','predict']){await pg.click(`[data-ht=${k}]`);await check('home/'+k)}
for(const br of ['football','basketball','womens-basketball','volleyball','mens-volleyball','womens-football','more']){
  const tabs=await pg.evaluate(br=>{setSport(br);return tabsFor(br).map(x=>x[0])},br);
  for(const tb of tabs){if(tb==='play'){const gs=await pg.evaluate(()=>PLAY[current].map(x=>x[0]));for(const g of gs){try{await pg.evaluate(g=>pickGame(g),g)}catch(e){console.log("ERR",br,g,e.message.split("\n").filter(l=>/at /.test(l)).slice(0,12).join(" | "))}await pg.waitForTimeout(60);await check(br+'/play/'+g)}continue}
    await pg.evaluate(x=>{tab=x;render()},tb);await pg.waitForTimeout(60);await check(br+'/'+tb)}}
await pg.click('#setBtn');await check('settings');await pg.keyboard.press('Escape');
await pg.evaluate(()=>startTour());await check('tour');
for(const [k,v] of issues)console.log(v.padEnd(32),k);console.log('TOTAL',issues.size,errs);await b.close()})();
