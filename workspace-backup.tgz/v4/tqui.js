const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();
for(const [w,h,tag,L] of [[1280,900,'d','en'],[390,844,'m','tr'],[390,844,'a','ar']]){const pg=await b.newPage({viewport:{width:w,height:h}});const errs=[];pg.on('pageerror',e=>errs.push(e.message));
await pg.goto('file://'+process.cwd()+'/fenerbahce.html#football-play');await pg.waitForTimeout(300);if(L!=='en'){await pg.selectOption('#lang',L);await pg.waitForTimeout(300)}
await pg.evaluate(()=>{playSel.football='quiz';QZ.football=null;render()});await pg.waitForTimeout(150);
await pg.locator('#gameArea').screenshot({path:`../q_${tag}_levels.png`});
await pg.click('[data-qlv="extreme"]');await pg.waitForTimeout(1200);await pg.locator('#gameArea').screenshot({path:`../q_${tag}_q.png`});
for(let i=0;i<7;i++){await pg.click('[data-qo="0"]');await pg.waitForTimeout(60);if(i===0)await pg.locator('#gameArea').screenshot({path:`../q_${tag}_ans.png`});await pg.click('[data-q="next"]');await pg.waitForTimeout(60)}
await pg.locator('#gameArea').screenshot({path:`../q_${tag}_end.png`});
// timeout test on super hard with shortened time
await pg.click('[data-q="levels"]');await pg.click('[data-qlv="super"]');await pg.evaluate(()=>{});
console.log(tag,'launcher',await pg.evaluate(()=>document.querySelector('[data-game="quiz"]').innerText.replace(/\n/g,' | ')),errs);await pg.close()}
await b.close()})();
