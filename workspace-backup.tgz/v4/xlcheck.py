import json,re,sys,os,glob
os.chdir(os.path.dirname(os.path.abspath(__file__))+'/xl')
M=json.load(open('master.json'))
scripts={'ru':'cyr','fa':'ara'}
def chk(L,c):
    src=[l.split('\t') for l in open(f'c{c:02d}.txt').read().split('\n') if l.strip()]
    idx=[int(s[0]) if len(s)==2 else int(s[1]) for s in src]
    p=f'{L}_c{c:02d}.tsv'
    if not os.path.exists(p): return None
    rows={}
    bad=[]
    for ln in open(p).read().split('\n'):
        if not ln.strip(): continue
        a=ln.split('\t',1)
        if len(a)<2: bad.append('noTab:'+ln[:40]);continue
        rows[int(a[0])]=a[1]
    miss=[i for i in idx if i not in rows]
    extra=[i for i in rows if i not in idx]
    for i in idx:
        if i not in rows: continue
        e,t=M[i],rows[i]
        if sorted(re.findall(r'\{\w+\}',e))!=sorted(re.findall(r'\{\w+\}',t)): bad.append(f'{i} ph {e[:30]} | {t[:40]}')
        if e.count('<b>')!=t.count('<b>'): bad.append(f'{i} <b>')
        sc=scripts.get(L,'lat')
        if sc!='cyr' and re.search('[Ѐ-ӿ]',t): bad.append(f'{i} cyr')
        if sc!='ara' and re.search('[؀-ۿ]',t): bad.append(f'{i} ara')
        if re.search('[۰-۹]',t): bad.append(f'{i} fa-digit')
        if not t.strip(): bad.append(f'{i} empty')
    return len(rows),miss,extra,bad
for L in sys.argv[1].split(','):
    for c in range(10):
        r=chk(L,c)
        if r is None: continue
        n,miss,extra,bad=r
        print(L,c,n,'miss',miss[:5],len(miss),'extra',extra[:5],'bad',bad[:8])
