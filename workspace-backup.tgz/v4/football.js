/* ---------- FAN GAMES ---------- */
const norm = s => String(s).toLocaleLowerCase("tr").replace(/ç/g,"c").replace(/ğ/g,"g").replace(/ı/g,"i").replace(/ö/g,"o").replace(/ş/g,"s").replace(/ü/g,"u").replace(/æ/g,"ae").replace(/ø/g,"o").normalize("NFD").replace(/[̀-ͯ]/g,"").replace(/[^a-z ]/g," ").replace(/\s+/g," ").trim();
const shuffle = a => {a=[...a];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
const store = {get(k,d){try{const v=localStorage.getItem(k);return v==null?d:JSON.parse(v)}catch(e){return d}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const rnd=(a,b)=>a+Math.random()*(b-a);
const pickW=(items,wf)=>{const ws=items.map(wf);let t=ws.reduce((a,b)=>a+b,0)*Math.random();for(let i=0;i<items.length;i++){t-=ws[i];if(t<=0)return items[i]}return items[items.length-1]};
function lev(a,b){const m=a.length,n=b.length;if(Math.abs(m-n)>2)return 9;const d=Array.from({length:m+1},(_,i)=>[i]);for(let j=1;j<=n;j++)d[0][j]=j;for(let i=1;i<=m;i++)for(let j=1;j<=n;j++)d[i][j]=Math.min(d[i-1][j]+1,d[i][j-1]+1,d[i-1][j-1]+(a[i-1]===b[j-1]?0:1));return d[m][n]}
const closeEnough=(v,a)=>v===a||(a.length>=5&&lev(v,a)<=(a.length>=8?2:1));
const lastName=n=>{const w=n.split(" ");return w.length>1?w.slice(1).join(" "):n};
const seasonLabel=id=>id.replace("-","–");
const CUR=2026;

/* ===== Player database ===== */
const NAT={TUR:"Turkey",BRA:"Brazil",GER:"Germany",CRO:"Croatia",CHI:"Chile",URU:"Uruguay",SVK:"Slovakia",POR:"Portugal",DEN:"Denmark",NGA:"Nigeria",NED:"the Netherlands",SUI:"Switzerland",GHA:"Ghana",FRA:"France",ISR:"Israel",ARG:"Argentina",ESP:"Spain",POL:"Poland",SRB:"Serbia",BIH:"Bosnia and Herzegovina",SEN:"Senegal",MAR:"Morocco",ECU:"Ecuador",COL:"Colombia",CMR:"Cameroon",KOR:"South Korea",HUN:"Hungary",KOS:"Kosovo"};
const P_RAW=[
 ["Rüştü Reçber","GK","",86,"TUR",1994,2007,"Rüştü"],["Volkan Demirel","GK","",84,"TUR",2002,2019,"Volkan"],["Harald Schumacher","GK","",84,"GER",1988,1991,"Schumacher"],["Ederson","GK","",86,"BRA",2025,2026],["Dominik Livaković","GK","",81,"CRO",2023,2025],["Altay Bayındır","GK","",77,"TUR",2019,2023],["Mert Günok","GK","",76,"TUR",2008,2015],
 ["Gökhan Gönül","RB","",80,"TUR",2007,2017],["Mert Müldür","RB","LB",78,"TUR",2024,2026],["Önder Turacı","RB","CB",76,"TUR",2004,2010],["Fatih Akyel","RB","",77,"TUR",2002,2004],["Mauricio Isla","RB","W",77,"CHI",2017,2020],["Şener Özbayraklı","RB","",75,"TUR",2014,2018],
 ["Diego Lugano","CB","",84,"URU",2006,2011],["Edu Dracena","CB","",81,"BRA",2006,2009],["Milan Škriniar","CB","",85,"SVK",2025,2026],["Bruno Alves","CB","",81,"POR",2013,2016],["Simon Kjær","CB","",81,"DEN",2015,2017],["Joseph Yobo","CB","",79,"NGA",2010,2014],["Ogün Temizkanoğlu","CB","CM",80,"TUR",1990,2003],["Çağlar Söyüncü","CB","",79,"TUR",2023,2026],["Jayden Oosterwolde","CB","LB",79,"NED",2022,2026],["Serdar Aziz","CB","",77,"TUR",2018,2024],["Egemen Korkmaz","CB","",76,"TUR",2011,2015],["Bekir İrtegün","CB","",75,"TUR",2010,2015],
 ["Fábio Luciano","CB","",80,"BRA",2003,2006],["Kim Min-jae","CB","",84,"KOR",2021,2022,"Kim Min-jae"],["Martin Škrtel","CB","",81,"SVK",2016,2019],["Attila Szalai","CB","",79,"HUN",2020,2023],
 ["Roberto Carlos","LB","",87,"BRA",2007,2009,"Roberto Carlos"],["Ümit Özat","LB","CM",80,"TUR",1997,2007],["Ferdi Kadıoğlu","LB","RB,W",81,"TUR",2018,2024,"Ferdi"],["Hasan Ali Kaldırım","LB","",76,"TUR",2012,2019,"Hasan Ali"],["Reto Ziegler","LB","",76,"SUI",2011,2013],["Gökçek Vederson","LB","W",75,"TUR",2007,2010,"Vederson"],["Levent Mercan","LB","",75,"TUR",2024,2026],["André Santos","LB","W",79,"BRA",2009,2011],["Filip Kostić","LB","W",79,"SRB",2024,2025],
 ["Emre Belözoğlu","CM","AM",85,"TUR",2008,2020,"Emre"],["Mehmet Aurélio","CM","",81,"TUR",2003,2008,"Aurélio"],["Stephen Appiah","CM","",81,"GHA",2005,2008],["Fred","CM","",83,"BRA",2023,2026],["Mattéo Guendouzi","CM","",83,"FRA",2025,2026],["Raul Meireles","CM","",80,"POR",2012,2016],["Josef de Souza","CM","",80,"BRA",2015,2019,"Josef"],["Oğuz Çetin","CM","AM",80,"TUR",1988,1996],["Selçuk Şahin","CM","",76,"TUR",2003,2015],["İsmail Yüksek","CM","",77,"TUR",2019,2026,"İsmail"],["Cristian Baroni","CM","",78,"BRA",2009,2014,"Cristian"],["Mehmet Topal","CM","CB",78,"TUR",2012,2019],["Mehmet Topuz","CM","W",77,"TUR",2009,2014],["Claudio Maldonado","CM","",76,"CHI",2007,2009],["Deivid","CM","ST",76,"BRA",2006,2009],["Willian Arão","CM","",77,"BRA",2022,2023],["Luiz Gustavo","CM","",81,"BRA",2019,2022],
 ["Alex de Souza","AM","",91,"BRA",2004,2012,"Alex"],["Jay-Jay Okocha","AM","CM",86,"NGA",1996,1998,"Okocha"],["Rıdvan Dilmen","AM","",85,"TUR",1985,1994,"Rıdvan"],["Haim Revivo","AM","W",83,"ISR",1997,2002],["Ariel Ortega","AM","",82,"ARG",2002,2003],["Can Bartu","AM","ST",87,"TUR",1955,1970,"Can Bartu"],["Diego Ribas","AM","",80,"BRA",2014,2016,"Diego"],["Mesut Özil","AM","",79,"GER",2021,2022],["Marco Asensio","AM","W",83,"ESP",2025,2026],["Sebastian Szymański","AM","CM",81,"POL",2023,2025],["Arda Güler","AM","W",82,"TUR",2021,2023,"Arda"],["Anderson Talisca","AM","ST",84,"BRA",2025,2026,"Talisca"],["Mathieu Valbuena","AM","W",80,"FRA",2017,2019],
 ["Dušan Tadić","W","AM",84,"SRB",2023,2025],["Dirk Kuyt","W","ST",84,"NED",2012,2015],["Kerem Aktürkoğlu","W","",81,"TUR",2025,2026,"Kerem"],["İrfan Can Kahveci","W","AM",80,"TUR",2021,2026,"Kahveci"],["Miroslav Stoch","W","",79,"SVK",2011,2014],["Uğur Boral","W","",77,"TUR",2006,2011],["Tuncay Şanlı","W","ST,AM",82,"TUR",2002,2007,"Tuncay"],["Caner Erkin","W","LB",78,"TUR",2010,2021,"Caner"],["Allan Saint-Maximin","W","",80,"FRA",2024,2025],["Anthony Musaba","W","",76,"NED",2025,2026],["Nani","W","",81,"POR",2015,2016],
 ["Lefter Küçükandonyadis","ST","AM",93,"TUR",1947,1964,"Lefter"],["Cemil Turan","ST","",85,"TUR",1972,1981],["Aykut Kocaman","ST","",86,"TUR",1988,1996,"Aykut"],["Tanju Çolak","ST","",86,"TUR",1991,1993,"Tanju"],["Elvir Bolić","ST","",82,"BIH",1995,2000],["Pierre van Hooijdonk","ST","",83,"NED",2003,2005,"Van Hooijdonk"],["Nicolas Anelka","ST","",84,"FRA",2005,2006],["Mateja Kežman","ST","",81,"SRB",2006,2008],["Semih Şentürk","ST","",80,"TUR",2000,2013,"Semih"],["Serhat Akın","ST","W",78,"TUR",1998,2005,"Serhat"],["Edin Džeko","ST","",85,"BIH",2023,2025],["Robin van Persie","ST","",83,"NED",2015,2017,"Van Persie"],["Moussa Sow","ST","W",81,"SEN",2011,2017],["Emmanuel Emenike","ST","",80,"NGA",2013,2016],["Youssef En-Nesyri","ST","",82,"MAR",2024,2026],["Enner Valencia","ST","",81,"ECU",2020,2023],["Jhon Durán","ST","",80,"COL",2025,2026],["Pierre Webó","ST","",76,"CMR",2012,2014],["Mamadou Niang","ST","",81,"SEN",2010,2011],["Dani Güiza","ST","",80,"ESP",2008,2010,"Güiza"],["Vedat Muriqi","ST","",80,"KOS",2019,2020],["Márcio Nobre","ST","",78,"BRA",2003,2006]
];
const PLAYERS=P_RAW.map(([n,pos,alt,r,nat,from,to,short])=>({n,pos,alt:alt?alt.split(","):[],r,nat,from,to,short:short||lastName(n)}));
const PBY=Object.fromEntries(PLAYERS.map(p=>[p.n,p]));
const ROLE={GK:"GK",LB:"LB",RB:"RB",CB:"CB",CM:"CM",AM:"AM",LW:"W",RW:"W",LM:"W",RM:"W",ST:"ST"};
const ROLE_NAME={GK:"Goalkeeper",LB:"Left-back",RB:"Right-back",CB:"Centre-back",CM:"Central midfielder",AM:"Attacking midfielder",W:"Winger",ST:"Striker"};
const LINE_OF={GK:"GK",CB:"DF",LB:"DF",RB:"DF",CM:"MF",AM:"MF",W:"MF",ST:"FW"};
const LINE_NAME={GK:"goalkeeper",DF:"defender",MF:"midfielder",FW:"forward"};
let CUR_SQ=null;const inCurSquad=n=>{if(!CUR_SQ){CUR_SQ=new Set();try{SQUADS.football.groups.forEach(g=>g[1].forEach(x=>CUR_SQ.add(x[1])))}catch(e){}}return CUR_SQ.has(n)};
const yrs=p=>p.to>=CUR&&inCurSquad(p.n)?`${p.from}–`:`${p.from}–${String(p.to).slice(2)}`;

/* People: everyone in the season XIs plus the legends pool */
const SHORT_X={"Mehmet Aurélio":"Aurélio","Alex de Souza":"Alex","Josef de Souza":"Josef","Diego Ribas":"Diego","Cristian Baroni":"Cristian","Gökçek Vederson":"Vederson","Giuliano de Paula":"Giuliano","Bright Osayi-Samuel":"Osayi-Samuel","Miguel Crespo":"Crespo","Anderson Talisca":"Talisca","Dorgeles Nene":"Nene","Nélson Semedo":"Semedo","Kim Min-jae":"Kim Min-jae","Hasan Ali Kaldırım":"Hasan Ali","İrfan Can Kahveci":"Kahveci","İrfan Can Eğribayat":"Eğribayat"};
const EXTRA_AL={"Kim Min-jae":["kim","minjae","min jae"],"Robin van Persie":["persie","rvp"],"Pierre van Hooijdonk":["hooijdonk"],"Gökçek Vederson":["wederson"],"Mehmet Aurélio":["aurelio","marco aurelio"],"Youssef En-Nesyri":["nesyri"],"Bright Osayi-Samuel":["osayi","samuel"],"İrfan Can Kahveci":["irfan can"],"Simon Kjær":["kjaer","kjer","kjar"],"Roberto Carlos":["carlos"],"Roman Neustädter":["neustaedter"],"Márcio Nobre":["marcio"],"Dani Güiza":["dani guiza"],"Jailson":["jailson siqueira"],"Lincoln":["lincoln henrique"],"Eljif Elmas":["elif elmas"]};
const PEOPLE={};
function person(n){if(!PEOPLE[n]){const p=PBY[n];PEOPLE[n]={n,short:p?p.short:(SHORT_X[n]||lastName(n)),line:p?LINE_OF[p.pos]:null,seasons:[],p}}return PEOPLE[n]}
PLAYERS.forEach(p=>person(p.n));
SEASONS.forEach(([id,,,rows])=>rows.forEach((r,ri)=>r.forEach(n=>{const x=person(n);x.seasons.push(id);if(!x.p)x.line=x.line||["FW","MF","DF","GK"][ri]})));
function aliasesOf(n){const x=PEOPLE[n]||{short:lastName(n)},parts=norm(n).split(" "),al=new Set([norm(n),norm(x.short),norm(lastName(n))]);if(parts[0].length>=4)al.add(parts[0]);(EXTRA_AL[n]||[]).forEach(a=>al.add(norm(a)));return [...al].filter(Boolean)}
const initialsOf=n=>n.split(/[\s-]+/).map(w=>w[0].toLocaleUpperCase("tr")+".").join(" ");

function updateArcadeStats(){}
/* ===== 1. ALL-TIME XI DRAFT + LEGENDS CUP ===== */
const B4=[["GK",50,90],["LB",13,70],["CB",37,75],["CB",63,75],["RB",87,70]],B3=[["GK",50,90],["CB",24,74],["CB",50,77],["CB",76,74]];
const FORMS={
 "4-3-3":B4.concat([["CM",26,49],["CM",50,54],["CM",74,49],["LW",16,22],["ST",50,12],["RW",84,22]]),
 "4-4-2":B4.concat([["LM",12,42],["CM",37,48],["CM",63,48],["RM",88,42],["ST",36,14],["ST",64,14]]),
 "4-2-3-1":B4.concat([["CM",37,55],["CM",63,55],["LW",14,30],["AM",50,33],["RW",86,30],["ST",50,11]]),
 "4-1-4-1":B4.concat([["CM",50,58],["LM",12,37],["CM",37,40],["CM",63,40],["RM",88,37],["ST",50,12]]),
 "4-4-1-1":B4.concat([["LM",12,46],["CM",37,51],["CM",63,51],["RM",88,46],["AM",50,29],["ST",50,11]]),
 "4-3-1-2":B4.concat([["CM",26,54],["CM",50,57],["CM",74,54],["AM",50,35],["ST",36,14],["ST",64,14]]),
 "3-5-2":B3.concat([["LM",10,45],["CM",32,52],["AM",50,36],["CM",68,52],["RM",90,45],["ST",36,13],["ST",64,13]]),
 "3-4-3":B3.concat([["LM",10,48],["CM",37,52],["CM",63,52],["RM",90,48],["LW",16,20],["ST",50,12],["RW",84,20]]),
 "3-4-2-1":B3.concat([["LM",10,50],["CM",37,55],["CM",63,55],["RM",90,50],["AM",33,29],["AM",67,29],["ST",50,11]]),
 "5-3-2":[["GK",50,90],["LB",9,62],["CB",30,75],["CB",50,78],["CB",70,75],["RB",91,62],["CM",28,46],["CM",50,49],["CM",72,46],["ST",36,14],["ST",64,14]]
};
const slotRole=(form,i)=>ROLE[FORMS[form][i][0]];
function teamInfo(form,picks,cap){const idx=picks.map((p,i)=>p?i:-1).filter(i=>i>=0);
  const eff=picks.map((p,i)=>p?p.r-(p.pos===slotRole(form,i)?0:3)+(cap===i?2:0):null);
  if(!idx.length)return{eff,ovr:0,base:0};
  return{eff,ovr:idx.reduce((a,i)=>a+eff[i],0)/idx.length,base:idx.reduce((a,i)=>a+picks[i].r,0)/idx.length}}
let dr=null;
const drOrder=()=>{const S=FORMS[dr.form];return S.map((_,i)=>i).sort((a,b)=>S[b][2]-S[a][2]||S[a][1]-S[b][1])};
function newDraft(form){dr={form,picks:Array(11).fill(null),offers:{},active:0,rerolls:3,captain:null,phase:"pick",cup:null};dr.active=drOrder()[0]}
function getOffers(i){return chWith("football","rd",()=>getOffersRaw(i))}
function getOffersRaw(i){const used=new Set(dr.picks.filter(Boolean));
  if(!dr.offers[i]){const role=slotRole(dr.form,i);
    const nat=shuffle(PLAYERS.filter(p=>!used.has(p)&&p.pos===role)),alt=shuffle(PLAYERS.filter(p=>!used.has(p)&&p.pos!==role&&p.alt.includes(role)));
    const list=nat.slice(0,4);if(alt.length)list.push(alt[0]);else if(nat[4])list.push(nat[4]);dr.offers[i]=shuffle(list)}
  return dr.offers[i].filter(p=>!used.has(p))}
function pitch2(form,picks,o={}){const F=FORMS[form],info=o.info,tag=o.clickable?"button":"div";
  return `<div class="pitch2"><span class="box18 top"></span><span class="box18"></span>${F.map(([pos,x,y],i)=>{const p=picks[i],oop=p&&p.pos!==ROLE[pos];
    return `<${tag} class="ps ${p?"filled":""} ${o.active===i?"active":""} ${oop?"oop":""}" style="left:${x}%;top:${y}%" ${o.clickable?`type="button" data-slot="${i}"`:""} aria-label="${pos}${p?": "+esc(p.n):", empty"}"><span class="disc">${p?(info?info.eff[i]:p.r):pos}</span>${o.captain===i?'<span class="cap">C</span>':""}<span class="nm">${p?esc(p.short):""}</span></${tag}>`}).join("")}</div>`}
function tier(o){return o>=90?"Immortal. Lefter would approve.":o>=87?"Champions of Europe.":o>=84?"Title winners.":o>=81?"Champions League nights in Kadıköy.":o>=78?"A top-four side.":"A rebuild is needed."}
function renderDraft(p){
  if(!dr)newDraft("4-3-3");
  const info=teamInfo(dr.form,dr.picks,dr.captain),filled=dr.picks.filter(Boolean).length,best=store.get("fb-draft-best",null);
  let side="";
  if(dr.phase==="pick"){const i=dr.active,role=slotRole(dr.form,i);
    side=`<div class="box"><span class="label">Pick ${filled+1} of 11 · tap any empty spot to switch</span><h3 style="margin-top:4px">${ROLE_NAME[role]}</h3><div class="cands2">${getOffers(i).map((c,k)=>`<button class="cand2" data-cand="${k}"><span class="r">${c.r}</span><span class="info"><b>${esc(c.n)}</b><small>${c.nat} · ${yrs(c)} · ${c.pos==="W"?"Winger":c.pos}</small></span>${c.pos!==role?'<em class="tag bad">Out of position −3</em>':'<span></span>'}</button>`).join("")}</div>
      <div class="btns"><button class="btn ghost" data-d="reroll" ${dr.rerolls?"":"disabled"}>New options (${dr.rerolls} left)</button></div></div>`}
  else if(dr.phase==="captain")side=`<div class="box"><span class="label">Last step</span><h3 style="margin-top:4px">Choose your captain</h3><p style="margin-top:8px;color:var(--muted)">Tap a player on the pitch. The captain plays 2 above his rating.</p></div>`;
  else side=`<div class="box" id="cupBox"></div>`;
  const sum=`<div class="box"><span class="label">${dr.phase==="pick"?"Team so far":"Your XI"}</span><div class="ovr" style="margin-top:8px"><span class="big">${filled?info.ovr.toFixed(1):"–"}</span><dl><dt>Players</dt><dd>${filled}/11</dd><dt>Formation</dt><dd>${dr.form}</dd><dt>Best ever</dt><dd>${best!=null?Number(best).toFixed(1):"–"}</dd></dl></div></div>`;
  p.innerHTML=`<h2>All-Time XI Draft</h2><p class="intro">Pick a formation, then fill each spot from five Fenerbahçe players. Fill the spots in any order. Playing someone out of position costs 3 points, and your captain gets 2 extra. Then pick a season from 2000–01 onwards and play it through, game by game, in every competition the club entered that year.</p>
  <div class="filter" role="group" aria-label="Formation">${Object.keys(FORMS).map(f=>`<button data-form="${f}" aria-pressed="${f===dr.form}">${f}</button>`).join("")}</div>
  <div class="draft"><div>${pitch2(dr.form,dr.picks,{info,active:dr.phase==="pick"?dr.active:null,captain:dr.captain,clickable:true})}</div><div class="side">${side}${sum}</div></div>
  <p class="gnote">Ratings are fan ratings made for this game. Numbers on the pitch include position and captain adjustments. Changing formation starts a new draft.</p>`;
  p.querySelectorAll("[data-form]").forEach(b=>b.onclick=()=>{clearInterval(cupTimer);newDraft(b.dataset.form);renderPanel()});
  p.querySelectorAll("[data-slot]").forEach(b=>b.onclick=()=>{const i=+b.dataset.slot;
    if(dr.phase==="pick"&&!dr.picks[i]){dr.active=i;renderPanel()}
    else if(dr.phase==="captain"&&dr.picks[i]){dr.captain=i;dr.phase="done";const o=teamInfo(dr.form,dr.picks,i).ovr,bs=store.get("fb-draft-best",null);const nb=bs==null||o>bs;if(nb)store.set("fb-draft-best",Math.round(o*10)/10);dr.cup={round:0,results:[],live:null,opp:buildOpp(0),newBest:nb};updateArcadeStats();renderPanel()}});
  p.querySelectorAll("[data-cand]").forEach(b=>b.onclick=()=>{dr.picks[dr.active]=getOffers(dr.active)[+b.dataset.cand];const nx=drOrder().find(i=>!dr.picks[i]);if(nx==null){dr.phase="captain";dr.active=null}else dr.active=nx;renderPanel()});
  const rr=p.querySelector('[data-d="reroll"]');if(rr)rr.onclick=()=>{if(!dr.rerolls)return;dr.rerolls--;delete dr.offers[dr.active];renderPanel()};
  if(dr.phase==="done")renderCupBox();
}
const ROUNDS=[["Quarter-final","2010s Select",2010,2019,"4-4-2"],["Semi-final","2000s Select",2000,2009,"4-2-3-1"],["Final","Legends Select",0,0,"4-3-3"]];
function buildOpp(k){const [,name,a,b,form]=ROUNDS[k],used=new Set(dr.picks),picks=Array(11).fill(null);
  FORMS[form].forEach(([pos],i)=>{const role=ROLE[pos];let pool=PLAYERS.filter(p=>!used.has(p)&&p.pos===role&&(!a||(p.from<=b&&p.to>=a)));
    if(!pool.length)pool=PLAYERS.filter(p=>!used.has(p)&&p.pos===role);if(!pool.length)pool=PLAYERS.filter(p=>!used.has(p)&&p.alt.includes(role));
    pool.sort((x,y)=>y.r-x.r);const top=pool.slice(0,k===2?2:3);const pk=top[Math.floor(Math.random()*top.length)];picks[i]=pk;used.add(pk)});
  let cap=0;picks.forEach((p,i)=>{if(p.r>picks[cap].r)cap=i});return{name,form,picks,cap,info:teamInfo(form,picks,cap)}}

const SCW={ST:6,W:4,AM:4,CM:1.5,CB:.6,LB:.5,RB:.5,GK:0},ASW={AM:5,W:4,CM:3,ST:2,LB:2,RB:2,CB:.5,GK:.1};

const pensScore=p=>[p.h.filter(Boolean).length,p.a.filter(Boolean).length];
const won=res=>res.g[0]!==res.g[1]?res.g[0]>res.g[1]:pensScore(res.pens)[0]>pensScore(res.pens)[1];
function line(e,H,A){const T=e.t===0?H.name:A.name,r=a=>a[Math.floor((e.min*7+(e.s||"").length)%a.length)];
  if(e.type==="goal")return r([`GOAL! ${e.s} scores${e.a?` after a pass from ${e.a}`:""}.`,`GOAL! ${e.s} finishes it off${e.a?`. ${e.a} with the assist`:""}.`,`GOAL! What a strike from ${e.s}!`]);
  if(e.type==="save")return r([`${e.gk} saves from ${e.s}.`,`Big stop by ${e.gk}, denying ${e.s}.`,`${e.s} tests ${e.gk}, who holds on.`]);
  if(e.type==="miss")return r([`${e.s} drags it wide.`,`${e.s} heads over the bar.`,`Chance for ${e.s}, but it's blocked.`]);
  if(e.type==="card")return `Yellow card for ${e.s} (${T}).`;return e.type==="ht"?"Half-time.":"Full-time."}
let cupTimer=null;




/* ===== 3. NAME THE XI (every season) ===== */
const METRIC={minutes:"the most league minutes",starts:"the most league starts",apps:"the most league appearances (to March 2026)"};
let xi=null,xiTimer=null;const XI_TIME=150;
function newXI(id,mode){clearInterval(xiTimer);xi={id,mode:mode||(xi?xi.mode:"relaxed"),found:new Set(),hints:new Set(),wrong:0,ended:false,msg:"",cls:"",start:null}}
function xiPlayers(S){const rows=S[3],all=rows.flat(),cnt={};const al=all.map(n=>aliasesOf(n));al.forEach(a=>a.forEach(x=>cnt[x]=(cnt[x]||0)+1));
  const out=[];let k=0;rows.forEach((r,ri)=>r.forEach((n,ci)=>{const a=al[k++].filter(x=>cnt[x]===1||x===norm(n));out.push({key:ri+"-"+ci,name:n,line:["FW","MF","DF","GK"][ri],al:a})}));return out}
const xiScore=()=>Math.max(0,xi.found.size*10-xi.hints.size*4-xi.wrong*2);
const xiStars=()=>xi.found.size===11&&!xi.hints.size&&xi.wrong<=2?3:xi.found.size===11?2:xi.found.size>=6?1:0;
const xiLeft=()=>xi.start?Math.max(0,XI_TIME-Math.floor((Date.now()-xi.start)/1000)):XI_TIME;
const fmtClock=s=>`${Math.floor(s/60)}:${String(s%60).padStart(2,"0")}`;
function xiEnd(msg){if(xi.ended)return;xi.ended=true;clearInterval(xiTimer);xi.final=xiScore()+(xi.mode==="clock"&&xi.found.size===11?xiLeft():0);
  const best=store.get("fb-xi3",{}),b=best[xi.id]||{stars:0,score:0};best[xi.id]={stars:Math.max(b.stars,xiStars()),score:Math.max(b.score,xi.final)};store.set("fb-xi3",best);xi.msg=msg;xi.cls=xi.found.size===11?"good":"";updateArcadeStats()}
function renderXI(p){
  if(!xi)newXI(SEASONS[SEASONS.length-1][0]);
  const S=SEASONS.find(s=>s[0]===xi.id),si=SEASONS.indexOf(S),ps=xiPlayers(S),n=xi.found.size,best=store.get("fb-xi3",{});
  const locked=xi.ended||(xi.mode==="clock"&&!xi.start),rows=S[3],yStep=76/(rows.length-1);
  const slots=rows.map((r,ri)=>r.map((nm,ci)=>{const k=ri+"-"+ci,f=xi.found.has(k),show=f||xi.ended,x=(ci+1)/(r.length+1)*100,y=12+ri*yStep;
    const hint=xi.hints.has(k)?nm.split(/\s+/).map(w=>w[0]+"·".repeat(Math.min(w.length-1,6))).join(" "):"";
    return `<div class="ps ${f?"filled":xi.ended?"missed":""}" style="left:${x}%;top:${y}%"><span class="disc">${f?"✓":["FW","MF","DF","GK"][ri]}</span><span class="nm ${show?"":"dim"}">${show?esc(nm):esc(hint)}</span></div>`}).join("")).join("");
  const stars=s=>"★".repeat(s)+"☆".repeat(3-s);
  p.innerHTML=`<h2>Name the XI</h2><p class="intro">Every season from 2000–01 to 2025–26. Pick a season and name its eleven: the goalkeeper and ten outfield players with ${METRIC.minutes} for Fenerbahçe that year. Surnames work, and so do the names fans use. Each player is worth 10 points, a hint costs 4 and a wrong guess costs 2. Against the clock, the seconds left over are a bonus.</p>
  <div class="wtop"><div class="filter" role="group" aria-label="Mode"><button data-xm="relaxed" aria-pressed="${xi.mode==="relaxed"}">Relaxed</button><button data-xm="clock" aria-pressed="${xi.mode==="clock"}">Against the clock</button></div>
   <div class="btns" style="margin-top:0"><button class="btn ghost" data-x="prev" ${si===0?"disabled":""}>‹ Earlier</button><button class="btn ghost" data-x="rand">Random season</button><button class="btn ghost" data-x="nextS" ${si===SEASONS.length-1?"disabled":""}>Later ›</button></div></div>
  <div class="seasons" role="group" aria-label="Season">${SEASONS.map(s=>`<button data-xi="${s[0]}" aria-pressed="${s[0]===xi.id}"><b>${s[0].slice(2,4)}/${s[0].slice(5)}</b><span class="stars">${stars((best[s[0]]||{}).stars||0)}</span></button>`).join("")}</div>
  <div class="draft"><div class="pitch2 xi"><span class="box18 top"></span><span class="box18"></span>${slots}</div><div class="side"><div class="box">
    <span class="label">Most-used XI</span><h3 style="margin-top:4px">Fenerbahçe ${seasonLabel(S[0])}</h3>
    <div class="facts"><div><span class="label">Shape</span><b>${S[2]}</b></div><div><span class="label">Season</span><b>${seasonLabel(S[0])}</b></div></div>
    ${xi.mode==="clock"&&!xi.start&&!xi.ended?`<div class="btns"><button class="btn" data-x="start">Start the clock (${fmtClock(XI_TIME)})</button></div>`:
    `<form class="guessbar" id="xiForm" autocomplete="off"><input id="xiGuess" placeholder="Type a player…" aria-label="Player name" ${locked?"disabled":""}><button class="btn" ${locked?"disabled":""}>Guess</button></form>`}
    <p class="msg ${xi.cls}">${esc(xi.msg)}</p>
    <div class="xinums"><div><b class="count">${n}</b><span class="label">of 11</span></div><div><b class="count">${xi.ended?xi.final:xiScore()}</b><span class="label">points</span></div>${xi.mode==="clock"?`<div><b class="count" id="xiClock">${fmtClock(xiLeft())}</b><span class="label">left</span></div>`:""}</div>
    ${xi.ended?`<p style="margin-top:10px;font-size:22px;color:var(--yellow)">${stars(xiStars())}</p>`:""}
    <div class="btns"><button class="btn ghost" data-x="hint" ${locked?"disabled":""}>Hint (−4)</button><button class="btn ghost" data-x="give" ${locked?"disabled":""}>Give up</button><button class="btn ghost" data-x="reset">Start over</button></div>
    <p class="gnote">Picked by ${METRIC[S[1]]} in the Süper Lig. The shape comes from each player's listed position, so it may not match the tactics every week.</p>
  </div></div></div>`;
  p.querySelectorAll("[data-xi]").forEach(b=>b.onclick=()=>{newXI(b.dataset.xi);renderPanel()});
  p.querySelectorAll("[data-xm]").forEach(b=>b.onclick=()=>{newXI(xi.id,b.dataset.xm);renderPanel()});
  const on=(k,fn)=>{const b=p.querySelector(`[data-x="${k}"]`);if(b)b.onclick=fn};
  on("prev",()=>{newXI(SEASONS[si-1][0]);renderPanel()});on("nextS",()=>{newXI(SEASONS[si+1][0]);renderPanel()});
  on("rand",()=>{newXI(SEASONS[Math.floor(Math.random()*SEASONS.length)][0]);renderPanel()});
  const f=p.querySelector("#xiForm");if(f)f.onsubmit=e=>{e.preventDefault();if(locked)return;const raw=p.querySelector("#xiGuess").value,v=norm(raw);if(!v)return;
    const hit=ps.find(x=>!xi.found.has(x.key)&&x.al.some(a=>closeEnough(v,a)))||ps.find(x=>x.al.some(a=>closeEnough(v,a)));
    if(!hit){xi.wrong++;xi.msg=`${raw} isn't in this XI (−2).`;xi.cls="bad"}else if(xi.found.has(hit.key)){xi.msg=`You already have ${hit.name}.`;xi.cls=""}
    else{xi.found.add(hit.key);xi.msg=`Yes: ${hit.name}.`;xi.cls="good";if(xi.found.size===11)xiEnd("All eleven!")}
    renderPanel();const i=document.getElementById("xiGuess");if(i&&!i.disabled)i.focus()};
  on("start",()=>{xi.start=Date.now();xiTimer=setInterval(()=>{const c=document.getElementById("xiClock"),l=xiLeft();if(c)c.textContent=fmtClock(l);if(l<=0){xiEnd(`Time's up! You found ${xi.found.size} of 11.`);if(c)renderPanel()}},250);renderPanel();const i=document.getElementById("xiGuess");if(i)i.focus()});
  on("hint",()=>{const left=ps.filter(x=>!xi.found.has(x.key)&&!xi.hints.has(x.key));if(left.length){xi.hints.add(left[Math.floor(Math.random()*left.length)].key);xi.msg="Hint: first letters of one player.";xi.cls=""}renderPanel()});
  on("give",()=>{xiEnd(`You found ${xi.found.size} of 11.`);renderPanel()});on("reset",()=>{newXI(xi.id);renderPanel()});
}

/* ===== 4. PENALTIES with the wheel ===== */
const PEN30=[["Lefter Küçükandonyadis","Lefter",93],["Melih Kotanca","Melih",86],["Alex de Souza","Alex",92],["Aykut Kocaman","Aykut",90],["Naci Bastoncu","Naci",84],["Cemil Turan","Cemil",88],["Fikret Arıcan","Fikret",82],["Ogün Altıparmak","Ogün",84],["Şeref Has","Şeref",83],["Semih Şentürk","Semih",84],
 ["Tanju Çolak","Tanju",89],["Can Bartu","Can Bartu",87],["Rıdvan Dilmen","Rıdvan",86],["Selçuk Yula","Selçuk Yula",84],["Elvir Bolić","Bolić",84],["Pierre van Hooijdonk","Van Hooijdonk",91],["Tuncay Şanlı","Tuncay",85],["Moussa Sow","Sow",83],["Emmanuel Emenike","Emenike",82],["Edin Džeko","Džeko",90],
 ["Dušan Tadić","Tadić",89],["Enner Valencia","Valencia",86],["Robin van Persie","Van Persie",88],["Emre Belözoğlu","Emre",88],["Mateja Kežman","Kežman",84],["Nicolas Anelka","Anelka",87],["Youssef En-Nesyri","En-Nesyri",83],["Dirk Kuyt","Kuyt",87],["Roberto Carlos","R. Carlos",85],["Anderson Talisca","Talisca",88]].map(([n,s,r])=>({n,short:s,r}));
const GW=7.32,GH=2.44,gx=x=>15+x/GW*70,gy=y=>49.3-y/GH*37.3;
const ZC=z=>[[1.25,3.66,6.07][z%3],[1.72,0.6][Math.floor(z/3)]];
const zoneOf=(x,y)=>(y>1.22?0:3)+(x<2.44?0:x<4.88?1:2);
const ZN=["top left","top middle","top right","bottom left","bottom middle","bottom right"];
let pk=null,pkRAF=null;
function newPK(){cancelAnimationFrame(pkRAF);pkRAF=null;const full=dr&&dr.picks.every(Boolean);
  pk={phase:"setup",takers:[],respins:3,spinning:false,rot:0,lastNew:-1,gk:full?dr.picks[0]:PBY["Volkan Demirel"],you:[],them:[],turn:"shoot",t0:0,cx:3.66,cy:1.2,hist:[0,0,0,0,0,0],bias:shuffle([3.2,2,1.4,1,.8,.6]),banner:"",over:null,anim:null,tell:null,shot:null}}
const wheelItems=()=>PEN30.filter(x=>!pk.takers.includes(x));
function drawWheel(cv){if(!cv)return;const items=wheelItems(),dpr=window.devicePixelRatio||1,W=cv.clientWidth||400;cv.width=W*dpr;cv.height=W*dpr;const c=cv.getContext("2d");c.scale(dpr,dpr);
  const cs=getComputedStyle(document.documentElement),Y=cs.getPropertyValue("--yellow").trim(),N=cs.getPropertyValue("--navy-3").trim(),N2=cs.getPropertyValue("--navy").trim(),INK=cs.getPropertyValue("--ink").trim(),D="#0a1530";
  const R=W/2,seg=2*Math.PI/items.length;c.translate(R,R);
  items.forEach((it,i)=>{const a0=pk.rot+i*seg;c.beginPath();c.moveTo(0,0);c.arc(0,0,R-2,a0,a0+seg);c.closePath();c.fillStyle=i%2?Y:(i%4===0?N:N2);c.fill();c.strokeStyle="rgba(0,0,0,.25)";c.lineWidth=1;c.stroke();
    c.save();c.rotate(a0+seg/2);c.textAlign="right";c.textBaseline="middle";c.fillStyle=i%2?D:INK;const fs=Math.max(9,Math.min(15,W/(items.length*1.55)));c.font=`700 ${fs}px "Barlow Condensed", Arial Narrow, sans-serif`;c.fillText(it.short.toUpperCase(),R-12,0);c.restore()})}
function spinWheel(){if(pk.spinning||pk.takers.length>=5)return;const items=wheelItems(),seg=2*Math.PI/items.length,start=pk.rot,target=start+2*Math.PI*(5+Math.random())+Math.random()*2*Math.PI;
  const dur=matchMedia("(prefers-reduced-motion: reduce)").matches?600:3800,t0=performance.now();pk.spinning=true;renderPanel();
  const step=now=>{const k=Math.min(1,(now-t0)/dur),e=1-Math.pow(1-k,3);pk.rot=start+(target-start)*e;drawWheel(document.getElementById("wheel"));
    if(k<1)requestAnimationFrame(step);else{pk.rot=target%(2*Math.PI);const a=((-Math.PI/2-pk.rot)%(2*Math.PI)+4*Math.PI)%(2*Math.PI);const idx=Math.floor(a/seg)%items.length;pk.takers.push(items[idx]);pk.lastNew=pk.takers.length-1;pk.spinning=false;renderPanel()}};
  requestAnimationFrame(step)}
const taker=()=>pk.takers[pk.you.length%pk.takers.length];
const tri=(t,per)=>{const ph=(t%(2*per))/per;return ph<1?ph:2-ph};
function pkLoop(){if(!pk||(pk.phase!=="aimX"&&pk.phase!=="aimY")){pkRAF=null;return}const el=document.getElementById("pkAim");if(!el){pkRAF=null;return}
  const r=taker().r,now=performance.now()-pk.t0;if(pk.phase==="aimX"){pk.cx=-0.7+tri(now,(0.95+(r-75)*0.05)*1000)*(GW+1.4);pk.cy=1.15}else pk.cy=tri(now,(0.75+(r-75)*0.04)*1000)*3.2;
  el.style.left=gx(pk.cx)+"%";el.style.top=gy(pk.cy)+"%";pkRAF=requestAnimationFrame(pkLoop)}
function pkOutcome(){const y=pk.you.filter(Boolean).length,t=pk.them.filter(Boolean).length,ny=pk.you.length,nt=pk.them.length;
  if(ny<=5&&nt<=5){if(y+(5-ny)<t)return"lose";if(t+(5-nt)<y)return"win"}if(ny>=5&&ny===nt&&y!==t)return y>t?"win":"lose";return null}
function pkLock(){if(!pk||pk.over)return;if(pk.phase==="aimX"){pk.ax=pk.cx;pk.phase="aimY";pk.t0=performance.now();renderPanel()}else if(pk.phase==="aimY"){pk.ay=pk.cy;pkShoot()}}
function pkResolve(scored,banner,ball,keeper,isYou){pk.phase="anim";pk.anim={ball,keeper,played:false};renderPanel();
  setTimeout(()=>{(isYou?pk.you:pk.them).push(scored);pk.banner=banner;const o=pkOutcome();if(o){pk.over=o;if(o==="win")store.set("fb-pk-wins",store.get("fb-pk-wins",0)+1)}renderPanel();
    setTimeout(()=>{pk.anim=null;pk.banner="";if(pk.over)pk.phase="over";else if(isYou){pk.turn="save";pkPrepSave()}else{pk.turn="shoot";pk.phase="aimX";pk.t0=performance.now()}renderPanel()},1300)},620)}
function pkShoot(){const x=pk.ax,y=pk.ay;let banner,scored=false;const dive=Math.random()<.12?null:pickW([0,1,2,3,4,5],z=>1+2*pk.hist[z]),[tx,ty]=dive==null?[3.66,1]:ZC(dive),reach=dive==null?.95:1.15;
  if(x<0||x>GW)banner="Wide!";else if(y>GH)banner="Over the bar!";
  else{pk.hist[zoneOf(x,y)]++;const post=x<.14||x>GW-.14||y>GH-.12;if(post&&Math.random()<.4)banner="Off the woodwork!";else if(Math.hypot(x-tx,(y-ty)*1.25)<reach)banner="Saved!";else{banner="Goal!";scored=true}}
  pkResolve(scored,banner,[x,Math.min(y,3.3)],[tx,ty,dive],true)}
function pkPrepSave(){const z=pickW([0,1,2,3,4,5],i=>pk.bias[i]),[cx,cy]=ZC(z);let x=clamp(cx+rnd(-.95,.95),.15,GW-.15),y=clamp(cy+rnd(-.45,.45),.15,GH-.12);
  const miss=Math.random()<.08;if(miss){if(Math.random()<.5)y=2.75;else x=x<GW/2?-.35:GW+.35}
  const col=z%3,tc=Math.random()<.62?col:[0,1,2].filter(c=>c!==col)[Math.floor(Math.random()*2)];pk.shot={x,y,miss};pk.tell=["the left side","the middle","the right side"][tc];pk.phase="dive"}
function pkDive(z){if(pk.phase!=="dive")return;const [tx,ty]=ZC(z),{x,y,miss}=pk.shot,saved=!miss&&Math.hypot(x-tx,(y-ty)*1.25)<1.15;
  pkResolve(!miss&&!saved,miss?(y>GH?"Over the bar!":"Wide!"):saved?"You saved it!":"They score.",[x,y],[tx,ty,z],false)}
function renderPK(p){
  if(!pk)newPK();cancelAnimationFrame(pkRAF);pkRAF=null;
  if(pk.phase==="setup"){const full=pk.takers.length>=5;
    p.innerHTML=`<h2>Penalty Shootout</h2><p class="intro">First, spin the wheel to pick your five penalty takers. The wheel holds 30 of the greatest goalscorers in Fenerbahçe history, and each one has a composure rating: the higher it is, the slower your aiming marker moves. You get three re-spins.</p>
    <div class="pk-wrap"><div><div class="wheelwrap"><span class="ptr" aria-hidden="true"></span><canvas id="wheel" aria-label="Wheel of 30 Fenerbahçe goalscorers"></canvas><span class="hub">${full?"5/5":"SPIN"}</span></div></div>
    <div class="side"><div class="box"><span class="label">Your takers</span><ol class="takers">${[0,1,2,3,4].map(i=>{const t=pk.takers[i];return t?`<li class="${i===pk.lastNew?"new":""}"><b>${esc(t.n)}</b><em>${t.r}</em></li>`:`<li class="empty"><span>Spin to fill</span><span></span></li>`}).join("")}</ol>
      <div class="btns"><button class="btn" data-pk="spin" ${pk.spinning||full?"disabled":""}>${pk.spinning?"Spinning…":"Spin the wheel"}</button><button class="btn ghost" data-pk="respin" ${pk.spinning||!pk.takers.length||!pk.respins?"disabled":""}>Re-spin last (${pk.respins} left)</button></div>
      <div class="btns"><button class="btn ${full?"":"ghost"}" data-pk="go" ${full&&!pk.spinning?"":"disabled"}>Start the shootout</button></div>
      <p class="gnote">In goal: ${esc(pk.gk.n)}${dr&&dr.picks.every(Boolean)?" (from your drafted XI)":""}. Composure ratings are made up for this game.</p></div></div></div>`;
    requestAnimationFrame(()=>drawWheel(document.getElementById("wheel")));
    const on=(k,f)=>{const b=p.querySelector(`[data-pk="${k}"]`);if(b)b.onclick=f};
    on("spin",spinWheel);on("respin",()=>{if(!pk.respins||pk.spinning)return;pk.respins--;pk.takers.pop();pk.lastNew=-1;spinWheel()});
    on("go",()=>{pk.phase="aimX";pk.t0=performance.now();renderPanel()});return}
  const dots=a=>{let h="";for(let i=0;i<Math.max(5,a.length);i++)h+=`<i class="dot ${a[i]===true?"g":a[i]===false?"m":""}"></i>`;return h};
  const t=taker(),aim=pk.phase==="aimX"||pk.phase==="aimY",youKeep=pk.turn==="save";
  const rot=k=>{if(!k||k[2]==null)return 0;const c=k[2]%3,top=k[2]<3;return c===1?0:(c===0?-1:1)*(top?70:55)};
  const kp=pk.anim&&pk.anim.played?pk.anim.keeper:[3.66,.95],bp=pk.anim&&pk.anim.played?pk.anim.ball:null;
  let hud;
  if(pk.over)hud=`<span class="label">Full time</span><p class="msg ${pk.over==="win"?"good":"bad"}" style="font-size:20px">${pk.over==="win"?"Fenerbahçe win the shootout!":"The opponents win this one."}</p>`;
  else if(pk.turn==="shoot")hud=`<span class="label">Your kick ${pk.you.length+1}${pk.you.length>=5?" · sudden death":""}</span><h3 style="margin-top:4px">${esc(t.n)} <span style="color:var(--muted);font-size:16px">composure ${t.r}</span></h3>
     <p style="margin-top:8px">${pk.phase==="aimX"?"Step 1: stop the marker to set the direction.":pk.phase==="aimY"?"Step 2: stop it again to set the height. Too high and it goes over.":"…"}</p>
     <p class="gnote">Tap the pitch, press Space or use the button. The keeper learns where you like to shoot.</p>${aim?`<div class="btns"><button class="btn" data-pk="lock">${pk.phase==="aimX"?"Set direction":"Shoot"}</button></div>`:""}`;
  else hud=`<span class="label">You're in goal · ${esc(pk.gk.n)}</span><h3 style="margin-top:4px">Their taker is eyeing ${pk.tell||"…"}</h3><p class="gnote">The read is right a bit more often than not. Tap where you want to dive.</p>`;
  p.innerHTML=`<h2>Penalty Shootout</h2><p class="intro">Five kicks each, then sudden death. To shoot, time two taps: one for direction, one for height. In goal, read the taker and dive.</p>
  <div class="pk-wrap"><div class="pk-field" id="pkf"><div class="pk-line"></div><div class="pk-box"></div><div class="pk-spot"></div>
    <div class="pk-goal">${pk.phase==="dive"?[0,1,2,3,4,5].map(z=>`<button class="pk-zone" data-z="${z}" aria-label="Dive ${ZN[z]}"></button>`).join(""):""}</div>
    <div class="pk-keeper ${youKeep?"":"them"} ${pk.anim&&pk.anim.played?"notrans":""}" id="pkk" style="left:${gx(kp[0])}%;top:${gy(kp[1])}%;--rot:${pk.anim&&pk.anim.played?rot(pk.anim.keeper):0}deg"></div>
    <div class="pk-ball ${bp?"notrans":""}" id="pkb" style="left:${bp?gx(bp[0]):50}%;top:${bp?gy(bp[1]):88}%;${bp?"width:2.6%":""}"></div>
    ${aim?`<div class="pk-aim" id="pkAim" style="left:${gx(pk.cx)}%;top:${gy(pk.cy)}%"></div>${pk.phase==="aimY"?`<div class="pk-guide" style="left:${gx(pk.ax)}%"></div>`:""}`:""}
    <div class="pk-banner">${esc(pk.banner)}</div></div>
  <div class="side"><div class="box">${hud}</div><div class="box">
    <div class="pk-score"><div class="pk-team"><span style="color:var(--yellow)">Fener</span><div class="dots">${dots(pk.you)}</div><b>${pk.you.filter(Boolean).length}</b></div>
    <div class="pk-team"><span>Opponents</span><div class="dots">${dots(pk.them)}</div><b>${pk.them.filter(Boolean).length}</b></div></div>
    <p class="gnote">Order: ${pk.takers.map((x,i)=>`${i+1}. ${esc(x.short)}`).join(" · ")}</p>
    <div class="btns"><button class="btn ${pk.over?"":"ghost"}" data-pk="new">${pk.over?"New shootout":"Restart"}</button>${pk.over?`<button class="btn ghost" data-pk="same">Same takers</button>`:""}</div>
    <p class="gnote">Shootouts won: ${store.get("fb-pk-wins",0)}</p></div></div></div>`;
  p.querySelectorAll("[data-z]").forEach(b=>b.onclick=e=>{e.stopPropagation();pkDive(+b.dataset.z)});
  const lb=p.querySelector('[data-pk="lock"]');if(lb)lb.onclick=pkLock;
  p.querySelector('[data-pk="new"]').onclick=()=>{newPK();renderPanel()};
  const sm=p.querySelector('[data-pk="same"]');if(sm)sm.onclick=()=>{const tk=pk.takers;newPK();pk.takers=tk;pk.phase="aimX";pk.t0=performance.now();renderPanel()};
  p.querySelector("#pkf").onpointerdown=e=>{if(aim){e.preventDefault();pkLock()}};
  if(pk.anim&&!pk.anim.played){const a=pk.anim,b=p.querySelector("#pkb"),k=p.querySelector("#pkk");a.played=true;
    requestAnimationFrame(()=>requestAnimationFrame(()=>{b.style.left=gx(a.ball[0])+"%";b.style.top=gy(a.ball[1])+"%";b.style.width="2.6%";k.style.left=gx(a.keeper[0])+"%";k.style.top=gy(a.keeper[1])+"%";k.style.setProperty("--rot",rot(a.keeper)+"deg")}))}
  if(aim)pkRAF=requestAnimationFrame(pkLoop);
}

/* ===== 5. WHO AM I? (hard) ===== */
const SPECIAL={"Lefter Küçükandonyadis":"Fans called me 'Ordinaryüs', the Professor.","Can Bartu":"I also played basketball for the club, and later played in Italy.","Rıdvan Dilmen":"I later became one of Turkey's best-known TV pundits.","Aykut Kocaman":"I scored goals here and later coached the club to the 2012 cup.","Harald Schumacher":"I played in two World Cup finals for West Germany.","Jay-Jay Okocha":"I arrived from Eintracht Frankfurt and loved a step-over.","Tanju Çolak":"I crossed the city from Galatasaray to score for Fenerbahçe.","Haim Revivo":"I came from Celta Vigo and later played for Galatasaray.","Elvir Bolić":"I scored a famous Champions League winner at Old Trafford.","Oğuz Çetin":"I was a creative midfielder of the late 1980s and early 1990s.","Cemil Turan":"I was the goal machine of the 1970s title teams."};
let who=null;
function whoClues(x){const c=[];
  if(x.seasons.length){const s=x.seasons[Math.floor(Math.random()*x.seasons.length)],xi=SEASONS.find(q=>q[0]===s)[3].flat().filter(n=>n!==x.n),m=shuffle(xi).slice(0,2);
    c.push(`In ${seasonLabel(s)} I was in Fenerbahçe's most-used XI with ${m[0]} and ${m[1]}.`);
    c.push(x.seasons.length===1?"I was a regular for just one season.":`I was a regular in ${x.seasons.length} different seasons, between ${seasonLabel(x.seasons[0])} and ${seasonLabel(x.seasons[x.seasons.length-1])}.`);
    c.push(`I mostly played as a ${LINE_NAME[x.line]}${x.p?` and I'm from ${NAT[x.p.nat]}`:""}.`)}
  else{const p=x.p,m=shuffle(PLAYERS.filter(q=>together(p,q)&&q.r>=80)).slice(0,2);
    c.push(m.length?`At Fenerbahçe I played alongside ${m.map(q=>q.n).join(" and ")}.`:`My Fenerbahçe career started in ${p.from<1960?"the 1940s or 1950s":"the "+String(p.from).slice(0,3)+"0s"}.`);
    c.push(`My Fenerbahçe years were roughly ${p.from}–${p.to}.`);
    c.push(SPECIAL[x.n]||`I'm a ${ROLE_NAME[p.pos].toLowerCase()} from ${NAT[p.nat]}.`)}
  c.push(`My initials are ${initialsOf(x.n)}`);return c}
const together=(a,b)=>a!==b&&a.from<=b.to&&b.from<=a.to;
/* ===== 6. TIMELINE (hard) ===== */
const ARRIVALS=[["Alex de Souza",2004],["Roberto Carlos",2007],["Jay-Jay Okocha",1996],["Nicolas Anelka",2005],["Dirk Kuyt",2012],["Robin van Persie",2015],["Edin Džeko",2023],["Dušan Tadić",2023],["Milan Škriniar",2025],["Mattéo Guendouzi",2025],["Ederson",2025],["Mateja Kežman",2006],["Diego Lugano",2006],["Stephen Appiah",2005],["Harald Schumacher",1988],["Pierre van Hooijdonk",2003],["Raul Meireles",2012],["Diego Ribas",2014],["Fred",2023],["Mesut Özil",2021],["Marco Asensio",2025],["Haim Revivo",1997],["Ariel Ortega",2002],["Youssef En-Nesyri",2024],["Bruno Alves",2013],["Simon Kjær",2015],["Dominik Livaković",2023],["Sebastian Szymański",2023]];
function tlDeck(){const ev=[],seen=new Set(),add=(y,t,s)=>{if(!seen.has(t)){seen.add(t);ev.push({y,t,s})}};
  Object.values(SPORTS).forEach(s=>{(s.history||[]).forEach(([y,t])=>{if(/^\d{4}$/.test(y))add(+y,t,s.label)});(s.games||[]).forEach(g=>add(+g.date.slice(0,4),g.res?`${g.home} ${g.res} ${g.away} (${g.comp})`:`${g.title} (${g.comp})`,s.label))});
  ARRIVALS.forEach(([n,y])=>add(y,`${n} signs for Fenerbahçe`,"Transfers"));
  shuffle(Object.values(PEOPLE).filter(x=>x.seasons.length&&x.seasons[0]!=="2000-01")).slice(0,45).forEach(x=>add(+x.seasons[0].slice(0,4),`${x.n} becomes a first-team regular (season starts this year)`,"Squads"));
  return shuffle(ev)}
