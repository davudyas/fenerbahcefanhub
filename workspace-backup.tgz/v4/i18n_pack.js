/* ===== Language packs: translations load on demand, so English visitors don't download them ===== */
const PACK_OK={},PACK_WAIT={};
function LANGPACK(L,p){const D=DICT[L],Lo=LOWER[L];Object.assign(D,p.d);
  Object.keys(p.d).forEach(en=>{const k=en.toLowerCase();if(!Lo[k])Lo[k]=[en,D[en]]});(p.o||[]).forEach(([k,en,x])=>Lo[k]=[en,x]);
  /* newer language packs bring their own sentence templates, matched to I18N_PATS by position */
  if(p.p){PATTERNS[L]=p.p.filter(([i])=>I18N_PATS[i]).map(([i,tpl])=>[I18N_PATS[i][0],packTpl(i,tpl)]);PATTERNS[L].push([/^.+$/,m=>trDate(m[0])])}
  PACK_OK[L]=true;TCACHE.clear()}
/* "*" reuses the language-neutral helper of that pattern; #n turns "two"/"a" into a number, %n turns "24 November" into a local date */
function packTpl(i,tpl){if(tpl==="*")return I18N_PATS[i][2];if(/[#%]\d/.test(tpl))return m=>fillTpl(tpl.replace(/#(\d)/g,(_,k)=>String(NUMW(m[+k]))).replace(/%(\d)/g,(_,k)=>liveDay(m[+k])),m);return tpl}
function loadPack(L){if(L==="en"||PACK_OK[L])return Promise.resolve(true);if(PACK_WAIT[L])return PACK_WAIT[L];
  PACK_WAIT[L]=new Promise(res=>{const s=document.createElement("script");s.src=`lang-${L}.js`;s.async=true;s.onload=()=>res(!!PACK_OK[L]);s.onerror=()=>{delete PACK_WAIT[L];res(false)};document.head.appendChild(s)});return PACK_WAIT[L]}
function buildI18n(){
  ["tr","de"].forEach((L,li)=>{PATTERNS[L]=I18N_PATS.map(p=>[p[0],p[1+li]]).filter(p=>p[1]!=null);PATTERNS[L].push([/^.+$/,m=>trDate(m[0])])});
  XLANGS.forEach((L,li)=>{PATTERNS[L]=I18N_PATS.map((p,i)=>{const x=I18N_PATS_X[i];return [p[0],x?x[li]:p[2]]}).filter(p=>p[1]!=null);PATTERNS[L].push([/^.+$/,m=>trDate(m[0])])})}
function applyLang(){staticTexts();render();renderOnThisDay();if(typeof kanRender==="function")kanRender()}
function setLang(c){if(window.loadFont&&FONT_EXTRA[c])loadFont(FONT_EXTRA[c]);if(!LANGS.some(l=>l[0]===c))return;const prev=LANG;
  if(c==="en"||PACK_OK[c]){LANG=c;try{localStorage.setItem("fb-lang",c)}catch(e){}applyLang();return}
  document.documentElement.classList.add("lwait");
  loadPack(c).then(ok=>{document.documentElement.classList.remove("lwait");if(!ok){$("lang").value=prev;return}LANG=c;try{localStorage.setItem("fb-lang",c)}catch(e){}applyLang()})}
function initLang(){if(window.loadFont&&FONT_EXTRA[LANG])loadFont(FONT_EXTRA[LANG]);buildI18n();$("lang").innerHTML=LANGS.map(([c,n])=>`<option value="${c}">${n}</option>`).join("");$("lang").addEventListener("change",e=>setLang(e.target.value));
  const want=LANG;if(want!=="en"&&!PACK_OK[want]){LANG="en";document.documentElement.classList.add("lwait");const done=()=>document.documentElement.classList.remove("lwait");
    const tm=setTimeout(done,2500);loadPack(want).then(ok=>{clearTimeout(tm);done();if(ok){LANG=want;applyLang()}})}
  staticTexts();watchPanel()}
