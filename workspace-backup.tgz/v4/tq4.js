const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const pg=await b.newPage();await pg.goto('file://'+process.cwd()+'/fenerbahce_full.html');await pg.waitForTimeout(400);
console.log(await pg.evaluate(()=>["basketball","womens-basketball","volleyball","mens-volleyball","womens-football"].map(b=>{const S=SPORTS[b];return "### "+b+"\nSTATS "+JSON.stringify(S.stats)+"\nHIST "+S.history.map(h=>h.join(" | ")).join("\n")+"\nLEG "+S.legends.map(l=>l[0]+": "+l[1]+" — "+(l[3]||[]).join("; ")).join("\n")+"\nGAMES "+S.games.map(g=>g.date+" "+g.home+" "+(g.res||g.title)+" "+g.away+" ("+g.comp+")").join("\n")}).join("\n\n")));
await b.close()})();
