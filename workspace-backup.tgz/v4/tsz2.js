const gzAuto=require('./gzauto.js');
const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const pg=await b.newPage({viewport:{width:1280,height:900}});const errs=[];pg.on('pageerror',e=>errs.push(e.message+' '+(e.stack||'').split('\n')[1]));
await pg.goto('file://'+process.cwd()+'/fenerbahce.html#football-play');await pg.waitForTimeout(300);
const G={football:'draft',basketball:'draft5','womens-basketball':'draft5',volleyball:'draft6','mens-volleyball':'draft6','womens-football':'draft11'};
for(const br of Object.keys(G)){await pg.selectOption('#sport',br);await pg.evaluate(x=>{tab=x;syncHash();render()},'play');await pg.evaluate(g=>pickGame(g),G[br]);
 if(br==='football'){await gzAuto(pg);}
 else{let n=0;while(await pg.$('[data-tc="0"]')&&n<20){await pg.click('[data-tc="0"]');n++;await pg.waitForTimeout(10)}}
 await pg.waitForTimeout(100);
 const years=await pg.$$eval('[data-szy]',x=>x.map(e=>e.dataset.szy));
 const pick=[years[0],years[Math.floor(years.length/2)],years[years.length-1]];
 for(const y of pick){await pg.click(`[data-szy="${y}"]`);const info=await pg.evaluate(()=>document.querySelector('.szinfo')?.innerText.replace(/\n/g,' | '));
  await pg.click('[data-sz="start"]');await pg.click('[data-sz="all"]');await pg.waitForTimeout(50);
  const sum=await pg.evaluate(()=>document.querySelector('.szsum')?.innerText.replace(/\n+/g,' | '));const n=await pg.evaluate(()=>document.querySelector('.szhead .muted')?.innerText);
  console.log(br,y,'::',info,'=>',sum,'·',n);await pg.click('[data-sz="other"]')}
}
console.log('errors',errs);await b.close()})();
