const {chromium}=require('playwright');const path=require('path');
(async()=>{const b=await chromium.launch();const errs=[];for(const [W,H] of [[1100,700],[375,700]]){const pg=await b.newPage({viewport:{width:W,height:H}});pg.on('pageerror',e=>errs.push(e.message));await pg.route('**/*',r=>r.request().url().startsWith('file:')?r.continue():r.abort());
await pg.goto('file://'+path.resolve(__dirname,'../site/index.html'));await pg.waitForTimeout(800);await pg.click('#setBtn');await pg.waitForTimeout(400);
console.log(W,await pg.evaluate(()=>{const p=$('setPanel'),r=p.getBoundingClientRect();return {bottom:Math.round(r.bottom),vh:innerHeight,scrollH:p.scrollHeight,clientH:p.clientHeight,scrolls:p.scrollHeight>p.clientHeight}}));
await pg.screenshot({path:path.resolve(__dirname,'../scroll_'+W+'.png')})}
console.log('errs',errs);await b.close()})();
