/* in-page stand-in for supabase-js; all state lives in the Node hub (window.__hub) */
(function(){let cidN=0;const CH={};
window.__mockRecv=function(cid,kind,a){const ch=CH[cid];if(!ch)return;
  if(kind==="pg"){ch.L.filter(l=>l.type==="postgres_changes").forEach(l=>l.cb(a))}
  else if(kind==="bc"){ch.L.filter(l=>l.type==="broadcast").forEach(l=>l.cb({type:"broadcast",event:a.event,payload:a.payload}))}
  else if(kind==="pres"){ch.state=a;ch.L.filter(l=>l.type==="presence").forEach(l=>l.cb({}))}};
function q(table){const st={table,f:[],op:"select"};const b={
  select(){return b},order(){return b},insert(row){st.op="insert";st.row=row;return b},eq(k,v){st.f.push(["eq",k,v]);return b},in(k,v){st.f.push(["in",k,v]);return b},limit(){return b},
  maybeSingle(){st.single=true;return b},upsert(row){st.op="upsert";st.row=row;return b},
  then(res,rej){return window.__hub(st).then(r=>({data:r.data,error:r.error||null})).then(res,rej)}};return b}
window.supabase={createClient(url,key,opts){return {
  auth:{async getSession(){const j=localStorage.getItem("mock-sess");const u=j?JSON.parse(j):null;return {data:{session:u?{user:{id:u.id,email:u.email||"",is_anonymous:!u.email}}:null}}},
        async signInAnonymously(){const u="u-"+Math.random().toString(36).slice(2,10);localStorage.setItem("mock-sess",JSON.stringify({id:u}));await window.__hub({op:"auth",uid:u});return {data:{user:{id:u}},error:null}},
        async updateUser(a){const j=JSON.parse(localStorage.getItem("mock-sess")||"null");if(!j)return {error:{message:"no session"}};
          const r=await window.__hub({op:"upd",uid:j.id,email:a.email,password:a.password});if(r.error)return {data:{},error:r.error};if(a.email){j.email=a.email;localStorage.setItem("mock-sess",JSON.stringify(j))}return {data:{user:{id:j.id}},error:null}},
        async signInWithPassword(a){const r=await window.__hub({op:"login",email:a.email,password:a.password});if(r.error)return {data:{},error:r.error};localStorage.setItem("mock-sess",JSON.stringify({id:r.uid,email:a.email}));await window.__hub({op:"auth",uid:r.uid});return {data:{user:{id:r.uid}},error:null}},
        async signOut(){localStorage.removeItem("mock-sess");return {error:null}}},
  from:q,
  rpc(name,args){return window.__hub({op:"rpc",name,args}).then(r=>({data:r.data,error:r.error||null}))},
  channel(name,o){const cid="c"+(++cidN)+"-"+Math.random().toString(36).slice(2,6);const ch={cid,name,L:[],state:{},key:o&&o.config&&o.config.presence&&o.config.presence.key,
    on(type,filter,cb){ch.L.push({type,filter,cb});return ch},
    subscribe(cb){const pg=ch.L.find(l=>l.type==="postgres_changes");window.__hub({op:"sub",cid,name,pg:pg?pg.filter:null}).then(()=>cb&&cb("SUBSCRIBED"));return ch},
    async send(m){await window.__hub({op:"send",name,event:m.event,payload:m.payload,cid});return "ok"},
    async track(meta){await window.__hub({op:"track",name,key:ch.key,meta,cid});return "ok"},
    async untrack(){await window.__hub({op:"untrack",name,key:ch.key});return "ok"},
    presenceState(){return ch.state}};CH[cid]=ch;return ch},
  async removeChannel(ch){delete CH[ch.cid];await window.__hub({op:"unsub",cid:ch.cid,name:ch.name,key:ch.key});return "ok"}}}};
})();
