window.__mkMock=function(uid){
 const me=Math.random().toString(36).slice(2,10),bc=new BroadcastChannel('mockroom');
 function mkRoom(name){const L={topics:{},peerCbs:[],peers:{},my:{}};
  const snap=()=>Object.values(L.peers).map(p=>Object.freeze({...p,isMe:p.peer===me,sameTab:p.peer===me}));
  const fire=(joined=[],left=[])=>{const P=snap();setTimeout(()=>L.peerCbs.forEach(f=>f({peers:P,joined,left,updated:[]})),0)};
  const upd=(peer,by,presence)=>{const isNew=!L.peers[peer];L.peers[peer]={peer,by,presence,kind:"viewer",guest:false,updatedAt:Date.now()};fire(isNew?[L.peers[peer]]:[])};
  const R={name,emit:async(topic,data)=>{const m={room:name,kind:"emit",topic,data,peer:me,by:uid};bc.postMessage(m);recv(m)},
   on:(topic,f)=>{(L.topics[topic]=L.topics[topic]||[]).push(f);return ()=>{L.topics[topic]=L.topics[topic].filter(x=>x!==f)}},
   presence:async(patch)=>{Object.entries(patch).forEach(([k,v])=>{if(v===null)delete L.my[k];else L.my[k]=v});upd(me,uid,{...L.my});bc.postMessage({room:name,kind:"pres",peer:me,by:uid,presence:{...L.my}})},
   peers:()=>snap(),onPeers:(f)=>{L.peerCbs.push(f);setTimeout(()=>f({peers:snap(),joined:snap(),left:[],updated:[]}),0);return ()=>{L.peerCbs=L.peerCbs.filter(x=>x!==f)}},
   connected:()=>true,onConnection:f=>{setTimeout(()=>f(true),0);return ()=>{}},leave:async()=>{bc.postMessage({room:name,kind:"leave",peer:me});delete rooms[name]}};
  function recv(m){if(m.kind==="emit"){(L.topics[m.topic]||[]).forEach(f=>f({topic:m.topic,data:m.data,peer:m.peer,by:m.by,isMe:m.peer===me,sameTab:m.peer===me,kind:"viewer",guest:false}))}
   else if(m.kind==="pres")upd(m.peer,m.by,m.presence);else if(m.kind==="leave"){const p=L.peers[m.peer];delete L.peers[m.peer];fire([],p?[p]:[])}else if(m.kind==="hello"&&Object.keys(L.my).length)bc.postMessage({room:name,kind:"pres",peer:me,by:uid,presence:{...L.my}})}
  R._recv=recv;upd(me,uid,{});bc.postMessage({room:name,kind:"pres",peer:me,by:uid,presence:{}});bc.postMessage({room:name,kind:"hello",peer:me});return R}
 const rooms={};bc.onmessage=e=>{const m=e.data;const r=rooms[m.room];if(r)r._recv(m)};
 const lobby=rooms["lobby"]=mkRoom("lobby");lobby.join=async n=>rooms[n]||(rooms[n]=mkRoom(n));return lobby};
