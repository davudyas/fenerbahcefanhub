const gzAuto=require('./gzauto.js');
const {chromium}=require('playwright');
const LANG=process.argv[2]||'tr';
(async()=>{const b=await chromium.launch();const pg=await b.newPage({viewport:{width:1280,height:900}});const errs=[];pg.on('pageerror',e=>errs.push(e.message));
await pg.goto('file://'+process.cwd()+'/fenerbahce.html#football');await pg.waitForTimeout(200);
await pg.selectOption('#lang',LANG);await pg.waitForTimeout(150);
const EN=/\b(the|and|of|to|you|your|is|in|with|from|for|was|were|my|I|a|an|by|on|at|after|before|won|lost|played|next|score|points?|best|new|guess|clue|pick|team|player|season|round|final)\b/;
const left=new Map();
async function collect(where){const xs=await pg.evaluate(()=>{const out=[];const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);while(w.nextNode()){const n=w.currentNode,p=n.parentElement;if(!p||p.closest('script,style,textarea,[translate=no],select'))continue;if(p.offsetParent===null&&getComputedStyle(p).position!=='fixed')continue;const s=n.nodeValue.trim();if(s)out.push(s)}
  document.querySelectorAll('[placeholder],[aria-label]').forEach(e=>{if(!e.closest('[translate=no]'))out.push('@'+(e.getAttribute('placeholder')||e.getAttribute('aria-label')))});return out});
  xs.forEach(s=>{if(EN.test(s)&&!left.has(s))left.set(s,where)})}
const branches=['football','basketball','womens-basketball','volleyball','mens-volleyball','womens-football','more'];
for(const br of branches){await pg.selectOption('#sport',br);await pg.waitForTimeout(120);
  const tabs=await pg.$$eval('.tab',x=>x.map(t=>t.dataset.tab));
  for(const tb of tabs){await pg.evaluate(x=>{tab=x;syncHash();render()},tb);await pg.waitForTimeout(120);
    if(tb!=='play'){await collect(br+'/'+tb);continue}
    const games=await pg.evaluate(()=>PLAY[current].map(x=>x[0]));
    for(const g of games){await pg.evaluate(g=>pickGame(g),g);await pg.waitForTimeout(150);await collect(br+'/'+g);
      // poke a few interactions
      const clicks=['[data-qo="0"]','[data-q="next"]','[data-h="pos"]','[data-wh="more"]','[data-wh="give"]','[data-ins="0"]','[data-tc="0"]','[data-cand="0"]','[data-l="hint"]','[data-l="give"]','[data-fs="0"]','[data-sv="0"]','[data-wo]','[data-mc="0"]','[data-mc="1"]','[data-x="hint"]','[data-x="give"]','[data-pk="spin"]'];
      for(const c of clicks){const el=await pg.$(c);if(el&&await el.isVisible()&&await el.isEnabled()){await el.click().catch(()=>{});await pg.waitForTimeout(80);await collect(br+'/'+g+' '+c)}}
      if(g==='who'||g==='lineup'||g==='squad'||g==='xi'){const i=await pg.$('#whoGuess,#luGuess,#xiGuess');if(i&&await i.isEnabled()){await i.fill('zzzz');await i.press('Enter');await pg.waitForTimeout(80);await collect(br+'/'+g+' wrong')}}
    }}}
// draft through a full basketball five and the cup
await pg.selectOption('#sport','basketball');await pg.evaluate(x=>{tab=x;syncHash();render()},'play');await pg.evaluate(g=>pickGame(g),'draft5');
while(await pg.$('[data-tc="0"]')){await pg.click('[data-tc="0"]');await pg.waitForTimeout(60)}
await collect('bb cup');await pg.click('[data-sz="start"]');await pg.waitForTimeout(300);await collect('bb cup live');await pg.click('[data-sz="all"]');await pg.waitForTimeout(100);await collect('bb cup done');
await pg.selectOption('#sport','football');await pg.evaluate(g=>pickGame(g),'draft');
await gzAuto(pg);await pg.waitForTimeout(80);await collect('fb cup');await pg.click('[data-sz="start"]');await pg.waitForTimeout(400);await pg.click('[data-sz="all"]');await pg.waitForTimeout(100);await collect('fb cup done');
await pg.selectOption('#sport','volleyball');await pg.evaluate(g=>pickGame(g),'draft6');while(await pg.$('[data-tc="0"]')){await pg.click('[data-tc="0"]');await pg.waitForTimeout(50)}await pg.click('[data-sz="start"]');await pg.waitForTimeout(200);await pg.click('[data-sz="all"]');await pg.waitForTimeout(100);await collect('vb cup');
for(const [s,w] of left)console.log(w.padEnd(34),'|',s.slice(0,160));
console.log('TOTAL',left.size,'errors',JSON.stringify(errs));await b.close()})();
