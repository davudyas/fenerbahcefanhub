const {chromium}=require('playwright');const path=require('path');
const lum=c=>{const m=c.match(/[\d.]+/g).map(Number);const f=v=>{v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4)};return .2126*f(m[0])+.7152*f(m[1])+.0722*f(m[2])};
const cr=(a,b)=>{const x=lum(a),y=lum(b);return ((Math.max(x,y)+.05)/(Math.min(x,y)+.05)).toFixed(2)};
(async()=>{const b=await chromium.launch();const errs=[];
const pg=await b.newPage({viewport:{width:1200,height:900}});pg.on('pageerror',e=>errs.push(e.message));await pg.route('**/*',r=>r.request().url().startsWith('file:')?r.continue():r.abort());
await pg.goto('file://'+path.resolve(__dirname,'../site/index.html')+'#all');await pg.waitForTimeout(900);
console.log('default theme for a new visitor:',await pg.evaluate(()=>THEME),'lang:',await pg.evaluate(()=>LANG));
for(const th of ['bosphorus','pitch','sunset','sky','day']){await pg.evaluate(t=>applyTheme(t),th);await pg.waitForTimeout(250);
 const c=await pg.evaluate(()=>{const g=v=>{const d=document.createElement('div');d.style.color=`var(${v})`;document.body.appendChild(d);const c=getComputedStyle(d).color;d.remove();return c};
   const card=document.querySelector('.card');return {bg:getComputedStyle(document.body).backgroundColor,card:card?getComputedStyle(card).backgroundColor:'',ink:g('--ink'),muted:g('--muted'),dim:g('--dim'),accent:g('--accent'),good:g('--good'),bad:g('--bad')}});
 const solid=x=>/rgba\(.*,\s*0(\.\d+)?\)$/.test(x)?null:x;const bg=solid(c.card)||c.bg;
 console.log(th,'ink',cr(c.ink,bg),'muted',cr(c.muted,bg),'dim',cr(c.dim,bg),'accent',cr(c.accent,bg),'good',cr(c.good,bg),'bad',cr(c.bad,bg),'| bg',bg);
 await pg.screenshot({path:path.resolve(__dirname,'../th_'+th+'.png')});}
await pg.evaluate(()=>{applyTheme('pitch');setSport('football');tab='standings';render()});await pg.waitForTimeout(400);await pg.screenshot({path:path.resolve(__dirname,'../th_pitch_st.png')});
await pg.evaluate(()=>{applyTheme('sunset');tab='matches';render()});await pg.waitForTimeout(400);await pg.screenshot({path:path.resolve(__dirname,'../th_sunset_m.png')});
const m=await b.newPage({viewport:{width:390,height:844}});await m.route('**/*',r=>r.request().url().startsWith('file:')?r.continue():r.abort());await m.goto('file://'+path.resolve(__dirname,'../site/index.html')+'#all');await m.waitForTimeout(800);
await m.evaluate(()=>applyTheme('bosphorus'));await m.waitForTimeout(200);await m.screenshot({path:path.resolve(__dirname,'../th_bos_m.png')});
await m.evaluate(()=>applyTheme('sky'));await m.waitForTimeout(200);await m.screenshot({path:path.resolve(__dirname,'../th_sky_m.png')});
// returning visitor who picked Canary keeps it; one on Light moves to Matchday
const r=await b.newPage();await r.route('**/*',x=>x.request().url().startsWith('file:')?x.continue():x.abort());await r.goto('file://'+path.resolve(__dirname,'../site/index.html'));
await r.evaluate(()=>{localStorage.setItem('fb-look','23');localStorage.setItem('fb-theme','canary')});await r.reload();await r.waitForTimeout(500);const k1=await r.evaluate(()=>THEME);
await r.evaluate(()=>{localStorage.setItem('fb-look','23');localStorage.setItem('fb-theme','light')});await r.reload();await r.waitForTimeout(500);const k2=await r.evaluate(()=>THEME);
await r.evaluate(()=>applyTheme('light'));await r.reload();await r.waitForTimeout(500);const k3=await r.evaluate(()=>THEME);
console.log('kept canary:',k1,'| old light → ',k2,'| picks light again later →',k3);
console.log('errs',errs);await b.close()})();
