const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const ctx=await b.newContext();const pg=await ctx.newPage();const F='file://'+process.cwd()+'/fenerbahce.html';
await pg.goto(F+'#volleyball-play');await pg.waitForTimeout(200);await pg.selectOption('#lang','tr');await pg.waitForTimeout(100);
await pg.reload();await pg.waitForTimeout(300);
console.log('after reload lang:',await pg.$eval('#lang',s=>s.value),await pg.$eval('#langCode',s=>s.textContent),'| tab:',await pg.$eval('.tab[aria-selected=true]',x=>x.textContent),'| h2:',await pg.$eval('#gameArea h2',x=>x.textContent));
await pg.selectOption('#lang','en');await pg.waitForTimeout(100);console.log('back to en:',await pg.$eval('#gameArea h2',x=>x.textContent),await pg.$eval('.tab[aria-selected=true]',x=>x.textContent));
await b.close()})();
