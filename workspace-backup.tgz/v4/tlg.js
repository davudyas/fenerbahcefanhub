/* Stand-alone site test: two fans in separate browsers, Supabase replaced by an in-memory hub */
const {chromium}=require('playwright');const fs=require('fs'),path=require('path');
const SITE=path.resolve(__dirname,'../site');
let html=fs.readFileSync(SITE+'/index.html','utf8');
html=html.replace(/window\.FB_SB=\{[^<]*\};/,'window.FB_SB={"url":"https://mock.supabase.co","key":"anon"};').replace(/<script src="https:\/\/cdn\.jsdelivr[^"]*"><\/script>/,'<script src="mocksb.js"></script>');
fs.writeFileSync(SITE+'/_t.html',html);fs.copyFileSync(__dirname+'/mocksb.js',SITE+'/mocksb.js');
const docs=new Map(),profiles=new Map(),subs=new Map(),pres={},uidOf=new Map();let rls=0;
const push=(cid,k,a)=>{const s=subs.get(cid);if(s)s.page.evaluate(([c,k,a])=>window.__mockRecv&&window.__mockRecv(c,k,a),[cid,k,a]).catch(()=>{})};
const presPush=name=>{for(const [cid,s] of subs)if(s.name===name)push(cid,'pres',pres[name]||{})};
const users=new Map();
function hub(page,st){
 if(st.op==='auth'){uidOf.set(page,st.uid);return {}}
 if(st.op==='upd'){if(st.email){for(const [e,u] of users)if(e===st.email&&u.id!==st.uid)return {error:{message:'A user with this email address has already been registered',code:'email_exists',status:422}};users.set(st.email,{id:st.uid,pw:null})}
   if(st.password){const e=[...users].find(([e,u])=>u.id===st.uid);if(!e)return {error:{message:'email not confirmed'}};e[1].pw=st.password}return {}}
 if(st.op==='login'){const u=users.get(st.email);if(!u||u.pw!==st.password)return {error:{message:'Invalid login credentials',code:'invalid_credentials',status:400}};return {uid:u.id}}
 if(st.op==='sub'){subs.set(st.cid,{page,name:st.name,pg:st.pg});if(pres[st.name])setTimeout(()=>presPush(st.name),20);return {}}
 if(st.op==='unsub'){subs.delete(st.cid);if(pres[st.name]&&st.key){delete pres[st.name][st.key];presPush(st.name)}return {}}
 if(st.op==='send'){for(const [cid,s] of subs)if(s.name===st.name)push(cid,'bc',{event:st.event,payload:st.payload});return {}}
 if(st.op==='track'){(pres[st.name]=pres[st.name]||{})[st.key]=[{...st.meta,presence_ref:'r'}];presPush(st.name);return {}}
 if(st.op==='untrack'){if(pres[st.name]){delete pres[st.name][st.key];presPush(st.name)}return {}}
 const T=st.table==='docs'?docs:profiles;
 if(st.op==='upsert'){const me=uidOf.get(page)||null;if(st.row.id!==me){rls++;return {error:{message:'violates row-level security'}}}
  const key=st.table==='docs'?st.row.col+'|'+st.row.id:st.row.id;T.set(key,st.row);
  for(const [cid,s] of subs){if(!s.pg||s.pg.table!==st.table)continue;if(s.pg.filter){const [k,v]=s.pg.filter.split('=eq.');if(String(st.row[k])!==v)continue}push(cid,'pg',{eventType:'UPDATE',new:st.row,old:{}})}
  return {data:null}}
 let rows=[...T.values()];for(const [op,k,v] of st.f)rows=rows.filter(r=>op==='eq'?r[k]===v:v.includes(r[k]));
 return {data:st.single?(rows[0]||null):rows}}
(async()=>{const b=await chromium.launch();const errs=[];const log=(...a)=>console.log(...a);
const mk=async(W)=>{const ctx=await b.newContext({viewport:{width:W||1200,height:1000}});await ctx.exposeBinding('__hub',(src,st)=>hub(src.page,st));const pg=await ctx.newPage();
 pg.on('pageerror',e=>errs.push(e.message));await pg.goto('file://'+SITE+'/_t.html#all');await pg.waitForFunction(()=>typeof XC!=='undefined'&&XC.on,null,{timeout:8000});await pg.waitForTimeout(400);return pg};
const A=await mk(),B=await mk();
const keys=await A.evaluate(()=>{const L=LIVE.football,n=L.next.find(x=>x[0]>=todayISO()),r=L.last.find(x=>x[0]&&x[1]==="Süper Lig");return {up:xKey("football",n[0],n[4]),played:xKey("football",r[0],r[3]),res:[r[4],r[5]],venue:r[2],upVenue:n[3]}});log(JSON.stringify(keys));
await A.evaluate(k=>{const P={[k.up]:[2,1],[k.played]:k.res};store.set('fb-preds',P);return xWrite('predictions',{p:P})},keys);
await B.evaluate(k=>{const P={[k.up]:[0,0],[k.played]:[k.res[0]+1,k.res[1]]};store.set('fb-preds',P);return xWrite('predictions',{p:P})},keys);
await A.evaluate(()=>FB_SITE&&XC.user.setName('Ali'));await B.evaluate(()=>XC.user.setName('Ayşe'));await B.waitForTimeout(800);
await B.evaluate(()=>{current='home';render()});await B.waitForTimeout(800);
const card=async(pg)=>pg.evaluate(()=>{const c=document.querySelector('.lgallc');return c?c.innerText.replace(/\n+/g,' | '):'none'});
log('B default:',await card(B));
await B.selectOption('#lgMSel',keys.up);await B.waitForTimeout(300);log('B upcoming:',await card(B));
await B.selectOption('#lgMSel',keys.played);await B.waitForTimeout(300);log('B played:',await card(B));
await B.locator('.lgallc').screenshot({path:path.resolve(__dirname,'../lg_played.png')});
await B.selectOption('#lgMSel',keys.up);await B.waitForTimeout(300);await B.locator('.lgallc').screenshot({path:path.resolve(__dirname,'../lg_up.png')});
await B.evaluate(()=>{$('lang').value='ar';$('lang').dispatchEvent(new Event('change'))});await B.waitForTimeout(1500);log('AR:',await card(B));
await B.locator('.lgallc').screenshot({path:path.resolve(__dirname,'../lg_ar.png')});
log('errs',JSON.stringify(errs));await b.close();fs.unlinkSync(SITE+'/_t.html');fs.unlinkSync(SITE+'/mocksb.js')})().catch(e=>{console.error('FAIL',e.message.slice(0,400));process.exit(1)});
