/* ================= LANGUAGES ================= */
const LANGS=[["en","English","EN","en-GB"],["tr","Türkçe","TR","tr-TR"],["de","Deutsch","DE","de-DE"],["es","Español","ES","es-ES"],["fr","Français","FR","fr-FR"],["it","Italiano","IT","it-IT"],["pt","Português","PT","pt-BR"],["nl","Nederlands","NL","nl-NL"],["pl","Polski","PL","pl-PL"],["ru","Русский","RU","ru-RU"],["az","Azərbaycanca","AZ","az-Latn-AZ"],["bs","Bosanski / Hrvatski / Srpski","BHS","bs-Latn-BA"],["sq","Shqip","SQ","sq-AL"],["ar","العربية","AR","ar-u-nu-latn"],["fa","فارسی","FA","fa-IR-u-nu-latn"]];
const RTL_LANGS=["ar","fa"];
let LANG=(()=>{try{const v=localStorage.getItem("fb-lang");if(LANGS.some(l=>l[0]===v))return v}catch(e){}return "en"})();
const LOC=()=>LANGS.find(l=>l[0]===LANG)[3];
const EN_NS={"res:W":"W","res:D":"D","res:L":"L","ha:H":"H","ha:A":"A","ha:N":"N","col:P":"P","col:W":"W","col:D":"D","col:L":"L","col:GF":"GF","col:GA":"GA","col:GD":"GD","col:Pts":"Pts","col:+/−":"+/−","col:PF":"PF","col:PA":"PA","col:Sets":"Sets",
 "colt:P":"Played","colt:W":"Won","colt:D":"Drawn","colt:L":"Lost","colt:GF":"Goals for","colt:GA":"Goals against","colt:GD":"Goal difference","colt:Pts":"Points","colt:+/−":"Points difference","colt:PF":"Points for","colt:PA":"Points against","colt:Sets":"Sets won–lost"};
const XLANGS=["es","fr","ar"],DICT={},LOWER={},PATTERNS={},TCACHE=new Map();LANGS.forEach(([c])=>{if(c!=="en"){DICT[c]={};LOWER[c]={};PATTERNS[c]=[]}});
const capFirst=s=>s?s[0].toLocaleUpperCase(LOC())+s.slice(1):s;
function addZip(L,en,x){if(x==null||en==null)return;
  if(typeof x==="string"){if(typeof en==="string"&&en!==x){DICT[L][en]=x}return}
  if(Array.isArray(x)){x.forEach((v,i)=>addZip(L,en[i],v));return}
  if(typeof x==="object")Object.keys(x).forEach(k=>addZip(L,en[k],x[k]))}
function lookup(s){if(s==null)return null;const D=DICT[LANG];if(D[s]!=null)return D[s];const lo=LOWER[LANG][s.toLowerCase()];if(lo==null)return null;const [k,x]=lo,up=c=>c!==c.toLowerCase();
  if(up(s[0])&&!up(k[0]))return capFirst(x);if(!up(s[0])&&up(k[0])&&LANG==="tr")return x[0].toLocaleLowerCase("tr")+x.slice(1);return x}
/* translate one group for templates; falls back to the original text */
function g1(x){if(x==null)return "";const r=trText(x,true);return r==null?x:r}
function fillTpl(tpl,m){return tpl.replace(/([@$])(l|U)?(\d)/g,(_,k,mod,i)=>{let v=m[+i];if(v==null)return "";if(k==="@")v=g1(v);if(mod==="l")v=v.toLocaleLowerCase(LOC());if(mod==="U")v=capFirst(v);return v})}
function trText(s,noSplit){if(LANG==="en"||s==null)return null;const key=LANG+"\u0001"+s;if(TCACHE.has(key))return TCACHE.get(key);
  let r=lookup(s);
  if(r==null)for(const [re,f] of PATTERNS[LANG]){const m=s.match(re);if(!m)continue;const out=typeof f==="function"?f(m,g1):fillTpl(f,m);if(out!=null){r=out;break}}
  if(r==null&&!noSplit){const parts=s.split(/(?<=[.!?])\s+(?=[A-Z0-9“"'‘(])/);if(parts.length>1){let any=false;const out=parts.map(p=>{const x=trText(p,true);if(x!=null){any=true;return x}return p});if(any)r=out.join(" ")}}
  TCACHE.set(key,r);return r}
function t(s){if(s==null)return s;if(LANG==="en")return EN_NS[s]!=null?EN_NS[s]:s;const r=trText(String(s));return r!=null?r:(EN_NS[s]!=null?EN_NS[s]:s)}
function tf(s,v){return t(s).replace(/\{(\w+)\}/g,(m,k)=>v[k]!=null?v[k]:m)}
function lbl(s){return LANG==="en"?s.label.toLowerCase():["tr","es","fr"].includes(LANG)?t(s.label).toLocaleLowerCase(LOC()):t(s.label)}
function asOf(){return fmtDay(new Date(ASOF_ISO+"T12:00:00"),{day:"numeric",month:"long",year:"numeric"})}
/* English date strings in the data ("25 May 2025", "April 2024") */
const EN_MONTHS=["January","February","March","April","May","June","July","August","September","October","November","December"];
function trDate(s){let m=s.match(/^(\d{1,2}) ([A-Z][a-z]+) (\d{4})$/),d;if(m&&EN_MONTHS.includes(m[2])){d=new Date(+m[3],EN_MONTHS.indexOf(m[2]),+m[1],12);return fmtDay(d,{day:"numeric",month:"long",year:"numeric"})}
  m=s.match(/^([A-Z][a-z]+) (\d{4})$/);if(m&&EN_MONTHS.includes(m[1])){d=new Date(+m[2],EN_MONTHS.indexOf(m[1]),15,12);return fmtDay(d,{month:"long",year:"numeric"})}return null}

/* Build dictionaries from the packs */


/* Translate whatever the game engines render (they write English) */
const TR_SKIP="script,style,textarea,[translate=no]";
function trDom(root){if(LANG==="en"||!root)return;const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT),nodes=[];while(w.nextNode())nodes.push(w.currentNode);
  nodes.forEach(n=>{const p=n.parentElement;if(!p||p.closest(TR_SKIP))return;const v=n.nodeValue,s=v.trim();if(!s||!/[A-Za-z]/.test(s))return;const r=trText(s);if(r!=null&&r!==s)n.nodeValue=v.replace(s,r)});
  root.querySelectorAll("[placeholder],[aria-label],[title]").forEach(el=>{if(el.closest(TR_SKIP))return;["placeholder","aria-label","title"].forEach(a=>{const v=el.getAttribute(a);if(!v)return;const r=trText(v.trim());if(r!=null&&r!==v)el.setAttribute(a,r)})})}
let trObs=null;
function watchPanel(){const panel=$("panel"),opts={childList:true,subtree:true,characterData:true};
  trObs=new MutationObserver(()=>{if(LANG==="en")return;trObs.disconnect();try{trDom(document.getElementById("gameArea"))}finally{trObs.takeRecords();trObs.observe(panel,opts)}});trObs.observe(panel,opts)}

/* Static text, picker and switching */
function staticTexts(){document.documentElement.lang=LANG;document.documentElement.dir=RTL_LANGS.includes(LANG)?"rtl":"ltr";
  [...$("sport").options].forEach(o=>{if(SPORTS[o.value])o.textContent=t(SPORTS[o.value].label)});$("sport").setAttribute("aria-label",t("Choose a branch"));
  document.querySelectorAll("[data-t]").forEach(el=>el.textContent=t(el.dataset.t));
  if(typeof themeTexts==="function")themeTexts();if(typeof helperTexts==="function")helperTexts();const ls=$("lang");ls.value=LANG;ls.setAttribute("aria-label",t("Language"));$("langCode").textContent=LANGS.find(l=>l[0]===LANG)[2]}


