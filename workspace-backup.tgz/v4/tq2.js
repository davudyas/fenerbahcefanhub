const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const pg=await b.newPage();await pg.goto('file://'+process.cwd()+'/fenerbahce.html');await pg.waitForTimeout(400);
console.log(await pg.evaluate(()=>JSON.stringify(["basketball","womens-basketball","volleyball","mens-volleyball","womens-football"].map(b=>[b,SPORTS[b].trophies.map(x=>x.slice(0,3))]),null,0)));
console.log(await pg.evaluate(()=>["Kadıköy, Istanbul, with facilities across the city","Show as a table","Matchday {n}","Finished {p}","Champions","Next match"].map(s=>{LANG="tr";const r=t(s);LANG="en";return s+" => "+r})));
await b.close()})();
