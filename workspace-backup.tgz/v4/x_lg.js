/* ===== Stand-alone site: private prediction leagues, reporting names and messages ===== */
(function(){if(!window.FB_SITE)return;
  /* an invite link looks like …#league=ABC234; remember the code and open the home page */
  let PENDING=null;{const m=location.hash.match(/^#league=([A-Za-z2-9]{6})$/);if(m){PENDING=m[1].toUpperCase();try{history.replaceState(null,"","#all")}catch(e){location.hash="all"}}}
  const LG={list:[],members:{},ready:false};
  let lgL=(()=>{try{return localStorage.getItem("fb-lg-sel")||"all"}catch(e){return "all"}})();
  const cl=()=>FB_SITE.client();
  async function lgLoad(){const c=cl();if(!c||!FB_SITE.on)return;
    const [a,b]=await Promise.all([c.from("leagues").select("code,name,owner").order("created_at"),c.from("league_members").select("code,id")]);
    if(a.error||b.error)return;LG.list=a.data||[];LG.members={};(b.data||[]).forEach(r=>(LG.members[r.code]=LG.members[r.code]||new Set()).add(r.id));LG.ready=true;
    if(lgL!=="all"&&!LG.list.some(l=>l.code===lgL))lgL="all";xNames([...new Set((b.data||[]).map(r=>r.id))]);if(typeof fillLeague==="function")fillLeague()}
  const ERR={bad:"League names need 1–30 characters.",rude:"Please keep it friendly. Pick another name.",none:"There's no league with that code. Check it and try again.",
    full:"That league is full.",many:"You can run up to 10 leagues.",net:"Couldn't connect. Try again."};
  const errOf=e=>{const m=(e&&e.message||"").toLowerCase();return /no such/.test(m)?"none":/full/.test(m)?"full":/too many/.test(m)?"many":/bad name/.test(m)?"bad":"net"};
  async function lgCreate(name){name=String(name||"").replace(/\s+/g," ").trim();if(!name||name.length>30)throw {k:"bad"};if(modBad(name))throw {k:"rude"};
    const {data,error}=await cl().rpc("create_league",{league_name:name});if(error)throw {k:errOf(error)};lgL=data;store.set("fb-lg-sel",lgL);await lgLoad();return data}
  async function lgJoin(code){code=String(code||"").trim().toUpperCase().replace(/[^A-Z0-9]/g,"");if(!/^[A-Z2-9]{6}$/.test(code))throw {k:"none"};
    const {data,error}=await cl().rpc("join_league",{league_code:code});if(error)throw {k:errOf(error)};lgL=code;store.set("fb-lg-sel",lgL);await lgLoad();return data}
  async function lgLeave(code){const {error}=await cl().rpc("leave_league",{league_code:code});if(error)throw {k:"net"};if(lgL===code){lgL="all";store.set("fb-lg-sel","all")}await lgLoad()}
  const invite=code=>location.origin+location.pathname+"#league="+code;

  /* the fan prediction table can show just the members of one of your leagues */
  {const _t=lgTable;lgTable=(b,per)=>{const r=_t(b,per);if(lgL==="all"||!LG.members[lgL])return r;const M=LG.members[lgL];return r.filter(x=>M.has(x.id==="me"?XC.me:x.id))}}
  {const _fl=fillLeague;fillLeague=function(){_fl();lgPaint()}}
  function lgPaint(){const box=$("leagueBox"),g=box&&box.querySelector(".lggrid");if(!g||!FB_SITE.on)return;
    const tcard=g.querySelector("article.card");if(tcard&&LG.list.length&&!tcard.querySelector("#lgLeague")){const sel=document.createElement("select");sel.id="lgLeague";sel.className="lgsel";sel.setAttribute("aria-label",t("League"));
      sel.innerHTML=`<option value="all">${esc(t("All fans"))}</option>`+LG.list.map(l=>`<option value="${esc(l.code)}" ${l.code===lgL?"selected":""}>${esc(modClean(l.name))}</option>`).join("");if(lgL==="all")sel.value="all";
      const bs=tcard.querySelector("#lgSel");(bs||tcard.querySelector(".label")).after(sel);sel.onchange=()=>{lgL=sel.value;store.set("fb-lg-sel",lgL);fillLeague();const n=$("lgLeague");if(n)n.focus()}}
    let c=g.querySelector(".lgpriv");if(!c){c=document.createElement("article");c.className="card lgpriv";c.id="lgPriv";g.appendChild(c)}
    const mine=LG.list.map(l=>{const n=LG.members[l.code]?LG.members[l.code].size:1;return `<li><div><b>${esc(modClean(l.name))}</b><span class="muted">${tf(n===1?"1 member":"{n} members",{n})} · ${t("Code")} <code>${esc(l.code)}</code></span></div>
      <div class="btns"><button class="btn ghost sm" type="button" data-lgcopy="${esc(l.code)}">${t("Copy invite link")}</button><button class="btn ghost sm" type="button" data-lgshow="${esc(l.code)}">${t("Show table")}</button><button class="btn ghost sm lgleave" type="button" data-lgleave="${esc(l.code)}">${t("Leave")}</button></div></li>`}).join("");
    const guest=FB_SITE._anon!==false;
    c.innerHTML=`<span class="label">${t("Private leagues")}</span><p class="fine">${t("Play the prediction league with just your friends. Everyone predicts as usual; your league gets its own table. Share the invite link in your group chat.")}</p>
      ${PENDING?`<div class="lginv"><p>${tf("You've been invited to a private league (code {c}).",{c:`<code>${esc(PENDING)}</code>`})}</p><div class="btns"><button class="btn sm" type="button" id="lgInvYes">${t("Join league")}</button><button class="btn ghost sm" type="button" id="lgInvNo">${t("No thanks")}</button></div></div>`:""}
      ${mine?`<ul class="lgmylist">${mine}</ul>`:""}
      <form class="lgform" id="lgNewF"><input id="lgNew" maxlength="30" placeholder="${esc(t("League name, e.g. Kadıköy Crew"))}" aria-label="${esc(t("League name"))}"><button class="btn sm" type="submit">${t("Create league")}</button></form>
      <form class="lgform" id="lgJoinF"><input id="lgCode" maxlength="6" autocapitalize="characters" spellcheck="false" placeholder="${esc(t("Code, e.g. ABC234"))}" aria-label="${esc(t("League code"))}"><button class="btn ghost sm" type="submit">${t("Join")}</button></form>
      <p class="fine" id="lgPMsg" role="status" aria-live="polite"></p>
      ${guest?`<p class="fine">${t("Tip: create an account (top right) to keep your leagues when you switch devices.")}</p>`:""}`;
    const msg=x=>{const m=$("lgPMsg");if(m)m.textContent=x};
    const busy=(f,el)=>async e=>{e&&e.preventDefault&&e.preventDefault();const bs=c.querySelectorAll("button");bs.forEach(b=>b.disabled=true);try{await f(el)}catch(x){msg(t(ERR[x&&x.k]||ERR.net))}bs.forEach(b=>b.disabled=false)};
    $("lgNewF").onsubmit=busy(async()=>{const code=await lgCreate($("lgNew").value);xToast(tf("League created. Share the code {c} or copy the invite link.",{c:code}))});
    $("lgJoinF").onsubmit=busy(async()=>{const r=await lgJoin($("lgCode").value);xToast(tf("You joined {n}.",{n:modClean(r.name)}))});
    if(PENDING){$("lgInvYes").onclick=busy(async()=>{const code=PENDING;const r=await lgJoin(code);PENDING=null;xToast(tf("You joined {n}.",{n:modClean(r.name)}));lgPaint()});$("lgInvNo").onclick=()=>{PENDING=null;lgPaint()}}
    c.querySelectorAll("[data-lgcopy]").forEach(b=>b.onclick=async()=>{const u=invite(b.dataset.lgcopy);try{await navigator.clipboard.writeText(u);xToast(t("Invite link copied."))}catch(e){msg(u)}});
    c.querySelectorAll("[data-lgshow]").forEach(b=>b.onclick=()=>{lgL=b.dataset.lgshow;store.set("fb-lg-sel",lgL);fillLeague();const s=$("lgLeague");if(s){s.scrollIntoView({block:"center",behavior:"smooth"});s.focus()}});
    c.querySelectorAll("[data-lgleave]").forEach(b=>b.onclick=busy(async()=>{if(b.dataset.sure!=="1"){b.dataset.sure="1";b.textContent=t("Click again to leave");return}await lgLeave(b.dataset.lgleave);xToast(t("You left the league."))}));
    if(PENDING&&!c.dataset.scrolled){c.dataset.scrolled="1";setTimeout(()=>c.scrollIntoView({block:"center",behavior:"smooth"}),400)}}

  /* ---- reports: a small flag next to other fans' names and messages ---- */
  const HIDDEN=new Set();
  {const _xn=xName;xName=id=>HIDDEN.has(id)&&id!==XC.me?t("A fan"):_xn(id)}
  {const _rn=rtName;rtName=p=>p&&!p.isMe&&HIDDEN.has(p.by)?t("A fan"):_rn(p)}
  const UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  async function report(uid,kind,content){const {error}=await cl().from("reports").insert({reporter:XC.me,target:uid,kind,content:String(content||"").slice(0,300)});
    if(error&&error.code!=="23505")throw error}
  function flag(el){const uid=el.dataset.uid;el.dataset.rep="1";if(!UUID.test(uid)||uid===XC.me)return;const kind=el.dataset.msg!=null?"message":"name";
    const b=document.createElement("button");b.type="button";b.className="rflag";b.setAttribute("aria-label",t(kind==="message"?"Report this message":"Report this name"));b.title=b.getAttribute("aria-label");
    b.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M5 21V4M5 4h11l-2 4 2 4H5"/></svg>';
    b.onclick=e=>{e.stopPropagation();if(el.querySelector(".rask"))return;const ask=document.createElement("span");ask.className="rask";
      ask.innerHTML=`<span>${t(kind==="message"?"Report this message?":"Report this name?")}</span><button type="button" class="btn sm" data-r="y">${t("Report")}</button><button type="button" class="btn ghost sm" data-r="n">${t("Cancel")}</button>`;
      el.appendChild(ask);ask.querySelector('[data-r="n"]').onclick=ev=>{ev.stopPropagation();ask.remove()};
      ask.querySelector('[data-r="y"]').onclick=async ev=>{ev.stopPropagation();ask.querySelectorAll("button").forEach(x=>x.disabled=true);
        try{await report(uid,kind,kind==="message"?el.dataset.msg:(XC.names[uid]||(el.querySelector(".nm")||{}).textContent||""));ask.remove();b.remove();xToast(t("Thanks for letting us know."))}
        catch(x){ask.remove();xToast(t("Couldn't send the report. Try again."))}}};
    const nm=el.querySelector(".nm");(nm||el).appendChild(b)}
  const scan=()=>{if(!FB_SITE.on||!XC.me)return;document.querySelectorAll("[data-uid]:not([data-rep])").forEach(flag)};
  let st=null;new MutationObserver(()=>{clearTimeout(st);st=setTimeout(scan,120)}).observe(document.body,{childList:true,subtree:true});

  /* start once the shared features are connected */
  const w=setInterval(async()=>{if(!FB_SITE.on||!XC.me)return;clearInterval(w);
    try{const a=await FB_SITE.account();FB_SITE._anon=!a||a.anon}catch(e){}
    try{const {data}=await cl().rpc("hidden_names");(data||[]).forEach(r=>HIDDEN.add(typeof r==="string"?r:(r.hidden_names||r)));if(HIDDEN.size){Object.keys(XC.names).forEach(()=>0);xRefresh()}}catch(e){}
    await lgLoad();scan();
    cl().channel("lg-"+Math.random().toString(36).slice(2,8)).on("postgres_changes",{event:"*",schema:"public",table:"league_members"},()=>{clearTimeout(w._t);w._t=setTimeout(lgLoad,600)}).subscribe()},700);
  setTimeout(()=>clearInterval(w),30000);
})();

/* ===== Moderation (admins only; every action is checked again by the database) ===== */
(function(){if(!window.FB_SITE)return;window.FB_BANNED=new Set();
  const cl=()=>FB_SITE.client();
  async function loadBans(){try{const {data}=await cl().rpc("banned_ids");const B=new Set((data||[]).map(r=>typeof r==="string"?r:r.banned_ids));window.FB_BANNED=B;
    let ch=false;Object.values(XC.docs).forEach(col=>B.forEach(id=>{if(col&&col[id]){delete col[id];ch=true}}));B.forEach(id=>{if(XC.names[id]){XC.names[id]="";ch=true}});if(ch)xRefresh()}catch(e){}}
  const SHIELD='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M12 3l7 3v5c0 4.5-3 8.3-7 10-4-1.7-7-5.5-7-10V6z"/><path d="M9 12l2 2 4-4"/></svg>';
  let tab="fans";const F={show:"reg",sort:"active",q:"",open:new Set(),list:null,partial:false};
  const nm=x=>x.name?esc(x.name):'<span class="muted">(no name)</span>';
  const badges=x=>`${x.registered?`<span class="mbadge">registered${x.username?" · "+esc(x.username):""}</span>`:`<span class="mbadge">guest</span>`}${x.banned?'<span class="mbadge bad">banned</span>':""}`;
  const acts=(x,dismiss)=>`<div class="btns"><button class="btn ghost sm" data-ma="name" data-id="${x.id||x.target}">Reset name</button><button class="btn ghost sm" data-ma="clear" data-id="${x.id||x.target}">Clear predictions &amp; scores</button>
    ${x.banned?`<button class="btn ghost sm" data-ma="unban" data-id="${x.id||x.target}">Unban</button>`:`<button class="btn ghost sm mdanger" data-ma="ban" data-id="${x.id||x.target}">Ban</button>`}${dismiss?`<button class="btn ghost sm" data-ma="dismiss" data-id="${x.target}" data-k="${esc(x.kind)}">Dismiss</button>`:""}</div>`;
  async function paint(){const body=$("modBody");if(!body)return;body.innerHTML='<p class="fine">Loading…</p>';
    try{if(tab==="fans"){await paintFans(body);return}
      if(tab==="reports"){const {data,error}=await cl().rpc("admin_reports");if(error)throw error;
        body.innerHTML=(data||[]).length?`<ul class="mlist">${data.map(x=>`<li><div class="mhead"><b>${nm(x)}</b>${badges(x)}<span class="muted">${x.kind==="message"?"message":"name"} · ${x.reporters} report${x.reporters===1?"":"s"} · ${esc(mDate(String(x.last).slice(0,10),true))}</span></div>
          ${(x.samples||[]).filter(Boolean).length?`<p class="msample">${x.samples.filter(Boolean).map(s=>"“"+esc(s)+"”").join("<br>")}</p>`:""}${x.target?acts(x,true):""}</li>`).join("")}</ul>`:'<p class="fine">No reports. All quiet.</p>'}
      else if(tab==="find"){body.innerHTML=`<form id="mFindF" class="lgform"><input id="mFind" placeholder="Fan name or username" aria-label="Fan name or username"><button class="btn sm" type="submit">Search</button></form><div id="mFound"></div>`;
        $("mFindF").onsubmit=async e=>{e.preventDefault();const q=$("mFind").value.trim();if(!q)return;const {data,error}=await cl().rpc("admin_find",{q});const f=$("mFound");if(error){f.innerHTML='<p class="fine">Search failed.</p>';return}
          f.innerHTML=(data||[]).length?`<ul class="mlist">${data.map(x=>`<li><div class="mhead"><b>${nm(x)}</b>${badges(x)}<span class="muted">joined ${esc(mDate(String(x.created_at).slice(0,10),true))}</span></div>${acts(x,false)}</li>`).join("")}</ul>`:'<p class="fine">No fans found.</p>';wire()};$("mFind").focus()}
      else{const {data,error}=await cl().rpc("admin_leagues");if(error)throw error;
        body.innerHTML=(data||[]).length?`<ul class="mlist">${data.map(x=>`<li><div class="mhead"><b>${esc(x.name)}</b><span class="muted"><code>${esc(x.code)}</code> · ${x.members} member${x.members===1?"":"s"}${x.owner_name?" · made by "+esc(x.owner_name):""}</span></div>
          <div class="btns"><input class="mren" value="${esc(x.name)}" maxlength="30" aria-label="New league name"><button class="btn ghost sm" data-ma="lrename" data-id="${esc(x.code)}">Rename</button><button class="btn ghost sm mdanger" data-ma="ldel" data-id="${esc(x.code)}">Delete league</button></div></li>`).join("")}</ul>`:'<p class="fine">No private leagues yet.</p>'}
      wire()}catch(e){body.innerHTML='<p class="fine">Couldn\'t load this. Try again.</p>'}}
  /* ---- Fans: everyone at a glance, with their activity ---- */
  const when=d=>d?esc(mDate(String(d).slice(0,10),true)):"–";
  async function loadFans(){let r=await cl().rpc("admin_users",{include_guests:F.show!=="reg"});F.partial=false;
    if(r.error){/* until the database function exists, fall back to the newest 25 */const f=await cl().rpc("admin_find",{q:""});if(f.error)throw r.error;F.partial=true;
      const D=k=>XC.docs[k]||{};r={data:(f.data||[]).map(x=>({...x,predictions:Object.keys((D("predictions")[x.id]||{}).p||{}).length,motm:Object.keys((D("motm")[x.id]||{}).v||{}).length,ratings:Object.keys((D("ratings")[x.id]||{}).r||{}).length,games:!!D("scores")[x.id],leagues:[],reports:0}))}}
    F.list=r.data||[]}
  function matchLabel(k){const [b,d,o]=k.split("|");const sp=SPORTS[b];return `${esc(mDate(d,true))} · ${esc(o||"")}${sp?` <span class="muted">· ${esc(t(sp.label))}</span>`:""}`}
  async function activity(id){const {data,error}=await cl().from("docs").select("col,data,updated_at").eq("id",id);if(error)return '<p class="fine">Couldn\'t load their activity.</p>';
    const by={};(data||[]).forEach(r=>by[r.col]=r.data||{});const R=xResults(),out=[];
    const P=Object.entries(by.predictions&&by.predictions.p||{}).sort((a,b)=>b[0].split("|")[1].localeCompare(a[0].split("|")[1]));
    if(P.length)out.push(`<h4>Predictions (${P.length})</h4><ul class="mact">${P.slice(0,30).map(([k,v])=>{const res=R[k],pts=res?xPoints(v,res):null,[bb,dd,oo]=k.split("|"),hm=typeof lgVenue!=="function"||lgVenue(bb,dd,oo)!=="A",sc=x=>hm?`${esc(x[0])}–${esc(x[1])}`:`${esc(x[1])}–${esc(x[0])}`;
      return `<li><span>${matchLabel(k)} <span class="muted">(${hm?"home":"away"})</span></span><b>${sc(v)}</b><span class="muted">${res?`result ${sc(res)} · ${pts} pt${pts===1?"":"s"}`:"not played yet"}</span></li>`}).join("")}</ul>`);
    const V=Object.entries(by.motm&&by.motm.v||{});if(V.length)out.push(`<h4>Man of the Match votes (${V.length})</h4><ul class="mact">${V.slice(-20).reverse().map(([k,v])=>`<li><span>${matchLabel(k)}</span><b>${esc(v)}</b></li>`).join("")}</ul>`);
    const Ra=Object.entries(by.ratings&&by.ratings.r||{});if(Ra.length)out.push(`<h4>Player ratings (${Ra.length} matches)</h4><ul class="mact">${Ra.slice(-15).reverse().map(([k,v])=>`<li><span>${matchLabel(k)}</span><span class="muted">${esc(Object.entries(v||{}).map(([n,x])=>n+" "+x).join(", "))}</span></li>`).join("")}</ul>`);
    const S=by.scores&&by.scores.s;if(S){const L=Object.fromEntries(BOARDS.map(b=>[b[0],b[1]]));const g=Object.entries(S).filter(([,v])=>typeof v==="number"&&v>0);
      if(g.length)out.push(`<h4>Game bests</h4><ul class="mact">${g.map(([k,v])=>`<li><span>${esc(t(L[k]||k))}</span><b>${esc(v)}</b></li>`).join("")}</ul>`)}
    const n=(o,f)=>o&&o[f]?Object.keys(o[f]).length:0;const extra=[n(by.challenges,"c")&&`${n(by.challenges,"c")} challenges played`,n(by.seasons,"b")&&`${n(by.seasons,"b")} season-game records`,n(by.watch,"w")&&`${n(by.watch,"w")} watch parties`].filter(Boolean);
    if(extra.length)out.push(`<p class="fine">${extra.join(" · ")}</p>`);
    return out.join("")||'<p class="fine">Nothing saved yet.</p>'}
  async function paintFans(body,keep){if(!F.list||!keep)await loadFans();
    const q=F.q.trim().toLowerCase();let L=F.list.filter(x=>F.show==="all"||(F.show==="reg"?x.registered:!x.registered)).filter(x=>!q||(x.name||"").toLowerCase().includes(q)||(x.username||"").includes(q));
    const tim=x=>Date.parse(x.last_active||x.created_at||0)||0;
    L.sort(F.sort==="new"?(a,b)=>Date.parse(b.created_at)-Date.parse(a.created_at):F.sort==="pred"?(a,b)=>b.predictions-a.predictions:F.sort==="rep"?(a,b)=>b.reports-a.reports||tim(b)-tim(a):(a,b)=>tim(b)-tim(a));
    const reg=F.list.filter(x=>x.registered).length;
    body.innerHTML=`<div class="mtools"><input id="mQ" value="${esc(F.q)}" placeholder="Filter by name or username" aria-label="Filter fans">
      <select id="mShow" aria-label="Show"><option value="reg">Registered fans</option><option value="guest">Guests</option><option value="all">Everyone</option></select>
      <select id="mSort" aria-label="Sort"><option value="active">Last active</option><option value="new">Newest</option><option value="pred">Most predictions</option><option value="rep">Most reported</option></select></div>
      <p class="fine">${L.length} shown${F.show!=="guest"?` · ${reg} registered`:""}${F.partial?" · showing the newest 25 for now (database update pending)":""}</p>
      ${L.length?`<ul class="mlist mfans">${L.map(x=>`<li data-fan="${x.id}"><div class="mhead"><b>${nm(x)}</b>${badges(x)}${x.admin?'<span class="mbadge">admin</span>':""}${x.reports?`<span class="mbadge bad">${x.reports} report${x.reports===1?"":"s"}</span>`:""}</div>
        <p class="mstats">${x.predictions} prediction${x.predictions===1?"":"s"} · ${x.motm} MOTM vote${x.motm===1?"":"s"} · ${x.ratings} rating${x.ratings===1?"":"s"}${x.games?" · plays the games":""}${(x.leagues||[]).length?` · leagues: ${x.leagues.map(esc).join(", ")}`:""}</p>
        <p class="muted mwhen">Joined ${when(x.created_at)} · last active ${when(x.last_active)}${x.last_sign_in_at&&x.registered?` · last log-in ${when(x.last_sign_in_at)}`:""}</p>
        <div class="btns"><button class="btn ghost sm" data-mx="${x.id}" aria-expanded="${F.open.has(x.id)}">${F.open.has(x.id)?"Hide activity":"Show activity"}</button></div><div class="mactw" id="act-${x.id}" ${F.open.has(x.id)?"":"hidden"}></div>${x.admin?"":acts(x,false)}</li>`).join("")}</ul>`:'<p class="fine">No fans match.</p>'}`;
    $("mShow").value=F.show;$("mSort").value=F.sort;
    $("mShow").onchange=()=>{F.show=$("mShow").value;paintFans(body)};$("mSort").onchange=()=>{F.sort=$("mSort").value;paintFans(body,true)};
    let qt;$("mQ").oninput=()=>{clearTimeout(qt);qt=setTimeout(()=>{F.q=$("mQ").value;const pos=$("mQ").selectionStart;paintFans(body,true).then(()=>{const i=$("mQ");i.focus();i.setSelectionRange(pos,pos)})},200)};
    body.querySelectorAll("[data-mx]").forEach(b=>b.onclick=async()=>{const id=b.dataset.mx,box=$("act-"+id);if(F.open.has(id)){F.open.delete(id);box.hidden=true;b.textContent="Show activity";b.setAttribute("aria-expanded","false");return}
      F.open.add(id);box.hidden=false;b.textContent="Hide activity";b.setAttribute("aria-expanded","true");box.innerHTML='<p class="fine">Loading…</p>';box.innerHTML=await activity(id)});
    for(const id of F.open){const box=$("act-"+id);if(box)activity(id).then(h=>{box.innerHTML=h})}
    wire()}
  const RPC={name:id=>["admin_reset_name",{target:id}],clear:id=>["admin_clear_data",{target:id}],ban:id=>["admin_ban",{target:id,why:null}],unban:id=>["admin_unban",{target:id}],ldel:id=>["admin_delete_league",{c:id}]};
  const DONE={name:"Name reset.",clear:"Predictions and scores cleared.",ban:"Fan banned. They can't save anything any more and show as “A fan”.",unban:"Ban lifted.",dismiss:"Report dismissed.",ldel:"League deleted.",lrename:"League renamed."};
  function wire(){document.querySelectorAll("#modBody [data-ma]").forEach(b=>b.onclick=async()=>{const a=b.dataset.ma,id=b.dataset.id;
    if(["clear","ban","ldel"].includes(a)&&b.dataset.sure!=="1"){b.dataset.sure="1";b.textContent="Click again to confirm";return}
    b.disabled=true;let r;
    if(a==="dismiss")r=await cl().rpc("admin_dismiss",{target:id,k:b.dataset.k});
    else if(a==="lrename")r=await cl().rpc("admin_rename_league",{c:id,n:b.parentNode.querySelector(".mren").value});
    else{const [f,args]=RPC[a](id);r=await cl().rpc(f,args)}
    if(r.error){b.disabled=false;xToast("That didn't work: "+r.error.message);return}
    xToast(DONE[a]);if(a==="name"||a==="ban"){XC.names[id]="";if(window.RT&&RT.names)RT.names[id]=""}if(a==="clear"||a==="ban")Object.values(XC.docs).forEach(c=>{if(c)delete c[id]});
    await loadBans();xRefresh();const mb=document.querySelector("#modDlg .modbox");if(mb)mb.focus();if(tab==="fans"){const body=$("modBody");await loadFans();paintFans(body,true)}else paint()})}
  function open(){let d=$("modDlg");if(!d){d=document.createElement("div");d.id="modDlg";d.className="moddlg";d.setAttribute("role","dialog");d.setAttribute("aria-modal","true");d.setAttribute("aria-labelledby","modT");
      d.innerHTML=`<div class="modbox" tabindex="-1"><div class="modtop"><h2 id="modT">Moderation</h2><button class="btn ghost sm" type="button" id="modX" aria-label="Close">✕</button></div>
        <div class="seg" role="tablist"><button type="button" role="tab" data-mt="fans">Fans</button><button type="button" role="tab" data-mt="reports">Reports</button><button type="button" role="tab" data-mt="leagues">Leagues</button></div>
        <p class="fine">Only you can see this. Reset name: their name goes back to “A fan”. Clear: deletes their predictions, votes and scores. Ban: they can't save names, predictions or scores and don't appear on leaderboards; it also takes them out of all leagues.</p><div id="modBody"></div></div>`;
      document.body.appendChild(d);$("modX").onclick=close;d.addEventListener("click",e=>{if(e.target===d)close()});document.addEventListener("keydown",e=>{const m=$("modDlg");if(e.key==="Escape"&&m&&!m.hidden)close()});
      d.querySelectorAll("[data-mt]").forEach(b=>b.onclick=()=>{tab=b.dataset.mt;mark();paint()})}
    d.hidden=false;document.body.style.overflow="hidden";mark();paint();$("modX").focus()}
  function mark(){document.querySelectorAll("#modDlg [data-mt]").forEach(b=>{const on=b.dataset.mt===tab;b.classList.toggle("on",on);b.setAttribute("aria-selected",on)})}
  function close(){const d=$("modDlg");if(d)d.hidden=true;document.body.style.overflow="";const b=$("modBtn");if(b&&b.offsetParent)b.focus();else{const a=$("acBtn");if(a)a.focus()}}
  const w=setInterval(async()=>{if(!FB_SITE.on||!XC.me)return;clearInterval(w);await loadBans();
    try{const {data}=await cl().rpc("is_admin");if(data!==true)return}catch(e){return}
    const host=document.querySelector(".bar .wrap"),acw=host&&host.querySelector(".acwrap");if(!host||$("modBtn"))return;
    const b=document.createElement("button");b.id="modBtn";b.type="button";b.className="hset hmod";b.title="Moderation";b.setAttribute("aria-label","Moderation");b.innerHTML=SHIELD;b.onclick=open;
    const wrap=document.createElement("div");wrap.className="modwrap";wrap.appendChild(b);host.insertBefore(wrap,acw||host.querySelector(".langpick"));
    /* also a button inside the account panel (the only place it shows on phones) */
    const addInPanel=()=>{const box=$("setAcct");if(box&&box.querySelector("#acOut")&&!$("modOpen")){const r=document.createElement("div");r.className="btns";r.innerHTML='<button class="btn sm" type="button" id="modOpen">'+SHIELD+' Moderation</button>';box.appendChild(r);$("modOpen").onclick=()=>{const p=$("acPanel");if(p)p.hidden=true;open()}}};
    new MutationObserver(addInPanel).observe(document.body,{childList:true,subtree:true});addInPanel()},800);
  setTimeout(()=>clearInterval(w),40000);
})();
