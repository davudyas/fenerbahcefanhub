const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const pg=await b.newPage({viewport:{width:390,height:844}});const errs=[];pg.on('pageerror',e=>errs.push(e.message));
await pg.goto('file://'+process.cwd()+'/fenerbahce.html');await pg.waitForTimeout(300);await pg.selectOption('#lang','ar');await pg.waitForTimeout(300);
await pg.locator('#leagueBox').screenshot({path:'../a2_league.png'});
await pg.evaluate(()=>{setSport('football');tab='europe';render()});await pg.waitForTimeout(150);await pg.screenshot({path:'../a2_eu.png',fullPage:false,clip:{x:0,y:0,width:390,height:844}});
await pg.evaluate(()=>document.getElementById('tabs').scrollIntoView());await pg.waitForTimeout(100);await pg.screenshot({path:'../a2_eu2.png'});
await pg.evaluate(()=>{tab='matches';render()});await pg.waitForTimeout(100);await pg.evaluate(()=>matchPage('football',0));await pg.waitForTimeout(150);await pg.screenshot({path:'../a2_mp.png'});
console.log(errs, await pg.evaluate(()=>document.documentElement.scrollWidth));await b.close()})();
