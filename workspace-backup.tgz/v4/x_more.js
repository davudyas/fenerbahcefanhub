/* ===== Deeper legends, early titles, fuller history (researched 7 November 2026) ===== */
const LEG_FACTS={
 "Lefter Küçükandonyadis":["215 official goals, first on the club's all-time list.","349 appearances."],
 "Can Bartu":["The first Turkish player to appear in a European final, with Fiorentina."],
 "Cemil Turan":["127 goals, sixth on the club's all-time list."],
 "Alex de Souza":["171 goals, third on the club's all-time list.","341 appearances."],
 "Volkan Demirel":["525 appearances, second only to Müjdat Yetkiner."],
 "Željko Obradović":["Five straight Final Fours, 2015 to 2019."],
 "Ekpe Udoh":["18 points in the 2017 semi-final against Real Madrid."],
 "Bogdan Bogdanović":["17 points in the 2017 final."],
 "Nigel Hayes-Davis":["23 points in the 2025 final against Monaco."],
 "Breanna Stewart":["35 points in the 2023 final, a 99–60 win over ÇBK Mersin."],
 "Julie Allemand":["13 points, 8 rebounds and 10 assists in the 2026 final."],
 "Kim Yeon-koung":["Wore number 10 in the 2012 Champions League-winning squad."],
 "Katarzyna Skowrońska":["Wore number 1 in the 2010 world champion squad."],
 "Naz Aydemir":["In both the 2010 and 2012 winning squads."],
 "Eda Erdem Dündar":["The only player in the 2010, 2012 and 2023–24 squads on this site."]};
const LEG_ADD={
 football:[
  ["Zeki Rıza Sporel","Forward · 1915–1934","The first great star of Turkish football and the club's leading scorer of the early era.",["Scored Turkey's first international goal, against Romania in 1923.","Club records credit him with around 470 goals, unofficial matches included."]],
  ["Fikret Arıcan","Forward · 1928–1947","Almost two decades in yellow and navy.",["109 goals, seventh on the club's all-time list."]],
  ["Naci Bastoncu","Forward · 1934–1947","A goalscorer of the club's first golden age.",["162 goals, fifth on the club's all-time list."]],
  ["Melih Kotanca","Forward · 1938–1948","Prolific striker of the National Division sides of the 1940s.",["172 goals, second on the club's all-time list."]],
  ["Şeref Has","Forward · 1955–1969","A loyal servant for fourteen seasons.",["382 appearances, fourth on the all-time list.","89 goals."]],
  ["Ogün Altıparmak","Forward · 1963–1971","Pace and goals in the title sides of the 1960s.",["89 goals, joint eighth on the all-time list."]],
  ["Müjdat Yetkiner","Defender · 1979–1996","Seventeen seasons, and more games than anyone in the club's history.",["570 appearances, the club record."]],
  ["Aykut Kocaman","Striker · 1988–1996","A penalty-box predator who came back to coach the club.",["167 goals, fourth on the all-time list.","As coach: the 2010–11 title and the 2012 and 2013 Turkish Cups."]],
  ["Rüştü Reçber","Goalkeeper · 1994–2007","Turkey's goalkeeper at the 2002 World Cup, where Turkey finished third.",["381 appearances for the club.","Named in the 2002 World Cup all-star team."]],
  ["Uche Okechukwu","Defender · 1990s","Nigerian centre-back who became the longest-serving foreign player in Turkish football.",[]],
  ["Tuncay Şanlı","Forward · 2002–2007","Versatile forward remembered for a Champions League hat-trick.",["Scored all three goals in a 3–0 win over Manchester United in December 2004."]],
  ["Zico","Head coach · 2006–2008","The Brazilian great won the 2006–07 title and took the team to the 2008 Champions League quarter-finals.",[]],
  ["Emre Belözoğlu","Midfielder · 2008–2020, with spells away","Captain and playmaker, and from November 2026 the head coach.",["Appointed head coach on 3 November 2026."]],
  ["Dirk Kuyt","Forward · 2012–2015","Tireless Dutch forward of the 2013–14 champions.",[]]],
 basketball:[
  ["Kostas Sloukas","Point guard · 2015–2021","Greek playmaker of the 2017 champions and five straight Final Fours.",[]],
  ["Luigi Datome","Forward · 2015–2019","Italian shooter and one of the leaders of the 2017 title team.",[]],
  ["Nikola Kalinić","Forward · 2016–2019","Two-way wing of the 2017 champions.",["17 points in the 2017 final."]],
  ["Bobby Dixon","Guard · 2014–2019","American-born guard who played for Turkey as Ali Muhammed.",["Part of the 2017 EuroLeague-winning team."]],
  ["Nicolò Melli","Forward · 2015–2019, 2024–","Scored 28 in the 2018 final, then came back to win the 2025 title.",["Still on the roster in 2026–27."]],
  ["Marko Gudurić","Guard · 2025 champion","19 points in the 2025 final, second only to Hayes-Davis.",["19 points against Monaco."]],
  ["Wade Baldwin IV","Guard · 2024–","A key guard in the 2025 title run.",["13 points in the 2025 final."]],
  ["İbrahim Kutluay","Shooting guard","One of the great shooters of Turkish basketball.",["The club retired his shirt in December 2025."]]],
 "womens-basketball":[
  ["Olcay Çakır","Guard","A club captain who came back again and again.",["Captain in 2022–23.","Three separate spells at the club."]],
  ["Tuğçe Canıtez","Center","A leader of the side that kept reaching European finals.",["Club captain from 2019 to 2022."]],
  ["Napheesa Collier","Forward · 2023–24","American star of the 2024 European title.",["33 points in the 2024 final against Villeneuve d'Ascq."]],
  ["Marina Maljković","Head coach · 2022–2023","Turned four lost finals into the first European title.",["Won the 2023 EuroLeague Women in Prague."]],
  ["Valérie Garnier","Head coach · 2023–2024","Coach of the perfect season.",["35–0 in the league and the 2024 EuroLeague, won in Mersin."]],
  ["Miguel Méndez","Head coach · 2025–","Led the 46–1 season and the third European title.",["2026 EuroLeague Women champion in Zaragoza."]]],
 volleyball:[
  ["Seda Tokatlıoğlu","Opposite · 2010 world champion","A two-time captain.",["Captain in 2005–06 and again from 2011 to 2014."]],
  ["Çiğdem Can Rasna","Middle blocker","Captain of the world champion era.",["Club captain from 2008 to 2011.","In the 2010 world champion squad."]],
  ["Fofão","Setter · 2010","Brazilian setting great who ran the offence of the 2010 world champions.",[]],
  ["Logan Tom","Outside hitter · 2012","US international in the 2012 Champions League-winning squad.",[]],
  ["Fabiana Claudino","Middle blocker · 2012","Brazilian Olympic champion who wore number 1 in the 2012 squad.",[]],
  ["Zé Roberto","Head coach · 2010–2012","Brazil's Olympic-winning coach took Fenerbahçe to the top of Europe.",["Coach of the 2012 Champions League win in Baku."]],
  ["Stefano Lavarini","Head coach · 2023–2024","Won the 2023–24 league and cup double.",[]]],
 more:[
  ["Ramil Guliyev","Athletics · sprinter","The fastest man in the club's history.",["200 m world champion in 2017.","European champion in 2018."]],
  ["Eşref Apak","Athletics · hammer","An Olympic medal in the hammer throw.",["Silver at the 2004 Athens Olympics."]],
  ["Ruhi Sarıalp","Athletics · triple jump","A pioneer of Turkish athletics.",["Bronze at the 1948 London Olympics."]],
  ["Yasmani Copello","Athletics · 400 m hurdles","Olympic medallist for Turkey in Rio.",["Bronze at the 2016 Rio Olympics."]],
  ["Karin Melis Mey","Athletics · long jump","A world championship medal in the long jump.",["Bronze at the 2009 World Championships."]],
  ["Tonguç Türsan","Rowing","The rower who gave Turkey its first international success in the sport.",["Silver at the 1955 Mediterranean Games."]],
  ["Tuğçe Subaşı","Sailing","A world champion on the water.",["Laser 4.7 world champion in 2002."]],
  ["Hikmet Topuzer","Club pioneer","The man behind the badge.",["Designed the club crest in 1910."]]]};
const HIST_ADD={
 football:[["1908","A home ground in Kadıköy","The Union Club Field opens on the spot where Şükrü Saracoğlu stands today, and Fenerbahçe play there. The club joins the Istanbul Football League a year later."],
  ["1912","First Istanbul League title","The 1911–12 Istanbul Football League is the club's first title, the start of a record 16."],
  ["1933","Champions of Turkey, owners of their ground","Fenerbahçe win the Turkish Football Championship for the first time and buy their ground from the state on 27 May."],
  ["1937","First National Division title","The nationwide National Division (Milli Küme) starts, and Fenerbahçe win it. Five more follow by 1950."],
  ["1960","Europe for the first time","A first European Cup campaign ends in a play-off against Nice."],
  ["1968","Manchester City knocked out","Under Ignác Molnár, Fenerbahçe knock the English champions out of the European Cup in the first round."],
  ["1996","A win at Old Trafford","A 1–0 Champions League win at Manchester United ends their 40-year unbeaten home record in European competition."],
  ["2001","Galatasaray's run ended","Fenerbahçe win the title and stop Galatasaray's streak of four in a row."],
  ["2004","Tuncay's hat-trick","Tuncay Şanlı scores all three in a 3–0 Champions League win over Manchester United in Istanbul."],
  ["2007","Zico's champions","Brazilian coach Zico leads Fenerbahçe to the 2006–07 title, the club's 17th."],
  ["2009","A European final in Kadıköy","Şükrü Saracoğlu hosts the UEFA Cup final, won 2–1 by Shakhtar Donetsk against Werder Bremen."],
  ["2011","Champions under Aykut Kocaman","A former goal machine of the club coaches Fenerbahçe to the 2010–11 title, number 18."],
  ["2013","Europa League semi-final","Fenerbahçe reach the last four, where Benfica win the tie."],
  ["2024","Conference League quarter-finals","A run to the last eight ends against Olympiacos."]],
 basketball:[["1957","First Turkish title","The first of 16 Turkish championships."],["1967","First Turkish Cup","The first of 10 Turkish Cups."],["2010","Into the Sinan Erdem Dome","Home games move to the Sinan Erdem Dome."],
  ["2015","First Final Four","A first EuroLeague Final Four, in Madrid, under Željko Obradović."],["2019","Five in a row","The Final Four in Vitoria-Gasteiz is the fifth in a row."],["2022","A museum for the branch","The Fenerbahçe Basketball Museum opens."],
  ["2024","Back among Europe's best","Under Šarūnas Jasikevičius, Fenerbahçe return to the Final Four, in Berlin."]],
 "womens-basketball":[["2014","Another final","A second straight EuroLeague final ends in defeat."],["2017","Third final","Another EuroLeague final, another runner-up medal."],
  ["2022","Fourth final, new coach","A fourth lost EuroLeague final. Marina Maljković takes over and builds the team that wins it a year later."],["2025","Miguel Méndez arrives","The new coach leads the 46–1 season that follows."]],
 volleyball:[["1977","The section closes","The volleyball section closes for lack of funds, before coming back."],["2009","First modern league title","The first Turkish league title in the current format. The men win the Balkan Cup."],
  ["2011","Third in Europe","A Champions League podium the year after reaching the final."],["2015","League and cup","A league title and Turkish Cup double."],["2016","Third again","Another Champions League bronze."],
  ["2017","Double again","League title and Turkish Cup once more."],["2023","Champions again","A first league title since 2017."],["2025","Cup winners","The Turkish Cup, a fifth in the club's history."]]};
const TROPHY_PRE=[["16","Istanbul Football League","1911–12, 1913–14, 1914–15, 1920–21, 1922–23, 1929–30, 1932–33, 1934–35, 1935–36, 1936–37, 1943–44, 1946–47, 1947–48, 1952–53, 1956–57, 1958–59","pre"],
 ["6","National Division (Milli Küme)","1937, 1940, 1943, 1945, 1946, 1950","pre"],["3","Turkish Football Championship","1933, 1935, 1944","pre"],["4","Istanbul Shield","1929–30, 1933–34, 1937–38, 1938–39","pre"]];
/* runs after buildI18n(), so the translation packs still zip against the original arrays */
function mergeContent(){
  Object.entries(LEG_ADD).forEach(([b,list])=>{const S=SPORTS[b];S.legends=(S.legends||[]).concat(list)});
  Object.values(SPORTS).forEach(S=>(S.legends||[]).forEach(l=>{if(!l[3])l[3]=LEG_FACTS[l[0]]||[]}));
  Object.entries(HIST_ADD).forEach(([b,list])=>{const S=SPORTS[b];S.history=S.history.concat(list).sort((a,c)=>parseInt(a[0],10)-parseInt(c[0],10))});
  SPORTS.more.history=CLUB_EVENTS.filter(e=>[1907,1910,1913,1914,1917,1928,1932,1948,1995,2002,2004,2015,2016,2017,2024,2026].includes(e[0])).filter((e,i,a)=>a.findIndex(x=>x[0]===e[0])===i).map(([y,txt,br])=>[String(y),txt,br]);
  const F=SPORTS.football;F.trophies[0]=["28","Turkish championship","1933, 1935, 1937, 1940, 1943, 1944, 1945, 1946, 1950, 1959, 1961, 1964, 1965, 1968, 1970, 1974, 1975, 1978, 1983, 1985, 1989, 1996, 2001, 2004, 2005, 2007, 2011, 2014"];
  F.trophies.splice(3,0,TROPHY_PRE[0].slice(0,3),TROPHY_PRE[3].slice(0,3));F.stats[0]=["28","Turkish championships"];
  F.history=F.history.map(h=>h[0]==="2014"&&/19/.test(h[1])?["2014","Title number 28","Fenerbahçe win the 2013–14 Süper Lig, their 28th national title in the club's count and their most recent league crown."]:h);
}

/* ===== Branch-specific Higher or Lower and Guess the Score ===== */
function luPoints(items,label){const out=[];(items||[]).forEach(L=>{L.st.forEach(([p,n,pts])=>{if(pts)out.push([n+" · "+L.label,pts])});L.bench.forEach(([n,pts])=>{if(pts)out.push([n+" · "+L.label,pts])})});return {key:"pts",label,items:out}}
const evYears=(list,label)=>({key:"year",label,year:true,items:list.map(([y,tx])=>[tx,y])});
const HOL_BY={
 football:()=>[HOL_SETS[0],HOL_SETS[1],{key:"titles",label:"titles",items:[["Turkish championships",28],["Turkish Cups",7],["Turkish Super Cups",10],["Istanbul Football League titles",16],["Istanbul Shields",4]]}],
 basketball:()=>[luPoints(MB_LINEUPS,"points in that Final Four game"),evYears(MB_EVENTS,"year it happened")],
 "womens-basketball":()=>[luPoints(WB_LINEUPS,"points in that final"),evYears(WB_EVENTS,"year it happened")],
 volleyball:()=>[evYears(VB_EVENTS,"year it happened"),{key:"titles",label:"titles",items:[["Turkish league titles",15],["Turkish Cups",5],["CEV Champions League titles",1],["Club World titles",1],["CEV Cups",1],["Men's Balkan Cups",2],["Men's CEV Challenge Cups",1]]}],
 more:()=>[HOL_SETS[2],evYears(CLUB_EVENTS,"year it happened")]};
const HOL_CACHE={};const holSets=b=>HOL_CACHE[b]||(HOL_CACHE[b]=HOL_BY[b]().filter(s=>s.items.length>2));
const holsS={};
function holPick2(set,not){const pool=set.items.filter(x=>!not.includes(x[0]));return pool[Math.floor(Math.random()*pool.length)]}
function newHolB(b,mode){const sets=holSets(b),prev=holsS[b];mode=mode||(prev?prev.mode:"mixed");const set=mode==="mixed"?sets[Math.floor(Math.random()*sets.length)]:sets.find(s=>s.key===mode)||sets[0];const a=holPick2(set,[]);holsS[b]={b,mode,set,a,b2:holPick2(set,[a[0]]),streak:0,phase:"ask",last:null,over:false};return holsS[b]}
function gHoL(el){const b=current,sets=holSets(b);let H=holsS[b]||newHolB(b,"mixed");hol=H;const best=store.get("fb-hol-best",0);
  const val=(x,set)=>set.year?String(x[1]):x[1],card=(x,show,cls)=>`<div class="holcard card ${cls||""}"><span class="label">${esc(t(H.set.label))}</span><b>${esc(t(x[0]))}</b><span class="hv">${show?val(x,H.set):"?"}</span></div>`;
  const modes=[["mixed","Mixed"]].concat(sets.map(s=>[s.key,{goals:"Goals",apps:"Appearances",titles:"Titles",pts:"Points",year:"Years"}[s.key]]));
  el.innerHTML=`<h2>${t("Higher or Lower")}</h2><p class="intro">${t(H.set.year?"Did the second event happen later than the first? Higher means a later year.":"Does the second record beat the first? Guess higher or lower and keep the run going. Equal numbers count either way.")}</p>
   <div class="filter" role="group" aria-label="${t("Category")}">${modes.map(([k,l])=>`<button data-hm="${k}" aria-pressed="${H.mode===k}">${t(l)}</button>`).join("")}</div>
   <div class="tlhead"><div><b class="count">${H.streak}</b><span class="label">${t("run")}</span></div><div><b class="count">${best}</b><span class="label">${t("record")}</span></div></div>
   <div class="holrow">${card(H.a,true)}<span class="vsx">${t("vs")}</span>${card(H.b2,H.phase!=="ask",H.last==null?"":H.last?"ok":"no")}</div>
   ${H.phase==="ask"?`<div class="btns"><button class="btn" data-hl="hi">▲ ${t(H.set.year?"Later":"Higher")}</button><button class="btn" data-hl="lo">▼ ${t(H.set.year?"Earlier":"Lower")}</button></div>`
    :H.over?`<p class="msg bad">${tf("Run over at {n}.",{n:H.streak})}</p><div class="btns"><button class="btn" data-hl="again">${t("Play again")}</button></div>`
    :`<p class="msg good">${t("Correct.")}</p><div class="btns"><button class="btn" data-hl="next">${t("Next")}</button></div>`}
   <p class="gnote">${t(b==="football"?"Goals as listed in the club records up to 2016, appearances up to 2019, titles as shown on this site.":b.includes("basketball")?"Points come from the box scores in Name the Lineup.":"Years and titles as shown on this site.")}</p>`;
  el.querySelectorAll("[data-hm]").forEach(x=>x.onclick=()=>{newHolB(b,x.dataset.hm);rerender()});
  el.querySelectorAll("[data-hl]").forEach(x=>x.onclick=()=>{const k=x.dataset.hl;
    if(k==="hi"||k==="lo"){const ok=k==="hi"?H.b2[1]>=H.a[1]:H.b2[1]<=H.a[1];H.last=ok;H.phase="show";if(ok){H.streak++;if(H.streak>store.get("fb-hol-best",0))store.set("fb-hol-best",H.streak)}else H.over=true;xBadgeCheck();xSyncScores()}
    else if(k==="next"){if(H.mode==="mixed"&&Math.random()<.4){H.set=sets[Math.floor(Math.random()*sets.length)];H.a=holPick2(H.set,[])}else H.a=H.b2;H.b2=holPick2(H.set,[H.a[0]]);H.phase="ask";H.last=null}
    else newHolB(b);rerender()})}
function gtsPoolB(b){const all=gtsPool().filter(x=>x.b===b),sc=s=>{const m=String(s).match(/^(\d+)–(\d+)/);return m?[+m[1],+m[2]]:null};
  if(b==="basketball"||b==="womens-basketball")(b==="basketball"?MB_LINEUPS:WB_LINEUPS).forEach(L=>{const r=sc(L.score);if(r&&L.date)all.push({b,date:L.date,comp:L.title,home:"Fenerbahçe",away:L.opp,hs:r[0],as:r[1],where:L.where,neutral:true})});
  if(b!=="football"&&b!=="basketball")(LIVE[b]||(b==="more"?LIVE["womens-football"]:null)||{last:[]}).last.forEach(r=>{const fbH=r[2]!=="A";all.push({b,date:r[0]||"",comp:r[1],home:fbH?"Fenerbahçe":r[3],away:fbH?r[3]:"Fenerbahçe",hs:fbH?+r[4]:+r[5],as:fbH?+r[5]:+r[4],note:r[6]})});
  if(b==="womens-basketball")SPORTS[b].games.forEach(g=>{const r=sc(g.res);if(r)all.push({b,date:g.date,comp:g.comp,home:g.home,away:g.away,hs:r[0],as:r[1],where:g.where,note:g.note})});
  const seen=new Set();return all.filter(x=>{const k=x.home+x.away+x.hs+x.as;if(seen.has(k))return false;seen.add(k);return true})}
const gtsS={};
function newGtsB(b){gtsS[b]={items:shuffle(gtsPoolB(b)).slice(0,8),i:0,score:0,ex:0,ans:null};return gtsS[b]}
function gGTS(el){const b=current;let G=gtsS[b]||newGtsB(b);gts=G;const N=G.items.length;
  if(!N){el.innerHTML=`<h2>${t("Guess the Score")}</h2><p class="intro">${t("No results with scores yet for this branch.")}</p>`;return}
  if(G.i>=N){const best=store.get("fb-gts-best",0);if(G.score>best)store.set("fb-gts-best",G.score);
    el.innerHTML=`<h2>${t("Guess the Score")}</h2><div class="quiz"><span class="label">${t("Final score")}</span><div class="final">${G.score}/${N*3}</div><p class="gnote">${tf("Exact scores: {n}. Best: {b}/{m}",{n:G.ex,b:Math.max(best,G.score),m:24})}</p><button class="btn" data-g="again" style="margin-top:14px">${t("Play again")}</button></div>`;
    el.querySelector('[data-g="again"]').onclick=()=>{newGtsB(b);rerender()};xSyncScores();xBadgeCheck();return}
  const x=G.items[G.i],bb=x.b.includes("basketball"),max=bb?199:x.b.includes("volleyball")?3:20,dt=x.date.length===10?mDate(x.date):x.date.length>=4?x.date.slice(0,4):"";
  el.innerHTML=`<h2>${t("Guess the Score")}</h2><p class="intro">${t(bb?"Eight real Fenerbahçe results with the score hidden. The right winner earns 1 point, and 3 if both scores are within 5 points.":x.b.includes("volleyball")?"Real Fenerbahçe results with the score in sets hidden. 3 points for the exact score, 1 for the right winner.":"Eight real Fenerbahçe results with the score hidden. 3 points for the exact score, 1 for the right result.")}</p>
   <div class="quiz"><div class="top"><span class="label">${tf("Match {i} of {n}",{i:G.i+1,n:N})}</span><span class="label">${tf("Score {n}",{n:G.score})}</span></div><div class="progress"><i style="width:${G.i/N*100}%"></i></div>
    <span class="label" style="margin-top:12px;display:block">${esc(t(x.comp))}${dt?` · ${dt}`:""}${x.where?` · ${esc(t(x.where))}`:""}</span>
    <div class="gtsrow"><label class="pin"><span>${esc(x.home)}</span><input id="gH" type="number" min="0" max="${max}" inputmode="numeric" ${G.ans?"disabled":""} value="${G.ans?G.ans[0]:""}"></label><span class="dash">–</span><label class="pin"><span>${esc(x.away)}</span><input id="gA" type="number" min="0" max="${max}" inputmode="numeric" ${G.ans?"disabled":""} value="${G.ans?G.ans[1]:""}"></label></div>
    ${G.ans?`<p class="explain"><b>${G.ans[2]===3?t("Spot on! +3"):G.ans[2]?tf("Right result, +{n}",{n:G.ans[2]}):t("Not this time.")}</b> ${tf("It finished {h}–{a}.",{h:x.hs,a:x.as})} ${x.note&&x.date?esc(t(x.note)):""}</p><button class="btn" data-g="next" style="margin-top:12px">${G.i+1<N?t("Next match"):t("See score")}</button>`
     :`<div class="btns"><button class="btn" data-g="go">${t("Lock it in")}</button></div>`}</div>`;
  const on=(k,f)=>{const q=el.querySelector(`[data-g="${k}"]`);if(q)q.onclick=f};
  on("go",()=>{const h=parseInt(el.querySelector("#gH").value,10),a=parseInt(el.querySelector("#gA").value,10);if(isNaN(h)||isNaN(a))return;const sg=v=>Math.sign(v),out=sg(h-a)===sg(x.hs-x.as)?1:0;
    const p=bb?out+(out&&Math.abs(h-x.hs)<=5&&Math.abs(a-x.as)<=5?2:0):(h===x.hs&&a===x.as?3:out);G.ans=[h,a,p];G.score+=p;if(p===3){G.ex++;store.set("fb-gts-exact",store.get("fb-gts-exact",0)+1)}rerender()});
  on("next",()=>{G.i++;G.ans=null;rerender()})}

/* ===== Themes ===== */
const THEMES=[["light","Light","#eef1f6","#0d1c3d"],["night","Kadıköy Night","#0d1c3d","#ffe500"],["day","Matchday","#f3f0e6","#1b3878"],["canary","Canary","#ffd60a","#0d1c3d"],["retro","1907 Retro","#efe4cc","#1d2f5c"],["flood","Floodlights","#000000","#ffe500"],["clean","Clean","#ffffff","#1b3878"],["bosphorus","Bosphorus","#04212b","#ffe500"],["pitch","Saracoğlu Pitch","#062014","#ffe500"],["sunset","Kadıköy Sunset","#fbeee2","#b8461b"],["sky","Sky Blue","#eaf3fb","#1660b8"]];
/* Matchday is the default design (v28). Anyone still on the old default (Light) moves to it once; a design someone picked themselves is kept */
let THEME=(()=>{try{const v=localStorage.getItem("fb-theme");if(localStorage.getItem("fb-look")!=="28"){localStorage.setItem("fb-look","28");if(!v||v==="light"){localStorage.setItem("fb-theme","day");return "day"}}
  if(THEMES.some(x=>x[0]===v))return v}catch(e){}return "day"})();
const FONT_EXTRA={retro:"https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&display=swap",ar:"https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap"};FONT_EXTRA.fa=FONT_EXTRA.ar;FONT_EXTRA.ru="https://fonts.googleapis.com/css2?family=Oswald:wght@500;600;700&family=Roboto:wght@400;500;700&display=swap";
function applyTheme(v){THEME=v;if(v==="retro"&&window.loadFont)loadFont(FONT_EXTRA.retro);document.documentElement.dataset.theme=v;try{localStorage.setItem("fb-theme",v)}catch(e){}const T=THEMES.find(x=>x[0]===v);const sw=document.getElementById("themeSw");if(sw){sw.style.background=`linear-gradient(135deg,${T[2]} 50%,${T[3]} 50%)`;sw.style.boxShadow="0 0 0 1.5px var(--line-2)"}
  const s=document.getElementById("theme");if(s)s.value=v;if(tab==="play"&&playSel[current]==="penalties"&&typeof drawWheel==="function")drawWheel(document.getElementById("wheel"))}
function initTheme(){const s=document.getElementById("theme");s.innerHTML=THEMES.map(([k,n])=>`<option value="${k}">${esc(t(n))}</option>`).join("");s.onchange=e=>applyTheme(e.target.value);applyTheme(THEME)}
function themeTexts(){const s=document.getElementById("theme");if(!s)return;[...s.options].forEach((o,i)=>o.textContent=t(THEMES[i][1]));s.setAttribute("aria-label",t("Design"));s.value=THEME}
