/* Stand-alone site test: two fans in separate browsers, Supabase replaced by an in-memory hub */
const {chromium}=require('playwright');const fs=require('fs'),path=require('path');
const SITE=path.resolve(__dirname,'../site');
let html=fs.readFileSync(SITE+'/index.html','utf8');
html=html.replace(/window\.FB_SB=\{[^<]*\};/,'window.FB_SB={"url":"https://mock.supabase.co","key":"anon"};').replace(/<script src="https:\/\/cdn\.jsdelivr[^"]*"><\/script>/,'<script src="mocksb.js"></script>');
fs.writeFileSync(SITE+'/_t.html',html);fs.copyFileSync(__dirname+'/mocksb.js',SITE+'/mocksb.js');
const docs=new Map(),profiles=new Map(),subs=new Map(),pres={},uidOf=new Map();let rls=0;
const push=(cid,k,a)=>{const s=subs.get(cid);if(s)s.page.evaluate(([c,k,a])=>window.__mockRecv&&window.__mockRecv(c,k,a),[cid,k,a]).catch(()=>{})};
const presPush=name=>{for(const [cid,s] of subs)if(s.name===name)push(cid,'pres',pres[name]||{})};
const users=new Map();
function hub(page,st){
 if(st.op==='auth'){uidOf.set(page,st.uid);return {}}
 if(st.op==='upd'){if(st.email){for(const [e,u] of users)if(e===st.email&&u.id!==st.uid)return {error:{message:'A user with this email address has already been registered',code:'email_exists',status:422}};users.set(st.email,{id:st.uid,pw:null})}
   if(st.password){const e=[...users].find(([e,u])=>u.id===st.uid);if(!e)return {error:{message:'email not confirmed'}};e[1].pw=st.password}return {}}
 if(st.op==='login'){const u=users.get(st.email);if(!u||u.pw!==st.password)return {error:{message:'Invalid login credentials',code:'invalid_credentials',status:400}};return {uid:u.id}}
 if(st.op==='sub'){subs.set(st.cid,{page,name:st.name,pg:st.pg});if(pres[st.name])setTimeout(()=>presPush(st.name),20);return {}}
 if(st.op==='unsub'){subs.delete(st.cid);if(pres[st.name]&&st.key){delete pres[st.name][st.key];presPush(st.name)}return {}}
 if(st.op==='send'){for(const [cid,s] of subs)if(s.name===st.name)push(cid,'bc',{event:st.event,payload:st.payload});return {}}
 if(st.op==='track'){(pres[st.name]=pres[st.name]||{})[st.key]=[{...st.meta,presence_ref:'r'}];presPush(st.name);return {}}
 if(st.op==='untrack'){if(pres[st.name]){delete pres[st.name][st.key];presPush(st.name)}return {}}
 const T=st.table==='docs'?docs:profiles;
 if(st.op==='upsert'){const me=uidOf.get(page)||null;if(st.row.id!==me){rls++;return {error:{message:'violates row-level security'}}}
  const key=st.table==='docs'?st.row.col+'|'+st.row.id:st.row.id;T.set(key,st.row);
  for(const [cid,s] of subs){if(!s.pg||s.pg.table!==st.table)continue;if(s.pg.filter){const [k,v]=s.pg.filter.split('=eq.');if(String(st.row[k])!==v)continue}push(cid,'pg',{eventType:'UPDATE',new:st.row,old:{}})}
  return {data:null}}
 let rows=[...T.values()];for(const [op,k,v] of st.f)rows=rows.filter(r=>op==='eq'?r[k]===v:v.includes(r[k]));
 return {data:st.single?(rows[0]||null):rows}}
(async()=>{const b=await chromium.launch();const errs=[];const log=(...a)=>console.log(...a);
const mk=async()=>{const ctx=await b.newContext({viewport:{width:1100,height:900}});await ctx.exposeBinding('__hub',(src,st)=>hub(src.page,st));const pg=await ctx.newPage();
 pg.on('pageerror',e=>errs.push(e.message));await pg.goto('file://'+SITE+'/_t.html#football-matches');await pg.waitForFunction(()=>typeof XC!=='undefined'&&XC.on,null,{timeout:8000});await pg.waitForTimeout(300);return pg};
const ready=pg=>pg.waitForFunction(()=>typeof XC!=='undefined'&&XC.on,null,{timeout:8000});
const openSet=async pg=>{await pg.waitForSelector('#acBtn');if(await pg.evaluate(()=>$('acPanel').hidden))await pg.click('#acBtn');await pg.waitForTimeout(350)};
const acc=async(pg,mode,u,p)=>{await openSet(pg);await pg.fill('#acUser',u);await pg.fill('#acPw',p);await pg.click(`[data-ac="${mode}"]`);await pg.waitForTimeout(600)};
const A=await mk();const ida=await A.evaluate(()=>XC.me);
await A.evaluate(()=>{const P={'football|2026-11-22|Test':[3,0]};store.set('fb-preds',P);store.set('fb-hol-best',12);return xWrite('predictions',{p:P})});await A.evaluate(()=>xSyncScores());await A.waitForTimeout(1800);
await openSet(A);log('guest view:',await A.evaluate(()=>$('setAcct').innerText.replace(/\n+/g,' | ').slice(0,200)));
await A.screenshot({path:path.resolve(__dirname,'../acc_guest.png')});
await acc(A,'register','ab','secret1');log('short name:',await A.evaluate(()=>$('acMsg').textContent));
await acc(A,'register','Kanarya1907','123');log('short pw:',await A.evaluate(()=>$('acMsg').textContent));
await acc(A,'register','Kanarya1907','secret1');log('after register:',await A.evaluate(()=>$('setAcct').innerText.replace(/\n+/g,' | ')),'same id:',await A.evaluate(()=>XC.me)===ida,'fan name:',JSON.stringify(profiles.get(ida)&&profiles.get(ida).name));
await A.screenshot({path:path.resolve(__dirname,'../acc_in.png')});
const B=await mk();const idb=await B.evaluate(()=>XC.me);
await acc(B,'register','kanarya1907','other12');log('taken:',await B.evaluate(()=>$('acMsg').textContent));
await acc(B,'login','kanarya1907','nope123');log('wrong pw:',await B.evaluate(()=>$('acMsg').textContent));
await acc(B,'login','kanarya1907','secret1');await B.waitForTimeout(500);await ready(B);await B.waitForTimeout(800);
log('B after login: id is A:',await B.evaluate(()=>XC.me)===ida,'preds hydrated:',await B.evaluate(()=>JSON.stringify(store.get('fb-preds',{}))));
await B.evaluate(()=>xSyncScores());await B.waitForTimeout(2000);log('scores kept best:',JSON.stringify(docs.get('scores|'+ida).data.s.hol));
await openSet(B);log('B account:',await B.evaluate(()=>$('setAcct').innerText.replace(/\n+/g,' | ')));await B.screenshot({path:path.resolve(__dirname,'../acc_in.png')});
await B.click('#acOut');await B.waitForTimeout(500);await ready(B);await B.waitForTimeout(500);
log('after logout: new guest',await B.evaluate(()=>XC.me)!==ida,'local preds:',await B.evaluate(()=>JSON.stringify(store.get('fb-preds',{}))));
await B.evaluate(()=>{setLang?0:0});
// Enter key logs in rather than registering
const C=await mk();await openSet(C);await C.fill('#acUser','kanarya1907');await C.fill('#acPw','secret1');await C.press('#acPw','Enter');await C.waitForTimeout(400);await ready(C);await C.waitForTimeout(600);log('Enter = login:',await C.evaluate(()=>XC.me)===ida);
log('button label:',await C.evaluate(()=>$('acBtn').innerText));
await C.setViewportSize({width:375,height:800});await C.waitForTimeout(200);await C.click('#acBtn');await C.waitForTimeout(300);await C.screenshot({path:path.resolve(__dirname,'../acc_mob.png')});
log('header overflow at 375:',await C.evaluate(()=>{const w=document.querySelector('.bar .wrap');return w.scrollWidth>w.clientWidth+1}));
await C.evaluate(()=>{$('lang').value='tr';$('lang').dispatchEvent(new Event('change'))});await C.waitForTimeout(1200);log('TR title:',await C.evaluate(()=>$('acTitle').textContent),await C.evaluate(()=>$('acBtn').getAttribute('aria-label')));
log('errs',JSON.stringify(errs));await b.close();fs.unlinkSync(SITE+'/_t.html');fs.unlinkSync(SITE+'/mocksb.js')})().catch(e=>{console.error('FAIL',e.message.slice(0,500));process.exit(1)});
