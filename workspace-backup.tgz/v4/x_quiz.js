/* ===== Quiz with five levels. Questions are built from the facts already on this site (history, trophies,
   legends, records, league finishes, European ties, box scores and squads), so every answer can be checked on the page. ===== */
const QLV=[["easy","Easy",3,0,"Three options. The basics every fan knows."],["normal","Normal",4,0,"Four options. Titles, legends and famous nights."],
 ["hard","Hard",4,0,"Four options. Seasons, line-ups and closer guesses."],["super","Super hard",4,25,"Four options and 25 seconds a question."],
 ["extreme","Extreme",5,15,"Five options and 15 seconds. Deep cuts only."]];
const QN=7;
const qPick=a=>a[Math.floor(Math.random()*a.length)];
const yrOf=s=>{const m=String(s).match(/^(\d{4})/);return m?+m[1]:null};
/* build one question: q text, the right answer, a pool of wrong answers */
function qMk(q,right,wrong,n,e){right=String(right);const w=[...new Set(wrong.map(String))].filter(x=>x!==right&&x!=="");if(w.length<n-1)return null;
  const o=shuffle([right,...shuffle(w).slice(0,n-1)]);return {q,o,a:o.indexOf(right),e:e||""}}
const qNear=(v,spread,min=0)=>{const out=new Set();for(let i=1;out.size<8&&i<60;i++){const d=Math.ceil(Math.random()*spread)*(Math.random()<.5?-1:1),x=v+d;if(x>=min&&x!==v)out.add(x)}return [...out]};
const qYears=(y,spread)=>qNear(y,spread,1900).filter(x=>x<=2026);
const qScore=(s,mirror=true)=>{const m=String(s).match(/^(\d+)[–-](\d+)$/);if(!m)return [];const a=+m[1],b=+m[2],o=new Set();
  [[1,0],[0,1],[-1,0],[0,-1],[1,1],[2,0],[0,2],[-1,1],[1,-1]].concat(mirror?[[b-a,a-b]]:[]).forEach(([x,y])=>{const p=a+x,q=b+y;if(p>=0&&q>=0&&(p!==a||q!==b))o.add(`${p}–${q}`)});return [...o]};
const qPos=p=>p===1?t("Champions"):ordL(p);

/* ---------- question makers shared by every branch ---------- */
function qHistory(b,spread){const H=(SPORTS[b].history||[]).filter(h=>/^\d{4}$/.test(String(h[0]))&&!String(h[1]).includes(String(h[0])));if(!H.length)return null;const h=qPick(H),y=+h[0];
  return qMk(tf("In which year: “{h}”?",{h:t(h[1])}),y,qYears(y,spread),0,t(h[2]))}
function qTrophyCount(b,spread){const T=(SPORTS[b].trophies||[]).filter(x=>/^\d+$/.test(x[0])&&!/appearance|Triple|Final Four/i.test(x[1]));if(!T.length)return null;const x=qPick(T),c=+x[0];
  return qMk(tf("How many times has Fenerbahçe won the {x}?",{x:t(x[1])}),c,qNear(c,spread,1),0,t(x[2]))}
function qLegendRole(b){const L=(SPORTS[b].legends||[]);if(L.length<4)return null;const l=qPick(L),role=t(l[1]).split(" · ")[0],roles=[...new Set(L.map(x=>t(x[1]).split(" · ")[0]))];
  return qMk(tf("What was {n}'s role at Fenerbahçe?",{n:l[0]}),role,roles,0,t(l[2]))}
function qLegendYears(b){const L=(SPORTS[b].legends||[]).map(l=>[l[0],(t(l[1]).split(" · ")[1]||"")]).filter(x=>/^\d{4}([–-]\d{0,4})?(, \d{4}.*)?$/.test(x[1]));if(L.length<4)return null;const l=qPick(L);
  return qMk(tf("When was {n} at Fenerbahçe?",{n:l[0]}),l[1],L.map(x=>x[1]),0)}
function qLegendWho(b){const L=(SPORTS[b].legends||[]);if(L.length<4)return null;const l=qPick(L.filter(x=>!x[2].includes(x[0].split(" ")[0])));if(!l)return null;
  return qMk(tf("Who is this? “{d}”",{d:t(l[2])}),l[0],L.map(x=>x[0]),0,t(l[1]))}
function qGameScore(b){const G=(SPORTS[b].games||[]).filter(g=>g.res&&/^\d+–\d+$/.test(g.res));if(!G.length)return null;const g=qPick(G);
  return qMk(tf("{h} v {a}, {c} ({y}). What was the score?",{h:g.home,a:g.away,c:t(g.comp),y:String(g.date).slice(0,4)}),g.res,qScore(g.res),0,t(g.note))}
function qGameOpp(b){const G=(SPORTS[b].games||[]).filter(g=>g.res);if(G.length<4)return null;const g=qPick(G),opp=g.home==="Fenerbahçe"?g.away:g.home;
  return qMk(tf("Who did Fenerbahçe play in this game? {c}, {d}, {r}.",{c:t(g.comp),d:fmtDate(g.date),r:g.res}),opp,G.map(x=>x.home==="Fenerbahçe"?x.away:x.home),0,t(g.note))}
function qOldQuiz(b,n){const Q=SPORTS[b].quiz;if(!Q||!Q.length)return null;const x=qPick(Q),right=x.o[x.a],wrong=x.o.filter((_,i)=>i!==x.a);
  return qMk(t(x.q),t(right),wrong.map(w=>t(w)),0,t(x.e||""))}
function qRecord(b){const R=RECORDS[b];if(!R)return null;const f=qPick(R.facts),v=f[0];let wrong;
  let q;if(/^\d+$/.test(v)){const yr=+v>1900&&+v<2100;wrong=yr?qYears(+v,8):qNear(+v,Math.max(3,Math.round(+v*.25)),1);q=tf(yr?"Club record: {k}. In which year?":"Club record: {k}. What is the number?",{k:t(f[1])})}
  else if(/^\d+–\d+$/.test(v)){wrong=qScore(v,false);q=tf("Club record: {k}. Which is right?",{k:t(f[1])})}else return null;
  return qMk(q,v,wrong,0,t(f[2]))}
function qTitleYear(b,lvl){const H=SZ_HIST[b];if(!H||!H.t||H.t.length<2)return null;const y=qPick(H.t),wrong=[];for(let x=Math.max(b==="volleyball"?2009:0,Math.min(...H.t)-3);x<=2026;x++)if(!H.t.includes(x))wrong.push(x);
  const near=lvl==="easy"?wrong:wrong.filter(x=>Math.abs(x-y)<=6);return qMk(tf("Which of these years ended with a Turkish league title?"),y,near,0)}

/* ---------- football ---------- */

function qFbFinish(range){const S=SEASON_POS.filter(([s])=>{const y=yrOf(s);return y>=range[0]&&y<=range[1]});if(!S.length)return null;const [s,p]=qPick(S);
  const opts=[1,2,3,4,5,6,7,8].filter(x=>x!==p).map(qPos);return qMk(tf("Where did Fenerbahçe finish in the league in {s}?",{s:seasonLabel(s)}),qPos(p),opts,0)}
function qFbTitleSeason(range){const T=SEASON_POS.filter(([s,p])=>p===1&&yrOf(s)>=range[0]&&yrOf(s)<=range[1]);const N=SEASON_POS.filter(([s,p])=>p>1&&yrOf(s)>=range[0]-5&&yrOf(s)<=range[1]+5);if(!T.length)return null;
  return qMk(t("Which of these seasons ended with a Turkish league title?"),seasonLabel(qPick(T)[0]),N.map(x=>seasonLabel(x[0])),0)}
function qFbXI(range){const S=SEASONS.filter(x=>{const y=yrOf(x[0]);return y>=range[0]&&y<=range[1]});if(!S.length)return null;const s=qPick(S),xi=s[3].flat(),y=yrOf(s[0]);
  const wrong=Object.entries(PEOPLE).filter(([n,v])=>!xi.includes(n)&&v.seasons&&v.seasons.length&&!v.seasons.includes(s[0])&&v.seasons.some(z=>Math.abs(yrOf(z)-y)<=6)).map(([n])=>n);
  return qMk(tf("Who was in Fenerbahçe's most-used league XI in {s}?",{s:seasonLabel(s[0])}),qPick(xi),wrong,0)}
function qFbNat(){const P=PLAYERS.filter(p=>p.nat&&NAT[p.nat]);const p=qPick(P),nm=c=>capFirst(t(NAT[c].replace(/^the /,"")));
  return qMk(tf("Which country is {n} from?",{n:p.n}),nm(p.nat),Object.keys(NAT).filter(c=>c!==p.nat).map(nm),0)}
function qEuOpp(filter){const R=EU_TIES.filter(filter);if(!R.length)return null;const r=qPick(R),same=new Set(EU_TIES.filter(x=>x[0]===r[0]).map(x=>x[3]));
  return qMk(tf("Who did Fenerbahçe play in the {c} in {s} ({r})?",{c:t(EU_COMP[r[1]]),s:r[0],r:t(r[2])}),r[3],EU_TIES.filter(x=>!same.has(x[3])&&x[1]===r[1]).map(x=>x[3]),0,
    tf("Home {h}, away {a}, Fenerbahçe first.",{h:r[5].replace("-","–"),a:r[6].replace("-","–")}))}
function qEuOut(){const bySeason={};EU_TIES.forEach(r=>{(bySeason[r[0]]=bySeason[r[0]]||[]).push(r)});const outs=Object.values(bySeason).map(L=>L[L.length-1]).filter(r=>!/^[GL]\d/.test(r[7])&&euTie(r).k==="L");if(!outs.length)return null;
  const r=qPick(outs);return qMk(tf("Who knocked Fenerbahçe out of Europe in {s}?",{s:r[0]}),r[3],outs.filter(x=>x[3]!==r[3]).map(x=>x[3]),0,tf("{c}, {r}: {g} on aggregate.",{c:t(EU_COMP[r[1]]),r:t(r[2]),g:euTie(r).agg}))}
function qEuAgg(){const R=EU_TIES.filter(r=>!r[7]&&r[5]!=="-"&&r[6]!=="-");const r=qPick(R),T=euTie(r);
  return qMk(tf("{s} {c}, {r} against {o}. What was the aggregate score, Fenerbahçe first?",{s:r[0],c:t(EU_COMP[r[1]]),r:t(r[2]),o:r[3]}),T.agg,qScore(T.agg),0,tf("Home {h}, away {a}, Fenerbahçe first.",{h:r[5].replace("-","–"),a:r[6].replace("-","–")}))}
function qFbScorerRank(maxRank){const L=RECORDS.football.lists[0].rows.slice(0,maxRank);const i=Math.floor(Math.random()*L.length),r=L[i];
  return qMk(tf("Who is number {n} on the club's all-time scoring list?",{n:i+1}),r[0],RECORDS.football.lists[0].rows.concat(RECORDS.football.lists[1].rows).map(x=>x[0]),0,tf("{n} goals, {y}.",{n:r[2],y:r[1]}))}
function qFbListNum(li){const L=RECORDS.football.lists[li],r=qPick(L.rows);
  return qMk(tf(li?"How many games did {n} play for the club, as listed?":"How many goals did {n} score for the club, as listed?",{n:r[0]}),r[2],qNear(r[2],li?40:25,1),0,t(L.note))}
function qFbApps(){const L=RECORDS.football.lists[1].rows;return qMk(t("Who has played the most games for Fenerbahçe?"),L[0][0],L.slice(1).map(x=>x[0]).concat(RECORDS.football.lists[0].rows.map(x=>x[0])),0,tf("{n} games, {y}.",{n:L[0][2],y:L[0][1]}))}
function qFbTop(){const L=RECORDS.football.lists[0].rows;return qMk(t("Who is Fenerbahçe's all-time top scorer?"),L[0][0],L.slice(1).map(x=>x[0]),0,tf("{n} goals, {y}.",{n:L[0][2],y:L[0][1]}))}

/* ---------- basketball line-ups and volleyball squads ---------- */
function luAll(L){return L.st.map(x=>[x[1],x[2]]).concat(L.bench.map(x=>[x[0],x[1]]))}
function qLuTop(LS){const ok=LS.filter(L=>{const a=luAll(L).filter(x=>x[1]!=null).sort((p,q)=>q[1]-p[1]);return a.length>1&&a[0][1]>a[1][1]});if(!ok.length)return null;const L=qPick(ok),a=luAll(L).filter(x=>x[1]!=null).sort((p,q)=>q[1]-p[1]);
  return qMk(tf("Who was Fenerbahçe's top scorer in the {l} against {o}?",{l:t(L.label),o:L.opp}),a[0][0],a.slice(1).map(x=>x[0]),0,tf("{n} points.",{n:a[0][1]}))}
function qLuPts(LS){const L=qPick(LS),a=luAll(L).filter(x=>x[1]!=null&&x[1]>=4);if(!a.length)return null;const p=qPick(a);
  return qMk(tf("How many points did {n} score in the {l} against {o}?",{n:p[0],l:t(L.label),o:L.opp}),p[1],qNear(p[1],5,0),0)}
function qLuCoach(LS){const C=[...new Set(LS.map(L=>L.coach).filter(Boolean))];if(C.length<2)return null;const L=qPick(LS.filter(x=>x.coach));
  return qMk(tf("Who was Fenerbahçe's coach in the {l} against {o}?",{l:t(L.label),o:L.opp}),L.coach,C.concat(["Željko Obradović","Šarūnas Jasikevičius","Marina Maljković","Valérie Garnier","Miguel Méndez","Ergin Ataman","Dimitris Itoudis","Lucas Mondelo"]),0)}
function qLuIn(LS){const L=qPick(LS),inn=luAll(L).map(x=>x[0]),out=[...new Set(LS.flatMap(x=>luAll(x).map(y=>y[0])))].filter(n=>!inn.includes(n));
  return qMk(tf("Who played for Fenerbahçe in the {l} against {o}?",{l:t(L.label),o:L.opp}),qPick(inn),out,0)}
function qSqIn(SQ,pool){const s=qPick(SQ),inn=s.sq.map(x=>x[1]),out=[...new Set(SQ.flatMap(x=>x.sq.map(y=>y[1])).concat(pool||[]))].filter(n=>!inn.includes(n));
  return qMk(tf("Who was in this squad: {l}?",{l:t(s.label)}),qPick(inn),out,0,t(s.note||""))}
function qSqNum(SQ){const s=qPick(SQ),p=qPick(s.sq.filter(x=>x[0]!=null));if(!p)return null;
  return qMk(tf("Which shirt number did {n} wear? ({l})",{n:p[1],l:t(s.label)}),p[0],s.sq.map(x=>x[0]).filter(x=>x!=null).concat(qNear(p[0],6,1)),0)}

/* ---------- question pools by branch and level ---------- */
const QPOOL={
 football:{easy:[()=>qOldQuiz("football"),()=>qHistory("football",30),()=>qFbTop(),()=>qFbTitleSeason([2000,2014]),()=>qLegendWho("football")],
  normal:[()=>qOldQuiz("football"),()=>qHistory("football",8),()=>qTrophyCount("football",6),()=>qLegendRole("football"),()=>qFbApps(),()=>qGameScore("football"),()=>qFbFinish([2010,2026]),()=>qFbTitleSeason([1959,2014])],
  hard:[()=>qHistory("football",3),()=>qLegendYears("football"),()=>qFbFinish([1995,2026]),()=>qFbXI([2005,2026]),()=>qGameOpp("football"),()=>qEuOut(),()=>qFbNat(),()=>qFbScorerRank(5)],
  super:[()=>qFbFinish([1970,1999]),()=>qFbXI([2000,2026]),()=>qEuOpp(r=>yrOf(r[0])>=1990),()=>qRecord("football"),()=>qFbListNum(0),()=>qEuOut(),()=>qHistory("football",2)],
  extreme:[()=>qFbFinish([1959,1985]),()=>qEuAgg(),()=>qEuOpp(r=>yrOf(r[0])<1990),()=>qFbScorerRank(10),()=>qFbListNum(1),()=>qFbXI([2000,2012]),()=>qRecord("football")]},
 basketball:{easy:[()=>qOldQuiz("basketball"),()=>qHistory("basketball",30),()=>qLegendWho("basketball")],
  normal:[()=>qOldQuiz("basketball"),()=>qHistory("basketball",8),()=>qTrophyCount("basketball",5),()=>qLegendRole("basketball"),()=>qLuCoach(MB_LINEUPS),()=>qTitleYear("basketball","easy")],
  hard:[()=>qHistory("basketball",3),()=>qLegendYears("basketball"),()=>qLuTop(MB_LINEUPS),()=>qGameScore("basketball"),()=>qLuIn(MB_LINEUPS),()=>qTitleYear("basketball","hard")],
  super:[()=>qLuPts(MB_LINEUPS),()=>qLuTop(MB_LINEUPS),()=>qRecord("basketball"),()=>qGameScore("basketball"),()=>qHistory("basketball",2),()=>qTitleYear("basketball","hard")],
  extreme:[()=>qLuPts(MB_LINEUPS),()=>qLuIn(MB_LINEUPS),()=>qRecord("basketball"),()=>qGameOpp("basketball"),()=>qTitleYear("basketball","hard")]},
 "womens-basketball":{easy:[()=>qOldQuiz("womens-basketball"),()=>qHistory("womens-basketball",30),()=>qLegendWho("womens-basketball")],
  normal:[()=>qOldQuiz("womens-basketball"),()=>qHistory("womens-basketball",8),()=>qTrophyCount("womens-basketball",6),()=>qLegendRole("womens-basketball"),()=>qLuCoach(WB_LINEUPS)],
  hard:[()=>qHistory("womens-basketball",3),()=>qLegendYears("womens-basketball"),()=>qLuTop(WB_LINEUPS),()=>qLuIn(WB_LINEUPS),()=>qTitleYear("womens-basketball","hard")],
  super:[()=>qLuPts(WB_LINEUPS),()=>qLuTop(WB_LINEUPS),()=>qRecord("womens-basketball"),()=>qHistory("womens-basketball",2),()=>qTitleYear("womens-basketball","hard")],
  extreme:[()=>qLuPts(WB_LINEUPS),()=>qLuIn(WB_LINEUPS),()=>qRecord("womens-basketball"),()=>qTitleYear("womens-basketball","hard")]},
 volleyball:{easy:[()=>qOldQuiz("volleyball"),()=>qHistory("volleyball",30),()=>qLegendWho("volleyball")],
  normal:[()=>qOldQuiz("volleyball"),()=>qHistory("volleyball",8),()=>qTrophyCount("volleyball",5),()=>qLegendRole("volleyball"),()=>qGameScore("volleyball")],
  hard:[()=>qHistory("volleyball",3),()=>qLegendYears("volleyball"),()=>qSqIn(VB_SQUADS),()=>qGameOpp("volleyball"),()=>qTitleYear("volleyball","hard")],
  super:[()=>qSqIn(VB_SQUADS),()=>qRecord("volleyball"),()=>qHistory("volleyball",2),()=>qTitleYear("volleyball","hard"),()=>qSqNum(VB_SQUADS)],
  extreme:[()=>qSqNum(VB_SQUADS),()=>qSqIn(VB_SQUADS),()=>qRecord("volleyball"),()=>qTitleYear("volleyball","hard")]},
 "mens-volleyball":{easy:[()=>qOldQuiz("mens-volleyball"),()=>qHistory("mens-volleyball",30)],
  normal:[()=>qOldQuiz("mens-volleyball"),()=>qHistory("mens-volleyball",8),()=>qTrophyCount("mens-volleyball",4),()=>qLegendRole("mens-volleyball")],
  hard:[()=>qHistory("mens-volleyball",3),()=>qLegendYears("mens-volleyball"),()=>qTitleYear("mens-volleyball","hard"),()=>qGameScore("mens-volleyball"),()=>qSqIn(MV_SQUADS,MV_POOL.map(p=>p[0]))],
  super:[()=>qHistory("mens-volleyball",2),()=>qRecord("mens-volleyball"),()=>qTitleYear("mens-volleyball","hard"),()=>qSqNum(MV_SQUADS),()=>qSqIn(MV_SQUADS,MV_POOL.map(p=>p[0]))],
  extreme:[()=>qSqNum(MV_SQUADS),()=>qRecord("mens-volleyball"),()=>qTitleYear("mens-volleyball","hard"),()=>qHistory("mens-volleyball",3)]},
 "womens-football":{easy:[()=>qOldQuiz("womens-football"),()=>qHistory("womens-football",20)],
  normal:[()=>qOldQuiz("womens-football"),()=>qHistory("womens-football",6),()=>qLegendRole("womens-football"),()=>qGameScore("womens-football")],
  hard:[()=>qHistory("womens-football",3),()=>qGameOpp("womens-football"),()=>qSqIn(WF_SQUADS,WF_POOL.map(p=>p[0])),()=>qGameScore("womens-football")],
  super:[()=>qRecord("womens-football"),()=>qSqNum(WF_SQUADS),()=>qSqIn(WF_SQUADS,WF_POOL.map(p=>p[0])),()=>qHistory("womens-football",2)],
  extreme:[()=>qSqNum(WF_SQUADS),()=>qRecord("womens-football"),()=>qHistory("womens-football",3),()=>qSqIn(WF_SQUADS,WF_POOL.map(p=>p[0]))]},
 more:{easy:[()=>qOldQuiz("more"),()=>qHistory("more",30)],normal:[()=>qOldQuiz("more"),()=>qHistory("more",8),()=>qLegendRole("more")],
  hard:[()=>qHistory("more",3),()=>qLegendYears("more"),()=>qLegendWho("more")],super:[()=>qHistory("more",2),()=>qLegendYears("more"),()=>qLegendWho("more")],extreme:[()=>qHistory("more",2),()=>qHistory("more",4),()=>qLegendWho("more"),()=>qLegendYears("more")]}};

function qRound(b,lv){const L=QLV.find(x=>x[0]===lv),n=L[2],pool=(QPOOL[b]||QPOOL.more)[lv],out=[],seen=new Set();
  for(let k=0;out.length<QN&&k<300;k++){let q=null;try{q=qPick(pool)()}catch(e){q=null}if(!q||seen.has(q.q))continue;
    /* trim to the level's option count, keeping the right answer */
    const right=q.o[q.a],wrong=q.o.filter((_,i)=>i!==q.a);if(wrong.length<n-1)continue;
    const o=shuffle([right,...shuffle(wrong).slice(0,n-1)]);seen.add(q.q);out.push({q:q.q,o,a:o.indexOf(right),e:q.e})}
  return out}
/* qMk with n=0 returns every option; qRound trims to the level */

/* ---------- UI ---------- */
const QZ={};let qzTimer=null;
function gQuiz(el){const b=current;clearInterval(qzTimer);let st=QZ[b];
  if(!st||!st.lv){const best=lv=>store.get(SK(b,"qz-"+lv),null);
    el.innerHTML=`<h2>${t("Quiz")}</h2><p class="intro">${t("Pick a level. Every round has seven questions, built from the facts on this site.")}</p>
     <div class="qtime"><span class="label" id="qtLab">${t("Quiz timer")}</span><div class="seg" role="group" aria-labelledby="qtLab">${QT_LEVELS.map(([v,l])=>`<button type="button" data-qt="${v}" aria-pressed="${store.get("fb-qtime","1")===v}">${esc(t(l))}</button>`).join("")}</div></div>
     <div class="qlevels">${QLV.map(([id,lab,n,sec,d],i)=>`<button class="qlv card" data-qlv="${id}" style="--q:${i}"><span class="qdots">${"●".repeat(i+1)}${"○".repeat(4-i)}</span><b>${esc(t(lab))}</b><span>${esc(t(d))}</span>${sec&&qTimeMult()!==1?`<span class="qtadj">${esc(qTimeMult()?tf("With your setting: {n} seconds a question.",{n:sec*qTimeMult()}):t("With your setting: no timer."))}</span>`:""}<small>${best(id)!=null?esc(tf("Best: {s}/{n}",{s:best(id),n:QN})):t("Not played yet")}</small></button>`).join("")}</div>`;
    el.querySelectorAll("[data-qt]").forEach(x=>x.onclick=()=>{store.set("fb-qtime",x.dataset.qt);rerender();const f=document.querySelector(`[data-qt="${x.dataset.qt}"]`);if(f)f.focus()});
    el.querySelectorAll("[data-qlv]").forEach(x=>x.onclick=()=>{QZ[b]={lv:x.dataset.qlv,qs:qRound(b,x.dataset.qlv),i:0,score:0,picked:null};rerender()});return}
  const L=QLV.find(x=>x[0]===st.lv),lab=t(L[1]),N=st.qs.length;
  if(st.i>=N){const k=SK(b,"qz-"+st.lv),best=store.get(k,null);if(!st.saved){st.saved=true;if(best==null||st.score>best)store.set(k,st.score);if(st.score>store.get(SK(b,"quiz"),0))store.set(SK(b,"quiz"),st.score);if(st.score===N&&["super","extreme"].includes(st.lv))store.set("fb-quiz-hard",1);if(typeof xBadgeCheck==="function")xBadgeCheck();if(typeof xSyncScores==="function")xSyncScores()}
    const msg=st.score===N?"Perfect. True Fenerbahçeli.":st.score>=N*.6?"Solid. The stands would be proud.":"Time to read the History tab again.";
    el.innerHTML=`<h2>${t("Quiz")} · ${esc(lab)}</h2><div class="quiz"><span class="label">${t("Final score")}</span><div class="final">${st.score}/${N}</div><p style="font-size:18px;margin-top:6px">${t(msg)}</p><p class="gnote">${esc(tf("Best: {s}/{n}",{s:Math.max(best||0,st.score),n:N}))}</p>
     <div class="btns"><button class="btn" data-q="again">${t("Play again")}</button><button class="btn ghost" data-q="levels">${t("Change level")}</button>${st.lv!=="extreme"&&st.score>=N-1?`<button class="btn ghost" data-q="up">${esc(tf("Try {l}",{l:t(QLV[QLV.indexOf(L)+1][1])}))} →</button>`:""}</div></div>`;
    const on=(k,f)=>{const x=el.querySelector(`[data-q="${k}"]`);if(x)x.onclick=f};
    on("again",()=>{QZ[b]={lv:st.lv,qs:qRound(b,st.lv),i:0,score:0,picked:null};rerender()});on("levels",()=>{QZ[b]=null;rerender()});on("up",()=>{const nl=QLV[QLV.indexOf(L)+1][0];QZ[b]={lv:nl,qs:qRound(b,nl),i:0,score:0,picked:null};rerender()});return}
  const item=st.qs[st.i],sec=L[3]*(typeof qTimeMult==="function"?qTimeMult():1);
  el.innerHTML=`<h2>${t("Quiz")} · ${esc(lab)}</h2><div class="quiz qz-${st.lv}"><div class="top"><span class="label">${tf("Question {i} of {n}",{i:st.i+1,n:N})}</span><span class="label">${tf("Score {n}",{n:st.score})}</span></div><div class="progress"><i style="width:${st.i/N*100}%"></i></div>
   ${sec&&st.picked===null?`<div class="qtimer" aria-hidden="true"><i id="qzBar"></i></div><p class="fine" id="qzLeft" aria-live="off"></p>`:""}
   <h3>${esc(item.q)}</h3><div class="opts">${item.o.map((o,idx)=>{let c="opt";if(st.picked!==null){if(idx===item.a)c+=" right";else if(idx===st.picked)c+=" wrong"}return `<button class="${c}" data-qo="${idx}" ${st.picked!==null?"disabled":""}>${esc(o)}</button>`}).join("")}</div>
   ${st.picked!==null?`<p class="explain"><b>${st.picked===-1?t("Time's up."):st.picked===item.a?t("Correct."):t("Not quite.")}</b> ${st.picked!==item.a?esc(tf("The answer is {a}.",{a:item.o[item.a]}))+" ":""}${item.e?esc(item.e):""}</p><button class="btn qnext" data-q="next">${t(st.i+1<N?"Next question":"See score")}</button>`:""}
   <div class="btns"><button class="linkbtn" data-q="quit">${t("Change level")}</button></div></div>`;
  el.querySelectorAll("[data-qo]").forEach(x=>x.onclick=()=>{clearInterval(qzTimer);st.picked=+x.dataset.qo;if(st.picked===item.a)st.score++;rerender()});
  const nx=el.querySelector('[data-q="next"]');if(nx){nx.onclick=()=>{st.i++;st.picked=null;rerender()};nx.focus()}
  el.querySelector('[data-q="quit"]').onclick=()=>{clearInterval(qzTimer);QZ[b]=null;rerender()};
  if(sec&&st.picked===null){const end=Date.now()+sec*1000,bar=$("qzBar"),left=$("qzLeft");const tick=()=>{if(!document.body.contains(bar)){clearInterval(qzTimer);return}const ms=end-Date.now();bar.style.width=Math.max(0,ms/(sec*10))+"%";left.textContent=tf("{n} seconds left",{n:Math.max(0,Math.ceil(ms/1000))});bar.classList.toggle("low",ms<5000);
    if(ms<=0){clearInterval(qzTimer);st.picked=-1;rerender()}};tick();qzTimer=setInterval(tick,200)}};
/* result image and badge */
EXT.result.push(g=>{if(g==="quiz"){const s=QZ[current];if(s&&s.lv&&s.i>=s.qs.length)return{title:`${t("Quiz")} · ${t(QLV.find(x=>x[0]===s.lv)[1])}`,big:`${s.score}/${s.qs.length}`,sub:t(SPORTS[current].label)};return null}});
BADGES.push(["quizx","Brain of Kadıköy","Get 7 out of 7 on Super hard or Extreme.",()=>store.get("fb-quiz-hard",0)>0]);
Object.keys(PLAY).forEach(b=>PLAY[b].forEach(x=>{if(x[0]==="quiz")x[2]="Five levels, Easy to Extreme"}));
