const {chromium}=require('playwright');const path=require('path');
(async()=>{const b=await chromium.launch();const pg=await b.newPage({viewport:{width:1000,height:700}});const errs=[];pg.on('pageerror',e=>errs.push(e.message));await pg.route('**/*',r=>r.request().url().startsWith('file:')?r.continue():r.abort());
await pg.goto('file://'+path.resolve(__dirname,'../site/index.html'));await pg.waitForTimeout(800);
for(const l of ['en','tr','de','ar']){await pg.evaluate(l=>{$('lang').value=l;$('lang').dispatchEvent(new Event('change'))},l);await pg.waitForTimeout(700);console.log(l,JSON.stringify(await pg.evaluate(()=>document.querySelector('.brand').innerText)))}
await pg.evaluate(()=>{$('lang').value='en';$('lang').dispatchEvent(new Event('change'))});await pg.waitForTimeout(500);await pg.locator('.bar').screenshot({path:path.resolve(__dirname,'../brand.png')});console.log('errs',errs);await b.close()})();
