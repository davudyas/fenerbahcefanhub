const fs=require('fs');const src=fs.readFileSync(__dirname+'/x_mod.js','utf8');const code=src.slice(0,src.indexOf('/* names:'));
const {modBad,modClean}=new Function(code+';return {modBad,modClean}')();
const bad=["fuck you","FUUUCK","f.u.c.k","Orospu çocuğu","siktir git","amk","s1kt1r","Hurensohn","nigger","motherfucker","puta madre","Arschloch","enculé","شرموط","ibne","şerefsiz","yarrak","a m k","fuckface","sikerim","amınakoyim"];
const good=["Niger","Nigeria","Scunthorpe","Amina","Kadıköy","Dick Advocaat","retard de train","computadora","reputation","kayarak koştu","sokak","pictures","gay pride","I got it","Fenerbahçe 3-1","Sıkı maç","Sikke","fasikül","Kocaelispor","Assist","Sakıp","Puttenham","Grand Est","Cassano","Mesut","Szymański","Asensio","Ankara","Nigerya","Constantinople","Coco","Bastardo? no","Shiitake","Puthenpurayil","Arcade","Analiz","yararak","Tadic","Džeko","En-Nesyri","Skriniar","Fick? no"];
console.log('BAD missed:',bad.filter(x=>!modBad(x)));
console.log('GOOD flagged:',good.filter(x=>modBad(x)));
console.log(modClean("Hadi Fener, fuck Galatasaray"),'|',modClean("orospu"),'|',modClean("great goal"));
