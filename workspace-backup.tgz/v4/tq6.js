const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const pg=await b.newPage();await pg.goto('file://'+process.cwd()+'/fenerbahce_full.html');await pg.waitForTimeout(400);
console.log(await pg.evaluate(()=>Object.entries(LIVE).filter(([k])=>k!=="more").map(([b,L])=>"### "+b+"\n"+(L.tables||[]).map(T=>JSON.stringify({comp:T.comp,sub:T.sub,cols:T.cols,key:T.key,zones:T.zones,tied:T.tied,note:T.note,n:(T.rows||[]).length,r0:(T.rows||[])[0],fb:(T.rows||[]).find(r=>r[0]==="Fenerbahçe"),keys:Object.keys(T)})).join("\n")+"\nNEXT "+JSON.stringify(L.next.slice(0,6))).join("\n")));
await b.close()})();
