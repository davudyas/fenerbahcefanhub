const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const f=process.argv[2]||'fenerbahce.html';
for(const [nm,opts] of [['desktop',{viewport:{width:1280,height:900}}],['phone (4x slower CPU)',{viewport:{width:390,height:844}}]]){
 const res=[];for(let k=0;k<4;k++){const ctx=await b.newContext(opts);const pg=await ctx.newPage();const cdp=await ctx.newCDPSession(pg);if(nm!=='desktop')await cdp.send('Emulation.setCPUThrottlingRate',{rate:4});await cdp.send('Performance.enable');
  await pg.goto('file://'+process.cwd()+'/'+f+'#all');await pg.waitForTimeout(300);const m=(await cdp.send('Performance.getMetrics')).metrics;const g=n=>m.find(x=>x.name===n).value;
  const nav=await pg.evaluate(()=>{const n=performance.getEntriesByType('navigation')[0];return n.domContentLoadedEventEnd});
  res.push({dcl:nav,script:g('ScriptDuration')*1000,layout:g('LayoutDuration')*1000,style:g('RecalcStyleDuration')*1000,heap:g('JSHeapUsedSize')/1e6});await ctx.close()}
 const avg=k=>Math.round(res.slice(1).reduce((a,r)=>a+r[k],0)/(res.length-1));console.log(nm,'ready',avg('dcl'),'ms | script',avg('script'),'ms | style',avg('style'),'| layout',avg('layout'),'| heap',avg('heap'),'MB')}
await b.close()})();
