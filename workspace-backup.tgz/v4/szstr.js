const {chromium}=require('playwright');const fs=require('fs');
(async()=>{const b=await chromium.launch();const pg=await b.newPage({viewport:{width:1280,height:900}});
await pg.goto('file://'+process.cwd()+'/fenerbahce.html#football-play');await pg.waitForTimeout(300);
const G={football:'draft',basketball:'draft5','womens-basketball':'draft5',volleyball:'draft6','mens-volleyball':'draft6','womens-football':'draft11'};const all=new Set();
const grab=async()=>{(await pg.evaluate(()=>{const out=[];const w=document.createTreeWalker(document.getElementById('gameArea'),NodeFilter.SHOW_TEXT);while(w.nextNode()){const s=w.currentNode.nodeValue.trim();if(s&&/[A-Za-z]{3}/.test(s))out.push(s)}return out})).forEach(s=>all.add(s))};
for(const br of Object.keys(G)){await pg.selectOption('#sport',br);await pg.click('[data-tab=play]');await pg.click(`[data-game=${G[br]}]`);await grab();
 if(br==='football'){while(await pg.$('[data-cand="0"]')){await pg.click('[data-cand="0"]');await pg.waitForTimeout(10)}await grab();await pg.click('[data-slot="0"]');}
 else{let n=0;while(await pg.$('[data-tc="0"]')&&n<20){await pg.click('[data-tc="0"]');n++;await pg.waitForTimeout(10)}}
 for(const y of await pg.$$eval('[data-szy]',x=>x.map(e=>e.dataset.szy).filter((e,i,a)=>i%4===0||i===a.length-1))){await pg.click(`[data-szy="${y}"]`);await grab();await pg.click('[data-sz="start"]');await pg.click('[data-sz="one"]');await grab();await pg.click('[data-sz="five"]');await grab();await pg.click('[data-sz="all"]');await grab();await pg.click('[data-sz="full"]');await grab();await pg.click('[data-sz="other"]')}}
const L=[...all];const miss=await pg.evaluate(L=>{const r={};["tr","es"].forEach(x=>{LANG=x;TCACHE.clear();r[x]=L.filter(s=>trText(s)==null)});LANG="en";return r},L);
const u=[...new Set([...miss.tr,...miss.es])];fs.writeFileSync('../sz_miss.json',JSON.stringify(u));console.log(L.length,u.length);u.forEach(s=>console.log(s.slice(0,140)));await b.close()})();
