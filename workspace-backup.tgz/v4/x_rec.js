/* ===== Club records per branch. Football tables: Wikipedia "List of Fenerbahçe S.K. records and statistics"
   (official games: goals as of 31 October 2016, appearances as of 30 May 2019) and "List of Fenerbahçe S.K. footballers"
   (all matches, correct to 17 May 2026). Other branches use facts already sourced on this site. ===== */
const RECORDS={
 football:{lists:[
   {title:"All-time top scorers",note:"Official matches only, as listed by Wikipedia in 2016.",unit:"Goals",rows:[["Lefter Küçükandonyadis","1947–1951, 1953–1964",215],["Melih Kotanca","1938–1948",172],["Alex de Souza","2004–2013",171],["Aykut Kocaman","1988–1996",167],["Naci Bastoncu","1934–1947",162],["Cemil Turan","1972–1981",127],["Fikret Arıcan","1928–1947",109],["Ogün Altıparmak","1963–1971",89],["Şeref Has","1955–1969",89],["Semih Şentürk","2000–2013",86]]},
   {title:"Most appearances",note:"Official matches only, as listed by Wikipedia in 2019.",unit:"Games",rows:[["Müjdat Yetkiner","1979–1996",570],["Volkan Demirel","2002–2019",525],["Cem Pamiroğlu","1976–1987",396],["Şeref Has","1955–1969",382],["Rüştü Reçber","1994–2003, 2004–2007",381],["Gökhan Gönül","2007–2016, 2020–2021",361],["Lefter Küçükandonyadis","1947–1951, 1953–1964",349],["Ziya Şengül","1964–1976",342],["Alex de Souza","2004–2013",341],["Selçuk Şahin","2003–2015",326]]},
   {title:"Top scorers, all matches",note:"A wider count that includes the early decades, from Wikipedia's list of Fenerbahçe footballers (correct to 17 May 2026).",unit:"Goals",rows:[["Zeki Rıza Sporel","1915–1934",470],["Lefter Küçükandonyadis","1947–1951, 1953–1964",423],["Alaattin Baydar","1915–1934",362],["Naci Bastoncu","1934–1944",232],["Fikret Arıcan","1927–1947",231],["Melih Kotanca","1939–1948",204],["Cemil Turan","1972–1980",194],["Şeref Has","1955–1969",168],["Aykut Kocaman","1988–1996",166],["Alex de Souza","2004–2012",166]]},
   {title:"Most appearances, all matches",note:"A wider count that includes the early decades, from Wikipedia's list of Fenerbahçe footballers (correct to 17 May 2026).",unit:"Games",rows:[["Müjdat Yetkiner","1979–1995",763],["Lefter Küçükandonyadis","1947–1951, 1953–1964",615],["Şeref Has","1955–1969",605],["Volkan Demirel","2002–2019",525],["Cem Pamiroğlu","1976–1986",508],["Naci Erdem","1953–1963",440],["Ziya Şengül","1964–1975",426],["Nedim Günar","1949–1963",416],["Nedim Doğan","1961–1973",416],["Alpaslan Eratlı","1973–1983",414]]}],
  facts:[
   ["28","Turkish championships","A record, counting the national titles before the Süper Lig began in 1959."],
   ["99","Most points in a league season","2023–24, from 38 games, and still second behind Galatasaray."],
   ["103","Most league goals in a season","1988–89."],
   ["6","Fewest league goals conceded in a season","1969–70."],
   ["6","Most goals by one player in a league game","Tanju Çolak, in a 7–1 win over Karşıyaka in 1992–93."],
   ["8–0","Biggest league win","Against Eyüpspor on 20 September 2026. The club's records list had two 8–1 wins, over Samsunspor and Kayserispor."],
   ["10–3","Biggest Turkish Cup win","Against Alanyaspor on 23 January 2008."],
   ["5–0","Biggest European wins","Turan Tovuz (1994), B36 Tórshavn (2006, away), MTK Budapest (2008, away) and Zimbru Chișinău (2023)."],
   ["0–7","Heaviest European defeat","Away at Benfica in the 1975–76 European Cup."],
   ["1968","First European trophy for a Turkish club","The 1966–67 Balkans Cup, won in a play-off against AEK Athens in May 1968."]],
  src:[["Wikipedia: List of Fenerbahçe S.K. records and statistics","https://en.wikipedia.org/wiki/List_of_Fenerbah%C3%A7e_S.K._records_and_statistics"],["Wikipedia: List of Fenerbahçe S.K. footballers","https://en.wikipedia.org/wiki/List_of_Fenerbah%C3%A7e_S.K._footballers"]]},
 basketball:{facts:[
   ["2","EuroLeague titles","2017 in Istanbul and 2025 in Abu Dhabi."],
   ["5","Final Fours in a row","2015 to 2019, all under Željko Obradović. Eight Final Fours in all."],
   ["24","Most three-pointers in a EuroLeague game","A EuroLeague record, in a 118–88 win over Valencia on 14 March 2024."],
   ["2025","First Triple Crown by a Turkish team","EuroLeague, Turkish league and Turkish Cup in the same season."],
   ["2012","First Turkish club to beat an NBA team","On 5 October 2012."],
   ["16","Turkish league titles","The first in 1957, the latest in 2026."]],
  src:[["EuroLeague: Fenerbahçe hits 24 threes vs Valencia","https://www.euroleaguebasketball.net/euroleague/news/fenerbahce-beko-hits-24-threes-vs-valencia-basket-breaks-all-time-record"]]},
 "womens-basketball":{facts:[
   ["20","Turkish league titles","A national record, from 1999 to 2026."],
   ["35–0","Perfect league season","2023–24, the year of the second EuroLeague title."],
   ["46–1","Record season","2025–26: every trophy, including the third EuroLeague Women."],
   ["99–60","Biggest EuroLeague final win","Against ÇBK Mersin in Prague, 2023."],
   ["35","Most points in a EuroLeague final","Breanna Stewart, in the 2023 final."],
   ["2","Triple Crowns","2024 and 2026."]]},
 volleyball:{facts:[
   ["2010","World champions without dropping a match","The FIVB Club World Championship in Doha."],
   ["2012","Champions of Europe","3–0 against RC Cannes in Baku. Kim Yeon-koung was MVP and top scorer."],
   ["2014","Two European cups in one day","The women won the CEV Cup and the men the CEV Challenge Cup, a first for a Turkish club."],
   ["15","Turkish league titles","Seven of them in the current league format."],
   ["1928","One of Turkey's first women's teams","Founded by Sabiha Gürayman, later Turkey's first female civil engineer."]]},
 "mens-volleyball":{facts:[
   ["3","League titles in a row","2010, 2011 and 2012."],
   ["5","Turkish league titles","2008, 2010, 2011, 2012 and 2019."],
   ["2014","European trophy","The CEV Challenge Cup, 3–0 against Andreoli Latina in Istanbul."],
   ["9","Years from the fourth division to the top flight","Refounded in 1976, in the national league by 1985."],
   ["3","League finals lost since 2013","2013–14, 2020–21 and 2023–24."],
   ["1927","First men's team","Aziz Torun was the first head coach."]],
  src:[["Wikipedia: Fenerbahçe S.K. (men's volleyball)","https://en.wikipedia.org/wiki/Fenerbah%C3%A7e_S.K._(men%27s_volleyball)"]]},
 "womens-football":{lists:[
   {title:"Top scorers, 2025–26",note:"The first title-winning season.",unit:"Goals",rows:[["Andrea Stašková","2025–26",20],["Yağmur Uraz","2025–26",16],["María Paula Salas","2025–26",15],["Flourish Sabastine","2025–26",12],["Busem Şeker","2025–26",8],["Marta Cox","2025–26",7],["Zeynep Kerimoğlu","2025–26",7],["Ece Türkoğlu","2025–26",6]]}],
  facts:[
   ["2026","First league title","Confirmed on 10 May 2026, with two rounds to spare."],
   ["83","Points in the title season","27 wins, 2 draws and 1 defeat from 30 games in 2025–26."],
   ["136–9","Goals for and against, 2025–26","136 scored and only 9 conceded in 30 league games."],
   ["18–0","Biggest win","Against ALG Spor on 25 January 2026. The away game at ALG Spor that season ended 15–0."],
   ["12–0","Biggest win of 2026–27 so far","Against Şile BilgiDoğa in September 2026, with a hat-trick from Andrea Stašková."],
   ["5–1","First European tie won","On aggregate against Minsk, Women's Europa Cup 2026–27."]],
  src:[["Wikipedia: 2025–26 Fenerbahçe S.K. (women's football) season","https://en.wikipedia.org/wiki/2025%E2%80%9326_Fenerbah%C3%A7e_S.K._(women%27s_football)_season"]]}};
