/* ===== Kanarya, the fan helper (asks Claude through the page's sample capability) ===== */
const KAN_SVG=`<svg viewBox="0 0 64 64" aria-hidden="true">
 <path d="M30 9c2-5 7-6 9-3-3 0-5 2-5 4 2-3 7-3 8 0-3-1-6 1-7 3z" fill="#f5b700"/>
 <ellipse cx="33" cy="36" rx="21" ry="20" fill="#ffd60a"/>
 <ellipse cx="35" cy="42" rx="12" ry="11" fill="#fff2a8"/>
 <path d="M14 34c3 10 11 15 18 13-7-3-11-8-12-16z" fill="#1b2f63"/>
 <path d="M15 37l9 4M16 41l8 3" stroke="#ffd60a" stroke-width="1.6" stroke-linecap="round"/>
 <circle cx="41" cy="28" r="4.2" fill="#0d1c3d"/><circle cx="42.5" cy="26.6" r="1.5" fill="#fff"/>
 <path d="M51 31l9 3-9 4z" fill="#ff9f1c"/>
 <path d="M22 52c6 4 16 4 22 0l-2 5c-6 3-13 3-18 0z" fill="#1b2f63"/><path d="M27 54.5h12" stroke="#ffd60a" stroke-width="1.6"/>
</svg>`;
const KAN={open:false,turns:[],busy:false,ctl:null,sample:null,off:false};
const KAN_CHIPS_TAB={home:["Which team plays next?","How did the teams do last time out?","Which branch has won the most?"],
 matches:["When is the next match?","How did the last match go?","What is our form like?"],standings:["Where are we in the table?","How far behind the leader are we?","Who are the closest rivals?"],
 squad:["Who is the captain?","Who is the coach?","Who are the new signings?"],games:["What was the biggest win?","Tell me about a famous final.","Which game still hurts?"],
 trophies:["How many titles does this branch have?","When was the last title?","Which trophy is the rarest?"],legends:["Who are the legends here?","Who is the greatest of all?","Tell me a fun fact about a legend."],
 history:["When did this branch start?","What was the greatest era?","Tell me something surprising."],derbies:["Who wins the derby more often?","What was the biggest derby win?","When is the next derby?"],
 venue:["How big is the stadium?","How do I get to the ground?","What is the atmosphere like?"],branches:["Which other sports does the club play?","Tell me about the rowing team.","What are the youngest branches?"],
 play:["How do the games here work?","How do I get badges?","Any tips for the draft?"]};
const KAN_CHIPS_SZ=["How is my season going?","Who is my top scorer?","How did the real team do that season?"];
function kanChips(){if(current!=="home"&&tab==="play"&&szS[current]&&szS[current].S)return KAN_CHIPS_SZ;return KAN_CHIPS_TAB[current==="home"?"home":tab]||KAN_CHIPS_TAB.matches}
const KAN_CHIPS=Object.values(KAN_CHIPS_TAB).flat().concat(KAN_CHIPS_SZ);
function kanContext(){if(current==="home")return `The fan is on the club home page, which shows every branch, so questions may be about any branch.`;
  const T=(tabsFor(current).find(x=>x[0]===tab)||[,tab])[1];let s=`The fan is looking at the "${SPORTS[current].label}" page, on the ${T} tab, so treat questions as being about that branch unless they say otherwise.`;
  if(tab==="play"){const g=(PLAY[current]||[]).find(x=>x[0]===playSel[current]);if(g)s+=` They have the "${g[1]}" game open.`;
    const z=szS[current]&&szS[current].S;if(z){const lg=z.C[0],tab2=lg.stage&&lg.stage.rows?szSort(lg.stage.rows):lg.lastTab||[],pos=tab2.findIndex(r=>r.me)+1;
      const res=z.log.slice(0,12).map(e=>`${e.comp} ${e.round?("round "+e.round):""} ${e.ha===1?"home":e.ha===-1?"away":"neutral"} vs ${e.opp}: ${e.g.s[0]}-${e.g.s[1]}`);
      const sc=Object.entries(z.scorers||{}).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([n,g])=>`${n} ${g}`);
      s+=`\nSIMULATED SEASON (made up by the site's season mode, not real): the fan's team "${z.my.n}" (rating ${z.my.r.toFixed(1)}) is playing ${z.season}. ${z.done?"The season is finished.":"The season is still running."} League position: ${pos||"not started"} of ${tab2.length}. Competitions: ${z.C.map(c=>`${c.name} (${c.status||"running"})`).join(", ")}. Latest results, newest first, your team's score first: ${res.join("; ")||"none yet"}. Top scorers: ${sc.join(", ")||"none"}. What the real Fenerbahçe did that season: ${z.D.real!=null?("finished "+z.D.real+" in the league"):"unknown"}. Talk about this as a simulation.`}}
  return s}
function kanBranch(id){const o=kanBranchRaw(id);runExt("kan",id,o);return o}
function kanBranchRaw(id){const S=SPORTS[id],L=LIVE[id],Q=SQUADS[id],V=VENUES[id];
  return {name:S.label,nickname:S.nick,intro:S.lede,stats:S.stats,home:S.home&&S.home[1],trophies:(S.trophies||[]).map(x=>x.slice(0,3)),
   legends:(S.legends||[]).map(l=>[l[0],l[1],l[2]].concat(l[3]||[])),history:(S.history||[]).map(h=>h.slice(0,3)),
   bigGames:(S.games||[]).map(g=>[g.date,g.comp,g.home,g.res||g.title,g.away,g.note]),otherBranches:S.branches,
   season:L?{season:L.season,summary:L.summary,results:L.last.slice(0,12),fixtures:L.next.slice(0,6),tables:L.tables.map(x=>({comp:x.comp,sub:x.sub,cols:x.cols,rows:x.rows,note:x.note}))}:undefined,
   squad:Q&&Q.groups?{coach:Q.coach,asOf:Q.asof,players:Q.groups.flatMap(g=>g[1].map(x=>`${x[1]}${x[0]!=null?" #"+x[0]:""} (${g[0]})`))}:Q?{note:Q.asof}:undefined,
   venue:V?`${V.name}, ${V.area}`:undefined}}
let KAN_DATA=null;
function kanRules(){const lang=LANGS.find(l=>l[0]===LANG)[1];if(!KAN_DATA){const all={};Object.keys(SPORTS).forEach(id=>all[id]=kanBranch(id));KAN_DATA=JSON.stringify(all)}
  return `You are Kanarya, a cheerful cartoon canary who helps fans on an unofficial Fenerbahçe fan website (not run by the club). Reply in ${lang}.
Keep answers short: one to four sentences, or a short list when asked for several things. Plain text only: no Markdown headings, tables or bold.
Base every fact on the SITE DATA below. Season data is as of ${ASOF}; today is ${todayISO()}. ${kanContext()}
If the data doesn't answer the question, say you don't know rather than guessing, and point to the official site fenerbahce.org. Never invent scores, dates, players or statistics. Be friendly about rivals.
You can also explain the site: the branch menu, the design and language menus, the All branches home page, the search button (players, seasons, finals, scores), player profiles (click a name), the "Real data" and "Estimate" labels, the tab groups (This season: Matches, Standings, Squad; Club: Big Games, Trophies, Legends, History, Derbies, Venue; and Play), the games on the Play tab including season mode, score predictions and player-of-the-match votes.
In the data, results rows are [date, competition, H/A/N, opponent, Fenerbahçe score, opponent score, note] (volleyball scores are sets) and fixture rows are [date, kick-off in Turkey time, competition, H/A, opponent, label].

SITE DATA (JSON):
${KAN_DATA}`}
function kanEl(tag,cls,txt){const e=document.createElement(tag);if(cls)e.className=cls;if(txt!=null)e.textContent=txt;return e}
function initHelper(){
  const root=kanEl("div","kan");root.id="kan";root.hidden=true;root.setAttribute("translate","no");
  root.innerHTML=`<section class="kanpanel" id="kanPanel" role="dialog" aria-modal="false" hidden>
    <header class="kanhead"><span class="kanav">${KAN_SVG}</span><div><b>Kanarya</b><span id="kanSub"></span></div><button class="kanx" id="kanClose" type="button">✕</button></header>
    <div class="kanlog" id="kanLog" aria-live="polite"></div>
    <div class="kanchips" id="kanChips"></div>
    <form class="kanform" id="kanForm" autocomplete="off"><input id="kanIn" maxlength="400"><button class="btn" id="kanSend"></button><button class="btn ghost" id="kanStop" type="button" hidden></button></form>
    <p class="kanfine" id="kanFine"></p></section>
   <button class="kanbtn" id="kanBtn" type="button" aria-expanded="false" aria-controls="kanPanel">${KAN_SVG}</button>`;
  document.body.appendChild(root);
  const btn=$("kanBtn"),panel=$("kanPanel");
  btn.onclick=()=>kanToggle(!KAN.open);$("kanClose").onclick=()=>kanToggle(false);
  document.addEventListener("keydown",e=>{if(e.key==="Escape"&&KAN.open){kanToggle(false);btn.focus()}});
  $("kanForm").onsubmit=e=>{e.preventDefault();kanAsk($("kanIn").value)};
  $("kanStop").onclick=()=>{if(KAN.ctl)KAN.ctl.abort()};
  helperTexts();
  /* only show the helper where the page can actually ask Claude */
  if(window.claude&&typeof window.claude.use==="function")window.claude.use("sample").then(s=>{if(s){KAN.sample=s;root.hidden=false}}).catch(()=>{})}
function helperTexts(){if(!$("kanBtn"))return;$("kanBtn").setAttribute("aria-label",t("Ask Kanarya"));$("kanBtn").title=t("Ask Kanarya");$("kanPanel").setAttribute("aria-label",t("Ask Kanarya"));
  $("kanSub").textContent=t("Fan helper");$("kanClose").setAttribute("aria-label",t("Close"));$("kanIn").placeholder=t("Ask a question…");$("kanIn").setAttribute("aria-label",t("Your question"));
  $("kanSend").textContent=t("Send");$("kanStop").textContent=t("Stop");$("kanFine").textContent=t("Answers come from Claude and use your own Claude usage. They can be wrong.");kanRender()}
function kanToggle(v){KAN.open=v;$("kanPanel").hidden=!v;$("kanBtn").setAttribute("aria-expanded",String(v));$("kan").classList.toggle("open",v);if(v){kanRender();setTimeout(()=>$("kanIn").focus(),30)}}
function kanRender(){const log=$("kanLog");if(!log||!KAN.open)return;log.innerHTML="";
  log.appendChild(kanEl("p","kmsg bot",t("Hi! I'm Kanarya. Ask me anything about Fenerbahçe: matches, titles, legends or how this site works.")));
  KAN.turns.forEach(m=>log.appendChild(kanEl("p","kmsg "+(m.role==="user"?"me":"bot")+(m.err?" err":""),m.content)));
  if(KAN.busy&&KAN.live==null)log.appendChild(kanEl("p","kmsg bot wait",t("Thinking…")));
  if(KAN.busy&&KAN.live!=null){const b=kanEl("p","kmsg bot",KAN.live);b.id="kanLive";log.appendChild(b)}
  const ch=$("kanChips");ch.innerHTML="";if(!KAN.busy&&!KAN.off)kanChips().slice(0,KAN.turns.length?2:3).forEach(c=>{const b=kanEl("button","kchip",t(c));b.type="button";b.onclick=()=>kanAsk(t(c));ch.appendChild(b)});
  $("kanSend").hidden=KAN.busy;$("kanStop").hidden=!KAN.busy;$("kanIn").disabled=KAN.busy||KAN.off;requestAnimationFrame(()=>{log.scrollTop=log.scrollHeight})}
async function kanAsk(q){q=(q||"").trim();if(!q||KAN.busy||!KAN.sample||KAN.off)return;$("kanIn").value="";
  KAN.turns.push({role:"user",content:q});KAN.busy=true;KAN.live=null;kanRender();
  const ctl=new AbortController();KAN.ctl=ctl;
  const hist=KAN.turns.filter(m=>!m.err).slice(-10);while(hist.length&&hist[0].role!=="user")hist.shift();
  try{const {text}=await KAN.sample([{role:"user",content:kanRules()},...hist.map(m=>({role:m.role,content:m.content}))],{modelTier:"quick",cache:false,signal:ctl.signal,
      onText:({text})=>{KAN.live=text;const el=$("kanLive");if(el){el.textContent=text;$("kanLog").scrollTop=$("kanLog").scrollHeight}else kanRender()}});
    KAN.turns.push({role:"assistant",content:text})}
  catch(e){const code=e&&e.code;if(e&&e.text&&code!=="refused")KAN.turns.push({role:"assistant",content:e.text});
    if(code!=="cancelled"){let msg="Something went wrong. Try again.";
      if(["not_granted","sampling_disabled","not_declared","capability_disabled","capability_removed"].includes(code)){msg="The helper can't answer in this view.";KAN.off=true}
      else if(code==="rate_limited")msg="Too many questions right now. Try again in a little while.";
      else if(code==="session_expired")msg="Please sign in to Claude again.";
      KAN.turns.push({role:"assistant",content:t(msg),err:true})}}
  finally{KAN.busy=false;KAN.live=null;KAN.ctl=null;kanRender();if(!KAN.off)$("kanIn").focus()}}
