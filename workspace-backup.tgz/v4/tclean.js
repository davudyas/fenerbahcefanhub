const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const errs=[];const shots=process.argv.slice(2);
const pg=await b.newPage({viewport:{width:390,height:844}});pg.on('pageerror',e=>errs.push(e.message));
await pg.goto('file://'+process.cwd()+'/fenerbahce.html#all');await pg.waitForTimeout(600);await pg.addStyleTag({content:'html{scroll-behavior:auto!important}'});
const shot=async(n,sel)=>{if(sel)await pg.evaluate(s=>{const e=document.querySelector(s);if(e){e.scrollIntoView({block:'start'});scrollBy(0,-80)}},sel);await pg.waitForTimeout(120);await pg.screenshot({path:'../cl_'+n+'.png'})};
await shot('m_home');await shot('m_home2','.hlines');
await pg.evaluate(()=>{setSport('football')});await shot('m_fb','#tabs');
await pg.evaluate(()=>{tab='records';syncHash();render()});await shot('m_club','#tabs');
await pg.evaluate(()=>{tab='standings';syncHash();render()});await shot('m_tab','#tabs');
await pg.setViewportSize({width:1366,height:768});
for(const th of ['day','clean','canary','retro','flood']){await pg.evaluate(v=>applyTheme(v),th);await pg.evaluate(()=>{setSport('home')});await shot('d_home_'+th,'.mcentre');}
await pg.evaluate(v=>applyTheme(v),'clean');await pg.evaluate(()=>{setSport('football');tab='matches';syncHash();render()});await shot('d_fb_clean','#tabs');
await pg.evaluate(()=>{pickGame('quiz')});await shot('d_play_clean','#tabs');
await pg.evaluate(v=>applyTheme(v),'night');await pg.evaluate(()=>{tab='games';syncHash();render()});await shot('d_games','#tabs');
console.log(errs, await pg.evaluate(()=>document.documentElement.scrollWidth));await b.close()})();
