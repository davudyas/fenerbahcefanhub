const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const pg=await b.newPage({viewport:{width:390,height:844}});
for(const h of ['football','basketball','all','volleyball']){await pg.goto('file://'+process.cwd()+'/fenerbahce.html#'+h);await pg.waitForTimeout(300);
console.log(h,await pg.evaluate(()=>{const W=innerWidth,o=[];document.querySelectorAll('body *').forEach(e=>{const r=e.getBoundingClientRect();if(r.right>W+1&&r.width>0&&!(e instanceof SVGElement))o.push(e.tagName+'.'+e.className.toString().slice(0,30)+'#'+e.id+' '+Math.round(r.right))});return [document.documentElement.scrollWidth,o.slice(0,6)]}))}
await b.close()})();
