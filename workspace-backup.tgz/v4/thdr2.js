const {chromium}=require('playwright');const path=require('path');
(async()=>{const b=await chromium.launch();const pg=await b.newPage({viewport:{width:375,height:800}});await pg.route('**/*',r=>r.request().url().startsWith('file:')?r.continue():r.abort());
await pg.goto('file://'+path.resolve(__dirname,'../site/index.html'));await pg.waitForTimeout(800);
console.log(await pg.evaluate(()=>{const br=document.querySelector('.brand');return br.outerHTML.slice(0,500)+' || '+[...br.querySelectorAll('*')].map(e=>e.tagName+'.'+e.className+':'+getComputedStyle(e).fontSize+':'+Math.round(e.getBoundingClientRect().width)).join(' ')}));
console.log(await pg.evaluate(()=>{const l=document.querySelector('.langpick');return l.outerHTML.slice(0,300)}));
await b.close()})();
