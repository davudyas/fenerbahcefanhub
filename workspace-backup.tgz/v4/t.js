const gzAuto=require('./gzauto.js');
const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const F='file://'+process.cwd()+'/fenerbahce.html';
const pg=await b.newPage({viewport:{width:1280,height:900}});
const errs=[];pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error'&&!m.text().includes('ERR_TUNNEL'))errs.push(m.text())});
const shot=async n=>{await pg.evaluate(()=>{const a=document.getElementById('gameArea')||document.getElementById('panel');a.scrollIntoView()});await pg.waitForTimeout(150);await pg.screenshot({path:n})};
const game=async g=>{await pg.evaluate(g=>pickGame(g),g);await pg.waitForTimeout(150)};
const log=m=>console.log(m,errs.length?JSON.stringify(errs.splice(0)):'');
// FOOTBALL
await pg.goto(F+'#football-play');await pg.waitForTimeout(400);
await game('quiz');await pg.click('[data-qlv="normal"]');for(let i=0;i<7;i++){await pg.click('[data-qo="0"]');await pg.click('[data-q="next"]');}log('fb quiz');
await game('draft');await gzAuto(pg);await pg.click('[data-sz="start"]');await pg.click('[data-sz="all"]');log('fb draft');
await game('wordle');await pg.keyboard.type('ABCDE');await pg.keyboard.press('Enter');log('fb wordle');
await game('xi');await pg.fill('#xiGuess','fred');await pg.press('#xiGuess','Enter');log('fb xi');
await game('penalties');await pg.click('[data-pk="spin"]');await pg.waitForTimeout(4200);log('fb pk');
await game('who');await pg.fill('#whoGuess','xx');await pg.press('#whoGuess','Enter');log('fb who');
await game('timeline');await pg.click('[data-ins="0"]');log('fb tl');
// BASKETBALL
for(const br of ['basketball','womens-basketball']){
 await pg.goto(F+'#'+br+'-play');await pg.waitForTimeout(400);
 await game('quiz');await pg.click('[data-qlv="hard"]');await pg.click('[data-qo="1"]');log(br+' quiz');
 await game('draft5');for(let i=0;i<6;i++)await pg.click('[data-tc="0"]');await pg.waitForTimeout(100);await shot(br+'_draft.png');
 await pg.click('[data-sz="start"]');await pg.waitForTimeout(2000);await shot(br+'_cup.png');await pg.click('[data-sz="all"]').catch(()=>{});log(br+' draft');
 await game('wordle');const ans=await pg.evaluate(()=>wdS[current].ans);for(const k of ans)await pg.keyboard.press(k);await pg.keyboard.press('Enter');await pg.waitForTimeout(600);await shot(br+'_wordle.png');log(br+' wordle');
 await game('lineup');for(const n of ['hall','melli','stewart','meesseman','xyz','dixon','mcbride'])  {await pg.fill('#luGuess',n);await pg.press('#luGuess','Enter');}await pg.click('[data-l="hint"]');await shot(br+'_lineup.png');
 await pg.click('[data-lu]:nth-child(2)');log(br+' lineup');
 await game('ft');await pg.click('[data-fs="0"]');for(let i=0;i<3;i++){await pg.waitForTimeout(300+Math.random()*400);await pg.keyboard.press('Space');await pg.waitForTimeout(1400);}await shot(br+'_ft.png');log(br+' ft');
 await game('who');await pg.fill('#whoGuess','nobody');await pg.press('#whoGuess','Enter');await shot(br+'_who.png');log(br+' who');
 await game('timeline');await pg.click('[data-ins="0"]');await pg.click('[data-ins="1"]');log(br+' tl');
}
// VOLLEYBALL
await pg.goto(F+'#volleyball-play');await pg.waitForTimeout(400);
await game('draft6');for(let i=0;i<7;i++)await pg.click('[data-tc="0"]');await pg.click('[data-sz="start"]');await pg.waitForTimeout(1800);await shot('vb_draft.png');await pg.click('[data-sz="all"]').catch(()=>{});log('vb draft');
await game('squad');for(const n of ['eda','kim','naz','fofao','skowronska','logan'])  {await pg.fill('#luGuess',n);await pg.press('#luGuess','Enter');}await shot('vb_squad.png');log('vb squad');
await game('serve');await pg.click('[data-sv="0"]');for(let i=0;i<3;i++){await pg.waitForTimeout(400);await pg.keyboard.press('Space');await pg.waitForTimeout(500);await pg.keyboard.press('Space');await pg.waitForTimeout(1500);}await shot('vb_serve.png');log('vb serve');
await game('who');await shot('vb_who.png');log('vb who');await game('wordle');log('vb wordle');await game('timeline');log('vb tl');await game('quiz');log('vb quiz');
// MORE
await pg.goto(F+'#more-play');await pg.waitForTimeout(400);
await game('which');await pg.click('[data-wo]');await shot('more_which.png');log('more which');
await game('memory');for(let i=0;i<4;i++){await pg.click(`[data-mc="${i}"]`);await pg.waitForTimeout(950);}await shot('more_mem.png');log('more mem');
await game('timeline');log('more tl');await game('quiz');log('more quiz');
await pg.goto(F+'#basketball');await pg.waitForTimeout(300);await pg.screenshot({path:'hero_bb.png'});
await pg.evaluate(x=>{tab=x;syncHash();render()},'trophies');await shot('bb_troph.png');
const m=await b.newPage({viewport:{width:390,height:844}});m.on('pageerror',e=>errs.push(e.message));
for(const u of ['#basketball-play','#volleyball-play','#more-play']){await m.goto(F+u);await m.waitForTimeout(300);}
await m.goto(F+'#basketball-play');await m.waitForTimeout(300);await m.evaluate(g=>pickGame(g),'lineup');await m.screenshot({path:'m_lineup.png',fullPage:true});
await m.goto(F+'#volleyball-play');await m.waitForTimeout(300);await m.evaluate(g=>pickGame(g),'serve');await m.click('[data-sv="0"]');await m.screenshot({path:'m_serve.png',fullPage:true});
console.log('mobile',JSON.stringify(errs),await m.evaluate(()=>document.documentElement.scrollWidth));
await b.close();})();
