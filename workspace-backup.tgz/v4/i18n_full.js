/* Full build only: builds every language from the catalogue. The published page loads ready-made language packs instead (i18n_pack.js). */

function buildI18n(){const roots={SPORTS,LIVE,CLUB_EVENTS,BR_FACTS,BR_NAMES,MEM_PAIRS,NAT,NAT2,BPOS,LINE_NAME,ROLE_NAME,SLOTNAME,METRIC,SPECIAL,SPECIAL_B,VB_AWARDS,DATA_NOTE,MB_LINEUPS,WB_LINEUPS,VB_SQUADS,TLCFG,PLAY,ZN,LENS};
  ["tr","de"].forEach((L,li)=>{Object.entries(I18N_UI).forEach(([en,v])=>{if(v[li]!=null)DICT[L][en]=v[li]});
    const C=I18N_CONTENT[L];Object.keys(C).forEach(k=>{if(roots[k])addZip(L,roots[k],C[k])});
    Object.entries(DICT[L]).forEach(([en,x])=>{const k=en.toLowerCase();if(!LOWER[L][k])LOWER[L][k]=[en,x]});
    PATTERNS[L]=I18N_PATS.map(p=>[p[0],p[1+li]]).filter(p=>p[1]!=null);PATTERNS[L].push([/^.+$/,m=>trDate(m[0])])});
  /* Spanish, French, Arabic come from the shared catalogue of English strings */
  XLANGS.forEach((L,li)=>{const X=I18N_X[L];I18N_CAT.forEach((en,i)=>{const v=X[i];if(v!=null&&v!==en)DICT[L][en]=v});
    Object.entries(DICT[L]).forEach(([en,x])=>{const k=en.toLowerCase();if(!LOWER[L][k])LOWER[L][k]=[en,x]});
    PATTERNS[L]=I18N_PATS.map((p,i)=>{const x=I18N_PATS_X[i];return [p[0],x?x[li]:p[2]]}).filter(p=>p[1]!=null);PATTERNS[L].push([/^.+$/,m=>trDate(m[0])])});
  /* new branches and helper, all languages */
  ["tr","de","es","fr","ar"].forEach((L,li)=>Object.entries(I18N_NEW).forEach(([en,v])=>{if(v&&v[li]!=null&&v[li]!==en){DICT[L][en]=v[li];LOWER[L][en.toLowerCase()]=[en,v[li]]}}))}
function setLang(c){if(c==="ar"&&window.loadFont)loadFont(FONT_EXTRA.ar);if(!LANGS.some(l=>l[0]===c))return;LANG=c;try{localStorage.setItem("fb-lang",c)}catch(e){}staticTexts();render();renderOnThisDay()}
function initLang(){if(LANG==="ar"&&window.loadFont)loadFont(FONT_EXTRA.ar);buildI18n();$("lang").innerHTML=LANGS.map(([c,n])=>`<option value="${c}">${n}</option>`).join("");$("lang").addEventListener("change",e=>setLang(e.target.value));staticTexts();watchPanel()}
