/* ===== Stand-alone site: Supabase stands in for the Claude page features (db, user, room, downloads) =====
   Only included in the GitHub Pages build. Inside Claude the real window.claude is used instead. */
(function(){
  if(window.claude&&window.claude.use)return;
  const CFG=window.FB_SB||{};
  const ok=()=>!!(CFG.url&&CFG.key&&window.supabase&&window.supabase.createClient);
  let sb=null,uidP=null;
  const client=()=>{if(!sb&&ok())sb=window.supabase.createClient(CFG.url,CFG.key,{auth:{persistSession:true,autoRefreshToken:true,storageKey:"fb-auth"},realtime:{params:{eventsPerSecond:10}}});return sb};
  /* every visitor gets an anonymous account the first time, kept in this browser */
  function uid(){if(uidP)return uidP;uidP=(async()=>{const c=client();if(!c)return null;
    let {data}=await c.auth.getSession();if(data&&data.session)return data.session.user.id;
    const r=await c.auth.signInAnonymously();if(r.error)throw r.error;return r.data.user.id})().catch(e=>{uidP=null;console.warn("[fb] sign-in",e&&e.message);return null});return uidP}
  const COLS=["predictions","motm","scores","ratings","seasons","challenges","watch"];

  /* ---- db: collection(col).onSnapshot(cb) and doc("col/id").set(data) ---- */
  /* what each shared collection keeps in this browser, so an account's saved data shows up on a new device */
  const LOCAL={predictions:["p","fb-preds"],motm:["v","fb-motm"],ratings:["r","fb-ratings"],challenges:["c","fb-ch"],seasons:["b","fb-sz-rec"],watch:["w","fb-watch"]};
  let REMOTE_SCORES={};
  function hydrate(c,me){return c.from("docs").select("col,data").eq("id",me).then(({data,error})=>{if(error)return;let changed=false;
    (data||[]).forEach(r=>{if(r.col==="scores"){REMOTE_SCORES=(r.data&&r.data.s)||{};return}const L=LOCAL[r.col];if(!L||typeof store==="undefined")return;const rem=(r.data&&r.data[L[0]])||{};
      const loc=store.get(L[1],{})||{};let n=0;Object.keys(rem).forEach(k=>{if(!(k in loc)){loc[k]=rem[k];n++}});if(n){store.set(L[1],loc);changed=true}});
    if(changed)setTimeout(()=>{try{xRefresh();if(typeof xBadgeCheck==="function")xBadgeCheck()}catch(e){}},0)}).catch(()=>{})}
  function makeDb(me){const c=client();const hyd=hydrate(c,me);
    const docSnap=(id,d)=>({id,exists:true,data:()=>d});
    return {
      collection(col){return {onSnapshot(cb,err){if(!COLS.includes(col)){err&&err(new Error("unknown collection"));return ()=>{}}
        const m={};let alive=true;const emit=()=>{if(alive)cb({docs:Object.entries(m).filter(([id])=>!(window.FB_BANNED&&window.FB_BANNED.has(id))).map(([id,d])=>docSnap(id,d))})};
        c.from("docs").select("id,data").eq("col",col).limit(5000).then(({data,error})=>{if(error){err&&err(error);return}(data||[]).forEach(r=>m[r.id]=r.data);emit()});
        const ch=c.channel("db-"+col+"-"+Math.random().toString(36).slice(2,8)).on("postgres_changes",{event:"*",schema:"public",table:"docs",filter:"col=eq."+col},p=>{
          if(p.eventType==="DELETE"){const id=p.old&&p.old.id;if(id){delete m[id];emit()}return}const r=p.new;if(r&&r.id){m[r.id]=r.data;emit()}}).subscribe();
        return ()=>{alive=false;c.removeChannel(ch)}}}},
      doc(path){const [col,id]=path.split("/");return {
        async set(data){if(!COLS.includes(col)||id!==me)throw Object.assign(new Error("not allowed"),{code:"forbidden"});await hyd;
          if(col==="scores"&&data&&data.s){const s={...data.s};Object.entries(REMOTE_SCORES).forEach(([k,v])=>{if(typeof v==="number"&&!(s[k]>=v))s[k]=v});data={...data,s};REMOTE_SCORES=s}
          const {error}=await c.from("docs").upsert({col,id,data,updated_at:new Date().toISOString()});if(error)throw error},
        async get(){const {data}=await c.from("docs").select("data").eq("col",col).eq("id",id).maybeSingle();return {id,exists:!!data,data:()=>data&&data.data}}}}}}

  /* ---- user: id() and profiles(ids); fans pick their own name in Settings ---- */
  const NAMES={};
  function makeUser(me){const c=client();
    /* when another fan renames themselves, update the boards without a reload */
    c.channel("profiles-"+Math.random().toString(36).slice(2,8)).on("postgres_changes",{event:"*",schema:"public",table:"profiles"},p=>{const r=p.new;if(!r||!r.id)return;NAMES[r.id]=r.name||"";
      try{if(typeof XC!=="undefined"&&r.id in XC.names)XC.names[r.id]=NAMES[r.id];if(typeof RT!=="undefined"&&r.id in RT.names)RT.names[r.id]=NAMES[r.id];if(typeof xRefresh==="function")xRefresh()}catch(e){}}).subscribe();
    return {
    async id(){return me},
    async profiles(ids){ids=[...new Set(ids)].filter(Boolean);const out={};const need=ids.filter(i=>!(i in NAMES));
      if(need.length){const {data}=await c.from("profiles").select("id,name").in("id",need.slice(0,200));need.forEach(i=>NAMES[i]="");(data||[]).forEach(r=>NAMES[r.id]=r.name||"")}
      ids.forEach(i=>out[i]={name:NAMES[i]||""});return out},
    async setName(n){n=String(n||"").replace(/\s+/g," ").trim().slice(0,24);if(n&&modBad(n))throw Object.assign(new Error("rude"),{code:"rude"});const {error}=await c.from("profiles").upsert({id:me,name:n,updated_at:new Date().toISOString()});if(error)throw error;NAMES[me]=n;return n},
    myName(){return NAMES[me]||""}}}

  /* ---- room: join(name) gives emit/on/presence/peers/onPeers/leave over Supabase Realtime ---- */
  function makeRoom(me){const c=client(),conn=Math.random().toString(36).slice(2,12);
    function open(name){const ch=c.channel("room:"+String(name).slice(0,60),{config:{broadcast:{self:true,ack:false},presence:{key:conn}}});
      let pres={},joined=false;const peerL=new Set(),msgL={};
      const peers=()=>{const st=ch.presenceState();return Object.entries(st).map(([k,metas])=>{const m=metas[metas.length-1]||{};const {by,presence_ref,...rest}=m;return {peer:k,by,isMe:by===me,sameTab:k===conn,kind:"viewer",presence:rest.p||{}}})};
      let prev={};const firePeers=()=>{const P=peers(),now={};P.forEach(p=>now[p.peer]=p);const joined=P.filter(p=>!prev[p.peer]),left=Object.values(prev).filter(p=>!now[p.peer]),updated=P.filter(p=>prev[p.peer]&&JSON.stringify(prev[p.peer].presence)!==JSON.stringify(p.presence));prev=now;
        peerL.forEach(f=>{try{f({peers:P,joined,left,updated})}catch(e){}})};
      ch.on("presence",{event:"sync"},firePeers);
      ch.on("broadcast",{event:"*"},({event,payload})=>{const L=msgL[event];if(!L||!payload)return;const P=peers().find(p=>p.peer===payload.peer);
        const m={topic:event,kind:"viewer",data:payload.data,peer:payload.peer,by:payload.by,isMe:payload.by===me,sameTab:payload.peer===conn,presence:P?P.presence:{}};L.forEach(f=>{try{f(m)}catch(e){}})});
      const ready=new Promise((res,rej)=>ch.subscribe(st=>{if(st==="SUBSCRIBED"){joined=true;ch.track({by:me,p:pres}).catch(()=>{});res()}else if(st==="CHANNEL_ERROR"||st==="TIMED_OUT")rej(new Error(st))}));
      const R={
        async emit(type,data){await ready;const r=await ch.send({type:"broadcast",event:type,payload:{data,peer:conn,by:me}});if(r!=="ok")throw new Error("send "+r)},
        on(type,f){(msgL[type]=msgL[type]||new Set()).add(f);return ()=>msgL[type].delete(f)},
        /* like the Claude room: keys are merged, a null value removes the key */
        async presence(patch){pres={...pres};Object.entries(patch||{}).forEach(([k,v])=>{if(v===null)delete pres[k];else pres[k]=v});await ready;await ch.track({by:me,p:pres})},
        peers,onPeers(f){peerL.add(f);if(joined)setTimeout(()=>{const P=peers();f({peers:P,joined:P,left:[],updated:[]})},0);return ()=>peerL.delete(f)},
        connected:()=>joined,onConnection(f){ready.then(()=>f(true),()=>f(false));return ()=>{}},
        async leave(){try{await ch.untrack()}catch(e){}try{await c.removeChannel(ch)}catch(e){}},
        async join(n){return openRoom(n)}};
      R._ready=ready;return R}
    const cache={};async function openRoom(n){if(cache[n])return cache[n];const r=open(n);cache[n]=r;try{await r._ready}catch(e){delete cache[n];throw e}const leave=r.leave;r.leave=()=>{delete cache[n];return leave()};return r}
    return openRoom("lobby")}

  /* ---- downloads: an ordinary browser download ---- */
  const downloads={async save({filename,data}){const blob=data instanceof Blob?data:new Blob([data],{type:/\.csv$/i.test(filename)?"text/csv;charset=utf-8":"application/octet-stream"});
    const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=filename||"download";document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},1500);return {saved:true}}};

  /* ---- accounts: username + password; the guest account becomes the permanent one, so nothing is lost ---- */
  const U_DOM="fans.fenerbahcefanhub.app";
  const uMail=u=>u+"@"+U_DOM;
  const uOk=u=>/^[a-z0-9][a-z0-9._-]{1,18}[a-z0-9]$/.test(u);
  const err=(code)=>Object.assign(new Error(code),{code});
  const authErr=e=>{const m=((e&&(e.code||""))+" "+(e&&e.message||"")).toLowerCase();if(e&&e.status===429||/rate limit|too many/.test(m))return err("slow");
    if(/already|exists|registered|taken/.test(m))return err("taken");if(/invalid login|credentials/.test(m))return err("wrong");if(/password/.test(m)&&/(short|least|weak|characters)/.test(m))return err("pw");return err("net")};
  async function account(){const c=client();if(!c)return null;const {data}=await c.auth.getSession();const u=data&&data.session&&data.session.user;if(!u)return null;
    const em=u.email||"";return {anon:!!u.is_anonymous||!em,username:em.endsWith("@"+U_DOM)?em.slice(0,-U_DOM.length-1):(em||null)}}
  async function register(name,pw){const c=client();if(!c)throw err("net");const u=String(name||"").trim().toLowerCase();if(!uOk(u))throw err("name");if(modBad(u))throw err("rude");if(String(pw||"").length<6)throw err("pw");
    const me=await uid();if(!me)throw err("net");const a=await account();if(a&&!a.anon)throw err("already");
    let r=await c.auth.updateUser({email:uMail(u)});if(r.error)throw authErr(r.error);
    r=await c.auth.updateUser({password:pw});if(r.error)throw authErr(r.error);
    try{const U=await window.claude.use("user");if(U&&!U.myName())await U.setName(String(name).trim())}catch(e){}
    return u}
  async function login(name,pw){const c=client();if(!c)throw err("net");const u=String(name||"").trim().toLowerCase();if(!uOk(u))throw err("wrong");
    const r=await c.auth.signInWithPassword({email:uMail(u),password:pw});if(r.error)throw authErr(r.error);return u}
  async function logout(){const c=client();if(!c)return;await c.auth.signOut().catch(()=>{});
    /* the next visitor on this browser starts fresh, without this account's predictions and votes */
    if(typeof store!=="undefined")Object.values(LOCAL).forEach(([,k])=>{try{store.set(k,{})}catch(e){}})}

  const cache={};
  window.FB_SITE={on:false,client,uid,account,register,login,logout};
  window.claude={async use(cap){
    if(cap==="downloads")return downloads;
    if(cap==="sample")return null; /* Kanarya stays off on the stand-alone site */
    if(cache[cap])return cache[cap];
    const me=await uid();if(!me)return null;window.FB_SITE.on=true;window.FB_SITE.me=me;
    if(cap==="db")return cache[cap]=makeDb(me);
    if(cap==="user")return cache[cap]=makeUser(me);
    if(cap==="room"){try{return cache[cap]=await makeRoom(me)}catch(e){console.warn("[fb] room",e&&e.message);return null}}
    return null}};
})();

/* Fan name field in Settings (stand-alone site only) */
(function(){if(!window.FB_SITE)return;const base=fillSettings;
  fillSettings=function(){base();const pan=$("setPanel");if(!pan||!XC.user||!XC.user.setName)return;const cur=XC.user.myName()||"";
    const tour=pan.querySelector("#setTour");const row=document.createElement("label");row.className="setrow";
    row.innerHTML=`<span>${t("Your fan name")}</span><span class="fnrow"><input id="setName" maxlength="24" autocomplete="nickname" value="${esc(cur)}" placeholder="${esc(t("e.g. Kadıköy Kanaryası"))}"><button class="btn ghost sm" type="button" id="setNameOk">${t("Save")}</button></span><small>${t("Shown on leaderboards and in watch parties. Leave it empty to appear as “A fan”.")}</small>`;
    (tour?tour.closest(".btns"):pan.lastElementChild).before(row);
    const save=async()=>{const b=$("setNameOk");b.disabled=true;try{const n=await XC.user.setName($("setName").value);XC.names[XC.me]=n;RT.names[XC.me]=n;xToast(n?tf("Saved. You're {n} now.",{n}):t("Saved."));xRefresh()}catch(e){xToast(t(e&&e.code==="rude"?"Please keep it friendly. Pick another name.":"Couldn't save your name. Try again."))}b.disabled=false};
    $("setNameOk").onclick=save;$("setName").onkeydown=e=>{if(e.key==="Enter"){e.preventDefault();save()}}};
  const AE={name:"Usernames need 3–20 letters (a–z), numbers, dots, dashes or underscores.",pw:"Passwords need at least 6 characters.",taken:"That username is already taken. Pick another one.",
    wrong:"Wrong username or password.",slow:"Too many attempts. Wait a few minutes and try again.",net:"Couldn't connect. Try again.",rude:"Please keep it friendly. Pick another name.",already:"You're already logged in."};
  async function fillAccount(){const box=$("setAcct");if(!box)return;const a=await FB_SITE.account().catch(()=>null);if(!$("setAcct"))return;acBtnLabel(a);
    if(a&&!a.anon){box.innerHTML=`<b class="acctin">${tf("Logged in as {u}.",{u:`<b>${esc(a.username||"")}</b>`})}</b><small>${t("Your points, predictions and fan name are saved to your account. Log in with the same username on any device.")}</small><div class="btns"><button class="btn ghost sm" type="button" id="acOut">${t("Log out")}</button></div>`;
      $("acOut").onclick=async()=>{$("acOut").disabled=true;await FB_SITE.logout();location.reload()};return}
    box.innerHTML=`<small>${t("You're playing as a guest on this device. Create an account to keep your points, predictions and fan name, and to log in on other devices.")}</small>
      <form id="acForm" class="acform" autocomplete="on"><input id="acUser" name="username" autocomplete="username" maxlength="20" autocapitalize="none" spellcheck="false" placeholder="${esc(t("Username"))}" aria-label="${esc(t("Username"))}">
      <input id="acPw" name="password" type="password" autocomplete="current-password" maxlength="72" placeholder="${esc(t("Password"))}" aria-label="${esc(t("Password"))}">
      <div class="btns"><button class="btn sm" type="button" data-ac="register">${t("Create account")}</button><button class="btn ghost sm" type="submit" data-ac="login">${t("Log in")}</button></div>
      <p class="fine" id="acMsg" role="status" aria-live="polite"></p></form>
      <small>${t("Usernames: 3–20 letters (a–z), numbers, dots, dashes or underscores. There is no password reset, so keep your password somewhere safe.")}</small>`;
    /* Enter logs in; "Create account" registers */
    let mode="login";const form=$("acForm");
    box.querySelector('[data-ac="login"]').onclick=()=>{mode="login";$("acPw").autocomplete="current-password"};
    box.querySelector('[data-ac="register"]').onclick=()=>{mode="register";$("acPw").autocomplete="new-password";form.requestSubmit?form.requestSubmit():form.onsubmit(new Event("submit"))};
    form.onsubmit=async e=>{e.preventDefault();const m=mode;mode="login";const msg=$("acMsg"),bs=box.querySelectorAll("[data-ac]");bs.forEach(b=>b.disabled=true);msg.textContent=t(m==="register"?"Creating your account…":"Logging in…");
      try{if(m==="register"){const u=await FB_SITE.register($("acUser").value,$("acPw").value);xToast(tf("Account created. You're logged in as {u}.",{u}));fillAccount();if($("setPanel")&&!$("setPanel").hidden)fillSettings()}
        else{await FB_SITE.login($("acUser").value,$("acPw").value);location.reload()}}
      catch(x){msg.textContent=t(AE[x&&x.code]||AE.net);bs.forEach(b=>b.disabled=false)}}}
  /* account button in the top bar, next to the language picker */
  const PERSON='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="8" r="3.6"/><path d="M4.5 20c1.2-3.8 4-5.6 7.5-5.6s6.3 1.8 7.5 5.6"/></svg>';
  function acBtnLabel(a){const b=$("acBtn");if(!b)return;const inn=a&&!a.anon;const lab=inn?(a.username||t("Your account")):t("Log in");
    b.querySelector(".aclab").textContent=lab;b.classList.toggle("in",!!inn);b.setAttribute("aria-label",inn?tf("Logged in as {u}.",{u:a.username||""}).replace(/<[^>]+>/g,""):t("Log in or create an account"))}
  function initAcct(){const host=document.querySelector(".bar .wrap");if(!host||$("acBtn"))return;const lp=host.querySelector(".langpick");
    const w=document.createElement("div");w.className="acwrap";w.innerHTML=`<button class="hset hacct" id="acBtn" type="button" aria-expanded="false" aria-controls="acPanel">${PERSON}<span class="aclab">${t("Log in")}</span></button>
      <div class="setpanel acpanel" id="acPanel" role="dialog" aria-modal="false" aria-labelledby="acTitle" hidden><h2 id="acTitle">${t("Your account")}</h2><div class="setrow acct" id="setAcct"></div></div>`;
    if(lp)host.insertBefore(w,lp);else host.appendChild(w);
    const btn=$("acBtn"),pan=$("acPanel");const close=back=>{pan.hidden=true;btn.setAttribute("aria-expanded","false");if(back)btn.focus()};
    btn.onclick=async()=>{if(!pan.hidden){close(false);return}$("acTitle").textContent=t("Your account");pan.hidden=false;btn.setAttribute("aria-expanded","true");await fillAccount();const f=pan.querySelector("input,button");if(f)f.focus()};
    document.addEventListener("click",e=>{if(!pan.hidden&&!e.target.closest(".acwrap"))close(false)});
    pan.addEventListener("keydown",e=>{if(e.key==="Escape"){e.stopPropagation();close(true)}});
    FB_SITE.account().then(acBtnLabel).catch(()=>{})}
  /* show the button once the shared features are connected; relabel it when the language changes */
  const waitAc=setInterval(()=>{if(FB_SITE.on){clearInterval(waitAc);initAcct()}},500);setTimeout(()=>clearInterval(waitAc),30000);
  document.addEventListener("change",e=>{if(e.target&&(e.target.id==="lang"||e.target.id==="setLang"))setTimeout(()=>{FB_SITE.account().then(acBtnLabel).catch(()=>{});const p=$("acPanel");if(p&&!p.hidden){$("acTitle").textContent=t("Your account");fillAccount()}},500)},true);
  /* load my own name once signed in */
  const wait=setInterval(()=>{if(XC.on&&XC.user&&XC.user.profiles){clearInterval(wait);XC.user.profiles([XC.me]).then(()=>{const f=$("setName"),n=XC.user.myName();if(f&&n&&!f.value&&document.activeElement!==f)f.value=n}).catch(()=>{})}},800);setTimeout(()=>clearInterval(wait),30000)})();
