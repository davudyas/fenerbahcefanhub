const {chromium}=require('playwright');const fs=require('fs');
(async()=>{const b=await chromium.launch();const pg=await b.newPage();const errs=[];pg.on('pageerror',e=>errs.push(e.message));
await pg.goto('file://'+process.cwd()+'/fenerbahce.html#football');await pg.waitForTimeout(400);
const r=await pg.evaluate(()=>{const out={},samples=[];Object.keys(SPORTS).forEach(b=>{QLV.forEach(([lv,,n])=>{let short=0,bad=0,uniq=new Set();for(let k=0;k<40;k++){const R=qRound(b,lv);if(R.length<7)short++;R.forEach(q=>{uniq.add(q.q);if(q.o.length!==n||new Set(q.o).size!==n||q.a<0)bad++})}
  out[b+"/"+lv]=`short ${short} bad ${bad} distinct ${uniq.size}`;const R=qRound(b,lv);R.slice(0,4).forEach(q=>samples.push(`[${b}/${lv}] ${q.q} || ${q.o.map((o,i)=>i===q.a?"*"+o:o).join(" / ")} || ${q.e}`))})});return [out,samples]});
console.log(r[0]);fs.writeFileSync('../res/quiz_samples.txt',r[1].join('\n'));console.log(errs);await b.close()})();
