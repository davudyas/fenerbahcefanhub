/* ===== v23: the "Matchday" layout. A score strip on top, a navy band with every branch as an icon tab, a two-column
   home page, card-based branch pages and a bottom tab bar on phones. Ideas taken from big sports sites (score strip,
   white cards on grey, stacked match rows, bottom bar); no club crests: teams get initials in a coloured circle. ===== */

/* ---------- Team initials ---------- */
const BADGE_COL=["#c8423b","#3d6aa6","#3f8f4a","#8e5b9a","#d7822c","#2f8f8a","#7c5b48","#b08a1e","#c0507a","#5b6b7c"];
function teamCode(n){if(n==="Fenerbahçe")return "FB";const w=n.replace(/[()]/g,"").split(/\s+/).filter(Boolean);
  const c=w.length===1?w[0].slice(0,3):w.slice(0,3).map(x=>x[0]).join("");return c.toLocaleUpperCase("tr")}
function teamBadge(n){const fb=n==="Fenerbahçe";let h=0;for(const ch of n)h=(h*31+ch.charCodeAt(0))>>>0;
  return `<span class="tb${fb?" fbb":""}" style="${fb?"":"--tb:"+BADGE_COL[h%BADGE_COL.length]}" aria-hidden="true">${esc(teamCode(n))}</span>`}

/* ---------- Day labels for grouped lists ---------- */
function dayLabel(iso){const d=Math.round((isoDay(iso)-isoDay(todayISO()))/DAY);
  return d===0?t("Today"):d===-1?t("Yesterday"):d===1?t("Tomorrow"):fmtDay(isoDay(iso),{weekday:"long",day:"numeric",month:"long"})}

/* ---------- Score strip ---------- */
function stripTile(x){
  if(x.r){const {b,r,i}=x,P=sides(r),o=outcome(r);
    return `<button class="stile" data-mi="${i}" data-mb="${b}" aria-label="${esc(tf("Match details: Fenerbahçe {a}–{b} {o}",{a:r[4],b:r[5],o:r[3]}))}"><span class="stc">${brIcon(b)}<span>${esc(t(r[1]))}</span></span><span class="sts">${mDate(r[0],true)} · ${t("FT")}</span>
      ${P.map(([n,sc])=>`<span class="str${n==="Fenerbahçe"?" fb":""}">${teamBadge(n)}<span class="sn">${esc(teamCode(n))}</span><b>${esc(sc)}</b></span>`).join("")}</button>`}
  const {b,n}=x,P=n[3]==="A"?[n[4],"Fenerbahçe"]:["Fenerbahçe",n[4]];
  return `<button class="stile up" data-gosport="${b}" aria-label="${esc(t(SPORTS[b].label)+": "+vsOpp(n[3],n[4])+", "+mDate(n[0])+(n[1]?" "+n[1]:""))}"><span class="stc">${brIcon(b)}<span>${esc(t(n[2]))}</span></span><span class="sts">${mDate(n[0],true)}${n[1]?" · "+esc(n[1]):""}</span>
    ${P.map(nm=>`<span class="str${nm==="Fenerbahçe"?" fb":""}">${teamBadge(nm)}<span class="sn">${esc(teamCode(nm))}</span></span>`).join("")}</button>`}
let stripPainted=false;
function paintStrip(){const tr=$("strack");if(!tr)return;const res=homeResults(9999).reverse(),fx=homeFixtures();
  let mon="",html="";const monTag=d=>{const m=d.slice(0,7);if(m===mon)return "";mon=m;return `<span class="smon" aria-hidden="true">${esc(fmtDay(isoDay(m+"-15"),{month:"short"}))}<small>${m.slice(0,4)}</small></span>`};
  res.forEach(x=>{html+=monTag(x.r[0])+stripTile(x)});if(fx.length)html+=`<span class="ssep" aria-hidden="true"></span>`;fx.forEach(x=>{html+=monTag(x.n[0])+stripTile(x)});
  tr.innerHTML=html;
  if(!stripPainted){stripPainted=true;requestAnimationFrame(()=>{const f=tr.querySelector(".stile.up");if(f&&tr.scrollWidth>tr.clientWidth){const rtl=document.documentElement.dir==="rtl";tr.scrollLeft=rtl?-(tr.scrollWidth-f.offsetLeft-f.offsetWidth-tr.clientWidth/3):Math.max(0,f.offsetLeft-tr.clientWidth/3)}})}}

/* ---------- Branch tabs with icons ---------- */
const BR_ROW=["home","football","womens-football","basketball","womens-basketball","volleyball","mens-volleyball","more"];
const ICON_HOME='<svg class="bri" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 11l8-6 8 6v8a1 1 0 0 1-1 1h-4v-6H9v6H5a1 1 0 0 1-1-1z"/></svg>';
const ICON_MORE='<svg class="bri" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><rect x="4" y="4" width="6.5" height="6.5" rx="1.5"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.5"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.5"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.5"/></svg>';
function brRowIcon(b){return b==="home"?ICON_HOME:b==="more"?ICON_MORE:brIcon(b).replace('role="img"','aria-hidden="true"').replace(/<title>.*?<\/title>/,"")}
function paintBrRow(){const nav=$("brRow");if(!nav)return;
  nav.querySelector(".wrap").innerHTML=BR_ROW.filter(b=>b==="home"||SPORTS[b]).map(b=>`<button type="button" data-br="${b}"${b===current?' aria-current="page"':""}>${brRowIcon(b)}<span>${esc(b==="home"?t("All branches"):b==="more"?t("More"):b==="football"?t("Men's Football"):t(SPORTS[b].label))}</span></button>`).join("");
  {const w=nav.querySelector(".wrap");nav.classList.remove("tight");if(w.scrollWidth>w.clientWidth+1)nav.classList.add("tight")}
  const on=nav.querySelector('[aria-current="page"]');if(on){const w=nav.querySelector(".wrap"),r0=w.getBoundingClientRect(),r1=on.getBoundingClientRect();if(r1.left<r0.left||r1.right>r0.right)w.scrollLeft+=r1.left-r0.left-24}}
{let rz;addEventListener("resize",()=>{clearTimeout(rz);rz=setTimeout(paintBrRow,150)})}
document.addEventListener("click",e=>{const x=e.target.closest("[data-br]");if(!x)return;setSport(x.dataset.br);scrollTo({top:0})});

/* ---------- Bottom tab bar (phones) ---------- */
let lastBr="football";
const BN=[["home","nav:Home",ICON_HOME],
 ["matches","Matches",'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M9 3v4M15 3v4"/></svg>'],
 ["standings","Standings",'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="M5 20V10M12 20V4M19 20v-7"/></svg>'],
 ["play","Play",'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="7" width="18" height="11" rx="4"/><path d="M8 11v3M6.5 12.5h3M15.5 12h.01M18 13.5h.01"/></svg>'],
 ["search","Search",'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="6.5"/><path d="M16 16l4 4"/></svg>']];
function bnActive(){return current==="home"?"home":tab==="standings"||tab==="race"?"standings":tab==="play"?"play":tab==="matches"?"matches":""}
function paintBnav(){const nav=$("bnav");if(!nav)return;const a=bnActive();
  nav.innerHTML=BN.map(([k,l,ic])=>`<button type="button" data-bn="${k}"${k===a?' aria-current="page"':""}>${ic}<span>${esc(t(l))}</span></button>`).join("")}
function goBranchTab(tb){const b=current==="home"?lastBr:current;let x=tb;if(!tabsFor(b).some(y=>y[0]===x))x=tabsFor(b).some(y=>y[0]==="matches")?"matches":tabsFor(b)[0][0];
  if(current!==b){current=b;gameFilter="All";mFilter="All";mAll=false}tab=x;syncHash();render();scrollTo({top:0})}
document.addEventListener("click",e=>{const x=e.target.closest("[data-bn]");if(!x)return;const k=x.dataset.bn;
  if(k==="home"){setSport("home");scrollTo({top:0})}else if(k==="search")openSearch();else goBranchTab(k)});

/* ---------- Home: matches grouped by day ---------- */
let hmTab="results";
function homeMatches(){const items=hmTab==="results"?homeResults(14).map(x=>({d:x.r[0],h:srowResult(x.b,x.r,x.i,true)})):homeFixtures().slice(0,14).map(x=>({d:x.n[0],h:srowFixture(x.b,x.n,true)}));
  let last="",out="";items.forEach(x=>{if(x.d!==last){if(last)out+="</ol>";out+=`<h4 class="dayh">${esc(dayLabel(x.d))}</h4><ol class="mlist srows">`;last=x.d}out+=x.h});if(last)out+="</ol>";
  return out||`<p class="muted">${t(hmTab==="results"?"No results yet.":"No upcoming fixtures in this snapshot.")}</p>`}
function paintHomeMatches(){const box=$("hmList");if(!box)return;box.innerHTML=homeMatches();
  document.querySelectorAll("[data-hm]").forEach(b=>b.setAttribute("aria-pressed",b.dataset.hm===hmTab));const c=$("hmCsv");if(c)c.hidden=hmTab!=="upcoming"}
document.addEventListener("click",e=>{const b=e.target.closest("[data-hm]");if(b){hmTab=b.dataset.hm;paintHomeMatches();b.focus();return}
  const g=e.target.closest('[data-gohome="fixtures"]');if(g){hmTab="upcoming";if(current==="home")paintHomeMatches()}
  const s=e.target.closest("[data-gostand]");if(s){current=s.dataset.gostand;tab="standings";gameFilter="All";mFilter="All";syncHash();render();scrollTo({top:0})}},true);

EXT.home.push(p=>{const lg=p.querySelector("#leagueBox"),csvBtn=p.querySelector("[data-calcsv]"),csv=csvBtn&&csvBtn.closest(".btns"),live=[...p.querySelectorAll(".wpcard.live")],more=p.querySelector(".hmore");
  const tmp=document.createElement("div");tmp.innerHTML=homeCentre();const next=tmp.querySelector(".mcnext");
  p.innerHTML=`<h2 class="vh">${t("All branches")}</h2>
   <h2 class="vh">${esc(t("Latest results and next games"))}</h2><div class="hgrid2"><div class="hmain" id="hMain"></div><aside class="hside" id="hSide"></aside></div>
   <section class="hsec" id="hs-predict"></section>`;
  const M=$("hMain"),S=$("hSide");
  live.forEach(x=>M.appendChild(x));
  M.insertAdjacentHTML("beforeend",`<section class="card mcard" id="hs-fixtures"><header class="mch"><h3>${t("Matches")}</h3>
     <div class="filter" role="group" aria-label="${t("Show")}"><button data-hm="results" aria-pressed="true">${t("Results")}</button><button data-hm="upcoming" aria-pressed="false">${t("Upcoming")}</button></div></header>
     <div id="hmList"></div><div id="hmCsv" hidden></div></section>
    <section class="card mcard" id="hs-teams"><header class="mch"><h3>${t("Every team")}</h3></header>${homeLines().replace(/^<h3 class="mh">.*?<\/h3>/,"")}</section>`);
  if(csv)$("hmCsv").appendChild(csv);
  if(next){next.classList.add("mcard");S.appendChild(next)}
  S.insertAdjacentHTML("beforeend",miniTable("football").replace('data-goto="standings"','data-gostand="football"')+
   `<section class="card mcard" id="hs-play"><header class="mch"><h3>${t("Play")}</h3></header><div class="hplay side">${PLAY_TEASE.map(([g,n,d])=>`<button class="hpcard" data-hplay="${g}"><b>${esc(t(n))}</b><span>${esc(t(d))}</span></button>`).join("")}
     <button class="hpcard" data-gohome="predict"><b>${esc(t("Predict the score"))}</b><span>${esc(t("Join the fans' prediction league"))}</span></button></div></section>`);
  if(lg)$("hs-predict").appendChild(lg);if(more)$("hs-predict").insertAdjacentElement("afterend",more);
  paintHomeMatches();document.body.dataset.view="home";fitLede();tourButton();paintChrome()});
EXT.afterPanel.push(()=>paintChrome());

/* ---------- Everything outside the panel ---------- */
function paintChrome(){if(current!=="home")lastBr=current;[["brRow","Branches"],["bnav","Main"]].forEach(([i,l])=>{const e=$(i);if(e)e.setAttribute("aria-label",t(l))});{const e=document.querySelector(".strip");if(e)e.setAttribute("aria-label",t("Latest results and next games"))}paintBrRow();paintBnav();paintStrip()}
function lookInit(){EN_NS["nav:Home"]="Home";const hero=document.querySelector(".hero"),col=hero&&hero.querySelector(".wrap>div");
  if(col){col.appendChild($("stats"));col.appendChild($("home"))}
  if(hero){const tw=document.createElement("div");tw.className="wrap herotabs";tw.appendChild($("tabs"));hero.appendChild(tw)}
  const bar=document.querySelector(".bar");
  if(bar){bar.insertAdjacentHTML("beforeend",`<nav class="brrow" id="brRow" aria-label="${esc(t("Branches"))}"><div class="wrap"></div></nav>`);
    bar.insertAdjacentHTML("beforebegin",`<div class="strip" role="region" aria-label="${esc(t("Latest results and next games"))}"><div class="wrap"><div class="strack" id="strack"></div></div></div>`)}
  const pk=document.querySelector(".picker");if(pk){pk.setAttribute("aria-hidden","true");pk.querySelectorAll("select").forEach(s=>s.tabIndex=-1)}
  document.body.insertAdjacentHTML("beforeend",`<nav class="bnav" id="bnav" aria-label="${esc(t("Main"))}"></nav>`);paintChrome()}

/* Settings and account panels: never taller than the screen, with their own scrollbar */
(function(){const fit=p=>{if(!p||p.hidden)return;p.style.maxHeight="";const r=p.getBoundingClientRect();const bn=document.getElementById("bnav"),bt=bn&&getComputedStyle(bn).display!=="none"&&bn.getBoundingClientRect().height?bn.getBoundingClientRect().top:innerHeight;
  p.style.maxHeight=Math.max(220,Math.floor(Math.min(innerHeight,bt)-Math.max(r.top,8)-12))+"px"};
  const fitAll=()=>document.querySelectorAll(".setpanel").forEach(fit);
  const mo=new MutationObserver(ms=>ms.forEach(m=>{if(m.target.classList&&m.target.classList.contains("setpanel")&&!m.target.hidden)requestAnimationFrame(()=>fit(m.target))}));
  const watch=()=>document.querySelectorAll(".setpanel").forEach(p=>{if(!p._fitW){p._fitW=1;mo.observe(p,{attributes:true,attributeFilter:["hidden"]})}});
  watch();setInterval(watch,1000);addEventListener("resize",fitAll);addEventListener("scroll",fitAll,{passive:true})})();
