// compare rendered text of every branch/tab in two builds (random games excluded)
const {chromium}=require('playwright');
const [,,A,B,langs]=process.argv;
(async()=>{const b=await chromium.launch();const snap=async f=>{const pg=await b.newPage({viewport:{width:1280,height:900}});const errs=[];pg.on('pageerror',e=>errs.push(e.message));
 await pg.addInitScript(()=>{let s=42;window.__reseed=()=>{s=42};Math.random=()=>{s=(s*16807)%2147483647;return s/2147483647}});
 await pg.goto('file://'+process.cwd()+'/'+f);await pg.waitForTimeout(500);const out={};
 for(const L of (langs||'en,tr').split(',')){if(L!=='en'){await pg.selectOption('#lang',L);await pg.waitForTimeout(300)}
  for(const br of ['home','football','basketball','womens-basketball','volleyball','mens-volleyball','womens-football','more']){const tabs=br==='home'?['x']:await pg.evaluate(br=>tabsFor(br).map(x=>x[0]).filter(x=>x!=='play'),br);
   for(const tb of tabs){out[L+'/'+br+'/'+tb]=await pg.evaluate(([br,tb])=>{window.__reseed();setSport(br);window.__reseed();if(tb!=='x'){tab=tb;render()}window.__reseed();return document.querySelector('main')?document.querySelector('main').innerText:document.body.innerText},[br,tb])}}}
 const perf=await pg.evaluate(()=>{const n=performance.getEntriesByType('navigation')[0];return {dcl:Math.round(n.domContentLoadedEventEnd),load:Math.round(n.loadEventEnd)}});
 await pg.close();return [out,errs,perf]};
const [X,ex,px]=await snap(A),[Y,ey,py]=await snap(B);let diff=0;
for(const k of new Set([...Object.keys(X),...Object.keys(Y)])){if(X[k]!==Y[k]){diff++;const a=(X[k]||'').split('\n'),c=(Y[k]||'').split('\n');console.log('DIFF',k,JSON.stringify(a.filter(x=>!c.includes(x)).slice(0,3)).slice(0,300),'=>',JSON.stringify(c.filter(x=>!a.includes(x)).slice(0,3)).slice(0,300))}}
console.log('pages',Object.keys(X).length,Object.keys(Y).length,'diffs',diff,'errs',ex,ey,'perf',px,py);await b.close()})();
