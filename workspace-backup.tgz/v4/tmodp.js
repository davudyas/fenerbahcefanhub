/* Stand-alone site test: two fans in separate browsers, Supabase replaced by an in-memory hub */
const {chromium}=require('playwright');const fs=require('fs'),path=require('path');
const SITE=path.resolve(__dirname,'../site');
let html=fs.readFileSync(SITE+'/index.html','utf8');
html=html.replace(/window\.FB_SB=\{[^<]*\};/,'window.FB_SB={"url":"https://mock.supabase.co","key":"anon"};').replace(/<script src="https:\/\/cdn\.jsdelivr[^"]*"><\/script>/,'<script src="mocksb.js"></script>');
fs.writeFileSync(SITE+'/_t.html',html);fs.copyFileSync(__dirname+'/mocksb.js',SITE+'/mocksb.js');
const docs=new Map(),profiles=new Map(),subs=new Map(),pres={},uidOf=new Map();let rls=0;
const push=(cid,k,a)=>{const s=subs.get(cid);if(s)s.page.evaluate(([c,k,a])=>window.__mockRecv&&window.__mockRecv(c,k,a),[cid,k,a]).catch(()=>{})};
const presPush=name=>{for(const [cid,s] of subs)if(s.name===name)push(cid,'pres',pres[name]||{})};
const users=new Map(),leagues=new Map(),members=[],reports=[];
const anonOf=new Map(),BANS=new Set(),REG=new Set();
function rpc(page,name,a){const me=uidOf.get(page);
 if(name==='create_league'){const c='ABC'+(234+leagues.size);leagues.set(c,{code:c,name:a.league_name,owner:me});members.push({code:c,id:me});pushPg('league_members',{code:c,id:me});return {data:c}}
 if(name==='join_league'){const l=leagues.get(a.league_code);if(!l)return {error:{message:'no such league'}};if(!members.some(m=>m.code===l.code&&m.id===me)){members.push({code:l.code,id:me});pushPg('league_members',{code:l.code,id:me})}return {data:{code:l.code,name:l.name}}}
 if(name==='leave_league'){const i=members.findIndex(m=>m.code===a.league_code&&m.id===me);if(i>=0)members.splice(i,1);return {data:null}}
 if(name==='is_admin')return {data:me===global.ADMIN};
 if(name==='banned_ids')return {data:[...BANS]};
 if(name.startsWith('admin_')&&me!==global.ADMIN)return {error:{message:'not allowed'}};
 if(name==='admin_users'){const ids=new Set([...uidOf.values()]);return {data:[...ids].map(id=>{const D=c=>(docs.get(c+'|'+id)||{}).data||{};const reg=!!REG.has(id);
   return {id,username:reg?'user'+id.slice(0,3):null,name:(profiles.get(id)||{}).name||'',registered:reg,banned:BANS.has(id),admin:id===global.ADMIN,created_at:'2026-11-12T10:00:00Z',last_sign_in_at:null,last_active:'2026-11-13T09:00:00Z',
   predictions:Object.keys(D('predictions').p||{}).length,motm:Object.keys(D('motm').v||{}).length,ratings:Object.keys(D('ratings').r||{}).length,games:docs.has('scores|'+id),leagues:members.filter(m=>m.id===id).map(m=>(leagues.get(m.code)||{}).name),reports:new Set(reports.filter(r=>r.target===id).map(r=>r.reporter)).size}}).filter(x=>a.include_guests||x.registered)}}
 if(name==='admin_reports'){const g={};reports.forEach(r=>{const k=r.target+'|'+r.kind;(g[k]=g[k]||{target:r.target,kind:r.kind,rs:new Set(),samples:[],last:'2026-11-13T00:00:00Z'}).rs.add(r.reporter);g[k].samples.push(r.content)});
   return {data:Object.values(g).map(x=>({target:x.target,kind:x.kind,reporters:x.rs.size,last:x.last,samples:x.samples,name:(profiles.get(x.target)||{}).name||'',registered:false,banned:BANS.has(x.target)}))}}
 if(name==='admin_ban'){BANS.add(a.target);const p=profiles.get(a.target);if(p)p.name='';return {data:null}}
 if(name==='admin_unban'){BANS.delete(a.target);return {data:null}}
 if(name==='admin_reset_name'){const p=profiles.get(a.target);if(p)p.name='';return {data:null}}
 if(name==='admin_clear_data'){for(const k of [...docs.keys()])if(k.endsWith('|'+a.target))docs.delete(k);return {data:null}}
 if(name==='admin_dismiss'){for(let i=reports.length-1;i>=0;i--)if(reports[i].target===a.target&&reports[i].kind===a.k)reports.splice(i,1);return {data:null}}
 if(name==='admin_find'){return {data:[...profiles.values()].filter(p=>(p.name||'').toLowerCase().includes(a.q.toLowerCase())).map(p=>({id:p.id,name:p.name,registered:false,banned:BANS.has(p.id),created_at:'2026-11-12T10:00:00Z'}))}}
 if(name==='admin_leagues')return {data:[...leagues.values()].map(l=>({code:l.code,name:l.name,created_at:'2026-11-12',members:members.filter(m=>m.code===l.code).length,owner_name:(profiles.get(l.owner)||{}).name}))};
 if(name==='admin_delete_league'){leagues.delete(a.c);return {data:null}}
 if(name==='hidden_names'){const c={};reports.filter(r=>r.kind==='name').forEach(r=>{(c[r.target]=c[r.target]||new Set()).add(r.reporter)});return {data:Object.entries(c).filter(([,s])=>s.size>=3).map(([k])=>k).concat([...BANS])}}
 return {error:{message:'unknown rpc'}}}
function pushPg(table,row){for(const [cid,s] of subs){if(s.pg&&s.pg.table===table)push(cid,'pg',{eventType:'INSERT',new:row,old:{}})}}
function hub(page,st){
 if(st.op==='auth'){uidOf.set(page,st.uid);return {}}
 if(st.op==='upd'){if(st.email){for(const [e,u] of users)if(e===st.email&&u.id!==st.uid)return {error:{message:'A user with this email address has already been registered',code:'email_exists',status:422}};users.set(st.email,{id:st.uid,pw:null})}
   if(st.password){const e=[...users].find(([e,u])=>u.id===st.uid);if(!e)return {error:{message:'email not confirmed'}};e[1].pw=st.password}return {}}
 if(st.op==='login'){const u=users.get(st.email);if(!u||u.pw!==st.password)return {error:{message:'Invalid login credentials',code:'invalid_credentials',status:400}};return {uid:u.id}}
 if(st.op==='sub'){subs.set(st.cid,{page,name:st.name,pg:st.pg});if(pres[st.name])setTimeout(()=>presPush(st.name),20);return {}}
 if(st.op==='unsub'){subs.delete(st.cid);if(pres[st.name]&&st.key){delete pres[st.name][st.key];presPush(st.name)}return {}}
 if(st.op==='send'){for(const [cid,s] of subs)if(s.name===st.name)push(cid,'bc',{event:st.event,payload:st.payload});return {}}
 if(st.op==='track'){(pres[st.name]=pres[st.name]||{})[st.key]=[{...st.meta,presence_ref:'r'}];presPush(st.name);return {}}
 if(st.op==='untrack'){if(pres[st.name]){delete pres[st.name][st.key];presPush(st.name)}return {}}
 if(st.op==='rpc')return rpc(page,st.name,st.args||{});
 if(st.table==='leagues'){const me=uidOf.get(page);return {data:[...leagues.values()].filter(l=>members.some(m=>m.code===l.code&&m.id===me))}}
 if(st.table==='league_members'){const me=uidOf.get(page);const mine=new Set(members.filter(m=>m.id===me).map(m=>m.code));return {data:members.filter(m=>mine.has(m.code))}}
 if(st.table==='reports'){const me=uidOf.get(page);if(st.row.reporter!==me)return {error:{message:'rls'}};if(reports.some(r=>r.reporter===me&&r.target===st.row.target&&r.kind===st.row.kind))return {error:{code:'23505',message:'dup'}};reports.push(st.row);return {data:null}}
 const T=st.table==='docs'?docs:profiles;
 if(st.op==='upsert'){const me=uidOf.get(page)||null;if(st.row.id!==me){rls++;return {error:{message:'violates row-level security'}}}
  const key=st.table==='docs'?st.row.col+'|'+st.row.id:st.row.id;T.set(key,st.row);
  for(const [cid,s] of subs){if(!s.pg||s.pg.table!==st.table)continue;if(s.pg.filter){const [k,v]=s.pg.filter.split('=eq.');if(String(st.row[k])!==v)continue}push(cid,'pg',{eventType:'UPDATE',new:st.row,old:{}})}
  return {data:null}}
 let rows=[...T.values()];for(const [op,k,v] of st.f)rows=rows.filter(r=>op==='eq'?r[k]===v:v.includes(r[k]));
 return {data:st.single?(rows[0]||null):rows}}
(async()=>{const b=await chromium.launch();const errs=[];const log=(...a)=>console.log(...a);const U=()=>'xxxxxxxx-xxxx-4xxx-8xxx-xxxxxxxxxxxx'.replace(/x/g,()=>(Math.random()*16|0).toString(16));
const mk=async(id,W)=>{const ctx=await b.newContext({viewport:{width:W||1300,height:1000}});await ctx.exposeBinding('__hub',(src,st)=>hub(src.page,st));
 await ctx.addInitScript(id=>{localStorage.setItem('mock-sess',JSON.stringify({id}))},id);const pg=await ctx.newPage();
 pg.on('pageerror',e=>errs.push(e.message));await pg.goto('file://'+SITE+'/_t.html#all');await pg.waitForFunction(()=>typeof XC!=='undefined'&&XC.on,null,{timeout:8000});
 await pg.evaluate(()=>window.__hub({op:'auth',uid:XC.me}));await pg.waitForTimeout(1500);return pg};
const ida=U(),idb=U();global.ADMIN=ida;
const A=await mk(ida),B=await mk(idb);
const keys=await A.evaluate(()=>{const L=LIVE.football,r=L.last.find(x=>x[0]&&x[1]==="Süper Lig");return {played:xKey("football",r[0],r[3]),res:[r[4],r[5]]}});
await B.evaluate(([k,pr])=>{const P={[k]:pr};store.set('fb-preds',P);xWrite('predictions',{p:P});return XC.user.setName('Troll99')},[keys.played,keys.res]);
await A.evaluate(([k,pr])=>{const P={[k]:pr};store.set('fb-preds',P);return xWrite('predictions',{p:P})},[keys.played,keys.res]);
await A.waitForTimeout(800);await A.reload();await A.waitForFunction(()=>typeof XC!=='undefined'&&XC.on);await A.evaluate(()=>window.__hub({op:'auth',uid:XC.me}));await A.waitForTimeout(2500);
log('admin button for admin:',await A.evaluate(()=>!!$('modBtn')),'| for normal fan:',await B.evaluate(()=>!!$('modBtn')));
log('B calling admin rpc:',await B.evaluate(async()=>{const r=await FB_SITE.client().rpc('admin_ban',{target:XC.me});return r.error&&r.error.message}));
await A.evaluate(u=>document.querySelector(`#leagueBox li[data-uid="${u}"] .rflag`).click(),idb);await A.waitForTimeout(150);await A.evaluate(u=>document.querySelector(`#leagueBox li[data-uid="${u}"] .rask [data-r="y"]`).click(),idb);await A.waitForTimeout(400);
global.REG_ADD=1;REG.add(idb);REG.add(ida);await B.evaluate(()=>{const V={[Object.keys(store.get('fb-preds',{}))[0]]:'Talisca'};store.set('fb-motm',V);return xWrite('motm',{v:V})});await A.waitForTimeout(500);
await A.click('#modBtn');await A.waitForTimeout(800);log('fans tab:',await A.evaluate(()=>$('modBody').innerText.replace(/\n+/g,' | ').slice(0,500)));
await A.evaluate(u=>document.querySelector(`[data-mx="${u}"]`).click(),idb);await A.waitForTimeout(700);log('activity:',await A.evaluate(u=>$('act-'+u).innerText.replace(/\n+/g,' | '),idb));
await A.screenshot({path:path.resolve(__dirname,'../mod_fans.png')});
await A.fill('#mQ','zzz');await A.waitForTimeout(500);log('filter none:',await A.evaluate(()=>$('modBody').innerText.includes('No fans match')));await A.fill('#mQ','');await A.waitForTimeout(500);
await A.click('[data-mt="reports"]');await A.waitForTimeout(600);log('reports tab:',await A.evaluate(()=>$('modBody').innerText.replace(/\n+/g,' | ')));
await A.screenshot({path:path.resolve(__dirname,'../mod_reports.png')});
const ban=await A.$('#modBody [data-ma="ban"]');await ban.click();log('ban asks:',await A.evaluate(()=>document.querySelector('#modBody [data-ma="ban"]').textContent));await ban.click();await A.waitForTimeout(800);
log('after ban:',await A.evaluate(()=>$('modBody').innerText.replace(/\n+/g,' | ').slice(0,200)));
await A.keyboard.press('Escape');await A.waitForTimeout(300);
log('A table after ban:',await A.evaluate(()=>[...document.querySelectorAll('#leagueBox .lggrid article:first-child .ptable li .nm')].map(x=>x.textContent).join(',')));
log('B can still save?',await B.evaluate(async()=>{try{await XC.user.setName('again');return 'saved (mock has no RLS)'}catch(e){return 'blocked'}}));
await A.click('#modBtn');await A.waitForTimeout(800);log('fans after ban:',await A.evaluate(()=>$('modBody').innerText.replace(/\n+/g,' | ').slice(0,300)));
await A.click('[data-mt="leagues"]');await A.waitForTimeout(400);log('leagues tab:',await A.evaluate(()=>$('modBody').innerText.slice(0,80)));
const M=await mk(ida,375);await M.waitForTimeout(800);log('mobile header overflow:',await M.evaluate(()=>{const w=document.querySelector('.bar .wrap');return w.scrollWidth-w.clientWidth}));await M.screenshot({path:path.resolve(__dirname,'../mod_mobile.png')});
log('errs',JSON.stringify(errs));await b.close();fs.unlinkSync(SITE+'/_t.html');fs.unlinkSync(SITE+'/mocksb.js')})().catch(e=>{console.error('FAIL',e.message.slice(0,500));process.exit(1)});
