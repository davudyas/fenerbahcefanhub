/* ================= NEW SECTIONS ================= */
function xFlag(c){return esc(t(c))}
function renderSquad(p){const S=SQUADS[current];if(!S){p.innerHTML="";return}
  const coach=S.coach?`<div class="coach card"><span class="label">${t("Head coach")}</span><b>${esc(S.coach)}</b>${S.coachNote?`<p class="muted">${esc(t(S.coachNote))}</p>`:""}</div>`:"";
  const groups=(S.groups||[]).map(([g,list])=>`<section class="sqgroup"><h3 class="mh">${esc(t(g))} <span class="cnt">${list.length}</span></h3><ul class="sqlist">${list.map(([n,name,nat])=>`<li class="card"><span class="no">${n==null?"–":n}</span><span class="nm">${esc(name)}</span><span class="nat">${xFlag(nat)}</span></li>`).join("")}</ul></section>`).join("");
  p.innerHTML=`<h2>${t("Squad")}</h2><p class="intro">${esc(t(S.asof))}</p>${coach}<div class="sqgroups">${groups}</div>${(S.notes||[]).map(n=>`<p class="fine">${esc(t(n))}</p>`).join("")}`}
function renderVenue(p){const V=VENUES[current];if(!V){p.innerHTML="";return}
  const map="https://www.google.com/maps/search/?api=1&query="+encodeURIComponent(V.name+", "+V.area);
  p.innerHTML=`<h2>${t("Venue")}</h2><article class="venue card"><span class="label">${esc(t(V.area))}</span><h3>${esc(t(V.name))}</h3>${V.cap?`<p class="vcap">${esc(t(V.cap))}</p>`:""}
   <ul class="vfacts">${V.facts.map(f=>`<li>${esc(t(f))}</li>`).join("")}</ul>
   ${V.travel.length?`<h4 class="mh">${t("Getting there")}</h4><ul class="vfacts">${V.travel.map(f=>`<li>${esc(t(f))}</li>`).join("")}</ul>`:""}
   <a class="linkbtn" href="${map}" target="_blank" rel="noopener">${t("Open in Google Maps →")}</a></article>`}
function recBar(r){const tot=r.w+r.d+r.l,pc=x=>(x/tot*100).toFixed(1);
  return `<div class="rec"><span class="label">${esc(t(r.label))}</span><div class="rbar" role="img" aria-label="${esc(tf("{w} wins, {d} draws, {l} defeats",{w:r.w,d:r.d,l:r.l}))}"><i class="w" style="width:${pc(r.w)}%"></i><i class="d" style="width:${pc(r.d)}%"></i><i class="l" style="width:${pc(r.l)}%"></i></div>
   <div class="rnums"><span><b>${r.w}</b> ${t("wins")}</span><span><b>${r.d}</b> ${t("draws")}</span><span><b>${r.l}</b> ${t("defeats")}</span>${r.gf!=null?`<span>${t("Goals")} <b>${r.gf}–${r.ga}</b></span>`:""}<span class="muted">${tf("{n} games",{n:tot})}</span></div></div>`}
function renderDerbies(p){
  p.innerHTML=`<h2>${t("Derbies")}</h2><p class="intro">${t("Fenerbahçe against their three great rivals. Records come from the dated sources shown; recent meetings are listed underneath.")}</p>
  <div class="rleg"><span><i class="w"></i>${t("Fenerbahçe wins")}</span><span><i class="d"></i>${t("Draws")}</span><span><i class="l"></i>${t("Rival wins")}</span></div>
  <div class="derbies">${DERBIES.map(D=>`<article class="derby card"><span class="label">${esc(t(D.since))}</span><h3>${t("vs")} ${esc(D.opp)}</h3><p class="dname">${esc(t(D.name))}</p>
   ${recBar(D.all)}${recBar(D.league)}
   <ul class="vfacts">${D.facts.map(f=>`<li>${esc(t(f))}</li>`).join("")}</ul>
   <h4 class="mh">${t("Recent meetings")}</h4><ul class="drecent">${D.recent.map(([d,c,ha,a,b])=>{const o=a>b?"W":a<b?"L":"D";return `<li><span class="fo ${o}">${t("res:"+o)}</span><span>${mDate(d,true)} ${isoDay(d).getFullYear()}</span><span class="muted">${esc(t(c))} · ${t(ha==="H"?"Home":ha==="A"?"Away":"Neutral")}</span><b>${a}–${b}</b></li>`}).join("")}</ul></article>`).join("")}</div>
  <p class="fine src">${t("Sources:")} <a href="https://wiki.riteme.site/wiki/Intercontinental_Derby" target="_blank" rel="noopener">Intercontinental Derby (Wikipedia)</a> · <a href="https://tr.euronews.com/2026/09/05/fenerbahce-besiktas-rekabetinde-365-randevu-tarihi-derbide-rakamlar-ne-soyluyor" target="_blank" rel="noopener">Euronews</a> · <a href="https://kureansiklopedi.com/en/detay/trabzonsporfenerbahce-derby-14-february-2026-1b02f" target="_blank" rel="noopener">Küre Ansiklopedi</a></p>`}
function seasonChart(){const W=1000,H=280,L=34,R=12,T=16,B=34,N=SEASON_POS.length,maxP=10,x=i=>L+i*(W-L-R)/(N-1),y=pos=>T+(pos-1)*(H-T-B)/(maxP-1);
  const pts=SEASON_POS.map(([s,pos],i)=>[x(i),y(pos)]),line=pts.map((q,i)=>(i?"L":"M")+q[0].toFixed(1)+" "+q[1].toFixed(1)).join(" ");
  const grid=[1,2,3,5,10].map(v=>`<line x1="${L}" x2="${W-R}" y1="${y(v)}" y2="${y(v)}" class="gl"/><text x="${L-8}" y="${y(v)+4}" text-anchor="end" class="ax">${v}</text>`).join("");
  const xt=SEASON_POS.map(([s],i)=>[s,i]).filter(([s])=>/^(19[6-9]0|20[0-2]0)–/.test(s)).map(([s,i])=>`<text x="${x(i)}" y="${H-10}" text-anchor="middle" class="ax">${s.slice(0,4)}</text>`).join("");
  const dots=SEASON_POS.map(([s,pos],i)=>`<g class="pt" data-tip="${esc(s+" · "+ordL(pos))}"><circle cx="${x(i)}" cy="${y(pos)}" r="14" class="hit"/><circle cx="${x(i)}" cy="${y(pos)}" r="${pos===1?6:4}" class="${pos===1?"ch":"ot"}"/></g>`).join("");
  const titles=SEASON_POS.filter(q=>q[1]===1).length;
  return `<figure class="schart card"><figcaption><span class="label">${t("Süper Lig finish, every season since 1959")}</span><b>${tf("{n} titles, never lower than 10th",{n:titles})}</b></figcaption>
   <div class="sleg"><span><i class="ch"></i>${t("Champions")}</span><span><i class="ot"></i>${t("Other finish")}</span></div>
   <div class="swrap"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(t("Line chart of Fenerbahçe's league position by season"))}">${grid}<path d="${line}" class="ln"/>${dots}${xt}</svg><div class="stip" hidden></div></div>
   <details><summary>${t("Show as a table")}</summary><div class="stable">${SEASON_POS.map(([s,pos])=>`<span class="${pos===1?"c":""}">${s}<b>${ordL(pos)}</b></span>`).join("")}</div></details></figure>`}
document.addEventListener("pointerover",e=>{const g=e.target.closest&&e.target.closest(".schart .pt");const wrap=e.target.closest&&e.target.closest(".swrap");if(!wrap)return;const tip=wrap.querySelector(".stip");if(!g){tip.hidden=true;return}
  const r=g.querySelector(".hit").getBoundingClientRect(),w=wrap.getBoundingClientRect();tip.textContent=g.dataset.tip;tip.hidden=false;tip.style.left=Math.min(w.width-110,Math.max(0,r.left-w.left+r.width/2-55))+"px";tip.style.top=(r.top-w.top-34)+"px"});

/* calendar links (fixtures are in Turkey time, UTC+3) */
function calLinks(n,big){if(!n||!n[0])return "";const [d,time,comp,ha,opp]=n,ttl=(ha==="H"?`Fenerbahçe – ${opp}`:`${opp} – Fenerbahçe`)+` (${t(comp)})`;
  const [Y,M,D]=d.split("-").map(Number);let g,o;const p2=v=>String(v).padStart(2,"0");
  if(time){const [h,mi]=time.split(":").map(Number),s=new Date(Date.UTC(Y,M-1,D,h-3,mi)),e=new Date(s.getTime()+2*36e5),gz=x=>x.toISOString().replace(/[-:]/g,"").replace(/\.\d{3}/,"");
    g=`https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(ttl)}&dates=${gz(s)}/${gz(e)}`;o=`https://outlook.live.com/calendar/0/deeplink/compose?subject=${encodeURIComponent(ttl)}&startdt=${s.toISOString()}&enddt=${e.toISOString()}`}
  else{const nx=new Date(Date.UTC(Y,M-1,D+1)),a=`${Y}${p2(M)}${p2(D)}`,b=`${nx.getUTCFullYear()}${p2(nx.getUTCMonth()+1)}${p2(nx.getUTCDate())}`;
    g=`https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(ttl)}&dates=${a}/${b}`;o=`https://outlook.live.com/calendar/0/deeplink/compose?subject=${encodeURIComponent(ttl)}&allday=true&startdt=${d}&enddt=${nx.toISOString().slice(0,10)}`}
  return big?`<p class="cal">${t("Add to calendar:")} <a href="${g}" target="_blank" rel="noopener">Google</a> · <a href="${o}" target="_blank" rel="noopener">Outlook</a></p>`
    :`<span class="calmini"><a href="${g}" target="_blank" rel="noopener" title="${esc(t("Add to Google Calendar"))}">+ Google</a><a href="${o}" target="_blank" rel="noopener" title="${esc(t("Add to Outlook"))}">+ Outlook</a></span>`}

/* ================= COMMUNITY (shared db) ================= */
const XC={db:null,user:null,me:null,on:false,noWrite:false,docs:{predictions:{},motm:{},scores:{},ratings:{},seasons:{},challenges:{},watch:{}},names:{},dl:null};
const xKey=(b,d,opp)=>`${b}|${d}|${opp}`;
async function initCommunity(){try{if(!window.claude||!window.claude.use)return;
  claude.use("downloads").then(d=>{XC.dl=d;if(!d)return;if(current==="home")render();else if(tab==="play"||tab==="matches")renderPanel()}).catch(()=>{});
  const [db,user]=await Promise.all([claude.use("db"),claude.use("user")]);if(!db||!user)return;const me=await user.id();if(!me)return;
  Object.assign(XC,{db,user,me,on:true});if(typeof paintLiveNotes==="function")paintLiveNotes();
  ["predictions","motm","scores","ratings","seasons","challenges","watch"].forEach(col=>db.collection(col).onSnapshot(snap=>{const m={};snap.docs.forEach(d=>{if(d.exists)m[d.id]=d.data()});XC.docs[col]=m;xNames(Object.keys(m));xRefresh()},()=>{}));
  xSyncScores()}catch(e){}finally{XC.tried=true;if(typeof paintLiveNotes==="function")paintLiveNotes()}}

async function xNames(ids){if(!XC.user)return;const need=ids.filter(i=>XC.names[i]==null);if(!need.length)return;try{const ps=await XC.user.profiles(need);need.forEach(i=>XC.names[i]=(ps[i]&&ps[i].name)||"");xRefresh()}catch(e){}}
let xName=id=>id===XC.me?t("You"):(XC.names[id]||t("A fan"));
function xRefresh(){const f=document.activeElement;if(f&&f.closest&&f.closest("#panel")&&/INPUT|SELECT/.test(f.tagName))return;if(current==="home"&&typeof fillLeague==="function"){fillLeague();return}if(typeof szLiveBoards==="function")szLiveBoards();
  if(tab==="matches"&&XM.L)xFillMatches();else if(tab==="play"&&playSel[current]==="board")renderPanel()}
async function xWrite(col,data){if(!XC.on||XC.noWrite)return false;try{await XC.db.doc(col+"/"+XC.me).set(data);return true}catch(e){XC.noWrite=true;return false}}
const xPreds=()=>store.get("fb-preds",{}),xVotes=()=>store.get("fb-motm",{});
function xAllDocs(col,local,field){const m={};Object.entries(XC.docs[col]).forEach(([id,d])=>m[id]=(d&&d[field])||{});m[XC.me||"me"]=local;return m}
function xResults(){const R={};Object.keys(LIVE).forEach(b=>LIVE[b].last.forEach(r=>{if(r[0])R[xKey(b,r[0],r[3])]=[+r[4],+r[5],b]}));return R}
function xPoints(pred,res){if(!pred||!res)return null;const [a,b]=pred,[x,y]=res,sg=v=>Math.sign(v);if(a===x&&b===y)return 3;return sg(a-b)===sg(x-y)?1:0}
function xTable(){const R=xResults(),all=xAllDocs("predictions",xPreds(),"p");return Object.entries(all).map(([id,p])=>{let pts=0,n=0,ex=0;Object.entries(p).forEach(([k,v])=>{const s=xPoints(v,R[k]);if(s!=null){n++;pts+=s;if(s===3)ex++}});return {id,pts,n,ex}}).filter(r=>r.n>0).sort((a,b)=>b.pts-a.pts||b.ex-a.ex)}
let XM={L:null,nx:null};
function xMatchesExtras(L,nx){XM={L,nx};xFillMatches()}
function xFillMatches(){xFillPred();xFillComm()}
function xFillPred(){const el=document.getElementById("predBox"),nx=XM.nx;if(!el||!nx||!nx[0])return;
  const key=xKey(current,nx[0],nx[4]),[Y,M,D]=nx[0].split("-").map(Number),[h,mi]=(nx[1]||"12:00").split(":").map(Number),closed=Date.now()>=Date.UTC(Y,M-1,D,h-3,mi);
  const mine=xPreds()[key],home=nx[3]==="H",fbLab="Fenerbahçe",opLab=nx[4];
  const all=xAllDocs("predictions",xPreds(),"p"),list=Object.values(all).map(p=>p[key]).filter(Boolean);
  let crowd="";if(list.length){const cnt={};list.forEach(([a,b])=>{const k=a+"–"+b;cnt[k]=(cnt[k]||0)+1});const top=Object.entries(cnt).sort((a,b)=>b[1]-a[1])[0],win=Math.round(list.filter(([a,b])=>a>b).length/list.length*100);
    crowd=`<p class="muted">${tf(list.length===1?"1 prediction so far. Most picked: {s}. {w}% expect a Fenerbahçe win.":"{n} predictions so far. Most picked: {s}. {w}% expect a Fenerbahçe win.",{n:list.length,s:"Fenerbahçe "+top[0],w:win})}</p>`}
  const inp=(id,v,lab)=>`<label class="pin"><span>${esc(lab)}</span><input id="${id}" type="number" min="0" max="${current.includes("basketball")?199:current==="volleyball"?3:20}" inputmode="numeric" value="${v==null?"":v}" ${closed?"disabled":""}></label>`;
  const pair=home?inp("pFb",mine&&mine[0],fbLab)+`<span class="dash">–</span>`+inp("pOp",mine&&mine[1],opLab):inp("pOp",mine&&mine[1],opLab)+`<span class="dash">–</span>`+inp("pFb",mine&&mine[0],fbLab);
  if(closed&&!mine&&!list.length){el.innerHTML=`<span class="label">${t("Predictions closed")}</span><p class="fine">${t("This match has kicked off.")}</p>`;return}
  el.innerHTML=`<span class="label">${t(closed?"Predictions closed":"Predict the score")}</span><div class="prow">${closed?"":pair}${closed?"":`<button class="btn" id="pSave">${t(mine?"Update":"Save")}</button>`}</div>
   ${mine?`<p class="msg good">${tf("Your prediction: Fenerbahçe {a}–{b} {o}",{a:mine[0],b:mine[1],o:opLab})}</p>`:""}${crowd}${!XC.on||XC.noWrite?`<p class="fine">${t("Saved on this device. Predictions from other fans show up when the page can share them.")}</p>`:""}`;
  const sv=document.getElementById("pSave");if(sv)sv.onclick=async()=>{const a=parseInt(document.getElementById("pFb").value,10),b=parseInt(document.getElementById("pOp").value,10);if(isNaN(a)||isNaN(b)||a<0||b<0)return;
    const P=xPreds();P[key]=[a,b];store.set("fb-preds",P);xFillPred();await xWrite("predictions",{p:P,ts:Date.now()});xFillMatches();xBadgeCheck()}}
function xFillComm(){xFillCommRaw();if(document.getElementById("commBox"))runExt("comm")}
function xFillCommRaw(){const el=document.getElementById("commBox");if(!el)return;const L=XM.L,last=L.last.find(r=>r[0]),S=SQUADS[current];let motm="";const names=motmNames(current);
  if(last){const key=xKey(current,last[0],last[3]),mine=xVotes()[key];
    const all=xAllDocs("motm",xVotes(),"v"),cnt={};Object.values(all).forEach(v=>{if(v[key]&&!modBad(v[key]))cnt[v[key]]=(cnt[v[key]]||0)+1});const tot=Object.values(cnt).reduce((a,b)=>a+b,0),top=Object.entries(cnt).sort((a,b)=>b[1]-a[1]).slice(0,5);
    motm=`<article class="card commcard"><span class="label">${t("Player of the match")}</span><h3>${tf("Fenerbahçe {a}–{b} {o}",{a:last[4],b:last[5],o:last[3]})}</h3><p class="muted">${mDate(last[0])} · ${esc(t(last[1]))}</p>
     ${mine?`<p class="msg good">${tf("You voted for {p}.",{p:esc(mine)})}</p>`:`<div class="prow"><select id="mSel" aria-label="${t("Player of the match")}"><option value="">${t("Choose a player…")}</option>${names.map(n=>`<option>${esc(n)}</option>`).join("")}<option value="__other">${t("Someone else…")}</option></select><input id="mOther" maxlength="40" placeholder="${t("Player name")}" aria-label="${t("Player name")}" hidden><button class="btn" id="mVote">${t("Vote")}</button></div>`}
     ${tot?`<ol class="tally">${top.map(([n,c])=>`<li><span>${esc(n)}</span><i style="width:${Math.max(6,c/tot*100)}%"></i><b>${c}</b></li>`).join("")}</ol>`:`<p class="fine">${t("No votes yet. Be the first to pick the player of the match.")}</p>`}</article>`}
  const rows=xTable();xNames(rows.map(r=>r.id).filter(i=>i!=="me"));
  const table=`<article class="card commcard"><span class="label">${t("Predictor table")}</span><h3>${t("Who reads the game best?")}</h3><p class="muted">${t("3 points for the exact score, 1 for the right result.")}</p>
   ${rows.length?`<ol class="ptable">${rows.slice(0,10).map((r,i)=>`<li class="${r.id===XC.me||r.id==="me"?"me":""}" data-uid="${esc(r.id)}"><span class="rk">${i+1}</span><span class="nm">${esc(r.id==="me"?t("You"):xName(r.id))}</span><span class="muted">${tf("{n} scored",{n:r.n})}</span><b>${r.pts}</b></li>`).join("")}</ol>`:`<p class="fine">${t("Points appear once a predicted match has been played.")}</p>`}</article>`;
  el.innerHTML=`<div class="comm">${motm}${table}</div>`;
  const ms=document.getElementById("mSel"),mo=document.getElementById("mOther");if(ms&&mo)ms.onchange=()=>{mo.hidden=ms.value!=="__other";if(!mo.hidden)mo.focus()};
  const mv=document.getElementById("mVote");if(mv)mv.onclick=async()=>{let v=ms.value;if(v==="__other")v=mo.value.trim().replace(/\s+/g," ").slice(0,40);if(!v)return;if(modBad(v)){xToast(t("Please keep it friendly. Pick another name."));return}const key=xKey(current,last[0],last[3]),V=xVotes();V[key]=v;store.set("fb-motm",V);xFillComm();await xWrite("motm",{v:V,ts:Date.now()});xFillComm();xBadgeCheck()}}

/* scores for the leaderboard */
const BRS=["football","basketball","womens-basketball","volleyball"];
function xCollect(){const o=xCollectRaw();runExt("collect",o);return o}
function xCollectRaw(){const mx=f=>Math.max(0,...BRS.map(f));
  return {daily:store.get("fb-daily-stats",{max:0}).max||0,fenerdle:mx(b=>store.get(SK(b,"wd-stats"),{max:0}).max||0),hol:store.get("fb-hol-best",0),gts:store.get("fb-gts-best",0),
   tl:Math.max(mx(b=>store.get(SK(b,"tl"),0)),store.get(SK("more","tl"),0)),who:mx(b=>store.get(SK(b,"who"),0)),ft:Math.max(store.get(SK("basketball","ft"),0),store.get(SK("womens-basketball","ft"),0)),sv:store.get("fb-volleyball-sv",0),pk:store.get("fb-pk-wins",0)}}
let xLastSync="",xSyncT=null;
function xSyncScores(){clearTimeout(xSyncT);xSyncT=setTimeout(()=>{if(!XC.on||XC.noWrite)return;const s=xCollect(),j=JSON.stringify(s);if(j===xLastSync)return;xLastSync=j;xWrite("scores",{s,ts:Date.now()})},1500)}
const BOARDS=[["daily","Daily Mix · best streak"],["fenerdle","Fenerdle · best streak"],["hol","Higher or Lower · best run"],["gts","Guess the Score · best"],["tl","Timeline · record"],["who","Who Am I? · best"],["ft","Free Throws · best"],["sv","Serve · best"],["pk","Shootouts won"],["pred","Predictor points"]];
function gBoard(el){const mine=xCollect(),tbl=xTable();let sel=store.get("fb-board","daily");if(!BOARDS.some(b=>b[0]===sel))sel="daily";
  let rows;if(sel==="pred")rows=tbl.map(r=>({id:r.id,v:r.pts}));else{const m={};Object.entries(XC.docs.scores).forEach(([id,d])=>{const v=d&&d.s&&d.s[sel];if(typeof v==="number"&&v>0)m[id]=v});m[XC.me||"me"]=mine[sel]||0;rows=Object.entries(m).map(([id,v])=>({id,v})).filter(r=>r.v>0)}
  rows.sort((a,b)=>b.v-a.v);xNames(rows.map(r=>r.id).filter(i=>i!=="me"));
  el.innerHTML=`<h2>${t("Leaderboard")}</h2><p class="intro">${t(XC.on?"Best scores from fans who have played on this page. Your bests are shared automatically when you play.":"Your own best scores. Other fans' scores appear here when the page can share them, for example for people you invite to the artifact.")}</p>
   <div class="filter" role="group" aria-label="${t("Board")}">${BOARDS.map(([k,l])=>`<button data-bd="${k}" aria-pressed="${k===sel}">${esc(t(l))}</button>`).join("")}</div>
   ${rows.length?`<ol class="ptable big">${rows.slice(0,15).map((r,i)=>`<li class="${r.id===XC.me||r.id==="me"?"me":""}" data-uid="${esc(r.id)}"><span class="rk">${i+1}</span><span class="nm">${esc(r.id==="me"?t("You"):xName(r.id))}</span><b>${r.v}</b></li>`).join("")}</ol>${XC.dl?`<div class="btns"><button class="btn ghost sm" id="bdShare">${t("Save the board as an image")}</button></div>`:""}`
     :`<div class="empty"><p>${t("Nobody is on this board yet. Play a round and be the first.")}</p>${BOARD_GAME[sel]&&PLAY[current].some(x=>x[0]===BOARD_GAME[sel])?`<button class="btn" data-bdplay="${BOARD_GAME[sel]}">${t("Play now")}</button>`:""}</div>`}
   <p class="livenote" data-livenote></p>`;
  el.querySelectorAll("[data-bd]").forEach(b=>b.onclick=()=>{store.set("fb-board",b.dataset.bd);rerender()});
  const bp=el.querySelector("[data-bdplay]");if(bp)bp.onclick=()=>{playSel[current]=bp.dataset.bdplay;store.set("fb-playsel",playSel);renderPanel()};
  const sh=el.querySelector("#bdShare");if(sh)sh.onclick=e=>xShare({title:t("Leaderboard"),sub:t(BOARDS.find(x=>x[0]===sel)[1]),rows:rows.slice(0,8).map((r,i)=>[i+1,r.id==="me"?t("You"):xName(r.id),r.v])},e.currentTarget);
  if(typeof paintLiveNotes==="function")paintLiveNotes()}
const BOARD_GAME={daily:"daily",fenerdle:"wordle",hol:"hol",gts:"gts",tl:"timeline",who:"who",ft:"ft",sv:"serve",pk:"penalties"};

/* ================= BADGES ================= */
const BADGES=[
 ["fenerdle1","First Fenerdle","Solve a daily Fenerdle.",()=>BRS.some(b=>store.get(SK(b,"wd-stats"),{wins:0}).wins>0)],
 ["fenerdle5","On a roll","Reach a Fenerdle streak of 5.",()=>BRS.some(b=>(store.get(SK(b,"wd-stats"),{max:0}).max||0)>=5)],
 ["quiz","Perfect quiz","Get every question right in a quiz.",()=>Object.keys(SPORTS).some(b=>store.get(SK(b,"quiz"),0)>=SPORTS[b].quiz.length)],
 ["who","Encyclopedia","Score 30 or more in Who Am I?",()=>BRS.some(b=>store.get(SK(b,"who"),0)>=30)],
 ["tl","Historian","Set a Timeline record of 10 or more.",()=>[...BRS,"more"].some(b=>store.get(SK(b,"tl"),0)>=10)],
 ["xi","All eleven","Name a whole XI with three stars.",()=>Object.values(store.get("fb-xi3",{})).some(v=>v.stars>=3)],
 ["cup","Champions!","Win the Süper Lig in a simulated season with your XI.",()=>store.get("fb-cups",0)>0],
 ["ff","Champions of Europe","Win a European trophy in a simulated season.",()=>Object.keys(SPORTS).some(b=>store.get(SK(b,"cups"),0)>0)],
 ["pk","Ice cold","Win a penalty shootout.",()=>store.get("fb-pk-wins",0)>0],
 ["ft","Sharpshooter","Score 20 or more at the free-throw line.",()=>Math.max(store.get(SK("basketball","ft"),0),store.get(SK("womens-basketball","ft"),0))>=20],
 ["sv","Ace machine","Score 24 or more serving.",()=>store.get("fb-volleyball-sv",0)>=24],
 ["daily","Daily habit","Play the Daily Mix three days in a row.",()=>(store.get("fb-daily-stats",{max:0}).max||0)>=3],
 ["dailyp","Full marks","Get 5 out of 5 in a Daily Mix.",()=>store.get("fb-daily-perfect",0)>0],
 ["hol","Higher and higher","Reach a run of 10 in Higher or Lower.",()=>store.get("fb-hol-best",0)>=10],
 ["gts","Score whisperer","Guess 3 exact scores in Guess the Score.",()=>store.get("fb-gts-exact",0)>=3],
 ["pred","Prophet","Predict the score of an upcoming match.",()=>Object.keys(xPreds()).length>0],
 ["motm","Fan's voice","Vote for a player of the match.",()=>Object.keys(xVotes()).length>0]];
function xBadgeCheck(){const seen=store.get("fb-badges",[]),now=BADGES.filter(b=>{try{return b[3]()}catch(e){return false}}).map(b=>b[0]),fresh=now.filter(id=>!seen.includes(id));
  if(fresh.length){store.set("fb-badges",[...new Set([...seen,...fresh])]);const b=BADGES.find(x=>x[0]===fresh[0]);xToast("🏅 "+tf("Badge unlocked: {b}",{b:t(b[1])}))}}
function xToast(msg){let el=document.getElementById("toast");if(!el){el=document.createElement("div");el.id="toast";el.setAttribute("role","status");document.body.appendChild(el)}el.textContent=msg;el.classList.add("on");clearTimeout(el._t);el._t=setTimeout(()=>el.classList.remove("on"),3200)}
function gBadges(el){const got=BADGES.filter(b=>{try{return b[3]()}catch(e){return false}}).map(b=>b[0]);
  el.innerHTML=`<h2>${t("Badges")}</h2><p class="intro">${tf("{n} of {m} unlocked. Badges are kept in this browser.",{n:got.length,m:BADGES.length})}</p>
   <div class="badges">${BADGES.map(([id,n,d])=>`<div class="badge card ${got.includes(id)?"on":""}"><span class="medal" aria-hidden="true">${got.includes(id)?"★":"☆"}</span><b>${esc(t(n))}</b><span>${esc(t(d))}</span></div>`).join("")}</div>`}

/* ================= HIGHER OR LOWER ================= */
let hol=null;




/* ================= GUESS THE SCORE ================= */
function gtsPool(){const out=[],sc=s=>{const m=String(s).match(/^(\d+)–(\d+)$/);return m?[+m[1],+m[2]]:null};
  ["football","basketball","volleyball","womens-football","mens-volleyball"].forEach(b=>SPORTS[b].games.forEach(g=>{const r=sc(g.res);if(r&&g.date.length>=7)out.push({b,date:g.date,comp:g.comp,home:g.home,away:g.away,hs:r[0],as:r[1],where:g.where,note:g.note})}));
  DERBIES.forEach(D=>D.recent.forEach(([d,c,ha,a,b])=>{const fbH=ha!=="A";out.push({b:"football",date:d,comp:c,home:fbH?"Fenerbahçe":D.opp,away:fbH?D.opp:"Fenerbahçe",hs:fbH?a:b,as:fbH?b:a})}));
  ["football","basketball"].forEach(b=>LIVE[b].last.forEach(r=>{if(!r[0])return;const fbH=r[2]!=="A";out.push({b,date:r[0],comp:r[1],home:fbH?"Fenerbahçe":r[3],away:fbH?r[3]:"Fenerbahçe",hs:fbH?+r[4]:+r[5],as:fbH?+r[5]:+r[4],note:r[6]})}));
  const seen=new Set();return out.filter(x=>{const k=x.date+x.home+x.away;if(seen.has(k))return false;seen.add(k);return true})}
let gts=null;




/* ================= DAILY MIX ================= */
function mulberry(a){return()=>{a|=0;a=a+0x6D2B79F5|0;let t2=Math.imul(a^a>>>15,1|a);t2=t2+Math.imul(t2^t2>>>7,61|t2)^t2;return((t2^t2>>>14)>>>0)/4294967296}}
function dailySet(day){const r=mulberry(day*9973),pick=a=>a[Math.floor(r()*a.length)],sh=a=>{a=[...a];for(let i=a.length-1;i>0;i--){const j=Math.floor(r()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};const Q=[];
  const br=pick(Object.keys(SPORTS)),qq=pick(SPORTS[br].quiz);Q.push({kind:"quiz",tag:SPORTS[br].label,q:qq.q,o:qq.o,a:qq.o[qq.a]});
  const ev=pick(CLUB_EVENTS),yrs=new Set([ev[0]]);while(yrs.size<4){const d=Math.floor(r()*30)-15;if(d)yrs.add(ev[0]+d)}Q.push({kind:"year",tag:"Club history",ev:ev[1],o:[...yrs].sort((a,b)=>a-b).map(String),a:String(ev[0])});
  const set=pick(HOL_SETS);let A=pick(set.items),B=pick(set.items);let g=0;while((B[0]===A[0]||B[1]===A[1])&&g++<50)B=pick(set.items);Q.push({kind:"hol",tag:"Records",label:set.label,o:[A[0],B[0]],a:A[1]>B[1]?A[0]:B[0]});
  const f=pick(BR_FACTS);Q.push({kind:"which",tag:"Which branch?",q:f[0],o:sh([f[1],...sh(BR_NAMES.filter(x=>x!==f[1])).slice(0,3)]),a:f[1]});
  const gm=pick(gtsPool().filter(x=>x.b!=="basketball")),ok=`${gm.hs}–${gm.as}`,alts=new Set([ok]);let k=0;while(alts.size<4&&k++<60){const h=Math.max(0,gm.hs+Math.floor(r()*5)-2),a=Math.max(0,gm.as+Math.floor(r()*5)-2);alts.add(`${h}–${a}`)}
  Q.push({kind:"score",tag:"Results",home:gm.home,away:gm.away,comp:gm.comp,year:gm.date.slice(0,4),o:sh([...alts]),a:ok});return Q}
function dQ(q){if(q.kind==="quiz")return t(q.q);if(q.kind==="year")return tf("In which year: {e}?",{e:t(q.ev)});if(q.kind==="hol")return tf("Who has more {l}?",{l:t(q.label)});if(q.kind==="which")return t(q.q);return tf("{h} vs {a}, {c} {y}. What was the score?",{h:q.home,a:q.away,c:t(q.comp),y:q.year})}
let dlS=null;
function gDaily(el){const day=localDay();if(!dlS||dlS.day!==day){const sv=store.get("fb-daily-"+day,null);dlS={day,Q:dailySet(day),ans:sv?sv.ans:[]}}const S=dlS,N=S.Q.length,i=S.ans.length,score=S.ans.filter((a,k)=>a===S.Q[k].a).length;
  const st=store.get("fb-daily-stats",{last:null,streak:0,max:0,played:0});
  if(i>=N){el.innerHTML=`<h2>${t("Daily Mix")}</h2><div class="quiz"><span class="label">${tf("Today's mix · #{n}",{n:day-DAY0+1})}</span><div class="final">${score}/${N}</div>
     <p class="gnote">${tf("Streak: {s} days · Best streak: {m}",{s:st.streak,m:st.max})}</p><ol class="dlres">${S.Q.map((q,k)=>`<li class="${S.ans[k]===q.a?"ok":"no"}"><span>${S.ans[k]===q.a?"✓":"✗"}</span>${esc(dQ(q))} <b>${esc(t(q.a))}</b></li>`).join("")}</ol><p class="gnote">${t("A new mix arrives at midnight.")}</p></div>`;return}
  const q=S.Q[i],picked=S.pick;
  el.innerHTML=`<h2>${t("Daily Mix")}</h2><p class="intro">${t("Five questions from across the whole club, the same for everyone today. Keep your streak going by playing every day.")}</p>
   <div class="quiz"><div class="top"><span class="label">${tf("Question {i} of {n}",{i:i+1,n:N})} · ${esc(t(q.tag))}</span><span class="label">${tf("Streak {n}",{n:st.streak})}</span></div><div class="progress"><i style="width:${i/N*100}%"></i></div>
   <h3>${esc(dQ(q))}</h3><div class="opts">${q.o.map(o=>`<button class="opt" data-do="${esc(o)}">${esc(t(o))}</button>`).join("")}</div></div>`;
  el.querySelectorAll("[data-do]").forEach(b=>b.onclick=()=>{S.ans.push(b.dataset.do);store.set("fb-daily-"+day,{ans:S.ans});
    if(S.ans.length>=N){const s=S.ans.filter((a,k)=>a===S.Q[k].a).length,ST=store.get("fb-daily-stats",{last:null,streak:0,max:0,played:0});if(ST.last!==day){ST.streak=ST.last===day-1?ST.streak+1:1;ST.max=Math.max(ST.max,ST.streak);ST.played++;ST.last=day;store.set("fb-daily-stats",ST)}if(s===N)store.set("fb-daily-perfect",1);xSyncScores();xBadgeCheck()}
    const ok=b.dataset.do===q.a;b.classList.add(ok?"right":"wrong");if(!ok){const r=[...el.querySelectorAll("[data-do]")].find(x=>x.dataset.do===q.a);if(r)r.classList.add("right")}el.querySelectorAll("[data-do]").forEach(x=>x.disabled=true);setTimeout(rerender,900)})}

/* ================= SHARE IMAGES ================= */
function xResultFor(g){for(const f of EXT.result){const r=f(g);if(r!==undefined)return r}return xResultForRaw(g)}
function xResultForRaw(g){const b=current;try{
  if(g==="quiz"){const s=quizS[b],q=SPORTS[b].quiz;if(s&&s.i>=q.length)return{title:t("Quiz"),big:`${s.score}/${q.length}`}}
  if(g==="wordle"){const w=wdS[b];if(w&&w.done)return{title:"Fenerdle"+(w.daily?" #"+w.num:""),big:w.won?`${w.rows.length}/6`:"X/6",grid:w.rows.map(r=>scoreGuess(r,w.ans))}}
  if(g==="who"){const w=whoS[b];if(w&&w.i>=w.q.length)return{title:t("Who Am I?"),big:`${w.score}/${w.q.length*4}`}}
  if(g==="timeline"){const x=tlS[b];if(x&&x.over)return{title:t(TLCFG[b].title),big:String(x.score),sub:t("points")}}
  if(g==="xi"&&xi&&xi.ended)return{title:t("Name the XI")+" · "+seasonLabel(xi.id),big:`${xi.found.size}/11`};
  if(g==="penalties"&&pk&&pk.over)return{title:t("Penalty Shootout"),big:`${pk.you.filter(Boolean).length}–${pk.them.filter(Boolean).length}`,sub:t(pk.over==="win"?"Fenerbahçe win the shootout!":"The opponents win this one.")};
  if(["draft","draft5","draft6","draft11"].includes(g)&&szS[b]&&szS[b].S&&szS[b].S.done){const S=szS[b].S,tro=szTrophies(S);return{title:tf("Season {s}",{s:szDash(S.season)}),big:tro.length?`${tro.length} 🏆`:"0",sub:tro.length?tro.map(x=>t(x)).join(" · "):t("No trophies this time")}}
  if(g==="ft"&&ftS[b]&&ftS[b].phase==="over")return{title:t("Free Throws"),big:String(ftS[b].score),sub:t("points")};
  if(g==="serve"&&svS.v&&svS.v.phase==="over")return{title:t("Serve"),big:`${svS.v.score}/36`};
  if(g==="which"&&whS&&whS.i>=10)return{title:t("Which Branch?"),big:`${whS.score}/10`};
  if(g==="daily"&&dlS&&dlS.ans.length>=dlS.Q.length)return{title:t("Daily Mix")+" #"+(dlS.day-DAY0+1),big:`${dlS.ans.filter((a,k)=>a===dlS.Q[k].a).length}/5`};
  if(g==="hol"&&hol&&hol.over)return{title:t("Higher or Lower"),big:String(hol.streak),sub:t("run")};
  if(g==="gts"&&gts&&gts.i>=gts.items.length)return{title:t("Guess the Score"),big:`${gts.score}/${gts.items.length*3}`}}catch(e){}return null}
function xCard(r){const c=document.createElement("canvas"),S=1080;c.width=S;c.height=S;const x=c.getContext("2d"),cs=getComputedStyle(document.documentElement),Y=cs.getPropertyValue("--yellow").trim()||"#ffe500",N1="#0b1a3d",N2="#050d22",INK="#f3f6ff",MU="#9fb0d6",DISP='"Big Shoulders Display", "Barlow Condensed", Arial Narrow, sans-serif';
  const gr=x.createLinearGradient(0,0,0,S);gr.addColorStop(0,N1);gr.addColorStop(1,N2);x.fillStyle=gr;x.fillRect(0,0,S,S);
  for(let i=0;i<S;i+=88){x.fillStyle=Y;x.fillRect(i,0,44,14);x.fillRect(i+44,S-14,44,14)}
  x.fillStyle=Y;x.font=`900 64px ${DISP}`;x.fillText("FENERBAHÇE",80,150);x.fillStyle=MU;x.font=`600 30px "Barlow Condensed", Arial, sans-serif`;x.fillText(t("Fan Hub").toUpperCase(),82,195);
  x.fillStyle=INK;x.font=`800 64px ${DISP}`;x.fillText(r.title.toUpperCase().slice(0,30),80,330);
  if(r.rows){if(r.sub){x.fillStyle=MU;x.font=`600 34px "Barlow", Arial, sans-serif`;x.fillText(r.sub.slice(0,60),80,385)}
    r.rows.slice(0,8).forEach(([rk,nm,v],i)=>{const y=480+i*68;x.fillStyle=i===0?Y:MU;x.font=`900 46px ${DISP}`;x.fillText(String(rk),80,y);x.fillStyle=INK;x.font=`600 40px "Barlow", Arial, sans-serif`;let n=String(nm);while(x.measureText(n).width>640&&n.length>4)n=n.slice(0,-2);x.fillText(n===String(nm)?n:n+"…",160,y);
      x.fillStyle=Y;x.font=`900 50px ${DISP}`;x.textAlign="right";x.fillText(String(v),S-80,y);x.textAlign="left";x.fillStyle="rgba(255,255,255,.08)";x.fillRect(80,y+22,S-160,2)})}
  else if(r.grid){const n=r.grid[0]?r.grid[0].length:5,sz=Math.min(64,Math.floor(760/n)),col={correct:Y,present:"#3d6fe0",absent:"#25324f"};r.grid.forEach((row,i)=>row.forEach((s,j)=>{x.fillStyle=col[s];x.fillRect(80+j*(sz+8),400+i*(sz+8),sz,sz)}));x.fillStyle=Y;x.font=`900 150px ${DISP}`;x.fillText(r.big,80,960)}
  else{x.fillStyle=Y;x.font=`900 300px ${DISP}`;x.fillText(r.big,74,700);if(r.sub){x.fillStyle=INK;x.font=`600 44px "Barlow", Arial, sans-serif`;wrapText(x,r.sub,80,790,920,54)}}
  x.fillStyle=MU;x.font=`600 30px "Barlow Condensed", Arial, sans-serif`;x.fillText(fmtDay(new Date(),{day:"numeric",month:"long",year:"numeric"}),80,S-60);return c}
function wrapText(x,s,X,Y,w,lh){const words=s.split(" ");let line="",y=Y;words.forEach(wd=>{const tt=line?line+" "+wd:wd;if(x.measureText(tt).width>w&&line){x.fillText(line,X,y);line=wd;y+=lh}else line=tt});if(line)x.fillText(line,X,y)}
async function xShare(r,btn){if(!XC.dl)return;btn.disabled=true;try{const c=xCard(r);const blob=await new Promise(res=>c.toBlob(res,"image/png"));await XC.dl.save({filename:"fenerbahce-"+(r.title.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"")||"result")+".png",data:blob})}catch(e){}btn.disabled=false}
