/* ===== Keeping it friendly: a word filter for fan names, chat, write-in votes and league names =====
   Matching works on a simplified form of the text: lower case, Turkish/accented letters folded, look-alike digits
   turned back into letters and repeated letters squeezed ("fuuuck" -> "fuck"). Words marked "=" must be a whole word,
   "^" must start a word, "*" may appear anywhere (only for long, unmistakable words, so normal words aren't caught). */
const MOD_WORDS=(()=>{const L={
  "=":"amk aq oç sik yarak yarrak kahpe gavat puşt pust kaltak sürtük surtuk ibne şerefsiz serefsiz cock twat slut whore fag fags cunt shit bitch bitches bastard asshole wanker nigger niggers nigga niggas faggot faggots neger spast kike spic chink paki tranny nazi puta puto pute putain salope connard connasse joder mierda cabron cabrón gilipollas maricon maricón pendejo fdp hdp fick ficken ficker fotze nique niquer zob زب كس عرص خول قحبة شرموط شرموطة منيوك",
  "^":"fuck sikt siker sikey sikiy sikis sikiş sikim amcik amcık orosp oruspu pezeven scheis scheiß arschloch hurens wichs schlamp schwuchtel missgeb encul batard bâtard shitt motherf",
  "*":"fuck faggot motherfuck orospu siktir sikerim sikeyim aminakoy pezevenk hurensohn wichser"};
  const out={"=":[],"^":[],"*":[]};Object.entries(L).forEach(([m,s])=>s.split(/\s+/).filter(Boolean).forEach(w=>{const n=modNorm(w);if(n)out[m].push({n,sq:modSq(n)===n})}));return out})();
/* lower case, folded letters and look-alike digits; modSq also squeezes repeated letters */
function modNorm(s){return String(s||"").toLocaleLowerCase("tr").replace(/i̇/g,"i")
  .replace(/[ıİ]/g,"i").replace(/ş/g,"s").replace(/ğ/g,"g").replace(/ç/g,"c").replace(/[öô]/g,"o").replace(/[üû]/g,"u").replace(/[àâä]/g,"a").replace(/[éèêë]/g,"e").replace(/[îï]/g,"i").replace(/ñ/g,"n").replace(/ß/g,"ss")
  .replace(/0/g,"o").replace(/1/g,"i").replace(/3/g,"e").replace(/4/g,"a").replace(/5/g,"s").replace(/7/g,"t").replace(/@/g,"a").replace(/\$/g,"s")}
function modSq(n){return n.replace(/([\p{L}])\1+/gu,"$1")}
/* true if the text contains a word from the list. Words with double letters (like "nigger") are only matched as written,
   so squeezing never turns them into ordinary words (like "Niger") */
function modBad(s){const n0=modNorm(s);if(!n0)return false;const T0=n0.split(/[^\p{L}]+/u).filter(Boolean),T1=T0.map(modSq);
  const hit=(toks,useSq)=>{const ok=e=>useSq?e.sq:true;if(toks.some(w=>MOD_WORDS["="].some(e=>ok(e)&&w===e.n)||MOD_WORDS["^"].some(e=>ok(e)&&w.startsWith(e.n))))return true;
    const j=toks.join("");return MOD_WORDS["*"].some(e=>ok(e)&&j.includes(e.n))};
  return hit(T0,false)||hit(T1,true)}
/* the same text with offending words replaced by asterisks */
function modClean(s){s=String(s||"");if(!modBad(s))return s;
  const out=s.split(/(\s+)/).map(p=>/^\s+$/.test(p)||!modBad(p)?p:p.replace(/\S/g,"*")).join("");return modBad(out)?out.replace(/\S/g,"*"):out}

/* names: an offensive fan name shows as "A fan" everywhere */
{const _xn=xName;xName=id=>{const n=_xn(id);return n&&id!==XC.me&&modBad(n)?t("A fan"):n}}
{const _rn=rtName;rtName=p=>{const n=_rn(p);return n&&!(p&&p.isMe)&&modBad(n)?t("A fan"):n}}
