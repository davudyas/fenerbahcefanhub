const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const pg=await b.newPage({viewport:{width:1280,height:900}});const errs=[];pg.on('pageerror',e=>errs.push(e.message));
await pg.goto('file://'+process.cwd()+'/fenerbahce.html#volleyball');await pg.waitForTimeout(300);
for(const th of ['day','canary']){await pg.selectOption('#theme',th);await pg.evaluate(()=>{tab='trophies';render()});await pg.waitForTimeout(150);await pg.locator('.tlchart').screenshot({path:`../u_${th}_chart.png`})}
await pg.evaluate(()=>{setSport('home')});await pg.waitForTimeout(150);await pg.screenshot({path:'../u_canary_home.png'});
console.log(errs);await b.close()})();
