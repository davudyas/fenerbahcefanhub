module.exports=async function gzAuto(pg,shot){
  await pg.evaluate(()=>{window.GZ_FAST=1});
  if(await pg.$('[data-gz="form"]')){await pg.click('[data-gz="form"]');await pg.waitForSelector('[data-gz="season"]',{timeout:5000})}
  for(let k=0;k<60;k++){
    if(await pg.$('#cupBox'))return k;
    if(await pg.$('[data-gz="season"]')){await pg.click('[data-gz="season"]');await pg.waitForSelector('.gzsq',{timeout:5000});if(shot&&k===0)await shot();continue}
    if(await pg.$('[data-gz="free"]')){await pg.click('[data-gz="free"]');await pg.waitForSelector('.gzsq',{timeout:5000});continue}
    const b=await pg.$('.gzp:not([disabled])');if(!b)throw new Error('stuck');await b.click();await pg.waitForTimeout(30);
    const f=await pg.$('.ps.fit');if(f){await f.click();await pg.waitForTimeout(30)}
  }throw new Error('no finish')};
