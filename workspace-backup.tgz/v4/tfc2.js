const {chromium}=require('playwright');const fs=require('fs');
const K=JSON.parse(fs.readFileSync('../gz_keys.json','utf8'));
(async()=>{const b=await chromium.launch();const pg=await b.newPage();const errs=[];pg.on('pageerror',e=>errs.push(e.message));await pg.goto('file://'+process.cwd()+'/fenerbahce.html');await pg.waitForTimeout(300);
for(const L of ['tr','de','es','fr','ar']){await pg.selectOption('#lang',L);await pg.waitForTimeout(400);
 const miss=await pg.evaluate(K=>K.filter(s=>t(s)===s),K);console.log(L,JSON.stringify(miss))}
console.log(errs);await b.close()})();
