const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const F='file://'+process.cwd()+'/fenerbahce.html';
for(const [w,h,tag] of [[1280,900,'d'],[390,844,'m']]){
const pg=await b.newPage({viewport:{width:w,height:h}});const errs=[];pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error'&&!m.text().includes('ERR_'))errs.push(m.text())});
const go=async(br,tb)=>{await pg.evaluate(([br,tb])=>{setSport(br);if(tb){tab=tb;render()}},[br,tb]);await pg.waitForTimeout(120)};
const sh=async n=>{await pg.screenshot({path:`../u_${tag}_${n}.png`,fullPage:false})};
const shPanel=async n=>{const el=await pg.$('#panel');await el.screenshot({path:`../u_${tag}_${n}.png`})};
await pg.goto(F);await pg.waitForTimeout(500);await sh('home');
await pg.evaluate(()=>document.getElementById('panel').scrollIntoView());await sh('home2');
for(const br of ['football','basketball','womens-basketball','volleyball','mens-volleyball','womens-football']){await go(br);await pg.evaluate(()=>scrollTo(0,0));await sh('hero_'+br)}
await go('football','trophies');await shPanel('troph');
await go('basketball','trophies');await shPanel('trophbb');
await go('football','derbies');await shPanel('derby');
await go('football','legends');await shPanel('leg');
await pg.click('.legend2 .lname');await pg.waitForTimeout(150);await sh('pp');
await pg.keyboard.press('Escape');
await pg.click('#hSearch');await pg.waitForTimeout(100);await pg.fill('#sq','6-0');await pg.waitForTimeout(300);await sh('search60');
console.log(tag,'res 6-0',await pg.evaluate(()=>[...document.querySelectorAll('#sres b')].slice(0,6).map(x=>x.textContent)));
await pg.fill('#sq','2017 final four');await pg.waitForTimeout(300);console.log(tag,'2017ff',await pg.evaluate(()=>[...document.querySelectorAll('#sres b')].slice(0,6).map(x=>x.textContent)));
await pg.fill('#sq','alex');await pg.waitForTimeout(300);console.log(tag,'alex',await pg.evaluate(()=>[...document.querySelectorAll('#sres b')].slice(0,6).map(x=>x.textContent)));
await pg.click('#sres [data-sr]');await pg.waitForTimeout(150);await sh('ppalex');
await pg.keyboard.press('Escape');
await pg.click('#hSearch');await pg.fill('#sq','6-0');await pg.waitForTimeout(300);
await pg.evaluate(()=>{const x=[...document.querySelectorAll('#sres [data-sr]')].find(b=>/Galatasaray/.test(b.textContent));x&&x.click()});await pg.waitForTimeout(600);await sh('goto60');
console.log(tag,'after nav',await pg.evaluate(()=>[current,tab,!!document.querySelector('.flash')]));
// season mode line
await go('football','play');await pg.evaluate(()=>{playSel.football='draft';render()});await pg.waitForTimeout(100);
await pg.evaluate(()=>{const b=document.querySelector('[data-auto]')||document.querySelector('[data-dr="auto"]');b&&b.click()});
const btns=await pg.evaluate(()=>[...document.querySelectorAll('#gameArea button')].map(b=>b.dataset&&JSON.stringify(b.dataset)).filter(Boolean).slice(0,30));console.log(btns.join(' '));
console.log(tag,'errs',errs,'sw',await pg.evaluate(()=>document.documentElement.scrollWidth));await pg.close()}
await b.close()})();
