const {chromium}=require('playwright');const path=require('path');const SITE=path.resolve(__dirname,'../site');
(async()=>{const b=await chromium.launch();const ctx=await b.newContext();const C=await ctx.newPage();const e3=[];C.on('pageerror',e=>e3.push(e.message));
await ctx.route('**/*',r=>r.request().url().startsWith('file:')?r.continue():r.abort());
await C.goto('file://'+SITE+'/index.html#football-play');await C.waitForTimeout(2000);
console.log('notes',await C.evaluate(()=>[...document.querySelectorAll('[data-livenote]')].map(e=>e.dataset.livenote+': '+e.textContent)));
await C.evaluate(()=>{playSel.football='live';render()});await C.waitForTimeout(800);console.log('live:',await C.evaluate(()=>document.getElementById('panel').innerText.slice(0,400)));
await C.evaluate(()=>{current='home';render()});await C.waitForTimeout(500);console.log('home notes',await C.evaluate(()=>[...document.querySelectorAll('[data-livenote]')].map(e=>e.dataset.livenote+': '+e.textContent)));
await C.click('#setBtn');console.log('name row offline:',await C.evaluate(()=>!!document.getElementById('setName')),await C.evaluate(()=>$('setPanel').innerText.slice(0,600)));
console.log('errs',e3);await b.close()})();
