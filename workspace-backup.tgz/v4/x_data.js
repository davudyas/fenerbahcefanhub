/* ===== New content data (researched 7 November 2026) ===== */
const SEASON_POS=[["1959",1],["1959–60",2],["1960–61",1],["1961–62",2],["1962–63",3],["1963–64",1],["1964–65",1],["1965–66",4],["1966–67",2],["1967–68",1],["1968–69",4],["1969–70",1],["1970–71",2],["1971–72",3],["1972–73",2],["1973–74",1],["1974–75",1],["1975–76",2],["1976–77",2],["1977–78",1],["1978–79",3],["1979–80",2],["1980–81",10],["1981–82",3],["1982–83",1],["1983–84",2],["1984–85",1],["1985–86",5],["1986–87",5],["1987–88",8],["1988–89",1],["1989–90",2],["1990–91",5],["1991–92",2],["1992–93",5],["1993–94",2],["1994–95",4],["1995–96",1],["1996–97",3],["1997–98",2],["1998–99",3],["1999–2000",4],["2000–01",1],["2001–02",2],["2002–03",6],["2003–04",1],["2004–05",1],["2005–06",2],["2006–07",1],["2007–08",2],["2008–09",4],["2009–10",2],["2010–11",1],["2011–12",2],["2012–13",2],["2013–14",1],["2014–15",2],["2015–16",2],["2016–17",3],["2017–18",2],["2018–19",6],["2019–20",7],["2020–21",3],["2021–22",2],["2022–23",2],["2023–24",2],["2024–25",2],["2025–26",2]];

const DERBIES=[
 {opp:"Galatasaray",name:"The Intercontinental Derby",since:"First meeting: 1909",
  all:{label:"All meetings, including friendlies, as of 26 October 2026",p:407,w:150,d:125,l:132,gf:547,ga:510},
  league:{label:"Süper Lig, as of 26 October 2026",p:139,w:53,d:46,l:40,gf:166,ga:139},
  facts:["Biggest win: 6–0 at Şükrü Saracoğlu on 6 November 2002.","Galatasaray's biggest win: 7–0 in the Istanbul Football League on 12 February 1911.","Longest unbeaten run in the fixture: 18 derbies for Fenerbahçe, 1942 to 1946.","Galatasaray went more than 20 years without a league win in Kadıköy, from December 1999 to February 2020."],
  recent:[["2026-10-26","Süper Lig","A",1,2],["2026-04-26","Süper Lig","A",0,3],["2026-01-10","Super Cup final","N",2,0]]},
 {opp:"Beşiktaş",name:"The Istanbul derby with Beşiktaş",since:"First meeting: 28 November 1924, won 4–0 by Fenerbahçe",
  all:{label:"All meetings, before September 2026",p:364,w:137,d:97,l:130,gf:504,ga:463},
  league:{label:"Süper Lig, before September 2026",p:140,w:51,d:45,l:44,gf:162,ga:160},
  facts:["Beşiktaş's biggest win: 7–1 in the Dörtler tournament on 23 March 1941.","Fenerbahçe's biggest win: 7–0, a friendly on 6 December 1958.","Highest-scoring official meeting: Beşiktaş 5–4 in the TSYD Cup, 11 August 1974.","League meetings in Kadıköy: Fenerbahçe 18 wins, 15 draws, Beşiktaş 12 wins."],
  recent:[["2026-09-05","Süper Lig","H",1,2],["2026-04-05","Süper Lig","H",1,0],["2025-12-23","Turkish Cup","H",1,2]]},
 {opp:"Trabzonspor",name:"The rivalry with Trabzonspor",since:"The great rivalry of the 1970s and 1980s title races",
  all:{label:"All meetings, after February 2026",p:139,w:56,d:39,l:44,gf:184,ga:159},
  league:{label:"Süper Lig, after February 2026",p:106,w:45,d:34,l:27,gf:148,ga:113},
  facts:["A 1–1 draw with Trabzonspor on the last day of 2009–10 handed the title to Bursaspor.","Fenerbahçe won 3–2 in Trabzon on 14 February 2026.","Next meeting: 13 December 2026 in Kadıköy."],
  recent:[["2026-02-14","Süper Lig","A",3,2],["2025-09-14","Süper Lig","H",1,0],["2025-04-06","Süper Lig","H",4,1]]}];

const SQUADS={
 football:{coach:"Emre Belözoğlu",coachNote:"Signed on 3 November 2026, a week after İsmail Kartal left by mutual agreement. Assistant coach Dirk Kuyt took charge for the Göztepe and Liverpool games.",asof:"Squad list as of 3 September 2026",
  groups:[["Goalkeepers",[[31,"Ederson","Brazil"],[34,"Mert Günok","Turkey"],[13,"Tarık Çetin","Turkey"]]],
   ["Defenders",[[3,"Archie Brown","England"],[14,"Yiğit Efe Demir","Turkey"],[15,"Nathan Aké","Netherlands"],[18,"Mert Müldür","Turkey"],[21,"Kojo Peprah Oppong","Ghana"],[22,"Levent Mercan","Turkey"],[24,"Jayden Oosterwolde","Netherlands"],[27,"Nélson Semedo","Portugal"],[37,"Milan Škriniar","Slovakia"],[77,"Ognjen Mimović","Serbia"]]],
   ["Midfielders",[[5,"İsmail Yüksek","Turkey"],[6,"Mattéo Guendouzi","France"],[8,"Mert Hakan Yandaş","Turkey"],[10,"Marco Asensio","Spain"],[17,"İrfan Can Kahveci","Turkey"],[28,"Bartuğ Elmaz","Turkey"],[70,"Oğuz Aydın","Turkey"],[91,"N'Golo Kanté","France"]]],
   ["Forwards",[[7,"Kerem Aktürkoğlu","Turkey"],[9,"Romelu Lukaku","Belgium"],[11,"Mason Greenwood","England"],[19,"Vedat Muriqi","Kosovo"],[45,"Dorgeles Nene","Mali"]]]]},
 basketball:{coach:"Šarūnas Jasikevičius",asof:"Compiled from the club's 2026 signings and re-signings; may be incomplete",
  groups:[["Guards",[[0,"Shane Larkin","Turkey"],[8,"Talen Horton-Tucker","United States"],[9,"Johnny Juzang","United States"],[10,"Melih Mahmutoğlu","Turkey"],[11,"Trent Forrest","United States"],[31,"Shavon Shields","Denmark"],[43,"Ignas Sargiūnas","Lithuania"]]],
   ["Forwards",[[12,"Braxton Key","United States"],[21,"Will Clyburn","United States"],[30,"Chris Silva","Gabon"]]],
   ["Bigs",[[1,"Marcus Bingham Jr.","United States"],[4,"Nicolò Melli","Italy"],[5,"Sertaç Şanlı","Turkey"]]]]},
 "womens-basketball":{asof:"Signings announced for 2026–27; the full roster has not been published in a source we could verify",
  groups:[["New signings",[[null,"Lauren Betts","United States"],[null,"Luisa Geiselsöder","Germany"],[null,"Laura Juškaitė","Lithuania"],[null,"Leila Lacan","France"],[null,"Nell Angloma","France"],[null,"Tima Pouye","France"],[null,"Zeynep Şevval Gül","Turkey"],[null,"Manolya Kurtulmuş","Turkey"]]]],
  notes:["The team plays as Fenerbahçe Tarfin in 2026–27.","Left in the summer: Sevgi Uzun (to Galatasaray) and Tilbe Şenyürek (to Girona)."]},
 volleyball:{asof:"Confirmed for 2026–27 in club and press reports; not a full roster",
  groups:[["Confirmed players",[[null,"Eda Erdem Dündar","Turkey"],[null,"Hande Baladın","Turkey"],[null,"Alessia Orro","Italy"],[null,"Gizem Örge","Turkey"],[null,"Saliha Şahin","Turkey"],[null,"Kübra Akman","Turkey"],[null,"Sinead Jack-Kısal","Turkey"],[null,"Brenda Castillo","Dominican Republic"]]]],
  notes:["Left in the summer: Aslı Kalaç and Yaasmeen Bedart-Ghani. Agnieszka Korneluk retired."]}};

const VENUES={
 football:{name:"Şükrü Saracoğlu Stadium",area:"Kadıköy, Istanbul",cap:"47,911 seats",
  facts:["Opened in 1908 as the Union Club Field and Fenerbahçe's home ever since. The club bought it from the state in 1933.","Named after Şükrü Saracoğlu in 1998, then rebuilt stand by stand between 1999 and 2006 with a new roof.","Hosted the 2009 UEFA Cup final, won 2–1 by Shakhtar Donetsk against Werder Bremen.","Its sponsored name is Chobani Stadyumu."],
  travel:["Söğütlüçeşme station, on Marmaray and the Metrobüs line, is right next to the stadium.","Kadıköy ferry pier is about a 15-minute walk away, with boats from Eminönü and Beşiktaş."]},
 basketball:{name:"Ülker Sports and Event Hall",area:"Ataşehir, Istanbul",cap:"13,059 seats, up to 13,800 with lounges",
  facts:["Opened on 25 January 2012.","Built for about ₺200 million and designed by Ömerler Architecture.","Hosted the finals of the 2014 FIBA Women's World Championship.","Also a concert venue, with shows from Jennifer Lopez to Cirque du Soleil."],
  travel:["The hall is in Ataşehir on the Asian side. A journey planner gives the best metro or bus route on match days."]},
 "womens-basketball":{name:"Metro Enerji Sports Hall",area:"Istanbul",cap:"",
  facts:["The home court of the women's team."],travel:[]},
 volleyball:{name:"Burhan Felek Sport Hall",area:"Üsküdar, Istanbul",cap:"7,000 seats",
  facts:["Opened on 19 November 2010.","Hosted Women's CEV Champions League finals matches in 2011 and the CEV Cup final in 2012.","Both Fenerbahçe volleyball teams play their league matches here."],travel:[]}};

/* Higher or Lower: club records (Wikipedia list of records; goals list dated 2016, appearances 2019) */
const HOL_SETS=[
 {key:"goals",label:"goals for Fenerbahçe",items:[["Lefter Küçükandonyadis",215],["Melih Kotanca",172],["Alex de Souza",171],["Aykut Kocaman",167],["Naci Bastoncu",162],["Cemil Turan",127],["Fikret Arıcan",109],["Ogün Altıparmak",89],["Şeref Has",89],["Semih Şentürk",86]]},
 {key:"apps",label:"appearances for Fenerbahçe",items:[["Müjdat Yetkiner",570],["Volkan Demirel",525],["Cem Pamiroğlu",396],["Şeref Has",382],["Rüştü Reçber",381],["Gökhan Gönül",361],["Lefter Küçükandonyadis",349],["Ziya Şengül",342],["Alex de Souza",341],["Selçuk Şahin",326]]},
 {key:"titles",label:"titles",items:[["Football: Turkish championships",28],["Men's basketball: Turkish league titles",16],["Women's basketball: Turkish league titles",20],["Volleyball: Turkish league titles",15],["Rowing: Turkish championships",44],["Swimming: women's national titles",33],["Athletics: men's league titles",20],["Football: Turkish Cups",7],["Men's basketball: Turkish Cups",10],["Women's basketball: Turkish Cups",15],["Volleyball: Turkish Cups",5],["Football: Super Cups",10],["Men's basketball: Presidential Cups",9]]}];
