const {chromium}=require('playwright');
const S=["Light","More","Results","Upcoming","FT","Yesterday","Today","Tomorrow","Full table","Full squad","{n} players","Team","P","Pts","Branches","Main","Latest results and next games","No results yet.","Show","Home","Matches","Standings","Search","Play","Latest results","Coming up","Season so far","Form","Coach","Squad","Every team","All branches","Next match","Next up","Predict the score","Join the fans' prediction league","Download CSV","Last five","Full schedule","All results","Matchday","Dark"];
(async()=>{const b=await chromium.launch();const pg=await b.newPage();await pg.goto('file://'+process.cwd()+'/fenerbahce.html');await pg.waitForTimeout(300);
for(const L of ['tr','de','es','fr','ar']){await pg.selectOption('#lang',L);await pg.waitForTimeout(400);
 const miss=await pg.evaluate(S=>S.filter(s=>{try{return t(s)===s}catch(e){return 'ERR'}}),S);console.log(L,JSON.stringify(miss))}
await b.close()})();
