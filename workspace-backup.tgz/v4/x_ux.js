/* ===== Look & feel: hero scenes, tab groups, club home, charts, legends, player pages, search, data labels ===== */

/* ---------- 1. Hero scene and accent per branch ---------- */
const BR_ACCENT={home:"#ffe500",football:"#ffe500",basketball:"#ff9f1c","womens-basketball":"#ff7a8a",volleyball:"#3fd0c9","mens-volleyball":"#5aa9ff","womens-football":"#7be495",more:"#ffe500"};
let LIGHTHOUSE_SVG=null;
const sceneStars=(n,seed)=>{const r=szRng(seed);let s="";for(let i=0;i<n;i++)s+=`<circle cx="${(r()*400).toFixed(0)}" cy="${(r()*120).toFixed(0)}" r="${(0.6+r()*1.1).toFixed(1)}" fill="#fff" opacity="${(0.35+r()*0.5).toFixed(2)}"${i%5===0?' class="twinkle"':""}/>`;return s};
const sceneCrowd=(y0,y1,seed)=>{const r=szRng(seed);let s="";for(let i=0;i<170;i++){const x=r()*400,y=y0+r()*(y1-y0);s+=`<circle cx="${x.toFixed(0)}" cy="${y.toFixed(0)}" r="${(1.2+r()*1.2).toFixed(1)}" fill="${r()<.45?"var(--br)":r()<.6?"#f5f3ea":"#1b3878"}" opacity="${(0.35+r()*0.5).toFixed(2)}"/>`}return s};
const SCENES={
 football:()=>`<defs><linearGradient id="scP" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1f7a43"/><stop offset="1" stop-color="#0b3a20"/></linearGradient><radialGradient id="scF"><stop offset="0" style="stop-color:#fff;stop-opacity:.95"/><stop offset=".35" style="stop-color:var(--br);stop-opacity:.45"/><stop offset="1" style="stop-color:var(--br);stop-opacity:0"/></radialGradient></defs>
  ${sceneStars(26,7)}<path d="M0 150 L400 150 L400 250 L0 250Z" fill="#0a1736"/>${sceneCrowd(156,240,11)}
  <g opacity=".9"><path d="M46 250 V70 M354 250 V70" stroke="#26375f" stroke-width="5"/><rect x="26" y="52" width="40" height="22" rx="3" fill="#dfe6ff"/><rect x="334" y="52" width="40" height="22" rx="3" fill="#dfe6ff"/></g>
  <circle cx="46" cy="63" r="70" fill="url(#scF)"/><circle cx="354" cy="63" r="70" fill="url(#scF)"/>
  <polygon points="60,250 340,250 420,400 -20,400" fill="url(#scP)"/>
  ${[0,1,2,3,4].map(i=>`<polygon points="${60+i*56},250 ${88+i*56},250 ${(-20+i*88+44).toFixed(0)},400 ${(-20+i*88).toFixed(0)},400" fill="#fff" opacity=".045"/>`).join("")}
  <g fill="none" stroke="#e9f5ec" stroke-opacity=".75" stroke-width="2"><polygon points="72,256 328,256 392,394 8,394"/><path d="M40 318 H360"/><ellipse cx="200" cy="318" rx="58" ry="16"/><polygon points="140,256 260,256 266,272 134,272"/></g>
  <circle cx="246" cy="352" r="11" fill="#f5f3ea"/><polygon points="246,347.5 250.3,350.6 248.6,355.6 243.4,355.6 241.7,350.6" fill="#0a1530"/>`,
 "womens-football":()=>`<defs><linearGradient id="scP2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1b6e3c"/><stop offset="1" stop-color="#0a3520"/></linearGradient><radialGradient id="scG"><stop offset="0" style="stop-color:var(--br);stop-opacity:.5"/><stop offset="1" style="stop-color:var(--br);stop-opacity:0"/></radialGradient></defs>
  ${sceneStars(30,3)}<circle cx="200" cy="120" r="170" fill="url(#scG)"/>
  <rect x="0" y="282" width="400" height="118" fill="url(#scP2)"/><path d="M0 300 H400" stroke="#e9f5ec" stroke-opacity=".5" stroke-width="2"/>
  <g stroke="#e9f5ec" stroke-opacity=".28" stroke-width="1">${Array.from({length:15},(_,i)=>`<path d="M${104+i*13} 166 L${128+i*10.3} 250"/>`).join("")}${Array.from({length:7},(_,i)=>`<path d="M${104+i*1.7} ${166+i*12} H${296-i*1.7}"/>`).join("")}</g>
  <path d="M104 290 V164 H296 V290" fill="none" stroke="#f5f3ea" stroke-width="7" stroke-linejoin="round"/><path d="M104 164 L128 250 H272 L296 164" fill="none" stroke="#f5f3ea" stroke-opacity=".5" stroke-width="2"/>
  <path d="M218 214 q14 18 34 20" stroke="var(--br)" stroke-width="2" fill="none" opacity=".8"/>
  <circle cx="232" cy="236" r="13" fill="#f5f3ea"/><polygon points="232,230.5 237.2,234.3 235.2,240.4 228.8,240.4 226.8,234.3" fill="#0a1530"/>
  <path d="M70 330 q60 -40 150 -88" stroke="var(--br)" stroke-width="2.5" stroke-dasharray="3 7" fill="none" opacity=".7"/>`,
 basketball:()=>`<defs><linearGradient id="scW" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#b46a2d"/><stop offset="1" stop-color="#6e3b16"/></linearGradient><radialGradient id="scS" cx=".5" cy="0" r="1"><stop offset="0" style="stop-color:var(--br);stop-opacity:.38"/><stop offset="1" style="stop-color:var(--br);stop-opacity:0"/></radialGradient></defs>
  ${sceneStars(18,5)}<polygon points="150,0 250,0 330,260 70,260" fill="url(#scS)"/>
  <polygon points="0,262 400,262 400,400 0,400" fill="url(#scW)"/>${Array.from({length:9},(_,i)=>`<path d="M0 ${270+i*15} H400" stroke="#000" stroke-opacity=".12"/>`).join("")}
  <polygon points="150,262 250,262 284,400 116,400" style="fill:var(--br)" opacity=".25"/><path d="M150 262 L116 400 M250 262 L284 400" stroke="#f5f3ea" stroke-opacity=".7" stroke-width="2"/>
  <path d="M200 262 V110" stroke="#26375f" stroke-width="7"/><rect x="152" y="70" width="96" height="62" rx="4" fill="#f5f3ea" fill-opacity=".12" stroke="#f5f3ea" stroke-width="3"/><rect x="184" y="92" width="32" height="24" fill="none" stroke="#f5f3ea" stroke-width="2.5"/>
  <ellipse cx="200" cy="138" rx="24" ry="6" fill="none" style="stroke:var(--br)" stroke-width="4"/>
  <path d="M178 140 L186 168 M190 141 L193 170 M200 142 V170 M210 141 L207 170 M222 140 L214 168 M184 154 H216 M188 164 H212" stroke="#f5f3ea" stroke-opacity=".75" stroke-width="1.4" fill="none"/>
  <path d="M86 214 Q120 60 186 120" stroke="var(--br)" stroke-width="2.5" stroke-dasharray="3 7" fill="none" opacity=".75"/>
  <circle cx="86" cy="220" r="20" fill="#e2762c"/><path d="M66 220 H106 M86 200 V240 M72 206 q14 14 0 28 M100 206 q-14 14 0 28" stroke="#3b1a07" stroke-width="1.8" fill="none"/>`,
 "womens-basketball":()=>`<defs><linearGradient id="scW2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#a85e2a"/><stop offset="1" stop-color="#5f3214"/></linearGradient><radialGradient id="scS2" cx=".72" cy=".2" r=".7"><stop offset="0" style="stop-color:var(--br);stop-opacity:.42"/><stop offset="1" style="stop-color:var(--br);stop-opacity:0"/></radialGradient></defs>
  ${sceneStars(22,9)}<rect width="400" height="400" fill="url(#scS2)"/>
  <polygon points="0,280 400,250 400,400 0,400" fill="url(#scW2)"/>${Array.from({length:8},(_,i)=>`<path d="M0 ${290+i*15} L400 ${262+i*17}" stroke="#000" stroke-opacity=".12"/>`).join("")}
  <g transform="translate(-20,80)"><path d="M352 250 V60" stroke="#26375f" stroke-width="8"/><rect x="300" y="44" width="16" height="74" rx="3" fill="#f5f3ea" fill-opacity=".2" stroke="#f5f3ea" stroke-width="3"/>
  <path d="M316 104 H352" stroke="#26375f" stroke-width="5"/><ellipse cx="282" cy="110" rx="26" ry="7" fill="none" style="stroke:var(--br)" stroke-width="4"/>
  <path d="M258 112 L266 146 M270 114 L273 148 M282 115 V150 M294 114 L291 148 M306 112 L298 146 M262 130 H302 M267 142 H297" stroke="#f5f3ea" stroke-opacity=".8" stroke-width="1.4" fill="none"/>
  <circle cx="282" cy="132" r="17" fill="#e2762c"/><path d="M265 132 H299 M282 115 V149 M270 120 q11 12 0 24 M294 120 q-11 12 0 24" stroke="#3b1a07" stroke-width="1.6" fill="none"/>
  <path d="M230 96 q20 -10 34 6 M226 112 q14 -6 26 0" stroke="var(--br)" stroke-width="3" stroke-linecap="round" fill="none"/>
  </g><path d="M60 300 Q140 100 242 184" stroke="#f5f3ea" stroke-opacity=".35" stroke-width="2" stroke-dasharray="2 8" fill="none"/>`,
 volleyball:()=>`<defs><linearGradient id="scV" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1d5d8f"/><stop offset="1" stop-color="#0b2a4a"/></linearGradient><radialGradient id="scVG"><stop offset="0" style="stop-color:var(--br);stop-opacity:.45"/><stop offset="1" style="stop-color:var(--br);stop-opacity:0"/></radialGradient></defs>
  ${sceneStars(24,13)}<circle cx="200" cy="90" r="120" fill="url(#scVG)"/>
  <polygon points="0,272 400,272 400,400 0,400" fill="url(#scV)"/><polygon points="60,272 340,272 380,400 20,400" fill="#e07a2f" opacity=".55"/><path d="M60 272 L20 400 M340 272 L380 400 M200 272 V400" stroke="#f5f3ea" stroke-opacity=".7" stroke-width="2"/>
  <path d="M30 290 V140 M370 290 V140" stroke="#dfe6ff" stroke-width="6"/>
  <g stroke="#f5f3ea" stroke-opacity=".35" stroke-width="1">${Array.from({length:22},(_,i)=>`<path d="M${30+i*16} 152 V212"/>`).join("")}${[0,1,2,3].map(i=>`<path d="M30 ${152+i*20} H370"/>`).join("")}</g>
  <rect x="30" y="146" width="340" height="9" fill="#f5f3ea"/><rect x="30" y="210" width="340" height="4" fill="#f5f3ea" opacity=".8"/>
  <circle cx="214" cy="86" r="22" fill="#f5f3ea"/><path d="M194 80 q20 -8 40 4 M198 100 q8 -22 30 -30 M206 66 q-6 22 10 40" style="stroke:var(--br)" stroke-width="3" fill="none"/>
  <path d="M150 50 l30 18 M140 72 l34 10 M156 30 l26 26" stroke="#f5f3ea" stroke-opacity=".5" stroke-width="2.5" stroke-linecap="round"/>`,
 "mens-volleyball":()=>`<defs><linearGradient id="scV2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#173f73"/><stop offset="1" stop-color="#081a35"/></linearGradient><radialGradient id="scVG2" cx=".3" cy=".25"><stop offset="0" style="stop-color:var(--br);stop-opacity:.5"/><stop offset="1" style="stop-color:var(--br);stop-opacity:0"/></radialGradient></defs>
  ${sceneStars(20,17)}<rect width="400" height="400" fill="url(#scVG2)"/>
  <polygon points="0,300 400,300 400,400 0,400" fill="url(#scV2)"/><path d="M0 330 H400" stroke="#f5f3ea" stroke-opacity=".5" stroke-width="2"/>
  <path d="M10 320 V170 M390 320 V170" stroke="#dfe6ff" stroke-width="6"/>
  <g stroke="#f5f3ea" stroke-opacity=".3" stroke-width="1">${Array.from({length:24},(_,i)=>`<path d="M${10+i*16.5} 184 V250"/>`).join("")}${[0,1,2,3].map(i=>`<path d="M10 ${184+i*22} H390"/>`).join("")}</g>
  <rect x="10" y="176" width="380" height="10" fill="#f5f3ea"/>
  <path d="M60 30 L250 150" stroke="var(--br)" stroke-width="10" stroke-linecap="round" opacity=".25"/><path d="M90 50 L250 150" stroke="#f5f3ea" stroke-width="3" stroke-linecap="round" opacity=".5"/>
  <circle cx="262" cy="160" r="22" fill="#f5f3ea"/><path d="M242 156 q20 -10 40 2 M248 176 q6 -22 28 -32 M254 140 q-4 22 14 40" style="stroke:var(--br)" stroke-width="3" fill="none"/>
  <path d="M300 236 l14 40 M318 232 l8 44 M336 236 l-2 42" stroke="#f5f3ea" stroke-opacity=".45" stroke-width="5" stroke-linecap="round"/>`};
const SCENE_CAP={football:"Kadıköy under the floodlights","womens-football":"Top corner","basketball":"Nothing but net","womens-basketball":"Swish","volleyball":"Over the net","mens-volleyball":"The spike"};
function applyHero(b){const hero=document.querySelector(".hero");if(!hero)return;hero.style.setProperty("--br",BR_ACCENT[b]||"#ffe500");hero.dataset.br=b;
  const svg=document.querySelector(".scene svg");if(!svg)return;if(!LIGHTHOUSE_SVG)LIGHTHOUSE_SVG=svg.innerHTML;
  const k=SCENES[b]?b:"light",cap=document.querySelector(".scene .cap");if(cap){cap.removeAttribute("data-t");cap.textContent=t(SCENE_CAP[b]||"Fener · the lighthouse that named the club")}if(svg.dataset.scene===k)return;svg.dataset.scene=k;svg.innerHTML=SCENES[b]?SCENES[b]():LIGHTHOUSE_SVG}

/* ---------- 3. Club home ---------- */
const HOME_BR=["football","basketball","womens-basketball","volleyball","mens-volleyball","womens-football"];
function homeFixtures(){const today=todayISO(),out=[];HOME_BR.forEach(b=>{const L=LIVE[b];if(!L)return;L.next.filter(n=>n[0]&&n[0]>=today).forEach(n=>out.push({b,n}))});return out.sort((a,c)=>(a.n[0]+a.n[1]).localeCompare(c.n[0]+c.n[1]))}
function renderHome(){$("sport").value="home";applyHero("home");
  $("heroTr").textContent="Kadıköy · 1907";$("heroTitle").textContent="Fenerbahçe";$("heroNick").textContent=t("One club, every branch");
  $("heroLede").textContent=t("Football, basketball, volleyball and more, all on one page. Pick a branch to dive in, or see what is coming up across the club below.");$("kitNum").textContent="07";
  $("stats").innerHTML=[["28","Turkish football championships"],["2","EuroLeague titles"],["3","EuroLeague Women titles"],["1907","Club founded"]].map(([v,k])=>`<div class="stat"><span class="v">${v}</span><span class="k">${esc(t(k))}</span></div>`).join("");
  $("home").innerHTML=`<span class="label">${esc(t("Base"))}</span><b>${esc(t("Kadıköy, Istanbul, with facilities across the city"))}</b>`;
  $("tabs").innerHTML="";$("tabs").classList.add("grouped");
  const today=todayISO(),fx=homeFixtures().slice(0,8);
  const card=b=>{const S=SPORTS[b],L=LIVE[b],nx=nextFixture(b),last=L&&L.last.find(r=>r[0]),o=last?outcome(last):null;
    return `<article class="hcard card" style="--br:${BR_ACCENT[b]}"><div class="hhead"><div><h3>${esc(t(S.label))}</h3><p class="muted">${esc(t(S.nick))}</p></div></div>
     ${L?`<dl class="hrows"><dt>${t("Next match")}</dt><dd>${nx?`<b>${nx.n[0]?mDate(nx.n[0],true):esc(t(nx.n[5]||""))}${nx.n[1]?" · "+nx.n[1]:""}</b><br>${esc(nx.n[3]==="A"?nx.n[4]+" – Fenerbahçe":"Fenerbahçe – "+nx.n[4])} <span class="muted">· ${esc(t(nx.n[2]))}</span>`:`<span class="muted">${t("No upcoming fixtures in this snapshot.")}</span>`}</dd>
       <dt>${t("Latest result")}</dt><dd>${last?`<span class="fo ${o}">${t("res:"+o)}</span> ${esc(last[3])} <b>${last[4]}–${last[5]}</b> <span class="muted">${mDate(last[0],true)}</span>`:"–"}</dd>
       <dt>${esc(t(L.summary[0][1]))}</dt><dd><b>${esc(t(L.summary[0][0]))}</b></dd></dl>`:""}
     <button class="btn ghost" data-gosport="${b}">${esc(tf("Open {x}",{x:t(S.label)}))} →</button></article>`};
  $("panel").removeAttribute("aria-labelledby");
  $("panel").innerHTML=`<h2>${t("All branches")}</h2><p class="intro">${t("Every Fenerbahçe team on this site.")}</p>
   <div class="hgrid">${HOME_BR.map(card).join("")}</div>
   <h3 class="mh" style="margin-top:28px">${t("Coming up across the club")}</h3>
   <ol class="hfx">${fx.map(({b,n})=>`<li class="hfrow card"><div class="md"><b>${mDate(n[0],true)}</b><span>${n[1]||""}</span></div><div class="mm"><span class="mcomp">${brIcon(b)}${esc(t(n[2]))}</span><span class="mopp">${esc(vsOpp(n[3],n[4]))}</span></div><div class="ms"><button class="linkbtn" data-gosport="${b}">${t("Open")} →</button></div></li>`).join("")||`<li class="muted">${t("No upcoming fixtures in this snapshot.")}</li>`}</ol>
   <article class="card hmore"><div><h3>${esc(t(SPORTS.more.label))}</h3><p class="muted">${esc(t("Esports, athletics, rowing, sailing, swimming, table tennis, boxing and wheelchair basketball."))}</p></div><button class="btn ghost" data-gosport="more">${esc(tf("Open {x}",{x:t(SPORTS.more.label)}))} →</button></article>`;
  runExt("home",$("panel"));renderNextBanner();if(typeof kanRender==="function")kanRender()}
document.addEventListener("click",e=>{const g=e.target.closest("[data-gosport]");if(!g)return;setSport(g.dataset.gosport);window.scrollTo({top:0,behavior:"smooth"})});

/* ---------- 4. Charts ---------- */
const TL_DATA={
 football:()=>({series:[["Istanbul League",TROPHY_PRE[0][2].split(", ").map(x=>+x.slice(0,4)+1)],["Turkish champions",SPORTS.football.trophies[0][2].split(", ").map(Number)],["Turkish Cups",[1968,1974,1979,1983,2012,2013,2023]]]}),
 basketball:()=>({series:[["Turkish champions",[1957,1959,1965,1991,2007,2008,2010,2011,2014,2016,2017,2018,2022,2024,2025,2026]],["Turkish Cups",[1967,2010,2011,2013,2016,2019,2020,2024,2025,2026]],["European titles",[2017,2025]]]}),
 "womens-basketball":()=>({series:[["Turkish champions",SZ_HIST["womens-basketball"].t],["European titles",[2023,2024,2026]]]}),
 volleyball:()=>({series:[["Turkish champions",SZ_HIST.volleyball.t],["Turkish Cups",SZ_HIST.volleyball.c],["European and world titles",[2010,2012,2014]]],note:"League titles shown for the current format only (7 of 15)."}),
 "mens-volleyball":()=>({series:[["Turkish champions",SZ_HIST["mens-volleyball"].t],["Turkish Cups",SZ_HIST["mens-volleyball"].c],["European titles",[2014]],["Balkan Cups",[2009,2013]]]}),
 "womens-football":()=>({series:[["Turkish champions",[2026]]]})};
function trophyChart(b){if(!TL_DATA[b])return "";const D=TL_DATA[b](),all=D.series.flatMap(s=>s[1]);if(all.length<2)return "";
  const d0=Math.floor(Math.min(...all)/10)*10,dec=[];for(let d=d0;d<=2020;d+=10)dec.push(d);
  const cnt=dec.map(d=>D.series.map(s=>s[1].filter(y=>y>=d&&y<d+10).length)),mx=Math.max(...cnt.map(c=>c.reduce((a,b)=>a+b,0)),1);
  const W=1000,H=250,L=30,R=10,T=14,B=30,bw=Math.min(56,(W-L-R)/dec.length*.62),x=i=>L+(i+.5)*(W-L-R)/dec.length,y=v=>H-B-v*(H-T-B)/mx;
  const ticks=[...new Set([0,Math.ceil(mx/2),mx])];
  const bars=dec.map((d,i)=>{let acc=0;return cnt[i].map((c,k)=>{if(!c)return "";const y1=y(acc),y2=y(acc+c);acc+=c;return `<rect x="${(x(i)-bw/2).toFixed(1)}" y="${(y2+1).toFixed(1)}" width="${bw.toFixed(1)}" height="${Math.max(1,y1-y2-2).toFixed(1)}" rx="3" class="s${k+1}"><title>${d}s · ${esc(t(D.series[k][0]))}: ${c}</title></rect>`}).join("")+`<rect x="${(x(i)-(W-L-R)/dec.length/2).toFixed(1)}" y="${T}" width="${((W-L-R)/dec.length).toFixed(1)}" height="${H-T-B}" fill="transparent"><title>${d}s: ${D.series.map((s,k)=>`${t(s[0])} ${cnt[i][k]}`).join(" · ")}</title></rect>`}).join("");
  return `<figure class="tlchart card"><figcaption><span class="label">${t("Titles by decade")}</span><span class="clegend">${D.series.map((s,k)=>`<span><i class="s${k+1}"></i>${esc(t(s[0]))} (${s[1].length})</span>`).join("")}</span></figcaption>
   <svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${t("Titles by decade")}">${ticks.map(v=>`<path d="M${L} ${y(v)} H${W-R}" class="grid"/><text x="${L-8}" y="${y(v)+4}" text-anchor="end" class="ax">${v}</text>`).join("")}${bars}${dec.map((d,i)=>`<text x="${x(i)}" y="${H-10}" text-anchor="middle" class="ax">${String(d).slice(0,2)==="19"?"’"+String(d).slice(2):d}s</text>`).join("")}</svg>
   ${D.note?`<p class="fine">${esc(t(D.note))}</p>`:""}
   <details><summary>${t("Show as a table")}</summary><div class="tscroll"><table class="stand"><thead><tr><th>${t("Decade")}</th>${D.series.map(s=>`<th>${esc(t(s[0]))}</th>`).join("")}</tr></thead><tbody>${dec.map((d,i)=>`<tr><td>${d}s</td>${cnt[i].map(c=>`<td>${c}</td>`).join("")}</tr>`).join("")}</tbody></table></div></details></figure>`}
function derbyOverview(){return `<figure class="h2h card"><figcaption class="label">${t("All meetings, head to head")}</figcaption>${DERBIES.map(D=>{const r=D.all,tot=r.w+r.d+r.l,pc=v=>(v/tot*100).toFixed(1);
   return `<div class="h2hrow"><b>${esc(D.opp)}</b><div class="rbar" title="${r.w}–${r.d}–${r.l}"><i class="w" style="width:${pc(r.w)}%"></i><i class="d" style="width:${pc(r.d)}%"></i><i class="l" style="width:${pc(r.l)}%"></i></div><span class="h2hnum">${r.w} · ${r.d} · ${r.l}</span></div>`}).join("")}</figure>`}
function seasonLine(S){const P=S.line||[];if(P.length<2)return "";const W=1000,H=190,L=34,R=12,T=12,B=26,n=P.length,mx=Math.max(...P.map(p=>p[1]),1),x=i=>L+i*(W-L-R)/Math.max(1,n-1),y=v=>H-B-v*(H-T-B)/mx;
  const line=k=>P.map((p,i)=>`${i?"L":"M"}${x(i).toFixed(1)} ${y(p[k]).toFixed(1)}`).join(" ");
  return `<figure class="szline"><figcaption><span class="label">${t("Points through the season")}</span><span class="clegend"><span><i class="s1"></i>${esc(S.my.n)}</span><span><i class="dash"></i>${t("League leader")}</span></span></figcaption>
   <svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${t("Points through the season")}"><path d="M${L} ${y(0)} H${W-R}" class="grid"/><path d="M${L} ${y(mx)} H${W-R}" class="grid"/><text x="${L-6}" y="${y(mx)+4}" text-anchor="end" class="ax">${mx}</text><text x="${L-6}" y="${y(0)+4}" text-anchor="end" class="ax">0</text>
   <path d="${line(1)}" class="ln2"/><path d="${line(0)}" class="ln1"/>${P.map((p,i)=>`<circle cx="${x(i).toFixed(1)}" cy="${y(p[0]).toFixed(1)}" r="9" fill="transparent"><title>${tf("Matchday {n}",{n:i+1})}: ${p[0]} · ${t("League leader")} ${p[1]}</title></circle>`).join("")}
   <text x="${L}" y="${H-6}" class="ax">1</text><text x="${W-R}" y="${H-6}" text-anchor="end" class="ax">${n}</text></svg></figure>`}

/* ---------- 5. Legend cards ---------- */
function renderLegends(p,s){p.innerHTML=`<h2>${t("Legends")} ${dchip("real")}</h2><p class="intro">${t("Names every Fenerbahçe fan should know.")}</p><div class="legends2">${s.legends.map(([n,r,x,fa])=>{const parts=t(r).split(" · "),key=fa&&fa[0],rest=(fa||[]).slice(1);
    return `<article class="legend2 card"><div class="lhead"><span>${esc(parts[0])}</span>${parts.length>1?`<span class="lyrs">${esc(parts.slice(1).join(" · "))}</span>`:""}</div>
     <div class="lbody"><button class="lname" data-player="${esc(n)}">${esc(n)}</button><p>${esc(t(x))}</p>${key?`<div class="lkey">${esc(t(key))}</div>`:""}${rest.length?`<ul class="lfacts">${rest.map(f=>`<li>${esc(t(f))}</li>`).join("")}</ul>`:""}</div>
     <div class="lfoot"><button class="linkbtn" data-player="${esc(n)}">${t("Profile")} →</button></div></article>`}).join("")}</div>`}

/* ---------- 6. Player pages ---------- */
let PPI=null;
const nk=s=>norm(s).replace(/[^a-z0-9 ]/g,"").trim();
function ppIndex(){if(PPI)return PPI;const M=new Map(),add=(n,b)=>{if(!n)return;const k=nk(n);let e=M.get(k);if(!e){e={n,b:new Set()};M.set(k,e)}e.b.add(b)};
  Object.keys(PEOPLE).forEach(n=>add(n,"football"));PLAYERS.forEach(p=>add(p.n,"football"));
  Object.entries(BPEOPLE).forEach(([b,P])=>Object.keys(P).forEach(n=>add(n,b)));
  Object.entries(SPORTS).forEach(([b,S])=>(S.legends||[]).forEach(l=>add(l[0],b)));
  Object.entries(SQUADS).forEach(([b,Q])=>(Q.groups||[]).forEach(g=>g[1].forEach(x=>add(x[1],b))));
  PPI=[...M.values()];return PPI}
function ppFind(n){const k=nk(n);return ppIndex().find(e=>nk(e.n)===k)||{n,b:new Set()}}
function ppMentions(n){const parts=n.split(" "),last=parts[parts.length-1],keys=[n];if(last.length>=5&&parts.length>1)keys.push(last);const hit=s=>s&&keys.some(k=>s.includes(k)),out=[];
  Object.entries(SPORTS).forEach(([b,S])=>{(S.games||[]).forEach((g,i)=>{if(hit(g.note)||hit(g.title))out.push({b,tb:"games",i,lab:g.res?`${g.home} ${g.res} ${g.away}`:t(g.title),sub:`${t(g.comp)} · ${fmtDate(g.date)}`,txt:t(g.note)})});
   (S.history||[]).forEach((h,i)=>{if(hit(h[2])||hit(h[1]))out.push({b,tb:"history",i,lab:`${h[0]} · ${t(h[1])}`,sub:t(S.label),txt:t(h[2])})})});return out.slice(0,8)}
function playerPage(n){const e=ppFind(n),brs=[...e.b],secs=[];
  const p=PBY[n],F=PEOPLE[n];let pos="",nat="",yrsT="",rating=null,ten="";
  if(p){pos=t(ROLE_NAME[ROLE[p.pos]]||p.pos);nat=t(NAT[p.nat]||"");yrsT=yrs(p);rating=p.r}
  brs.forEach(b=>{const X=BPEOPLE[b]&&(BPEOPLE[b][n]||BPEOPLE[b][PERSON_MAP[n]]);if(X){pos=pos||capFirst(t(BPOS[X.pos]||""));nat=nat||t((NAT2[X.nat]||"").replace(/^the /,""));ten=ten||X.ten;if(rating==null)rating=X.r}});
  brs.forEach(b=>{const l=(SPORTS[b].legends||[]).find(x=>x[0]===n);if(l)secs.push(`<section><h4 class="mh">${t("Legend")} · ${esc(t(SPORTS[b].label))}</h4><p class="lrole">${esc(t(l[1]))}</p><p>${esc(t(l[2]))}</p>${(l[3]||[]).length?`<ul class="lfacts">${l[3].map(f=>`<li>${esc(t(f))}</li>`).join("")}</ul>`:""}</section>`)});
  Object.entries(SQUADS).forEach(([b,Q])=>(Q.groups||[]).forEach(([g,list])=>list.forEach(([num,nm,c])=>{if(nm===n)secs.push(`<section><h4 class="mh">${t("Squad")} · ${esc(t(SPORTS[b].label))}</h4><p>${num!=null?`#${num} · `:""}${esc(t(g))} · ${esc(t(c))}</p><p class="fine">${esc(t(Q.asof))}</p></section>`)})));
  if(F&&F.seasons&&F.seasons.length)secs.push(`<section><h4 class="mh">${t("In the most-used XI")}</h4><p>${F.seasons.map(s=>seasonLabel(s)).join(", ")}</p></section>`);
  brs.forEach(b=>{const X=BPEOPLE[b]&&(BPEOPLE[b][n]||BPEOPLE[b][PERSON_MAP[n]]);if(!X)return;
    if(X.apps&&X.apps.length)secs.push(`<section><h4 class="mh">${t("Box scores")}</h4><ul class="pplist">${X.apps.map(a=>`<li><span>${esc(t(a.L.label))} · ${t("vs")} ${esc(a.L.opp)}</span><b>${a.pts==null?t("DNP"):tf("{n} pts",{n:a.pts})}</b></li>`).join("")}</ul></section>`);
    if(X.squads&&X.squads.length)secs.push(`<section><h4 class="mh">${t("Famous squads")}</h4><ul class="pplist">${X.squads.map(s=>`<li><span>${esc(t(s.S.label))}</span><b>${s.num!=null?"#"+s.num:""}</b></li>`).join("")}</ul></section>`)});
  const sp=SPECIAL[n]||SPECIAL_B[n]||VB_AWARDS[n];if(sp)secs.push(`<section><h4 class="mh">${t("Who Am I? clue")}</h4><p>${esc(t(sp))}</p></section>`);
  const men=ppMentions(n);if(men.length)secs.push(`<section><h4 class="mh">${t("Mentioned in")}</h4><ul class="pplist links">${men.map(m=>`<li><button class="linkbtn" data-goitem="${m.b}|${m.tb}|${m.i}">${esc(m.lab)}</button><span class="muted">${esc(m.sub)}</span></li>`).join("")}</ul></section>`);
  const facts=[pos&&[t("Position"),pos],nat&&[t("Country"),nat],(yrsT||ten)&&[t("Years at the club"),yrsT||ten],rating!=null&&[t("Rating in the games"),`${rating} ${dchip("est")}`]].filter(Boolean);
  ovOpen(`<article class="pp"><span class="label">${brs.map(b=>esc(t(SPORTS[b].label))).join(" · ")||t("Player")}</span><h2>${esc(n)}</h2>
   ${facts.length?`<dl class="ppfacts">${facts.map(([k,v])=>`<div><dt>${esc(k)}</dt><dd>${v}</dd></div>`).join("")}</dl>`:""}
   ${secs.join("")||`<p class="muted">${t("Not much on this player yet.")}</p>`}
   ${KAN&&KAN.sample&&!KAN.off?`<div class="btns"><button class="btn ghost" data-askp="${esc(n)}">${esc(tf("Ask Kanarya about {x}",{x:n}))}</button></div>`:""}</article>`,n)}
document.addEventListener("click",e=>{const p=e.target.closest("[data-player]");if(p){e.preventDefault();playerPage(p.dataset.player);return}
  const a=e.target.closest("[data-askp]");if(a){ovClose();kanToggle(true);kanAsk(tf("Tell me about {x}.",{x:a.dataset.askp}));return}
  const g=e.target.closest("[data-goitem]");if(g){const [b,tb,i]=g.dataset.goitem.split("|");goItem(b,tb,i)}});
function goItem(b,tb,i){ovClose();if(tb==="europe"&&i!=null&&isNaN(+i)){euQ=i;i=null}if(current!==b)setSport(b);gameFilter="All";mFilter="All";tab=tb;syncHash();render();
  const el=i!=null&&i!==""?document.querySelector(`[data-hk="${tb}-${i}"]`):null;const go=el||$("tabs");setTimeout(()=>{go.scrollIntoView({behavior:"smooth",block:el?"center":"start"});if(el){el.classList.add("flash");setTimeout(()=>el.classList.remove("flash"),2200)}},40)}

/* ---------- overlay shared by search and player pages ---------- */
let OV_RET=null;
function ovOpen(html,label){let ov=$("ov");if(!ov){ov=document.createElement("div");ov.id="ov";ov.className="ov";ov.hidden=true;ov.innerHTML=`<div class="ovbox card" role="dialog" aria-modal="true"><button class="ovx" type="button" data-ovx>✕</button><div id="ovBody"></div></div>`;document.body.appendChild(ov);
    ov.addEventListener("click",e=>{if(e.target===ov||e.target.closest("[data-ovx]"))ovClose()})}
  if(ov.hidden)OV_RET=document.activeElement;$("ovBody").innerHTML=html;ov.querySelector(".ovbox").setAttribute("aria-label",label||"");ov.querySelector("[data-ovx]").setAttribute("aria-label",t("Close"));ov.hidden=false;document.body.classList.add("ovopen");
  const f=ov.querySelector("input")||ov.querySelector("[data-ovx]");setTimeout(()=>f&&f.focus(),20)}
function ovClose(){const ov=$("ov");if(!ov||ov.hidden)return;ov.hidden=true;document.body.classList.remove("ovopen");if(OV_RET&&OV_RET.focus)OV_RET.focus()}
document.addEventListener("keydown",e=>{const ov=$("ov");if(e.key==="Escape"&&ov&&!ov.hidden){e.stopPropagation();ovClose()}
  if((e.key==="/"&&!e.target.closest("input,textarea,select"))||((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==="k")){e.preventDefault();openSearch()}},true);

/* ---------- 7. Search ---------- */
let SIX=null;
const sn=s=>String(s).toLocaleLowerCase("tr").replace(/ç/g,"c").replace(/ğ/g,"g").replace(/ı/g,"i").replace(/ö/g,"o").replace(/ş/g,"s").replace(/ü/g,"u").normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[–—−]/g,"-").replace(/\s*-\s*(?=\d)/g,"-").replace(/[^\p{L}\p{N}\- ]/gu," ").replace(/\s+/g," ").trim();
function searchIndex(){if(SIX)return SIX;const I=[],push=(kind,label,sub,hay,act,b)=>I.push({kind,label,sub,lab:sn(label),hay:sn(label+" "+(sub||"")+" "+String(hay||"").replace(/(\d{4})-(\d{2})(?:-(\d{2}))?/g,"$1 $2 $3")),act,b});
  ppIndex().forEach(e=>push("p",e.n,[...e.b].map(b=>t(SPORTS[b].label)).join(" · "),"",{player:e.n}));
  Object.entries(SPORTS).forEach(([b,S])=>{(S.games||[]).forEach((g,i)=>push("g",g.res?`${g.home} ${g.res} ${g.away}`:t(g.title),`${t(g.comp)} · ${fmtDate(g.date)} · ${t(S.label)}`,`${g.comp} ${g.date} ${g.note} ${g.tag}`,{b,tb:"games",i},b));
    (S.history||[]).forEach((h,i)=>push("h",`${h[0]} · ${t(h[1])}`,t(S.label),`${h[1]} ${h[2]}`,{b,tb:"history",i},b));
    (S.trophies||[]).forEach((x,i)=>push("t",`${x[0]} × ${t(x[1])}`,`${t(S.label)} · ${t(x[2])}`,x[1]+" "+x[2],{b,tb:"trophies"},b))});
  SEASON_POS.forEach(([s,pos])=>{if(+s.slice(0,4)>=1959)push("s",`${s} · ${t("Süper Lig")}`,pos===1?t("Champions"):tf("Finished {p}",{p:ordL(pos)}),"season sezon",{b:"football",tb:"history"},"football")});
  [["basketball",MB_LINEUPS],["womens-basketball",WB_LINEUPS]].forEach(([b,LS])=>LS.forEach(L=>push("g",`${L.label} · ${L.title}`,`${t("vs")} ${L.opp} · ${L.score} · ${t(SPORTS[b].label)}`,`${L.date} ${L.where}`,{b,play:"lineup",lu:L.id},b)));
  HOME_BR.forEach(b=>{const L=LIVE[b];if(!L)return;L.last.forEach(r=>push("m",`Fenerbahçe ${r[4]}–${r[5]} ${r[3]}`,`${t(r[1])} · ${r[0]?mDate(r[0],true):t(r[6]||"")} · ${t(SPORTS[b].label)}`,`${r[0]} ${r[6]||""}`,{b,tb:"matches"},b))});
  runExt("search",I,push);SIX=I;return I}
const SKIND={p:"Players",g:"Big games and finals",m:"This season's results",h:"History",t:"Trophies",s:"Seasons"};
function runSearch(q){const toks=sn(q).split(/\s+/).filter(Boolean);if(!toks.length)return [];const lq=sn(q);
  const scRx=toks.filter(k=>/^\d+-\d+$/.test(k)).map(k=>new RegExp("(^|[^\\d])"+k+"($|[^\\d])"));
  return searchIndex().map(it=>{if(!toks.every(k=>/^\d+-\d+$/.test(k)||it.hay.includes(k))||!scRx.every(r=>r.test(it.lab)||r.test(it.hay.replace(/\d{4} \d{2} \d{2}/g,""))))return null;let sc=0;const l=sn(it.label);if(l.startsWith(lq))sc+=5;if(l.includes(lq))sc+=3;if(it.kind==="p")sc+=2;if(it.b===current)sc+=1;return {it,sc}}).filter(Boolean).sort((a,b)=>b.sc-a.sc).slice(0,40).map(x=>x.it)}
function openSearch(){ovOpen(`<div class="srch"><h2>${t("Search")}</h2><input id="sq" type="search" autocomplete="off" placeholder="${t("Players, seasons, finals, scores…")}" aria-label="${t("Search")}"><p class="fine">${t("Try a name, a year, a competition or a score like 6–0.")}</p><div id="sres" aria-live="polite"></div></div>`,t("Search"));
  const inp=$("sq");let tm=null;inp.addEventListener("input",()=>{clearTimeout(tm);tm=setTimeout(()=>showResults(inp.value),120)});
  inp.addEventListener("keydown",e=>{if(e.key==="Enter"){const f=$("sres").querySelector("[data-sr]");if(f)f.click()}})}
let SRES=[];
function showResults(q){const R=runSearch(q);SRES=R;const box=$("sres");if(!q.trim()){box.innerHTML="";return}
  if(!R.length){box.innerHTML=`<p class="muted">${t("Nothing found.")}</p>`;return}
  const groups={};R.forEach((it,i)=>{(groups[it.kind]=groups[it.kind]||[]).push([it,i])});
  box.innerHTML=Object.entries(groups).map(([k,L])=>`<section><h4 class="mh">${t(SKIND[k])}</h4><ul class="sreslist">${L.slice(0,8).map(([it,i])=>`<li><button data-sr="${i}"><b>${esc(it.label)}</b><span>${esc(it.sub||"")}</span></button></li>`).join("")}</ul></section>`).join("");
  box.querySelectorAll("[data-sr]").forEach(x=>x.onclick=()=>{const a=SRES[+x.dataset.sr].act;if(a.player){playerPage(a.player);return}
    if(a.play){ovClose();playSel[a.b]=a.play;if(a.lu)luS[a.b]={id:a.lu,found:new Set(),hints:new Set(),wrong:0,ended:false,msg:"",cls:""};setSport(a.b,true);setTimeout(()=>$("tabs").scrollIntoView({behavior:"smooth"}),40);return}
    goItem(a.b,a.tb,a.i)})}

/* ---------- 8. Real data and estimates ---------- */
function dchip(kind,txt){return kind==="real"?`<span class="dchip real" title="${esc(t("Taken from the sources listed on the page."))}">${esc(txt||t("Real data"))}</span>`:`<span class="dchip est" title="${esc(t("Made up for the games on this site."))}">${esc(txt||t("Estimate"))}</span>`}

/* ---------- hooks into the page ---------- */
$("hSearch").addEventListener("click",openSearch);
EXT.afterPanel.push((p,s)=>{const h2=p.querySelector("h2");
  if(h2&&!h2.querySelector(".dchip")&&tab!=="play")h2.insertAdjacentHTML("beforeend"," "+(tab==="squad"&&SQUADS[current]&&/2025/.test(SQUADS[current].asof||"")?dchip("est",t("Older list")):dchip("real")));
  if(tab==="trophies"){const c=p.querySelector(".cabinet");if(c)c.insertAdjacentHTML("beforebegin",trophyChart(current))}
  if(tab==="derbies"){const r=p.querySelector(".rleg");if(r)r.insertAdjacentHTML("afterend",derbyOverview())}
  if(tab==="games"){const list=s.games.filter(g=>gameFilter==="All"||g.tag===gameFilter);p.querySelectorAll(".games .game").forEach((el,k)=>el.dataset.hk="games-"+s.games.indexOf(list[k]))}
  if(tab==="history")p.querySelectorAll(".timeline > li").forEach((el,k)=>el.dataset.hk="history-"+k);
  if(tab==="squad")p.querySelectorAll(".sqlist .nm").forEach(el=>{const n=el.textContent;el.innerHTML=`<button class="pname" data-player="${esc(n)}">${esc(n)}</button>`});
  if(typeof kanRender==="function"&&KAN&&KAN.open)kanRender()});
/* the draft and penalty games carry an "Estimate" label: their ratings are made up */
EXT.play.push((p,g)=>{const h=document.querySelector("#gameArea h2");if(h&&["draft","draft5","draft6","draft11","penalties","ft","serve"].includes(g)&&!h.querySelector(".dchip"))h.insertAdjacentHTML("beforeend"," "+dchip("est",t("Fan ratings")))});
