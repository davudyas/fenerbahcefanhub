const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const errs=[];
for(const th of ['night','day','canary','retro','flood']){const pg=await b.newPage({viewport:{width:1280,height:900}});pg.on('pageerror',e=>errs.push(th+': '+e.message));
 await pg.goto('file://'+process.cwd()+'/fenerbahce.html#football');await pg.waitForTimeout(200);await pg.evaluate(v=>{const s=document.getElementById('theme');s.value=v;s.dispatchEvent(new Event('change'))},th);await pg.waitForTimeout(200);
 await pg.screenshot({path:`th_${th}_top.png`});await pg.evaluate(x=>{tab=x;syncHash();render()},'standings');await pg.waitForTimeout(100);await pg.locator('#panel').screenshot({path:`th_${th}_stand.png`,clip:undefined});
 await pg.evaluate(x=>{tab=x;syncHash();render()},'play');await pg.evaluate(g=>pickGame(g),'wordle');await pg.waitForTimeout(150);await pg.locator('#gameArea').screenshot({path:`th_${th}_wordle.png`});await pg.close()}
const pg=await b.newPage({viewport:{width:390,height:844}});await pg.goto('file://'+process.cwd()+'/fenerbahce.html#football');await pg.evaluate(()=>{const s=document.getElementById('theme');s.value='day';s.dispatchEvent(new Event('change'))});await pg.waitForTimeout(150);await pg.screenshot({path:'th_m_day.png'});
console.log('sw',await pg.evaluate(()=>document.documentElement.scrollWidth));
console.log('errors',JSON.stringify(errs));await b.close()})();
