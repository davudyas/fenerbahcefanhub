
const SEASONS=[["2000-01", "starts", "4-5-1", [["Kennet Andersson"], ["Nikola Lazetić", "Ogün Temizkanoğlu", "Haim Revivo", "Milan Rapaić", "Samuel Johnson"], ["Mustafa Doğan", "Zoran Mirković", "Abdullah Ercan", "Miško Mirković"], ["Rüştü Reçber"]]], ["2001-02", "minutes", "4-3-3", [["Serhat Akın", "Kennet Andersson", "Ali Güneş"], ["Samuel Johnson", "Ogün Temizkanoğlu", "Haim Revivo"], ["Abdullah Ercan", "Ümit Özat", "Zoran Mirković", "Mustafa Doğan"], ["Rüştü Reçber"]]], ["2002-03", "minutes", "4-3-3", [["Tuncay Şanlı", "Serhat Akın", "Ali Güneş"], ["Kemal Aslan", "Hakan Bayraktar", "Ceyhun Eriş"], ["Ümit Özat", "Samuel Johnson", "Fatih Akyel", "Ogün Temizkanoğlu"], ["Rüştü Reçber"]]], ["2003-04", "minutes", "4-3-3", [["Pierre van Hooijdonk", "Tuncay Şanlı", "Ali Güneş"], ["Mehmet Aurélio", "Selçuk Şahin", "Serhat Akın"], ["Fábio Luciano", "Ümit Özat", "Stjepan Tomas", "Fatih Akyel"], ["Volkan Demirel"]]], ["2004-05", "minutes", "4-4-2", [["Márcio Nobre", "Tuncay Şanlı"], ["Mehmet Aurélio", "Ümit Özat", "Alex de Souza", "Deniz Barış"], ["Fábio Luciano", "Servet Çetin", "Önder Turacı", "Serkan Balcı"], ["Rüştü Reçber"]]], ["2005-06", "minutes", "4-3-3", [["Tuncay Şanlı", "Márcio Nobre", "Nicolas Anelka"], ["Stephen Appiah", "Mehmet Aurélio", "Alex de Souza"], ["Ümit Özat", "Fábio Luciano", "Önder Turacı", "Serkan Balcı"], ["Volkan Demirel"]]], ["2006-07", "minutes", "4-4-2", [["Tuncay Şanlı", "Mateja Kežman"], ["Alex de Souza", "Stephen Appiah", "Mehmet Aurélio", "Deniz Barış"], ["Edu Dracena", "Önder Turacı", "Diego Lugano", "Ümit Özat"], ["Volkan Demirel"]]], ["2007-08", "minutes", "4-4-2", [["Deivid", "Semih Şentürk"], ["Mehmet Aurélio", "Alex de Souza", "Gökçek Vederson", "Uğur Boral"], ["Edu Dracena", "Gökhan Gönül", "Diego Lugano", "Roberto Carlos"], ["Volkan Demirel"]]], ["2008-09", "minutes", "4-4-2", [["Dani Güiza", "Deivid"], ["Alex de Souza", "Emre Belözoğlu", "Deniz Barış", "Selçuk Şahin"], ["Roberto Carlos", "Gökhan Gönül", "Diego Lugano", "Uğur Boral"], ["Volkan Demirel"]]], ["2009-10", "minutes", "4-5-1", [["Dani Güiza"], ["Alex de Souza", "Cristian Baroni", "André Santos", "Emre Belözoğlu", "Gökçek Vederson"], ["Gökhan Gönül", "Fábio Bilica", "Diego Lugano", "Mehmet Topuz"], ["Volkan Demirel"]]], ["2010-11", "minutes", "4-5-1", [["Mamadou Niang"], ["Alex de Souza", "Emre Belözoğlu", "André Santos", "Cristian Baroni", "Caner Erkin"], ["Mehmet Topuz", "Joseph Yobo", "Gökhan Gönül", "Diego Lugano"], ["Volkan Demirel"]]], ["2011-12", "minutes", "4-5-1", [["Miroslav Stoch"], ["Cristian Baroni", "Alex de Souza", "Mehmet Topuz", "Emre Belözoğlu", "Caner Erkin"], ["Joseph Yobo", "Reto Ziegler", "Gökhan Gönül", "Bekir İrtegün"], ["Volkan Demirel"]]], ["2012-13", "minutes", "5-3-2", [["Dirk Kuyt", "Moussa Sow"], ["Cristian Baroni", "Mehmet Topal", "Raul Meireles"], ["Gökhan Gönül", "Bekir İrtegün", "Hasan Ali Kaldırım", "Joseph Yobo", "Egemen Korkmaz"], ["Volkan Demirel"]]], ["2013-14", "minutes", "4-3-3", [["Dirk Kuyt", "Moussa Sow", "Emmanuel Emenike"], ["Caner Erkin", "Mehmet Topal", "Alper Potuk"], ["Gökhan Gönül", "Bruno Alves", "Egemen Korkmaz", "Bekir İrtegün"], ["Volkan Demirel"]]], ["2014-15", "minutes", "4-3-3", [["Moussa Sow", "Dirk Kuyt", "Emmanuel Emenike"], ["Caner Erkin", "Alper Potuk", "Emre Belözoğlu"], ["Mehmet Topal", "Gökhan Gönül", "Bruno Alves", "Bekir İrtegün"], ["Volkan Demirel"]]], ["2015-16", "minutes", "4-3-3", [["Nani", "Fernandão", "Robin van Persie"], ["Mehmet Topal", "Josef de Souza", "Diego Ribas"], ["Simon Kjær", "Bruno Alves", "Hasan Ali Kaldırım", "Gökhan Gönül"], ["Volkan Demirel"]]], ["2016-17", "minutes", "4-5-1", [["Moussa Sow"], ["Josef de Souza", "Mehmet Topal", "Alper Potuk", "Jeremain Lens", "Volkan Şen"], ["Martin Škrtel", "Hasan Ali Kaldırım", "Simon Kjær", "Şener Özbayraklı"], ["Volkan Demirel"]]], ["2017-18", "minutes", "4-5-1", [["Giuliano de Paula"], ["Josef de Souza", "Mehmet Topal", "Nabil Dirar", "Mathieu Valbuena", "Aatif Chahechouhe"], ["Roman Neustädter", "Hasan Ali Kaldırım", "Martin Škrtel", "Mauricio Isla"], ["Volkan Demirel"]]], ["2018-19", "minutes", "4-5-1", [["Roberto Soldado"], ["André Ayew", "Mehmet Topal", "Eljif Elmas", "Jailson", "Nabil Dirar"], ["Hasan Ali Kaldırım", "Martin Škrtel", "Mauricio Isla", "Roman Neustädter"], ["Harun Tekin"]]], ["2019-20", "minutes", "4-5-1", [["Vedat Muriqi"], ["Ozan Tufan", "Luiz Gustavo", "Garry Rodrigues", "Max Kruse", "Tolga Ciğerci"], ["Nabil Dirar", "Serdar Aziz", "Jailson", "Mauricio Isla"], ["Altay Bayındır"]]], ["2020-21", "minutes", "5-4-1", [["Enner Valencia"], ["Ozan Tufan", "Dimitris Pelkas", "Luiz Gustavo", "José Sosa"], ["Caner Erkin", "Serdar Aziz", "Marcel Tisserand", "Attila Szalai", "Gökhan Gönül"], ["Altay Bayındır"]]], ["2021-22", "minutes", "4-5-1", [["Serdar Dursun"], ["Ferdi Kadıoğlu", "Miha Zajc", "Diego Rossi", "Miguel Crespo", "İrfan Can Kahveci"], ["Kim Min-jae", "Bright Osayi-Samuel", "Attila Szalai", "Serdar Aziz"], ["Altay Bayındır"]]], ["2022-23", "minutes", "4-4-2", [["Enner Valencia", "Michy Batshuayi"], ["Willian Arão", "Diego Rossi", "İrfan Can Kahveci", "Miha Zajc"], ["Attila Szalai", "Ferdi Kadıoğlu", "Samet Akaydın", "Lincoln"], ["Altay Bayındır"]]], ["2023-24", "minutes", "4-5-1", [["Edin Džeko"], ["Dušan Tadić", "Sebastian Szymański", "İsmail Yüksek", "Fred", "İrfan Can Kahveci"], ["Ferdi Kadıoğlu", "Alexander Djiku", "Jayden Oosterwolde", "Bright Osayi-Samuel"], ["Dominik Livaković"]]], ["2024-25", "minutes", "4-4-2", [["Edin Džeko", "Youssef En-Nesyri"], ["Dušan Tadić", "Fred", "Sebastian Szymański", "Sofyan Amrabat"], ["Filip Kostić", "Alexander Djiku", "Mert Müldür", "Çağlar Söyüncü"], ["Dominik Livaković"]]], ["2025-26", "apps", "4-3-3", [["Anderson Talisca", "Kerem Aktürkoğlu", "Dorgeles Nene"], ["Fred", "İsmail Yüksek", "Marco Asensio"], ["Jayden Oosterwolde", "Milan Škriniar", "Nélson Semedo", "Archie Brown"], ["Ederson"]]]];

const SPORTS = {
  football: {
    label:"Football", tr:"Futbol", title:"Football", num:"07",
    nick:"Sarı Kanaryalar — the Yellow Canaries",
    lede:"The heart of the club. Fenerbahçe were the first champions of Turkey's national league in 1959 and have stayed one of the Big Three of Turkish football ever since. Latest silverware: the 2025 Super Cup, won 2–0 against Galatasaray in January 2026.",
    stats:[["19","Süper Lig titles"],["7","Turkish Cups"],["10","Super Cups"],["2nd","2025–26 league finish"]],
    home:["Home ground","Şükrü Saracoğlu Stadium, Kadıköy · 47,911 seats"],
    history:[
      ["1907","The club is founded","Ziya Songülen, Ayetullah Bey and Necip Okaner start the club in Kadıköy, on the Asian side of Istanbul. The name comes from the lighthouse (fener) at Fenerbahçe point."],
      ["1910s","Yellow and navy","The club settles on yellow and navy blue. The story goes that the colours came from daffodils growing around the lighthouse."],
      ["1923","General Harington Cup","Fenerbahçe beat a team from the British forces occupying Istanbul, a win remembered as a point of national pride."],
      ["1959","First national champions","Fenerbahçe win the first edition of the new nationwide Turkish league."],
      ["2002","The 6–0","A 6–0 home win over Galatasaray on 6 November, still the biggest margin in the derby's modern era."],
      ["2008","Champions League quarter-finals","A shootout win over Sevilla takes Fenerbahçe to the last eight, where they beat Chelsea 2–1 in the first leg."],
      ["2014","Title number 19","Fenerbahçe win the Süper Lig for the 19th time, their most recent league crown."],
      ["2026","Super Cup at the Olympic Stadium","Guendouzi and Oosterwolde score in a 2–0 final win over Galatasaray, the club's first Super Cup since 2014. The team finishes the season second, back in the Champions League."]
    ],
    games:[
      {date:"2002-11-06",comp:"Süper Lig",home:"Fenerbahçe",away:"Galatasaray",res:"6–0",out:"win",tag:"Derby",note:"The most famous night in the Intercontinental Derby. Fenerbahçe ran riot at home and the scoreline became a chant for a generation.",where:"Şükrü Saracoğlu, Istanbul"},
      {date:"2026-01-10",comp:"Super Cup final",home:"Galatasaray",away:"Fenerbahçe",res:"0–2",out:"win",tag:"Derby",note:"Guendouzi (28') and Oosterwolde (48') won the final in front of 58,397 fans. Guendouzi was man of the match.",where:"Atatürk Olympic Stadium, Istanbul"},
      {date:"2008-03-04",comp:"Champions League · Round of 16",home:"Sevilla",away:"Fenerbahçe",res:"3–2",out:"win",tag:"Europe",note:"5–5 on aggregate, then penalties. Volkan Demirel became a hero in the shootout and Fenerbahçe reached the quarter-finals.",where:"Ramón Sánchez Pizjuán, Seville"},
      {date:"2008-04",comp:"Champions League · Quarter-final",home:"Fenerbahçe",away:"Chelsea",res:"2–1",out:"win",tag:"Europe",note:"Fenerbahçe came from behind to beat Chelsea in Kadıköy. Chelsea turned it round in the return leg.",where:"Şükrü Saracoğlu, Istanbul"},
      {date:"2013-04-25",comp:"Europa League · Semi-final",home:"Fenerbahçe",away:"Benfica",res:"1–0",out:"win",tag:"Europe",note:"A first-leg win that put Fenerbahçe one step from a European final. Benfica won the second leg in Lisbon.",where:"Şükrü Saracoğlu, Istanbul"},
      {date:"2010-05-16",comp:"Süper Lig · Final day",home:"Fenerbahçe",away:"Trabzonspor",res:"1–1",out:"draw",tag:"Heartbreak",note:"A win would have sealed the title. The draw handed the championship to Bursaspor. Every club has a day it would rather forget.",where:"Şükrü Saracoğlu, Istanbul"}
    ],
    filters:["All","Derby","Europe","Heartbreak"],
    legends:[
      ["Lefter Küçükandonyadis","Forward · 1947–1964","Known as 'Ordinaryüs', the Professor. One of the greatest scorers in the club's history and a symbol of Kadıköy."],
      ["Can Bartu","Forward · 1950s–1970s","Played both football and basketball for Fenerbahçe, and later starred in Italy with Fiorentina."],
      ["Cemil Turan","Striker · 1970s","A prolific centre-forward in the title-winning sides of the 1970s."],
      ["Rıdvan Dilmen","Playmaker · 1980s–1990s","A gifted attacking midfielder, later one of Turkey's best-known football commentators."],
      ["Alex de Souza","No. 10 · 2004–2012","The Brazilian captain who led the 2011 title team. Probably the most loved foreign player in the club's history."],
      ["Volkan Demirel","Goalkeeper · 2002–2019","Spent almost two decades in goal, including the 2008 shootout against Sevilla."]
    ],
    trophies:[
      ["19","Süper Lig","1959, 1961, 1964, 1965, 1968, 1970, 1974, 1975, 1978, 1983, 1985, 1989, 1996, 2001, 2004, 2005, 2007, 2011, 2014"],
      ["7","Turkish Cup","1968, 1974, 1979, 1983, 2012, 2013, 2023"],
      ["10","Turkish Super Cup","Most recent: 2025 edition, won January 2026 against Galatasaray"],
      ["1","Balkans Cup","1968"]
    ],
    quiz:[
      {q:"In which Istanbul district was Fenerbahçe founded?",o:["Kadıköy","Beşiktaş","Taksim","Üsküdar"],a:0,e:"Kadıköy, on the Asian side. The stadium is still there."},
      {q:"What was the score in the derby against Galatasaray on 6 November 2002?",o:["4–0","6–0","3–1","5–2"],a:1,e:"6–0 at Şükrü Saracoğlu."},
      {q:"How many Süper Lig titles has Fenerbahçe won?",o:["17","21","19","24"],a:2,e:"19 since the national league started in 1959. The club also counts nine national titles from before 1959, which is why it speaks of 28."},
      {q:"What is the football team's nickname?",o:["Kara Kartallar","Sarı Kanaryalar","Cimbom","Bordo-Mavililer"],a:1,e:"Sarı Kanaryalar, the Yellow Canaries. Kara Kartallar is Beşiktaş, Cimbom is Galatasaray."},
      {q:"Who scored first in the 2025 Super Cup final?",o:["Oosterwolde","En-Nesyri","Guendouzi","Szymański"],a:2,e:"Guendouzi in the 28th minute. Oosterwolde added the second."}
    ]
  },


  basketball: {
    label:"Men's Basketball", tr:"Erkek Basketbol", title:"Basketball", num:"25",
    nick:"Fenerbahçe Tarfin",
    lede:"Two-time champions of Europe. Fenerbahçe won the EuroLeague at home in Istanbul in 2017 and again in Abu Dhabi in 2025, when they also completed Turkey's first Triple Crown. In 2025–26 they reached an eighth Final Four and won the league and cup at home.",
    stats:[["2","EuroLeague titles"],["8","Final Fours"],["16","Turkish league titles"],["10","Turkish Cups"]],
    home:["Home court","Ülker Sports and Event Hall, Ataşehir · 13,800 seats"],
    history:[
      ["1913","The basketball department opens","One of the oldest basketball sections in Turkey."],
      ["1991","Champions again","The first Turkish league title of the modern league era, ending a long wait."],
      ["2012","A win over an NBA team","On 5 October 2012 Fenerbahçe became the first Turkish club to beat an NBA side. The same year they moved into the Ülker Sports Arena."],
      ["2013","Obradović arrives","Željko Obradović, Europe's most decorated coach, takes over and builds a contender."],
      ["2016","First EuroLeague final","Fenerbahçe reach the final in Berlin and lose to CSKA Moscow in overtime."],
      ["2017","Champions of Europe","At the Final Four in Istanbul they beat Real Madrid, then Olympiacos 80–64. Ekpe Udoh is Final Four MVP."],
      ["2018","Back in the final","A second straight final, this time lost to Real Madrid in Belgrade."],
      ["2025","Second star and a Triple Crown","Under Šarūnas Jasikevičius they beat Panathinaikos and Monaco in Abu Dhabi, then add the league and cup: the first Triple Crown by a Turkish team."],
      ["2026","Eighth Final Four","A semi-final loss to Olympiacos in Athens, but the season still ends with the Turkish league title and the Turkish Cup."]
    ],
    games:[
      {date:"2017-05-21",comp:"EuroLeague Final",home:"Fenerbahçe",away:"Olympiacos",res:"80–64",out:"win",tag:"Final",note:"The first European title, won in front of a home crowd. Bogdanović and Kalinić scored 17 each.",where:"Sinan Erdem Dome, Istanbul"},
      {date:"2017-05-19",comp:"EuroLeague Semi-final",home:"Fenerbahçe",away:"Real Madrid",res:"84–75",out:"win",tag:"Final Four",note:"Ekpe Udoh scored 18 as Fenerbahçe beat the favourites.",where:"Sinan Erdem Dome, Istanbul"},
      {date:"2025-05-25",comp:"EuroLeague Final",home:"Fenerbahçe",away:"Monaco",res:"81–70",out:"win",tag:"Final",note:"Title number two. Nigel Hayes-Davis scored 23 and was named Final Four MVP.",where:"Etihad Arena, Abu Dhabi"},
      {date:"2025-05-23",comp:"EuroLeague Semi-final",home:"Fenerbahçe",away:"Panathinaikos",res:"82–76",out:"win",tag:"Final Four",note:"Devon Hall scored 18 to knock out the defending champions.",where:"Etihad Arena, Abu Dhabi"},
      {date:"2016-05-15",comp:"EuroLeague Final",home:"Fenerbahçe",away:"CSKA Moscow",res:"96–101",out:"loss",tag:"Final",note:"So close in their first final. It went to overtime before CSKA pulled away.",where:"Mercedes-Benz Arena, Berlin"},
      {date:"2018-05-20",comp:"EuroLeague Final",home:"Real Madrid",away:"Fenerbahçe",res:"85–80",out:"loss",tag:"Final",note:"Nicolò Melli scored 28 but Real Madrid held on in Belgrade.",where:"Štark Arena, Belgrade"}
    ],
    filters:["All","Final","Final Four"],
    legends:[
      ["Željko Obradović","Head coach · 2013–2020","Brought the first EuroLeague title and five straight Final Fours."],
      ["Šarūnas Jasikevičius","Head coach · 2023–","Coached the 2025 Triple Crown team."],
      ["Mirsad Türkcan","Power forward · 2006–2012","His number 6 was retired by the club in 2012."],
      ["Ömer Onan","Shooting guard · 2004–2014","His number 7 was retired in 2014."],
      ["Ekpe Udoh","Center · 2014–2017","Final Four MVP in 2017, a defensive anchor."],
      ["Bogdan Bogdanović","Guard · 2014–2017","Scoring guard of the 2017 team, later an NBA player."],
      ["Jan Veselý","Forward · 2014–2022","Started three straight EuroLeague finals."],
      ["Nigel Hayes-Davis","Forward · 2022–2025","Final Four MVP in 2025."]
    ],
    trophies:[
      ["2","EuroLeague","2017, 2025"],
      ["16","Turkish Super League","Most recently 2024, 2025 and 2026"],
      ["10","Turkish Cup","Most recently 2024, 2025 and 2026"],
      ["9","Presidential Cup","Most recently 2025 and 2026"],
      ["8","Final Four appearances","Most recent: Athens 2026"]
    ],
    quiz:[
      {q:"In which city did Fenerbahçe win their first EuroLeague?",o:["Berlin","Istanbul","Belgrade","Madrid"],a:1,e:"Istanbul, 2017, at a home Final Four."},
      {q:"Who did Fenerbahçe beat in the 2025 EuroLeague final?",o:["Real Madrid","Olympiacos","Monaco","Barcelona"],a:2,e:"Monaco, 81–70 in Abu Dhabi."},
      {q:"Who coached the 2025 title team?",o:["Željko Obradović","Ergin Ataman","Šarūnas Jasikevičius","Dimitris Itoudis"],a:2,e:"Šarūnas Jasikevičius."},
      {q:"Who was the 2017 Final Four MVP?",o:["Ekpe Udoh","Bogdan Bogdanović","Kostas Sloukas","Jan Veselý"],a:0,e:"Ekpe Udoh."},
      {q:"Whose number 6 shirt is retired by the club?",o:["Ömer Onan","Mirsad Türkcan","İbrahim Kutluay","Semih Erden"],a:1,e:"Mirsad Türkcan, retired in 2012. Ömer Onan's 7 followed in 2014."},
      {q:"Who scored 28 points for Fenerbahçe in the 2018 final?",o:["Nicolò Melli","Brad Wanamaker","Luigi Datome","Kostas Sloukas"],a:0,e:"Nicolò Melli, in an 85–80 loss to Real Madrid."},
      {q:"What did Fenerbahçe complete in 2024–25 that no Turkish team had done before?",o:["An unbeaten season","The Triple Crown","Three straight EuroLeagues","A win in the NBA"],a:1,e:"The Triple Crown: EuroLeague, Turkish league and Turkish Cup."}
    ]
  },

  "womens-basketball": {
    label:"Women's Basketball", tr:"Kadın Basketbol", title:"Women's Basketball", num:"26",
    nick:"Potanın Kraliçeleri — Queens of the Hoop",
    lede:"The most successful team in the club right now. Three EuroLeague Women titles since 2023, a record 20 Turkish league titles, and a 2025–26 season of 46 wins and one defeat in which they won every competition they entered.",
    stats:[["3","EuroLeague Women"],["20","Turkish league titles"],["2","Triple Crowns"],["15","Turkish Cups"]],
    home:["Home court","Metro Enerji Sports Hall, Istanbul"],
    history:[
      ["1954","The team is formed","Women's basketball becomes a permanent part of the club."],
      ["1999","First Super League title","The first of a record 20 Turkish Super League titles."],
      ["2005","A first European final","Runners-up in the EuroCup."],
      ["2013","First EuroLeague final","The first of four runner-up finishes before the breakthrough."],
      ["2019","Number 7 retired","Birsel Vardarlı, captain from 2012 to 2019, has her shirt retired."],
      ["2023","Champions of Europe","Breanna Stewart scores 35 in a 99–60 final win over ÇBK Mersin in Prague."],
      ["2024","Perfect season","35 wins from 35 league games, plus the EuroLeague (won in Mersin), the Turkish Cup and the SuperCup."],
      ["2026","Third star","An all-Turkish final against Galatasaray in Zaragoza, part of a 46–1 season and a clean sweep of every trophy."]
    ],
    games:[
      {date:"2023-04",comp:"EuroLeague Women Final",home:"Fenerbahçe",away:"ÇBK Mersin",res:"99–60",out:"win",tag:"Europe",note:"After four lost finals, Fenerbahçe finally lift the trophy. Breanna Stewart scored 35 and was MVP.",where:"Královka Arena, Prague"},
      {date:"2024-04",comp:"EuroLeague Women Final",title:"Back-to-back",out:"win",tag:"Europe",note:"Fenerbahçe beat Villeneuve d'Ascq in the final. Napheesa Collier scored 33 and Kayla McBride was MVP.",where:"Servet Tazegül Arena, Mersin"},
      {date:"2024",comp:"Turkish Super League",title:"35–0",out:"win",tag:"League",note:"A perfect league season: every one of 35 games won.",where:"Turkey"},
      {date:"2026-04-19",comp:"EuroLeague Women Final",title:"Number three",out:"win",tag:"Europe",note:"An all-Turkish final won against Galatasaray. Julie Allemand was Final Six MVP with 13 points, 8 rebounds and 10 assists.",where:"Pabellón Príncipe Felipe, Zaragoza"},
      {date:"2026",comp:"Turkish Super League",title:"27–0",out:"win",tag:"League",note:"Another unbeaten league season on the way to a 46–1 year.",where:"Turkey"}
    ],
    filters:["All","Europe","League"],
    legends:[
      ["Emma Meesseman","Forward · 2022–","Belgian star, EuroLeague Women MVP three years in a row (2023–2025) and one of the most decorated players in the competition."],
      ["Breanna Stewart","Forward · 2022–23, 2025–","Scored 35 in the 2023 final and came back for the third title."],
      ["Birsel Vardarlı","Point guard · 2006–2019","Captain from 2012 to 2019. Her number 7 is retired."],
      ["Kayla McBride","Guard · 2020–","MVP of the 2024 Final Four."],
      ["Julie Allemand","Point guard · 2024–","MVP of the 2026 Final Six."],
      ["Alperi Onar","Point guard · 2021–","Club captain since 2023."]
    ],
    trophies:[
      ["3","EuroLeague Women","2023, 2024, 2026"],
      ["20","Turkish Super League","1999 to 2026, a record"],
      ["15","Turkish Cup","Most recently 2024 and 2026"],
      ["3","FIBA Europe SuperCup Women","2023, 2024, 2026"],
      ["2","Triple Crowns","2024, 2026"]
    ],
    quiz:[
      {q:"When did Fenerbahçe win their first EuroLeague Women title?",o:["2013","2019","2023","2026"],a:2,e:"2023, after four lost finals."},
      {q:"What was the team's league record in 2023–24?",o:["33–2","35–0","30–5","34–1"],a:1,e:"35–0, a perfect season."},
      {q:"Who did Fenerbahçe beat in the 2026 final?",o:["Galatasaray","Valencia","ÇBK Mersin","Schio"],a:0,e:"Galatasaray, in an all-Turkish final in Zaragoza."},
      {q:"What does 'Potanın Kraliçeleri' mean?",o:["Yellow Angels","Queens of the Hoop","Lady Canaries","Kadıköy Stars"],a:1,e:"Queens of the Hoop."},
      {q:"How many points did Breanna Stewart score in the 2023 final?",o:["21","28","35","41"],a:2,e:"35, in a 99–60 win over ÇBK Mersin."},
      {q:"Whose number 7 is retired?",o:["Birsel Vardarlı","Olcay Çakır","Tuğçe Canıtez","Nevriye Yılmaz"],a:0,e:"Birsel Vardarlı, captain from 2012 to 2019."},
      {q:"Who was MVP of the 2026 Final Six?",o:["Emma Meesseman","Julie Allemand","Gabby Williams","Breanna Stewart"],a:1,e:"Julie Allemand, with 13 points, 8 rebounds and 10 assists in the final."}
    ]
  },

  volleyball: {
    label:"Volleyball", tr:"Voleybol", title:"Volleyball", num:"10",
    nick:"Sarı Melekler — the Yellow Angels",
    lede:"The first Turkish club to become world champions in an Olympic team sport. The women's team won the Club World Championship undefeated in 2010 and the CEV Champions League in 2012, and the men added a European cup of their own in 2014.",
    stats:[["1","Club World title"],["1","CEV Champions League"],["15","Turkish league titles"],["1928","Women's team founded"]],
    home:["Home court","Burhan Felek Sport Hall, Istanbul · 7,000 seats"],
    history:[
      ["1928","A pioneer starts the team","Sabiha Gürayman founds and captains the women's volleyball team. She later became Turkey's first female civil engineer."],
      ["1954","Back for good","The women's team is refounded with help from Çamlıca Girls' High School."],
      ["2010","World champions","Fenerbahçe win the FIVB Club World Championship in Doha without losing a match, beating Sollys Osasco 3–0 in the final."],
      ["2012","Champions of Europe","They beat RC Cannes in three straight sets in Baku. Kim Yeon-koung is MVP and top scorer."],
      ["2014","Two European cups in one day","The women win the CEV Cup and the men win the CEV Challenge Cup on the same day, a first for a Turkish club."],
      ["2024","A league and cup double","Fenerbahçe win the 2023–24 Turkish League and the Turkish Cup."]
    ],
    games:[
      {date:"2012-03-25",comp:"CEV Champions League Final",home:"Fenerbahçe",away:"RC Cannes",res:"3–0",out:"win",tag:"Women",note:"25–14, 25–22, 25–20. Kim Yeon-koung was MVP and Naz Aydemir best setter.",where:"Baku, Azerbaijan"},
      {date:"2012-03-24",comp:"CEV Champions League Semi-final",home:"Fenerbahçe",away:"Dinamo Kazan",res:"3–1",out:"win",tag:"Women",note:"Fenerbahçe lost the first set 17–25, then won the next three.",where:"Baku, Azerbaijan"},
      {date:"2014-03-29",comp:"CEV Cup Final",home:"Fenerbahçe",away:"Uralochka",res:"3–0",out:"win",tag:"Women",note:"25–11, 28–26, 25–22, in front of a home crowd.",where:"Istanbul"},
      {date:"2010-12",comp:"FIVB Club World Championship Final",home:"Fenerbahçe",away:"Sollys Osasco",res:"3–0",out:"win",tag:"Women",note:"World champions without dropping a match. Katarzyna Skowrońska was MVP.",where:"Doha, Qatar"},
      {date:"2014-03-29",comp:"CEV Challenge Cup",title:"Men's European title",out:"win",tag:"Men",note:"The men's team won its European trophy on the same day as the women's CEV Cup.",where:"Europe"}
    ],
    filters:["All","Women","Men"],
    legends:[
      ["Sabiha Gürayman","Founder · 1928","Founded the women's team, captained it, and later became Turkey's first female civil engineer."],
      ["Eda Erdem Dündar","Middle blocker · captain since 2014","In the 2010 world champion squad and still leading the team."],
      ["Kim Yeon-koung","Outside hitter · 2011–2017","MVP and top scorer of the 2012 Champions League Final Four."],
      ["Katarzyna Skowrońska","Opposite · 2010","MVP and top scorer of the 2010 Club World Championship."],
      ["Naz Aydemir","Setter","Best setter of the 2012 Champions League Final Four."],
      ["Melissa Vargas","Opposite · 2018–","Top scorer for Turkey's national team and MVP of a title-winning season."]
    ],
    trophies:[
      ["1","FIVB Club World Championship","2010"],
      ["1","CEV Champions League","2012"],
      ["1","CEV Cup (women)","2014"],
      ["15","Turkish League","7 in the current format: 2009, 2010, 2011, 2015, 2017, 2023, 2024"],
      ["5","Turkish Cup","2010, 2015, 2017, 2024, 2025"],
      ["1","CEV Challenge Cup (men)","2014"]
    ],
    quiz:[
      {q:"Who founded Fenerbahçe's women's volleyball team in 1928?",o:["Sabiha Gürayman","Halide Edib","Sabiha Gökçen","Eda Erdem"],a:0,e:"Sabiha Gürayman, later Turkey's first female civil engineer."},
      {q:"Who did Fenerbahçe beat in the 2010 Club World Championship final?",o:["VakıfBank","Sollys Osasco","Dinamo Kazan","Rabita Baku"],a:1,e:"Sollys Osasco of Brazil, 3–0 in Doha."},
      {q:"Who did they beat in the 2012 Champions League final?",o:["VakıfBank","Dynamo Moscow","RC Cannes","Imoco Conegliano"],a:2,e:"RC Cannes, 3–0."},
      {q:"Who was MVP of the 2012 Champions League Final Four?",o:["Logan Tom","Kim Yeon-koung","Eda Erdem","Fabiana Claudino"],a:1,e:"Kim Yeon-koung, who was also top scorer."},
      {q:"What is the volleyball team's nickname?",o:["Sarı Melekler","Sarı Kanaryalar","File Sultanları","Potanın Kraliçeleri"],a:0,e:"Sarı Melekler, the Yellow Angels."},
      {q:"Who has captained the team since 2014?",o:["Seda Tokatlıoğlu","Naz Aydemir","Eda Erdem Dündar","Çiğdem Can Rasna"],a:2,e:"Eda Erdem Dündar."}
    ]
  },

  more: {
    label:"Other Branches", tr:"Diğer Branşlar", title:"More Sports", num:"∞",
    nick:"One club, many sports",
    lede:"Fenerbahçe is a true multi-sport club, with European titles in six departments. Beyond football, basketball and volleyball it has world-class athletics, Turkey's most successful rowing and boxing sections, sailors, swimmers, table tennis, wheelchair basketball, women's football and esports.",
    stats:[["10+","Active branches"],["6","Branches with European titles"],["44","Turkish rowing titles"],["1907","Club founded"]],
    home:["Base","Kadıköy, Istanbul, with facilities across the city"],
    branches:[
      ["Athletics","Founded in 1913. Record 20 men's league titles and eight European Champion Clubs' Cups for the women. Ramil Guliyev won 200 m world gold in 2017."],
      ["Rowing","Founded in 1910. A record 44 Turkish championships. Tonguç Türsan's 1955 Mediterranean Games silver was Turkey's first international success in the sport."],
      ["Sailing","Founded in 1910. Won the 1917 Heybeliada races, Turkey's first official sailing competition. Tuğçe Subaşı became Laser 4.7 world champion in 2002."],
      ["Swimming","Founded in 1913, with a record 33 women's national championships."],
      ["Table Tennis","Founded in 1928. The women won the ETTU Cup in 2012 and 2013 and the European Champions League in 2015."],
      ["Boxing","Founded in 1914 and the most successful boxing section in Turkey, with nine world championship golds."],
      ["Wheelchair Basketball","European champions three times over: EuroCup 3 in 2019, EuroCup 2 in 2023 and EuroCup 1 in 2024."],
      ["Women's Football","Founded in 1995 and refounded in 2021. Turkish Super League champions in 2025–26."],
      ["Men's Volleyball","CEV Challenge Cup winners in 2014 and Balkan Cup winners in 2009 and 2013."],
      ["Esports","Founded in 2016, with three League of Legends Championship League titles."]
    ],
    quiz:[
      {q:"Which athlete won the 200 m world title in 2017 while at Fenerbahçe?",o:["Ramil Guliyev","Eşref Apak","Yasmani Copello","Ruhi Sarıalp"],a:0,e:"Ramil Guliyev. He added the European title in 2018."},
      {q:"How many Turkish rowing championships has Fenerbahçe won?",o:["12","25","44","60"],a:2,e:"44, a record."},
      {q:"In which year did the women's table tennis team win the European Champions League?",o:["2009","2015","2019","2023"],a:1,e:"2015, without losing a match."},
      {q:"Which branch won EuroCup 1 in 2024?",o:["Men's volleyball","Wheelchair basketball","Women's football","Swimming"],a:1,e:"Wheelchair basketball, after EuroCup 3 in 2019 and EuroCup 2 in 2023."},
      {q:"What did the sailing branch win in 1917?",o:["The Heybeliada races","An Olympic medal","The Bosphorus Cup","A world title"],a:0,e:"The Heybeliada races, Turkey's first official sailing competition."},
      {q:"Who designed the club badge in 1910?",o:["Ziya Songülen","Hikmet Topuzer","Necip Okaner","Ayetullah Bey"],a:1,e:"Hikmet Topuzer. The design has kept its core ever since."}
    ]
  }
};

/* ===== Branch game data ===== */
const NAT2={USA:"the United States",GRE:"Greece",MKD:"North Macedonia",FRA:"France",SRB:"Serbia",TUR:"Turkey",CRO:"Croatia",BIH:"Bosnia and Herzegovina",ITA:"Italy",LTU:"Lithuania",SUI:"Switzerland",SLO:"Slovenia",CAN:"Canada",CZE:"the Czech Republic",AUS:"Australia",BEL:"Belgium",LAT:"Latvia",UKR:"Ukraine",GER:"Germany",BLR:"Belarus",BRA:"Brazil",POL:"Poland",RUS:"Russia",KOR:"South Korea",BUL:"Bulgaria",DOM:"the Dominican Republic"};
/* name, pos, alt, rating, nat, short, tenure */
const MB_POOL=[
 ["Kostas Sloukas","PG","SG",86,"GRE","Sloukas","2015–2020"],["Bobby Dixon","PG","SG",84,"USA","Dixon","2014–2019 (later played as Ali Muhammed)"],["Bo McCalebb","PG","",85,"MKD","McCalebb","2011–2014"],["Brad Wanamaker","PG","SG",81,"USA","Wanamaker","2016–2018"],["Nando De Colo","PG","SG",87,"FRA","De Colo","2019–2022"],["Wade Baldwin IV","PG","SG",82,"USA","Baldwin",""],["Errick McCollum","PG","SG",80,"USA","McCollum",""],["Mahmoud Abdul-Rauf","PG","",81,"USA","Abdul-Rauf",""],["Nikos Zisis","PG","",80,"GRE","Zisis",""],["Will Solomon","PG","SG",80,"USA","Solomon",""],
 ["Bogdan Bogdanović","SG","SF",88,"SRB","Bogdanović","2014–2017"],["Marko Gudurić","SG","SF",83,"SRB","Gudurić",""],["Devon Hall","SG","",82,"USA","Hall",""],["Ömer Onan","SG","",82,"TUR","Onan","2004–2005, 2006–2014"],["İbrahim Kutluay","SG","",84,"TUR","Kutluay","1991–1999, 2006–2007"],["Melih Mahmutoğlu","SG","",78,"TUR","Melih",""],["Gordan Giriček","SG","SF",80,"CRO","Giriček",""],["Harun Erdenay","SG","",80,"TUR","Erdenay",""],["Talen Horton-Tucker","SG","SF",82,"USA","Horton-Tucker",""],["Ricky Hickman","SG","PG",79,"USA","Hickman",""],
 ["Nikola Kalinić","SF","SG",85,"SRB","Kalinić",""],["Luigi Datome","SF","PF",86,"ITA","Datome",""],["Bojan Bogdanović","SF","",84,"CRO","Bojan",""],["Linas Kleiza","SF","PF",82,"LTU","Kleiza",""],["James Nunnally","SF","SG",80,"USA","Nunnally",""],["Bonzie Colson","SF","PF",80,"USA","Colson",""],["Thabo Sefolosha","SF","SG",79,"SUI","Sefolosha",""],["Tarik Biberović","SF","SG",79,"TUR","Biberović",""],["Marko Milič","SF","",78,"SLO","Milič",""],["Dyshawn Pierre","SF","",76,"CAN","Pierre",""],
 ["Jan Veselý","PF","C",87,"CZE","Veselý","2014–2022"],["Nigel Hayes-Davis","PF","SF",86,"USA","Hayes-Davis","2022–2025"],["Nicolò Melli","PF","C",85,"ITA","Melli",""],["Mirsad Türkcan","PF","",84,"TUR","Türkcan","2006–2012"],["Nemanja Bjelica","PF","SF",84,"SRB","Bjelica",""],["Mike Batiste","PF","C",81,"USA","Batiste",""],["James Gist","PF","",80,"USA","Gist",""],["David Andersen","PF","C",81,"AUS","Andersen",""],["Derrick Williams","PF","SF",79,"USA","Williams",""],["Jason Thompson","PF","C",76,"USA","Thompson",""],
 ["Ekpe Udoh","C","PF",86,"USA","Udoh","2014–2017"],["Pero Antić","C","PF",80,"MKD","Antić",""],["Khem Birch","C","",80,"CAN","Birch",""],["Ahmet Düverioğlu","C","",77,"TUR","Düverioğlu",""],["Boban Marjanović","C","",82,"SRB","Marjanović",""],["Ömer Aşık","C","",80,"TUR","Aşık",""],["Semih Erden","C","",78,"TUR","Erden",""],["Žan Tabak","C","",80,"CRO","Tabak",""],["Tanoka Beard","C","PF",80,"USA","Beard",""],["Conrad McRae","C","PF",79,"USA","McRae",""]
];
const WB_POOL=[
 ["Olcay Çakır","PG","",80,"TUR","Çakır","2010–16, 2019–21, 2024–"],["Julie Allemand","PG","",86,"BEL","Allemand","2024–"],["Courtney Vandersloot","PG","",86,"USA","Vandersloot","2022–23"],["Yvonne Anderson","PG","",81,"SRB","Anderson","2023–24"],["Sevgi Uzun","PG","SG",80,"TUR","Uzun","2019–21, 2023–"],["Alperi Onar","PG","",77,"TUR","Onar","2021–"],["Birsel Vardarlı","PG","",80,"TUR","Vardarlı","2006–2019"],["Chelsea Gray","PG","",86,"USA","Gray","2019–20"],["Tuğçe Canıtez","PG","",76,"TUR","Canıtez","2013–22"],
 ["Kayla McBride","SG","",87,"USA","McBride","2020–"],["Diana Taurasi","SG","",90,"USA","Taurasi","2010–11"],["Cappie Pondexter","SG","PG",87,"USA","Pondexter","2006–08, 2011–14"],["Kelsey Plum","SG","PG",85,"USA","Plum","2017–19"],["Ariel Atkins","SG","",83,"USA","Atkins","2024–25"],["Katie Smith","SG","",84,"USA","Smith","2008–09"],["Kitija Laksa","SG","",78,"LAT","Laksa","2023–24"],["Allie Quigley","SG","",81,"USA","Quigley","2015–17"],
 ["Gabby Williams","SF","PF",85,"FRA","Gabby Williams","2024–"],["Napheesa Collier","SF","PF",89,"USA","Collier","2023–24"],["Alina Iagupova","SF","SG",84,"UKR","Iagupova","2021–23"],["Satou Sabally","SF","PF",85,"GER","Satou Sabally","2020–23"],["Penny Taylor","SF","",86,"AUS","Taylor","2009–12"],["Angel McCoughtry","SF","SG",87,"USA","McCoughtry","2010–14"],["Nicole Powell","SF","",80,"USA","Powell","2005–06, 2008–10"],["Cecilia Zandalasini","SF","",80,"ITA","Zandalasini","2018–21"],
 ["Breanna Stewart","PF","SF",93,"USA","Stewart","2022–23, 2025–"],["Emma Meesseman","PF","C",91,"BEL","Meesseman","2022–"],["Candace Parker","PF","C",90,"USA","Parker","2016–17"],["Jonquel Jones","PF","C",89,"BIH","Jones","2025–"],["Iliana Rupert","PF","C",84,"FRA","Rupert","2025–"],["Anastasiya Verameyenka","PF","C",80,"BLR","Verameyenka","2012–14, 2015–19"],["Nyara Sabally","PF","",80,"GER","Nyara Sabally","2024–25"],["Tilbe Şenyürek","PF","",74,"TUR","Şenyürek","2017–19, 2023–"],
 ["Tina Charles","C","",88,"USA","Charles","2014–15, 2024–25"],["Nikolina Milić","C","",82,"SRB","Milić","2023–"],["Kiah Stokes","C","",80,"USA","Stokes","2018–24"],["Teaira McCowan","C","",82,"TUR","McCowan","2025–"],["Tammy Sutton-Brown","C","",80,"CAN","Sutton-Brown","2006–11"],["Sandrine Gruda","C","PF",84,"FRA","Gruda","2016–17"],["Elizabeth Williams","C","",81,"USA","E. Williams","2019–20, 2021–22"],["Marième Badiane","C","",79,"FRA","Badiane","2023–25"]
];
const VB_POOL=[
 ["Fofão","S","",88,"BRA","Fofão",""],["Naz Aydemir","S","",85,"TUR","Naz",""],["Bojana Drča","S","",82,"SRB","Drča",""],["Alessia Orro","S","",86,"ITA","Orro",""],["Arelya Karasoy","S","",76,"TUR","Karasoy",""],["Zülfiye Gündoğdu","S","",74,"TUR","Gündoğdu",""],["Buse Ünal","S","",74,"TUR","Ünal",""],
 ["Katarzyna Skowrońska","OP","",88,"POL","Skowrońska",""],["Melissa Vargas","OP","",92,"TUR","Vargas",""],["Magdalena Stysiak","OP","",86,"POL","Stysiak",""],["Seda Tokatlıoğlu","OP","OH",82,"TUR","Tokatlıoğlu",""],["Lioubov Sokolova","OP","OH",85,"RUS","Sokolova",""],["Meryem Boz","OP","",79,"TUR","Boz",""],
 ["Kim Yeon-koung","OH","",93,"KOR","Kim Yeon-koung",""],["Logan Tom","OH","",86,"USA","Logan Tom",""],["Nataša Osmokrović","OH","",83,"CRO","Osmokrović",""],["Arina Fedorovtseva","OH","",88,"RUS","Fedorovtseva",""],["Ana Cristina de Souza","OH","",86,"BRA","Ana Cristina",""],["Hande Baladın","OH","",84,"TUR","Baladın",""],["Meliha İsmailoğlu","OH","",83,"TUR","İsmailoğlu",""],["Yağmur Koçyiğit","OH","",76,"TUR","Koçyiğit",""],["Liubov Shashkova","OH","",82,"RUS","Shashkova",""],["Elitsa Vasileva","OH","",83,"BUL","Vasileva",""],
 ["Eda Erdem Dündar","MB","",90,"TUR","Eda Erdem",""],["Christiane Fürst","MB","",86,"GER","Fürst",""],["Fabiana Claudino","MB","",87,"BRA","Fabiana",""],["Çiğdem Can Rasna","MB","",80,"TUR","Çiğdem",""],["Aslı Kalaç","MB","",82,"TUR","Kalaç",""],["Irina Fetisova","MB","",84,"RUS","Fetisova",""],["Ergül Avcı","MB","",78,"TUR","Avcı",""],["Chiaka Ogbogu","MB","",84,"USA","Ogbogu",""],["Hristina Ruseva","MB","",82,"BUL","Ruseva",""],["İpek Soroğlu","MB","",74,"TUR","Soroğlu",""],
 ["Nihan Güneyligil","L","",82,"TUR","Nihan",""],["Gizem Örge","L","",83,"TUR","Örge",""],["Brenda Castillo","L","",88,"DOM","Castillo",""],["Cansu Çetin","L","",76,"TUR","Cansu Çetin",""],["Merve Dalbeler","L","",76,"TUR","Dalbeler",""],["Songül Dikmen","L","",72,"TUR","Dikmen",""]
];
const toPeople=(raw)=>raw.map(([n,pos,alt,r,nat,short,ten])=>({n,pos,alt:alt?alt.split(","):[],r,nat,short:short||n.split(" ").slice(-1)[0],ten}));
const MB_P=toPeople(MB_POOL),WB_P=toPeople(WB_POOL),VB_P=toPeople(VB_POOL);
const BPOS={PG:"point guard",SG:"shooting guard",SF:"small forward",PF:"power forward",C:"center",S:"setter",OP:"opposite",OH:"outside hitter",MB:"middle blocker",L:"libero"};

/* Box-score lineups: starters [pos,name,pts], bench [name,pts|null] (null = did not play) */
const MB_LINEUPS=[
 {id:"2025F",label:"2025 Final",title:"EuroLeague Final",opp:"Monaco",score:"81–70 win",date:"25 May 2025",where:"Abu Dhabi",coach:"Šarūnas Jasikevičius",
  st:[["PG","Marko Gudurić",19],["SG","Devon Hall",13],["SF","Bonzie Colson",0],["PF","Nigel Hayes-Davis",23],["C","Khem Birch",2]],bench:[["Errick McCollum",3],["Wade Baldwin IV",13],["Nicolò Melli",5],["Tarik Biberović",3]]},
 {id:"2025S",label:"2025 Semi",title:"EuroLeague Semi-final",opp:"Panathinaikos",score:"82–76 win",date:"23 May 2025",where:"Abu Dhabi",coach:"Šarūnas Jasikevičius",
  st:[["PG","Marko Gudurić",3],["SG","Devon Hall",18],["SF","Bonzie Colson",3],["PF","Nigel Hayes-Davis",7],["C","Khem Birch",2]],bench:[["Errick McCollum",13],["Wade Baldwin IV",10],["Nicolò Melli",9],["Tarik Biberović",15],["Dyshawn Pierre",2]]},
 {id:"2018F",label:"2018 Final",title:"EuroLeague Final",opp:"Real Madrid",score:"80–85 loss",date:"20 May 2018",where:"Belgrade",coach:"Željko Obradović",
  st:[["PG","Brad Wanamaker",14],["SG","Marko Gudurić",0],["SF","Nikola Kalinić",7],["PF","Jan Veselý",3],["C","Ahmet Düverioğlu",8]],bench:[["Jason Thompson",0],["Nicolò Melli",28],["Melih Mahmutoğlu",null],["Kostas Sloukas",7],["James Nunnally",0],["Ali Muhammed",7],["Luigi Datome",6]]},
 {id:"2018S",label:"2018 Semi",title:"EuroLeague Semi-final",opp:"Žalgiris",score:"76–67 win",date:"18 May 2018",where:"Belgrade",coach:"Željko Obradović",
  st:[["PG","Brad Wanamaker",9],["SG","Marko Gudurić",0],["SF","Nikola Kalinić",2],["PF","Jan Veselý",8],["C","Ahmet Düverioğlu",4]],bench:[["Jason Thompson",0],["Nicolò Melli",4],["Melih Mahmutoğlu",null],["Kostas Sloukas",14],["James Nunnally",0],["Ali Muhammed",19],["Luigi Datome",16]]},
 {id:"2017F",label:"2017 Final",title:"EuroLeague Final",opp:"Olympiacos",score:"80–64 win",date:"21 May 2017",where:"Istanbul",coach:"Željko Obradović",
  st:[["PG","Bobby Dixon",8],["SG","Bogdan Bogdanović",17],["SF","Nikola Kalinić",17],["PF","Jan Veselý",8],["C","Ekpe Udoh",10]],bench:[]},
 {id:"2017S",label:"2017 Semi",title:"EuroLeague Semi-final",opp:"Real Madrid",score:"84–75 win",date:"19 May 2017",where:"Istanbul",coach:"Željko Obradović",
  st:[["PG","Bobby Dixon",9],["SG","Bogdan Bogdanović",14],["SF","Nikola Kalinić",12],["PF","Jan Veselý",12],["C","Ekpe Udoh",18]],bench:[]},
 {id:"2016F",label:"2016 Final",title:"EuroLeague Final",opp:"CSKA Moscow",score:"96–101 loss (OT)",date:"15 May 2016",where:"Berlin",coach:"Željko Obradović",
  st:[["PG","Kostas Sloukas",10],["SG","Bogdan Bogdanović",6],["SF","Nikola Kalinić",3],["PF","Luigi Datome",16],["PF","Jan Veselý",7]],bench:[["Ricky Hickman",5],["Ekpe Udoh",16],["Pero Antić",16],["Bobby Dixon",17],["Melih Mahmutoğlu",0],["Barış Hersek",null],["Berk Uğurlu",null]]},
 {id:"2016S",label:"2016 Semi",title:"EuroLeague Semi-final",opp:"Laboral Kutxa",score:"88–77 win",date:"13 May 2016",where:"Berlin",coach:"Željko Obradović",
  st:[["PG","Bobby Dixon",3],["SG","Bogdan Bogdanović",18],["SF","Luigi Datome",15],["PF","Pero Antić",8],["C","Ekpe Udoh",14]],bench:[["Ricky Hickman",3],["Kostas Sloukas",13],["Jan Veselý",14],["Nikola Kalinić",0],["Melih Mahmutoğlu",null],["Barış Hersek",null],["Berk Uğurlu",null]]}
];
const WB_LINEUPS=[
 {id:"2026F",label:"2026 Final",title:"EuroLeague Women Final",opp:"Galatasaray",score:"Champions",date:"19 April 2026",where:"Zaragoza",coach:"Miguel Méndez",
  st:[["PG","Julie Allemand",13],["PG","Sevgi Uzun",2],["SF","Gabby Williams",4],["PF","Breanna Stewart",9],["C","Emma Meesseman",20]],bench:[["Olcay Çakır",4],["Iliana Rupert",16],["Ayşe Yılmaz",null],["Alperi Onar",null],["Tuana Vural",null],["Tilbe Şenyürek",null],["Nikolina Milić",null]]},
 {id:"2024F",label:"2024 Final",title:"EuroLeague Women Final",opp:"Villeneuve d'Ascq",score:"Champions",date:"April 2024",where:"Mersin",coach:"Valérie Garnier",
  st:[["PG","Yvonne Anderson",7],["SG","Kayla McBride",17],["SF","Napheesa Collier",33],["PF","Emma Meesseman",22],["C","Nikolina Milić",16]],bench:[["Sevgi Uzun",3],["İdil Saçalır",0],["Alperi Onar",2],["Tilbe Şenyürek",2],["Marième Badiane",4],["Marija Leković",0],["Kitija Laksa",0]]},
 {id:"2023F",label:"2023 Final",title:"EuroLeague Women Final",opp:"ÇBK Mersin",score:"99–60 win",date:"April 2023",where:"Prague",coach:"Marina Maljković",
  st:[["PG","Olcay Çakır",11],["SG","Kayla McBride",16],["SF","Alina Iagupova",7],["PF","Breanna Stewart",35],["C","Emma Meesseman",10]],bench:[["Satou Sabally",11],["Mina Đorđević",0],["Alperi Onar",4],["Ivana Raca",0],["Courtney Vandersloot",5],["Merve Aydın",0],["Kiah Stokes",0]]}
];
/* volleyball squads: [number|null, name, pos|null] */
const VB_SQUADS=[
 {id:"2010",label:"2010 World champions",title:"FIVB Club World Championship",note:"Unbeaten in Doha, 3–0 over Sollys Osasco in the final",
  sq:[[1,"Katarzyna Skowrońska","OP"],[3,"Nihan Güneyligil","L"],[4,"Songül Dikmen","L"],[5,"Lioubov Sokolova","OP"],[6,"Ergül Avcı","MB"],[7,"Fofão","S"],[8,"İpek Soroğlu","MB"],[9,"Seda Tokatlıoğlu","OP"],[10,"Yağmur Koçyiğit","OH"],[11,"Christiane Fürst","MB"],[12,"Çiğdem Can Rasna","MB"],[13,"Nataša Osmokrović","OH"],[14,"Eda Erdem","MB"],[15,"Zülfiye Gündoğdu","S"],[17,"Naz Aydemir","S"]]},
 {id:"2012",label:"2012 Champions of Europe",title:"CEV Champions League Final",note:"3–0 over RC Cannes in Baku, 25 March 2012 · coach Zé Roberto",
  sq:[[1,"Fabiana Claudino","MB"],[3,"Nihan Güneyligil","L"],[4,"Merve Dalbeler","L"],[5,"Liubov Shashkova","OH"],[6,"Yağmur Koçyiğit","OH"],[7,"Duygu Bal",null],[9,"Seda Aslanyürek",null],[10,"Kim Yeon-koung","OH"],[11,"Naz Aydemir","S"],[12,"Zeynep Seda Eryüz",null],[14,"Eda Erdem","MB"],[15,"Logan Tom","OH"]]},
 {id:"2024",label:"2023–24 double winners",title:"Turkish League and Cup",note:"Announced squad for 2023–24 · coach Stefano Lavarini",
  sq:[[null,"Bojana Drča","S"],[null,"Buse Ünal","S"],[null,"Melissa Vargas","OP"],[null,"Magdalena Stysiak","OP"],[null,"Meryem Boz","OP"],[null,"Ana Cristina de Souza","OH"],[null,"Arina Fedorovtseva","OH"],[null,"Meliha Diken","OH"],[null,"Ada Germen","OH"],[null,"Irina Fetisova","MB"],[null,"Eda Erdem","MB"],[null,"Aslı Kalaç","MB"],[null,"Ergül Avcı","MB"],[null,"Cansu Çetin","L"],[null,"Gizem Örge","L"]]},
 {id:"2025",label:"2024–25 squad",title:"Turkish Cup winners",note:"Season squad with shirt numbers",
  sq:[[1,"Gizem Örge","L"],[3,"Magdalena Stysiak","OP"],[5,"Özlem Güven","L"],[8,"Aslı Kalaç","MB"],[9,"Meliha İsmailoğlu","OH"],[11,"Hristina Ruseva","MB"],[12,"Ana Cristina de Souza","OH"],[14,"Eda Erdem","MB"],[15,"Arelya Karasoy","S"],[16,"Elitsa Vasileva","OH"],[17,"Bojana Drča","S"],[18,"Dicle Nur Babat","MB"],[41,"Liza Safronova","OH"],[44,"Melissa Vargas","OP"]]}
];
const VB_AWARDS={"Katarzyna Skowrońska":"I was MVP and top scorer of the 2010 Club World Championship.","Kim Yeon-koung":"I was MVP and top scorer of the 2012 Champions League Final Four.","Naz Aydemir":"I was named best setter of the 2012 Champions League Final Four.","Eda Erdem":"I've captained the team since 2014.","Seda Tokatlıoğlu":"I captained the team in 2005–06 and again from 2011 to 2014.","Çiğdem Can Rasna":"I was club captain from 2008 to 2011.","Melissa Vargas":"I'm the top scorer for Turkey's national team."};
const ALIAS2={"Bobby Dixon":["ali muhammed","dixon"],"Ali Muhammed":["bobby dixon","dixon","muhammed"],"Seda Tokatlıoğlu":["seda aslanyurek","aslanyurek","seda"],"Seda Aslanyürek":["seda tokatlioglu","tokatlioglu","seda"],"Eda Erdem":["eda erdem dundar","eda","erdem"],"Eda Erdem Dündar":["eda","erdem"],"Meliha Diken":["meliha ismailoglu","ismailoglu","meliha"],"Meliha İsmailoğlu":["meliha diken","diken","meliha"],"Naz Aydemir":["naz","naz aydemir akyol"],"Kim Yeon-koung":["kim","yeon koung"],"Fabiana Claudino":["fabiana"],"Fofão":["fofao"],"Wade Baldwin IV":["baldwin","wade baldwin"],"Nigel Hayes-Davis":["hayes davis","hayes","nhd"],"Bojan Bogdanović":["bojan"],"Gabby Williams":["gabby"],"Satou Sabally":["satou"],"Nyara Sabally":["nyara"],"Ana Cristina de Souza":["ana cristina"],"Logan Tom":["logan"],"Julie Allemand":["allemand"]};
const DATA_NOTE={MB:"Lineups come from Final Four box scores.",WB:"Lineups come from EuroLeague Women final box scores.",VB:"Squads come from tournament squad lists, match sheets and club announcements."};

/* Timeline decks */
const ord=n=>n+(n%100>=11&&n%100<=13?"th":{1:"st",2:"nd",3:"rd"}[n%10]||"th");
const MB_EVENTS=(()=>{const e=[];[1957,1959,1965,1991,2007,2008,2010,2011,2014,2016,2017,2018,2022,2024,2025,2026].forEach((y,i)=>e.push([y,`Turkish champions for the ${ord(i+1)} time`,"Titles"]));
 [1967,2010,2011,2013,2016,2019,2020,2024,2025,2026].forEach((y,i)=>e.push([y,`The ${ord(i+1)} Turkish Cup win`,"Cups"]));
 [["Aydın Örs",2004],["Bogdan Tanjević",2007],["Neven Spahija",2010],["Simone Pianigiani",2012],["Željko Obradović",2013],["Igor Kokoškov",2020],["Aleksandar Đorđević",2021],["Dimitris Itoudis",2022],["Šarūnas Jasikevičius",2023]].forEach(([n,y])=>e.push([y,`${n} takes over as head coach`,"Coaches"]));
 [[2015,"Madrid"],[2016,"Berlin"],[2017,"Istanbul"],[2018,"Belgrade"],[2019,"Vitoria-Gasteiz"],[2024,"Berlin"],[2025,"Abu Dhabi"],[2026,"Athens"]].forEach(([y,c])=>e.push([y,`A Final Four in ${c}`,"Europe"]));
 e.push([2012,"First Turkish club to beat an NBA team","Firsts"],[2012,"Home games move to the Ülker Sports Arena","Arenas"],[2010,"Home games move to the Sinan Erdem Dome","Arenas"],[2022,"The Fenerbahçe Basketball Museum opens","Arenas"],[2012,"Mirsad Türkcan's number 6 is retired","Legends"],[2014,"Ömer Onan's number 7 is retired","Legends"],[2025,"İbrahim Kutluay's shirt is retired","Legends"],[1913,"The basketball department is founded","Firsts"]);return e})();
const WB_EVENTS=(()=>{const e=[];[1999,2002,2004,2006,2007,2008,2009,2010,2011,2012,2013,2016,2018,2019,2021,2022,2023,2024,2025,2026].forEach((y,i)=>e.push([y,`Super League champions for the ${ord(i+1)} time`,"Titles"]));
 [[2013,"Lose the EuroLeague final"],[2014,"Lose a second straight EuroLeague final"],[2017,"Lose the EuroLeague final again"],[2022,"Fourth EuroLeague final defeat"],[2023,"First EuroLeague Women title, in Prague"],[2024,"Second EuroLeague title, in Mersin"],[2026,"Third EuroLeague title, in Zaragoza"],[2005,"Runners-up in the EuroCup"],[2023,"First FIBA Europe SuperCup win"]].forEach(([y,t])=>e.push([y,t,"Europe"]));
 [["Zafer Kalaycıoğlu",2000],["Roberto Íñiguez",2012],["Víctor Lapeña",2019],["Marina Maljković",2022],["Miguel Méndez",2025]].forEach(([n,y])=>e.push([y,`${n} becomes head coach`,"Coaches"]));
 e.push([2012,"Birsel Vardarlı becomes captain","Captains"],[2023,"Alperi Onar becomes captain","Captains"],[2019,"Birsel Vardarlı's number 7 is retired","Legends"],[1954,"The women's basketball team is formed","Firsts"],[2024,"A perfect 35–0 league season","Records"],[2026,"A 46–1 season and every trophy won","Records"]);return e})();
const VB_EVENTS=(()=>{const e=[];[2009,2010,2011,2015,2017,2023,2024].forEach((y,i)=>e.push([y,`Turkish League champions (title ${i+1} in the current format)`,"Titles"]));
 [2010,2015,2017,2024,2025].forEach((y,i)=>e.push([y,`The ${ord(i+1)} Turkish Cup win`,"Cups"]));
 [["Jan de Brandt",2009],["Zé Roberto",2010],["Kamil Söz",2012],["Marcello Abbondanza",2013],["Zoran Terzić",2018],["Stefano Lavarini",2023],["Marco Fenoglio",2024]].forEach(([n,y])=>e.push([y,`${n} becomes head coach`,"Coaches"]));
 e.push([1928,"Sabiha Gürayman founds the women's team","Firsts"],[1954,"The women's team is refounded","Firsts"],[1977,"The section closes for lack of funds","Firsts"],[2010,"Runners-up in the Champions League","Europe"],[2010,"Club World Champions in Doha","Europe"],[2011,"Third in the Champions League","Europe"],[2012,"Champions League winners in Baku","Europe"],[2013,"Runners-up in the CEV Cup","Europe"],[2014,"CEV Cup winners at home","Europe"],[2016,"Third in the Champions League","Europe"],[2014,"Eda Erdem becomes captain","Captains"],[2008,"Çiğdem Can Rasna becomes captain","Captains"],[2014,"Men win the CEV Challenge Cup","Men"],[2009,"Men win the Balkan Cup","Men"],[2013,"Men win a second Balkan Cup","Men"]);return e})();
const CLUB_EVENTS=[[1907,"Fenerbahçe is founded in Kadıköy","Club"],[1910,"Colours change to yellow and navy","Club"],[1910,"Hikmet Topuzer designs the badge","Club"],[1910,"The rowing department is founded","Rowing"],[1910,"The sailing branch is founded","Sailing"],[1913,"Athletics, basketball and swimming departments open","Club"],[1914,"The boxing department is founded","Boxing"],[1917,"Win at the Heybeliada races, Turkey's first official sailing competition","Sailing"],[1918,"Atatürk visits the clubhouse on 3 May","Club"],[1928,"Table tennis and women's volleyball departments open","Club"],[1932,"The Kuşdili fire destroys the club's records","Club"],[1936,"Two club sailors compete at the Berlin Olympics","Sailing"],[1948,"Ruhi Sarıalp wins Olympic bronze","Athletics"],[1954,"The women's basketball team is formed","Basketball"],[1955,"Tonguç Türsan wins Mediterranean Games silver in rowing","Rowing"],[1968,"Football wins the Balkans Cup","Football"],[1993,"First men's European Champion Clubs' Cup in athletics","Athletics"],[1995,"The women's football team is founded","Women's football"],[1999,"Boxing: runners-up in the women's European Champions Cup","Boxing"],[2002,"Tuğçe Subaşı becomes Laser 4.7 world champion","Sailing"],[2004,"Eşref Apak wins Olympic silver in the hammer","Athletics"],[2010,"First women's European Champion Clubs' Cup in athletics","Athletics"],[2012,"Women's table tennis wins the ETTU Cup","Table tennis"],[2015,"Women's table tennis wins the Champions League","Table tennis"],[2016,"The esports branch is founded","Esports"],[2016,"Yasmani Copello wins Olympic bronze","Athletics"],[2017,"Ramil Guliyev becomes 200 m world champion","Athletics"],[2019,"Wheelchair basketball wins EuroCup 3","Wheelchair basketball"],[2021,"The women's football team is refounded","Women's football"],[2023,"Wheelchair basketball wins EuroCup 2","Wheelchair basketball"],[2024,"Wheelchair basketball wins EuroCup 1","Wheelchair basketball"],[2026,"Women's football win the Super League","Women's football"],[2014,"Men's volleyball wins the CEV Challenge Cup","Volleyball"],[2010,"Women's volleyball becomes Club World Champion","Volleyball"],[2017,"Men's basketball wins the EuroLeague","Basketball"],[2023,"Women's basketball wins the EuroLeague","Basketball"]];

/* Other branches: Which Branch? and Memory */
const BR_FACTS=[
 ["Ramil Guliyev became 200 m world champion in 2017.","Athletics"],["Eşref Apak won Olympic silver in the hammer throw in 2004.","Athletics"],["The women won the European Champion Clubs' Cup eight times between 2010 and 2019.","Athletics"],["Karin Melis Mey won World Championship bronze in the long jump in 2009.","Athletics"],["Holds a record 20 men's league titles in Turkey.","Athletics"],
 ["Tonguç Türsan won Mediterranean Games silver in 1955, Turkey's first international success in the sport.","Rowing"],["Has won a record 44 Turkish championships.","Rowing"],["Its clubhouse stood by the Kurbağalıdere, with a pier in front.","Rowing"],
 ["Won the Heybeliada races in 1917, Turkey's first official competition in the sport.","Sailing"],["Tuğçe Subaşı became world champion in the Laser 4.7 class in 2002.","Sailing"],["Behzat Baydar and Harun Ülman competed at the 1936 Berlin Olympics in the Star class.","Sailing"],
 ["The women won the European Champions League without losing a match in 2015.","Table tennis"],["Won the ETTU Cup in 2012 and again in 2013.","Table tennis"],["The men reached the ETTU Cup final in 2008, the best result by a Turkish team.","Table tennis"],
 ["Has won nine world championship golds and five Olympic silvers.","Boxing"],["Described as the most successful department of its kind in Turkey, founded in 1914.","Boxing"],
 ["Won EuroCup 3 in 2019, EuroCup 2 in 2023 and EuroCup 1 in 2024.","Wheelchair basketball"],["Turkish champions in 1999, 2000, 2019, 2022, 2023 and 2024.","Wheelchair basketball"],
 ["Founded in 1995, refounded in 2021, and league champions in 2025–26.","Women's football"],
 ["Won three League of Legends Championship League titles.","Esports"],
 ["Holds a record 33 women's national championships.","Swimming"],
 ["Won a European cup on the same day as the women's CEV Cup win in 2014.","Men's volleyball"],["Won the Balkan Cup in 2009 and 2013.","Men's volleyball"]
];
const BR_NAMES=["Athletics","Rowing","Sailing","Table tennis","Boxing","Wheelchair basketball","Women's football","Esports","Swimming","Men's volleyball"];
const MEM_PAIRS=[["Ramil Guliyev","Athletics"],["Tonguç Türsan","Rowing"],["Tuğçe Subaşı","Sailing"],["Melis Budak","Table tennis"],["9 world golds","Boxing"],["EuroCup 1 · 2024","Wheelchair basketball"],["League of Legends","Esports"],["Champions 2025–26","Women's football"],["33 women's titles","Swimming"],["Challenge Cup 2014","Men's volleyball"],["Sabiha Gürayman","Women's volleyball"],["Alex de Souza","Football"]];

/* Season snapshot, researched 6 November 2026; fixtures checked against fenerbahce.org on 11 November 2026. r: [date, comp, H/A/N, opponent, fbScore, oppScore, note?]  n: [date, time|"", comp, H/A, opponent] */
const ASOF="13 November 2026",ASOF_ISO="2026-11-13";
const LIVE={
football:{
  sources:[["fenerbahce.org fixtures","https://www.fenerbahce.org/fikstur"],["Sporx fixtures","https://www.sporx.com/fenerbahce-fiksturu-ve-mac-sonuclari"],["Goal.com table","https://www.goal.com/tr/ligler/super-lig/puan-durumu/482ofyysbdbeoxauk19yg7tdt"],["Sporx: Arca Çorum 0–5 Fenerbahçe","https://www.sporx.com/arca-corum-fenerbahce-maci-canli-5904799"],["SoccerNews top scorers","https://www.soccernews.com/soccer-stats/turkish-super-lig/top-scorers-assists/2026-27/"],["UCL league phase","https://en.wikipedia.org/wiki/2026%E2%80%9327_UEFA_Champions_League_league_phase"]],
  season:"2026-27",
  summary:[["6th","Süper Lig"],["19th","Champions League"],["Muriqi 7","League goals (top scorer)"]],
  last:[
    ["2026-11-08","Süper Lig","A","Arca Çorum",5,0,"Week 11",{fb:[["Mason Greenwood","12'"],["İrfan Can Kahveci","21'"],["İrfan Can Kahveci","56'"],["Mason Greenwood","63'"],["Oğuz Aydın","75'"]],op:[],v:"Çorum City Stadium",rep:{en:"Mason Greenwood and İrfan Can Kahveci both scored twice and Oğuz Aydın added a fifth in a comfortable away win.",tr:"Mason Greenwood ve İrfan Can Kahveci ikişer gol attı, Oğuz Aydın da beşinci golü ekledi: rahat bir deplasman galibiyeti.",de:"Mason Greenwood und İrfan Can Kahveci trafen jeweils doppelt, Oğuz Aydın legte das fünfte Tor nach. Ein ungefährdeter Auswärtssieg.",es:"Mason Greenwood e İrfan Can Kahveci marcaron dos goles cada uno y Oğuz Aydın añadió el quinto en una cómoda victoria a domicilio.",fr:"Mason Greenwood et İrfan Can Kahveci ont tous deux signé un doublé, et Oğuz Aydın a ajouté le cinquième but lors d'une victoire facile à l'extérieur.",ar:"سجّل ماسون غرينوود وإرفان جان كهوجي هدفين لكل منهما، وأضاف أوغوز أيدن الهدف الخامس في فوز مريح خارج الأرض."},src:["Sporx","https://www.sporx.com/arca-corum-fenerbahce-maci-canli-5904799"],hl:[["beIN SPORTS","https://beinsports.com.tr/haber/arca-corum-fk-fenerbahce"]]}],
    ["2026-11-04","Champions League","H","Liverpool",3,2,"League phase, matchday 4",{fb:[["Mason Greenwood","29'"],["Archie Brown","73'"],["Vedat Muriqi","79'"]],op:[["Trey Nyoni","25'"],["Alexander Isak","69'"]],v:"Şükrü Saracoğlu Stadium",rep:{en:"Fenerbahçe came from behind twice, and Vedat Muriqi scored the winner in the 79th minute.",tr:"Fenerbahçe iki kez geriye düştüğü maçta geri döndü ve galibiyet golünü 79. dakikada Vedat Muriqi attı.",de:"Fenerbahçe lag zweimal zurück und kam beide Male zurück. Vedat Muriqi erzielte in der 79. Minute den Siegtreffer.",es:"El Fenerbahçe remontó dos veces y Vedat Muriqi marcó el gol de la victoria en el minuto 79.",fr:"Fenerbahçe est revenu deux fois au score, et Vedat Muriqi a marqué le but de la victoire à la 79e minute.",ar:"عاد فنربخشة في النتيجة مرتين، وسجّل فيدات موريكي هدف الفوز في الدقيقة 79."},src:["Hürriyet Daily News","https://www.hurriyetdailynews.com/fenerbahce-stuns-liverpool-in-champions-league-229045"]}],
    ["2026-10-31","Süper Lig","H","Göztepe",1,2,"",{fb:[["Matteo Guendouzi","45+1'"]],op:[["Sinclair Armstrong","76'"],["Andre Henrique","78'"]],v:"Şükrü Saracoğlu Stadium",rep:{en:"Matteo Guendouzi put Fenerbahçe ahead just before half-time, but Göztepe scored twice in three minutes late on.",tr:"Matteo Guendouzi ilk yarının bitimine az kala Fenerbahçe'yi öne geçirdi, ancak Göztepe maçın sonlarında üç dakika içinde iki gol buldu.",de:"Matteo Guendouzi brachte Fenerbahçe kurz vor der Pause in Führung, doch Göztepe traf spät zweimal innerhalb von drei Minuten.",es:"Matteo Guendouzi adelantó al Fenerbahçe justo antes del descanso, pero el Göztepe marcó dos goles en tres minutos en el tramo final.",fr:"Matteo Guendouzi a donné l'avantage à Fenerbahçe juste avant la mi-temps, mais Göztepe a marqué deux fois en trois minutes en fin de match.",ar:"منح ماتيو غندوزي التقدّم لفنربخشة قبيل نهاية الشوط الأول، لكن غوزتيبي سجّل هدفين في ثلاث دقائق قرب النهاية."},src:["Cumhuriyet","https://www.cumhuriyet.com.tr/spor/goztepe-2-golle-guldu-fenerbahce-ye-kadikoy-de-buyuk-sok-2552027"]}],
    ["2026-10-26","Süper Lig","A","Galatasaray",1,2,"Derby",{fb:[["İrfan Can Kahveci","62'"]],op:[["Victor Osimhen","29'"],["Victor Osimhen","44'"]],v:"RAMS Park",rep:{en:"Victor Osimhen scored twice before half-time and İrfan Can Kahveci pulled one back with an overhead kick. Archie Brown and Abdülkerim Bardakcı were sent off after the final whistle.",tr:"Victor Osimhen ilk yarı bitmeden iki gol attı, İrfan Can Kahveci rövaşata ile farkı bire indirdi. Archie Brown ve Abdülkerim Bardakcı maçın bitiş düdüğünden sonra kırmızı kart gördü.",de:"Victor Osimhen traf vor der Pause zweimal, İrfan Can Kahveci verkürzte per Fallrückzieher. Archie Brown und Abdülkerim Bardakcı sahen nach dem Schlusspfiff Rot.",es:"Victor Osimhen marcó dos goles antes del descanso e İrfan Can Kahveci recortó distancias de chilena. Archie Brown y Abdülkerim Bardakcı fueron expulsados tras el pitido final.",fr:"Victor Osimhen a marqué deux fois avant la pause et İrfan Can Kahveci a réduit l'écart d'un retourné acrobatique. Archie Brown et Abdülkerim Bardakcı ont été expulsés après le coup de sifflet final.",ar:"سجّل فيكتور أوسيمين هدفين قبل نهاية الشوط الأول، وقلّص إرفان جان كهوجي الفارق بركلة مقصّية. وطُرد آرتشي براون وعبد الكريم بارداكجي بعد صافرة النهاية."},src:["Daily Sabah","https://www.dailysabah.com/sports/football/galatasaray-beat-fenerbahce-2-1-in-fiery-derby-to-extend-league-lead"]}],
    ["2026-10-20","Champions League","H","Slavia Praha",2,2,"League phase, matchday 3"],
    ["2026-10-17","Süper Lig","H","Alanyaspor",3,0],
    ["2026-10-14","Champions League","A","Aston Villa",0,6,"League phase, matchday 2"],
    ["2026-10-10","Süper Lig","A","Rizespor",3,0],
    ["2026-09-20","Süper Lig","H","Eyüpspor",8,0],
    ["2026-09-14","Süper Lig","A","Gaziantep FK",0,0],
    ["2026-09-10","Champions League","H","Roma",1,1,"League phase, matchday 1"],
    ["2026-09-05","Süper Lig","H","Beşiktaş",1,2,"Derby"],
    ["2026-08-30","Süper Lig","A","Samsunspor",2,0],
    ["2026-08-26","Champions League","A","Lyon",2,1,"Play-off, 2nd leg: through 3-2 on aggregate"],
    ["2026-08-22","Süper Lig","H","Konyaspor",4,2],
    ["2026-08-18","Champions League","H","Lyon",1,1,"Play-off, 1st leg"],
    ["2026-08-15","Süper Lig","A","Gençlerbirliği",1,2,"Opening day"],
    ["2026-08-11","Champions League","A","Sturm Graz",1,0,"3rd qualifying round, 2nd leg"],
    ["2026-08-05","Champions League","H","Sturm Graz",2,0,"3rd qualifying round, 1st leg"],
    ["2026-07-29","Champions League","A","Górnik Zabrze",1,1,"2nd qualifying round, 2nd leg"],
    ["2026-07-21","Champions League","H","Górnik Zabrze",1,0,"2nd qualifying round, 1st leg"]],
  next:[
    ["2026-11-21", "19:00", "Süper Lig", "A", "Kocaelispor"],
    ["2026-11-25", "23:00", "Champions League", "A", "Shakhtar Donetsk"],
    ["2026-11-29", "19:00", "Süper Lig", "H", "Erzurumspor"],
    ["2026-12-05", "19:00", "Süper Lig", "A", "Başakşehir"],
    ["2026-12-09", "23:00", "Champions League", "A", "LASK"],
    ["2026-12-13", "19:00", "Süper Lig", "H", "Trabzonspor"],
    ["2026-12-18", "20:00", "Süper Lig", "A", "Kasımpaşa"],
    ["2027-01-17", "", "Süper Lig", "H", "Amed SFK"],
    ["2027-01-20", "20:45", "Champions League", "H", "Villarreal"],
    ["2027-01-24", "", "Süper Lig", "H", "Gençlerbirliği"],
    ["2027-01-27", "23:00", "Champions League", "A", "Atlético Madrid"]],
  timeNote:"Kick-off times are Turkey time.",
  tables:[
    {comp:"Süper Lig",sub:"After matchday 11",cols:["P","W","D","L","GF","GA","GD","Pts"],key:7,
     rows:[["Galatasaray",11,9,1,1,27,15,"+12",28],["Trabzonspor",11,8,1,2,26,8,"+18",25],["Amed SFK",11,7,2,2,28,15,"+13",23],["Beşiktaş",11,7,1,3,23,12,"+11",22],["Kasımpaşa",11,5,5,1,17,11,"+6",20],["Fenerbahçe",11,6,1,4,29,10,"+19",19],["Kocaelispor",11,6,1,4,13,9,"+4",19],["Başakşehir",11,5,2,4,19,17,"+2",17],["Arca Çorum",11,5,1,5,21,21,"0",16],["Göztepe",11,4,3,4,22,19,"+3",15],["Rizespor",11,4,2,5,13,16,"−3",14],["Erzurumspor",11,4,2,5,10,17,"−7",14],["Alanyaspor",11,3,3,5,9,18,"−9",12],["Gençlerbirliği",11,3,2,6,12,21,"−9",11],["Konyaspor",11,2,2,7,6,14,"−8",8],["Gaziantep FK",11,2,2,7,9,19,"−10",8],["Samsunspor",11,2,1,8,11,26,"−15",7],["Eyüpspor",11,1,0,10,3,30,"−27",3]]},
    {comp:"Champions League",sub:"League phase after matchday 4 · points only, teams on equal points share a rank",cols:["Pts"],key:0,tied:true,note:"After all eight matchdays, the top 8 go straight to the last 16, 9th to 24th go into the knockout play-off and the rest are out.",
     rows:[["Paris Saint-Germain",12],["Real Madrid",12],["Arsenal",10],["Como",9],["Barcelona",9],["Aston Villa",9],["Manchester City",9],["Liverpool",9],["Club Brugge",9],["Sporting CP",9],["Real Betis",9],["Borussia Dortmund",9],["Bayern München",8],["Stuttgart",7],["Inter",6],["LASK",6],["Manchester United",6],["Galatasaray",6],["Fenerbahçe",5],["Roma",4],["Shakhtar Donetsk",4],["Viking",4],["Atlético Madrid",4],["PSV",4],["Bodø/Glimt",4],["Porto",3],["Napoli",3],["Villarreal",3],["AEK Athens",3],["RB Leipzig",3],["Sabah",3],["Feyenoord",3],["Lens",3],["Slavia Praha",1],["Lille",1],["Slovan Bratislava",0]]},
    {comp:"Turkish Cup",sub:"Fenerbahçe join at a later round",note:"No ties scheduled yet."}]},
basketball:{
  sources:[["fenerbahce.org fixtures","https://www.fenerbahce.org/fikstur"],["Sportschau: Paris 111–109 Fenerbahçe and EuroLeague table","https://www.sportschau.de/live-und-ergebnisse/basketball/euroleague-basketball/ma12385871/paris-basketball_fenerbahce/blitztabelle"],["Fener.org: Paris 111–109 Fenerbahçe","https://www.fener.org/index.php/2026/11/12/paris-basketball-111-109-fenerbahce-tarfin/"],["beIN Sports: Bursaspor 59–78 Fenerbahçe","https://beinsports.com.tr/lig/basketbol-super-ligi"],["beIN Sports BSL","https://beinsports.com.tr/lig/basketbol-super-ligi"],["BetExplorer fixtures","https://www.betexplorer.com/basketball/team/fenerbahce/rDhoZR1l/"],["Fanatik","https://www.fanatik.com.tr/takim/fenerbahce/basketbol/fikstur/"]],
  season:"2026-27",
  summary:[["7th","EuroLeague · 7–4"],["3rd","BSL · 5–2"],["1","Trophy won this autumn"]],
  last:[
    ["2026-11-11","EuroLeague","A","Paris Basketball",109,111,"Round 11 · after overtime"],
    ["2026-11-07","BSL","A","Bursaspor",78,59,"Week 7"],
    ["2026-11-05","EuroLeague","H","Baskonia",84,65,"Round 10"],
    ["2026-11-01","BSL","H","TOFAŞ",88,77,"Week 6"],
    ["2026-10-29","EuroLeague","A","Real Madrid",76,95,"Round 9"],
    ["2026-10-27","EuroLeague","A","Valencia Basket",78,86,"Round 8"],
    ["2026-10-25","BSL","A","Karşıyaka",97,72,"Week 5"],
    ["2026-10-23","EuroLeague","A","Olympiacos",64,61,"Round 7"],
    ["2026-10-18","BSL","H","Aliağa Petkimspor",77,82,"Week 4"],
    ["2026-10-15","EuroLeague","H","Partizan",74,65,"Round 6"],
    ["2026-10-10","BSL","A","Glint Çayırova",100,85,"Week 3"],
    ["2026-10-13","EuroLeague","H","Zalgiris Kaunas",99,80,"Round 5"],
    ["2026-10-08","EuroLeague","A","Panathinaikos",74,92,"Round 4"],
    ["2026-10-04","BSL","H","Biotekno Körfez",85,84,"Week 2"],
    ["2026-10-02","EuroLeague","H","Dubai Basketball",76,66,"Round 3"],
    ["2026-09-29","EuroLeague","H","Bayern München",100,76,"Round 2"],
    ["2026-09-27","BSL","A","Bahçeşehir Koleji",83,98,"Week 1"],
    ["2026-09-25","EuroLeague","H","Virtus Bologna",78,68,"Round 1"],
    ["2026-09-22","Presidential Cup","N","Beşiktaş",72,59,"Final: the club's 9th Presidential Cup"],
    ["2026-09","EuroLeague Super Cup","N","Dubai Basketball",85,77,"Third-place game"]],
  next:[
    ["2026-11-15", "20:30", "BSL", "H", "Anadolu Efes"],
    ["2026-11-17", "21:00", "EuroLeague", "H", "ASVEL"],
    ["2026-11-19", "22:30", "EuroLeague", "A", "Olimpia Milano"],
    ["2026-11-22", "20:30", "BSL", "A", "Beşiktaş"],
    ["2026-11-24", "23:00", "EuroLeague", "A", "Barcelona"],
    ["2026-12-03", "20:45", "EuroLeague", "H", "Crvena Zvezda"],
    ["2026-12-06", "13:00", "BSL", "H", "Trabzonspor"],
    ["2026-12-10", "20:45", "EuroLeague", "H", "Anadolu Efes"],
    ["2026-12-12", "13:00", "BSL", "A", "Bandırma Bordo"],
    ["2026-12-15", "20:45", "EuroLeague", "H", "Hapoel Tel Aviv"],
    ["2026-12-17", "20:45", "EuroLeague", "H", "Maccabi Tel Aviv"],
    ["2026-12-20", "15:30", "BSL", "H", "Türk Telekom"]],
  timeNote:"Tip-off times are Turkey time.",
  tables:[
    {comp:"EuroLeague",sub:"Regular season after round 11 · three games still to play",cols:["P","W","L","+/−"],key:1,
     zones:[[1,6,"Playoffs"],[7,10,"Play-in"],[11,20,"Out"]],
     rows:[["Panathinaikos",10,8,2,"+86"],["Valencia Basket",11,8,3,"+87"],["Olympiacos",11,8,3,"+75"],["Barcelona",10,7,3,"+28"],["Real Madrid",11,7,4,"+95"],["Crvena Zvezda",11,7,4,"+64"],["Fenerbahçe",11,7,4,"+47"],["Zalgiris Kaunas",11,7,4,"+36"],["Dubai Basketball",11,7,4,"+10"],["Hapoel Tel Aviv",11,6,5,"+35"],["Partizan",11,6,5,"+16"],["Paris Basketball",11,5,6,"−34"],["Anadolu Efes",10,4,6,"−29"],["Beşiktaş",10,4,6,"−32"],["Virtus Bologna",10,4,6,"−39"],["ASVEL",10,4,6,"−47"],["Maccabi Tel Aviv",11,3,8,"−86"],["Bayern München",11,3,8,"−92"],["Olimpia Milano",11,1,10,"−88"],["Baskonia",11,1,10,"−132"]]},
    {comp:"Basketbol Süper Ligi",sub:"After week 7 · Karşıyaka v Beşiktaş still to play · 2 points for a win, 1 for a loss",cols:["P","W","L","Pts"],key:3,
     rows:[["Türk Telekom",7,6,1,13],["Bahçeşehir Koleji",7,6,1,13],["Fenerbahçe",7,5,2,12],["Anadolu Efes",7,5,2,12],["Galatasaray",7,4,3,11],["Aliağa Petkimspor",7,4,3,11],["Trabzonspor",7,4,3,11],["Esenler Erokspor",7,4,3,11],["TOFAŞ",7,3,4,10],["Karşıyaka",6,3,3,9],["Beşiktaş",6,3,3,9],["Biotekno Körfez",7,2,5,9],["Bandırma Bordo",7,2,5,9],["Glint Çayırova",7,2,5,9],["Yukatel Denizli",7,1,6,8],["Bursaspor",7,1,6,8]]},
    {comp:"Turkish Cup",sub:"Played in February",note:"Top teams at the halfway point of the BSL qualify."}]},
"womens-basketball":{
  sources:[["fenerbahce.org fixtures","https://www.fenerbahce.org/fikstur"],["FIBA week 4 recap","https://www.fiba.basketball/en/news/recap-week-4-elw-2026-27"],["BetExplorer (Carolo)","https://www.betexplorer.com/basketball/team/flammes-carolo/n7U7tQWu/"],["NTV Spor","https://www.ntvspor.net/basketbol/fenerbahce-tarfin-euroleauge-womenda-3te-3-yapti-432060"],["Sporx","https://www.sporx.com/basketbol/tkbl/fenerbahce-tarfin-den-27-sayilik-galibiyet-SXHBQ1180451SXQ"],["Akşam: Botaş 60–88 Fenerbahçe","https://aksam.com.tr/spor/fenerbahc-tarfin-deplasmanda-farkli-kazandi/haber-1712676"]],
  season:"2026-27",
  summary:[["1st","EuroLeague Women group · 3–1"],["SuperCup","Won in October"],["Betts","Top scorer so far"]],
  last:[
    ["2026-11-07","KBSL","A","Botaş",88,60,"Week 7"],
    ["2026-11-03","EuroLeague Women","H","Valencia Basket",71,73,"Group C, round 4: first EuroLeague Women defeat since January"],
    ["2026-10-28","EuroLeague Women","H","Flammes Carolo",81,71,"Group C, round 3"],
    ["2026-10-24","KBSL","H","Turgutlu Belediyespor",84,57,"Week 5"],
    ["2026-10-21","EuroLeague Women","A","CS Rapid București",101,51,"Group C, round 2"],
    ["2026-10-17","KBSL","A","Beşiktaş BOA",69,81,"Week 4"],
    ["2026-10-14","EuroLeague Women","A","Valencia Basket",88,69,"Group C, round 1"],
    ["2026-10-07","FIBA Europe SuperCup","N","ÇBK Mersin",79,71,"Final in Mersin: trophy won"]],
  next:[
    ["2026-11-21", "14:00", "KBSL", "H", "OGM Ormanspor"],
    ["2026-11-25", "20:00", "EuroLeague Women", "H", "CS Rapid București"],
    ["2026-11-28", "19:00", "KBSL", "A", "Galatasaray"],
    ["2026-12-02", "21:00", "EuroLeague Women", "A", "Flammes Carolo"],
    ["2026-12-05", "14:00", "KBSL", "H", "İstanbul Gençlik"],
    ["2026-12-12", "14:00", "KBSL", "A", "ÇBK Mersin"]],
  timeNote:"Tip-off times are Turkey time.",
  tables:[
    {comp:"EuroLeague Women",sub:"Group C after round 4",cols:["P","W","L","PF","PA","+/−"],key:1,
     rows:[["Fenerbahçe",4,3,1,341,264,"+77"],["Flammes Carolo",4,3,1,349,274,"+75"],["Valencia Basket",4,2,2,310,283,"+27"],["CS Rapid București",4,0,4,228,407,"−179"]]},
    {comp:"Kadınlar Basketbol Süper Ligi (KBSL)",sub:"11 teams",note:"We could not find a full table we trust yet. The league results we could confirm are in the Matches tab."}]},
volleyball:{
  sources:[["fenerbahce.org fixtures","https://www.fenerbahce.org/fikstur"],["TVF standings","https://tvf.org.tr/lig/sultanlar-ligi"],["Star: THY 0–3 Fenerbahçe","https://m.star.com.tr/spor/fenerbahce-medicana-thyye-set-vermedi-yazi-2052120/"],["Vero Volley (CEV Pool C)","https://www.verovolley.com/cev-champions-league-volley-2027-la-numia-vero-volley-milano-inserita-nella-pool-c-insieme-a-fenerbahce-levallois-paris-e-budapest/"],["BetExplorer fixtures","https://www.betexplorer.com/volleyball/team/fenerbahce/h0xGjTQE/fixtures/"]],
  season:"2026-27",
  summary:[["7–0","Sultanlar Ligi, unbeaten"],["2nd","With a game in hand"],["21–3","Sets won and lost"]],
  last:[
    ["2026-11-08","Sultanlar Ligi","A","Türk Hava Yolları","3","0","Week 8 · 25-18, 25-17, 25-20"],
    ["2026-11-05","Sultanlar Ligi","H","Afyon Belediye Yüntaş","3","0","Week 7 · 25-10, 25-15, 25-18"],
    ["2026-11-01","Sultanlar Ligi","A","Galatasaray Daikin","3","0","Week 6 · 25-22, 25-18, 25-18"],
    ["2026-10-25","Sultanlar Ligi","H","Eczacıbaşı","3","1","Week 5 · 25-27, 27-25, 25-21, 25-22"],
    ["2026-10-18","Sultanlar Ligi","A","Zeren Spor","3","0","Week 4 · 25-12, 25-17, 25-18"],
    ["2026-10-11","Sultanlar Ligi","A","Beşiktaş","3","2","Week 2 · came back from 0-2 down"],
    ["2026-10-04","Sultanlar Ligi","H","Manisa BB","3","0","Week 1 · 25-12, 25-17, 25-14"]],
  next:[
    ["2026-11-15", "13:00", "Sultanlar Ligi", "H", "Nilüfer"],
    ["2026-11-18", "16:30", "Turkish Cup", "H", "Türk Hava Yolları", "Quarter-final"],
    ["2026-11-22", "16:00", "Sultanlar Ligi", "A", "Aras Kargo"],
    ["2026-11-24", "19:00", "CEV Champions League", "H", "Vasas Óbuda Budapest"],
    ["2026-11-29", "13:00", "Sultanlar Ligi", "H", "İlbank"],
    ["2026-12-03", "21:00", "CEV Champions League", "A", "Levallois Paris Saint Cloud"],
    ["2026-12-13", "13:00", "Sultanlar Ligi", "A", "Kuzeyboru"],
    ["2026-12-17", "21:30", "CEV Champions League", "A", "Numia Vero Volley Milano"],
    ["2026-12-20", "16:00", "Sultanlar Ligi", "A", "Manisa BB"],
    ["2027-01-12", "19:00", "CEV Champions League", "H", "Levallois Paris Saint Cloud"],
    ["2027-01-26", "21:00", "CEV Champions League", "A", "Vasas Óbuda Budapest"],
    ["2027-02-03", "19:00", "CEV Champions League", "H", "Numia Vero Volley Milano"]],
  timeNote:"Start times are Turkey time.",
  tables:[
    {comp:"Sultanlar Ligi",sub:"After week 8 · Fenerbahçe have a game in hand",cols:["P","W","L","Sets","Pts"],key:4,
     rows:[["VakıfBank",8,8,0,"24–4",23],["Fenerbahçe",7,7,0,"21–3",20],["Eczacıbaşı",8,6,2,"21–8",18],["Aras Kargo",8,5,3,"18–14",14],["Türk Hava Yolları",8,5,3,"16–14",14],["Kuzeyboru",8,5,3,"19–16",13],["Galatasaray",8,4,4,"16–15",14],["Göztepe",7,4,3,"13–13",11],["Nilüfer",8,2,6,"14–18",9],["Beşiktaş",8,2,6,"13–21",7],["Zeren Spor",8,2,6,"10–21",7],["İlbank",8,2,6,"8–20",6],["Afyon Belediye",8,2,6,"10–22",4],["Manisa BB",8,1,7,"8–22",5]]},
    {comp:"CEV Champions League",sub:"Pool C",cols:["P","W","L","Pts"],key:3,note:"Pool phase starts on 24 November.",
     rows:[["Fenerbahçe",0,0,0,0],["Numia Vero Volley Milano",0,0,0,0],["Levallois Paris Saint Cloud",0,0,0,0],["Vasas Óbuda Budapest",0,0,0,0]]}]},
"womens-football":{
  sources:[["fenerbahce.org fixtures","https://www.fenerbahce.org/fikstur"],["TFF league table and fixtures","https://www.tff.org/default.aspx?pageID=1000"],["Sabah: Fenerbahçe 1–0 Galatasaray","https://www.sabah.com.tr/spor/futbol/2026/11/07/kadinlar-derbisinde-kazanan-fenerbahce"],["TFF week 10 results","https://www.tff.org/default.aspx?pageID=1000"],["UEFA: Europa Cup round of 16, first legs","https://www.uefa.com/womenseuropacup/news/02aa-21f01f2a8bf1-9b2b3eabfb57-1000--women-s-europa-cup-round-of-16-first-legs-round-up-wolfs/"],["beIN Sports: Fenerbahçe 0–2 Real Sociedad","https://beinsports.com.tr/haber/fenerbahce-arsavev-real-sociedad-engelini-asamadi"]],
  season:"2026-27",label:"Women's Football",
  summary:[["3rd","Women's Super League"],["7–1–0","Won, drawn, lost"],["35–1","Goals for and against"]],
  last:[
    ["2026-11-11","Women's Europa Cup","H","Real Sociedad",0,2,"Round of 16, second leg · out, 0–4 on aggregate"],
    ["2026-11-07","Women's Super League","H","Galatasaray",1,0,"Week 10 · Ece Türkoğlu 89'"],
    ["2026-10-28","Women's Europa Cup","A","Real Sociedad",0,2,"Round of 16, first leg"],
    ["","Women's Super League","A","Giresun Sanayispor",8,0,"Week 9"],
    ["","Women's Super League","H","Haymana",5,0,"Week 7"],
    ["","Women's Super League","A","Yüksekova",1,1,"Week 6"],
    ["2026-09-30","Women's Europa Cup","H","Minsk",1,0,"Second qualifying round, second leg · 5–1 on aggregate"],
    ["","Women's Europa Cup","N","Minsk",4,1,"Second qualifying round, first leg (in Hungary)"],
    ["","Women's Super League","A","Beşiktaş",3,0,"Week 4"],
    ["2026-09-13","Women's Super League","H","Şile Bilgidoğa",12,0,"Week 3"],
    ["","Women's Super League","A","Amed",3,0,"Week 2"],
    ["","Women's Super League","H","Ankara BB Fomget",2,0,"Week 1"],
    ["2026-08-08","Women's Champions League","A","OH Leuven",1,1,"Second qualifying round · lost 2–4 on penalties"]],
  next:[
    ["2026-11-14", "14:00", "Women's Super League", "A", "Bakırköy", "Week 11"],
    ["2026-11-18", "14:00", "Women's Super League", "H", "Ünye", "Week 5, postponed"],
    ["2026-12-09", "14:00", "Women's Super League", "H", "Hakkarigücü", "Week 12"],
    ["2026-12-13", "14:00", "Women's Super League", "A", "Trabzonspor", "Week 13"],
    ["2026-12-19", "14:00", "Women's Super League", "H", "Antalyaspor", "Week 14"],
    ["2026-12-23", "14:00", "Women's Super League", "A", "Sultanbeyli Gücü", "Week 15"],
    ["2027-01-17", "14:00", "Women's Super League", "H", "Amed", "Week 17"],
    ["2027-01-24", "14:00", "Women's Super League", "A", "Şile Bilgidoğa", "Week 18"]],
  timeNote:"Women's football. The postponed week 5 home game is on 18 November; week 8 is still to be scheduled. Times are Turkey time.",
  tables:[
    {comp:"Women's Super League",sub:"After week 10 · Fenerbahçe have two games in hand",cols:["P","W","D","L","GF","GA","GD","Pts"],key:7,
     rows:[["Beşiktaş",10,7,2,1,22,6,"+16",23],["Ankara BB Fomget",10,7,1,2,51,9,"+42",22],["Fenerbahçe",8,7,1,0,35,1,"+34",22],["Trabzonspor",10,6,4,0,28,4,"+24",22],["Galatasaray",10,6,3,1,46,5,"+41",21],["Hakkarigücü",10,5,4,1,14,5,"+9",19],["Yüksekova",10,4,5,1,24,5,"+19",17],["Kayseri",9,4,3,2,19,12,"+7",15],["Amed",10,4,0,6,16,15,"+1",12],["Sultanbeyli Gücü",10,3,1,6,18,29,"−11",10],["Haymana",10,2,3,5,23,25,"−2",9],["Ünye",9,2,3,4,11,14,"−3",9],["Antalyaspor",10,2,3,5,13,26,"−13",9],["Bakırköy",10,1,1,8,11,26,"−15",1],["Şile Bilgidoğa",10,1,0,9,6,80,"−74",0],["Giresun Sanayispor",10,0,0,10,1,76,"−75",0]],
     note:"Bakırköy and Şile Bilgidoğa had 3 points deducted."},
    {comp:"Women's Europa Cup",sub:"Round of 16",note:"Out: Real Sociedad won both legs 2–0 (4–0 on aggregate)."}]},
"mens-volleyball":{
  sources:[["fenerbahce.org fixtures","https://www.fenerbahce.org/fikstur"],["TVF: Efeler Ligi week 5","https://tvf.org.tr/icerik/sms-grup-efeler-liginde-5hafta-sona-erdi-1"],["Fener.org: Fenerbahçe 3–1 Gebze","https://www.fener.org/index.php/2026/11/07/fenerbahce-medicana-3-1-gebze-belediyespor/"],["Voleybol Aktüel (week 4)","https://voleybolaktuel.com/sms-grup-efeler-liginde-4hafta-sona-erdi"],["Fanatik (week 3)","https://www.fanatik.com.tr/voleybol/efeler-liginde-3uncu-hafta-maclari-tamamlandi-2642571"],["Fanatik (week 2 fixtures)","https://www.fanatik.com.tr/voleybol/efeler-liginde-ikinci-hafta-basliyor-2642147"],["Fener.org: İBB 1–3 Fenerbahçe","https://www.fener.org/index.php/2026/10/31/ibb-spor-kulubu-1-3-fenerbahce-medicana/"]],
  season:"2026-27",label:"Men's Volleyball",
  summary:[["5th","Efeler Ligi"],["4–1","Won and lost"],["11","Points"]],
  last:[
    ["2026-11-07","Efeler Ligi","H","Gebze Belediyespor",3,1,"Week 5 · 25-21, 24-26, 25-23, 25-18"],
    ["2026-10-31","Efeler Ligi","A","İBB Spor Kulübü",3,1,"Week 4 · 21-25, 25-18, 25-21, 25-15"],
    ["","Efeler Ligi","H","Alanya Belediyespor",3,0,"Week 3 · 25-23, 25-20, 25-18"],
    ["2026-10-24","Efeler Ligi","A","Gaziantep Gençlik Spor",3,2,"Week 2"],
    ["","Efeler Ligi","H","Ziraat Bankkart",0,3,"Week 1"]],
  next:[
    ["2026-11-14", "19:00", "Efeler Ligi", "A", "Galatasaray"],
    ["2026-11-21", "19:00", "Efeler Ligi", "H", "Spor Toto"],
    ["2026-11-28", "16:00", "Efeler Ligi", "A", "Halkbank"],
    ["2026-12-05", "16:00", "Efeler Ligi", "H", "Akedaş Onikişubat"],
    ["2026-12-12", "14:00", "Efeler Ligi", "A", "Sungurlu Belediyespor"],
    ["2026-12-19", "19:00", "Efeler Ligi", "H", "Sultanbeyli Belediye Spor"],
    ["2026-12-22", "14:00", "Efeler Ligi", "A", "İstanbul Gençlik"],
    ["2026-12-26", "16:00", "Efeler Ligi", "A", "Altekma"]],
  timeNote:"Men's volleyball. Times are Turkey time.",
  tables:[
    {comp:"Efeler Ligi",sub:"After week 5",cols:["P","W","L","Pts"],key:3,
     rows:[["Halkbank",5,5,0,14],["Ziraat Bankkart",5,5,0,13],["Gebze Belediyespor",5,4,1,12],["Galatasaray",5,4,1,12],["Fenerbahçe",5,4,1,11],["Altekma",5,3,2,8],["Alanya Belediyespor",5,2,3,8],["Spor Toto",5,2,3,8],["İBB Spor Kulübü",5,2,3,6],["Akedaş Onikişubat",5,1,4,3],["Gaziantep Gençlik Spor",4,1,3,3],["İstanbul Gençlik",4,1,3,2],["Sungurlu Belediyespor",5,0,5,0],["Sultanbeyli Belediye Spor",5,0,5,-1]],
     note:"Sultanbeyli Belediye Spor had points deducted after a forfeit."}]}
};

/* ===== New content data (researched 7 November 2026) ===== */
const SEASON_POS=[["1959",1],["1959–60",2],["1960–61",1],["1961–62",2],["1962–63",3],["1963–64",1],["1964–65",1],["1965–66",4],["1966–67",2],["1967–68",1],["1968–69",4],["1969–70",1],["1970–71",2],["1971–72",3],["1972–73",2],["1973–74",1],["1974–75",1],["1975–76",2],["1976–77",2],["1977–78",1],["1978–79",3],["1979–80",2],["1980–81",10],["1981–82",3],["1982–83",1],["1983–84",2],["1984–85",1],["1985–86",5],["1986–87",5],["1987–88",8],["1988–89",1],["1989–90",2],["1990–91",5],["1991–92",2],["1992–93",5],["1993–94",2],["1994–95",4],["1995–96",1],["1996–97",3],["1997–98",2],["1998–99",3],["1999–2000",4],["2000–01",1],["2001–02",2],["2002–03",6],["2003–04",1],["2004–05",1],["2005–06",2],["2006–07",1],["2007–08",2],["2008–09",4],["2009–10",2],["2010–11",1],["2011–12",2],["2012–13",2],["2013–14",1],["2014–15",2],["2015–16",2],["2016–17",3],["2017–18",2],["2018–19",6],["2019–20",7],["2020–21",3],["2021–22",2],["2022–23",2],["2023–24",2],["2024–25",2],["2025–26",2]];

const DERBIES=[
 {opp:"Galatasaray",name:"The Intercontinental Derby",since:"First meeting: 1909",
  all:{label:"All meetings, including friendlies, as of 26 October 2026",p:407,w:150,d:125,l:132,gf:547,ga:510},
  league:{label:"Süper Lig, as of 26 October 2026",p:139,w:53,d:46,l:40,gf:166,ga:139},
  facts:["Biggest win: 6–0 at Şükrü Saracoğlu on 6 November 2002.","Galatasaray's biggest win: 7–0 in the Istanbul Football League on 12 February 1911.","Longest unbeaten run in the fixture: 18 derbies for Fenerbahçe, 1942 to 1946.","Galatasaray went more than 20 years without a league win in Kadıköy, from December 1999 to February 2020."],
  recent:[["2026-10-26","Süper Lig","A",1,2],["2026-04-26","Süper Lig","A",0,3],["2026-01-10","Super Cup final","N",2,0]]},
 {opp:"Beşiktaş",name:"The Istanbul derby with Beşiktaş",since:"First meeting: 28 November 1924, won 4–0 by Fenerbahçe",
  all:{label:"All meetings, before September 2026",p:364,w:137,d:97,l:130,gf:504,ga:463},
  league:{label:"Süper Lig, before September 2026",p:140,w:51,d:45,l:44,gf:162,ga:160},
  facts:["Beşiktaş's biggest win: 7–1 in the Dörtler tournament on 23 March 1941.","Fenerbahçe's biggest win: 7–0, a friendly on 6 December 1958.","Highest-scoring official meeting: Beşiktaş 5–4 in the TSYD Cup, 11 August 1974.","League meetings in Kadıköy: Fenerbahçe 18 wins, 15 draws, Beşiktaş 12 wins."],
  recent:[["2026-09-05","Süper Lig","H",1,2],["2026-04-05","Süper Lig","H",1,0],["2025-12-23","Turkish Cup","H",1,2]]},
 {opp:"Trabzonspor",name:"The rivalry with Trabzonspor",since:"The great rivalry of the 1970s and 1980s title races",
  all:{label:"All meetings, after February 2026",p:139,w:56,d:39,l:44,gf:184,ga:159},
  league:{label:"Süper Lig, after February 2026",p:106,w:45,d:34,l:27,gf:148,ga:113},
  facts:["A 1–1 draw with Trabzonspor on the last day of 2009–10 handed the title to Bursaspor.","Fenerbahçe won 3–2 in Trabzon on 14 February 2026.","Next meeting: 13 December 2026 in Kadıköy."],
  recent:[["2026-02-14","Süper Lig","A",3,2],["2025-09-14","Süper Lig","H",1,0],["2025-04-06","Süper Lig","H",4,1]]}];

const SQUADS={
 football:{coach:"Emre Belözoğlu",coachNote:"Signed on 3 November 2026, a week after İsmail Kartal left by mutual agreement. Assistant coach Dirk Kuyt took charge for the Göztepe and Liverpool games.",asof:"Squad list as of 3 September 2026",
  groups:[["Goalkeepers",[[31,"Ederson","Brazil"],[34,"Mert Günok","Turkey"],[13,"Tarık Çetin","Turkey"]]],
   ["Defenders",[[3,"Archie Brown","England"],[14,"Yiğit Efe Demir","Turkey"],[15,"Nathan Aké","Netherlands"],[18,"Mert Müldür","Turkey"],[21,"Kojo Peprah Oppong","Ghana"],[22,"Levent Mercan","Turkey"],[24,"Jayden Oosterwolde","Netherlands"],[27,"Nélson Semedo","Portugal"],[37,"Milan Škriniar","Slovakia"],[77,"Ognjen Mimović","Serbia"]]],
   ["Midfielders",[[5,"İsmail Yüksek","Turkey"],[6,"Mattéo Guendouzi","France"],[8,"Mert Hakan Yandaş","Turkey"],[10,"Marco Asensio","Spain"],[17,"İrfan Can Kahveci","Turkey"],[28,"Bartuğ Elmaz","Turkey"],[70,"Oğuz Aydın","Turkey"],[91,"N'Golo Kanté","France"]]],
   ["Forwards",[[7,"Kerem Aktürkoğlu","Turkey"],[9,"Romelu Lukaku","Belgium"],[11,"Mason Greenwood","England"],[19,"Vedat Muriqi","Kosovo"],[45,"Dorgeles Nene","Mali"]]]]},
 basketball:{coach:"Šarūnas Jasikevičius",asof:"Compiled from the club's 2026 signings and re-signings; may be incomplete",
  groups:[["Guards",[[0,"Shane Larkin","Turkey"],[8,"Talen Horton-Tucker","United States"],[9,"Johnny Juzang","United States"],[10,"Melih Mahmutoğlu","Turkey"],[11,"Trent Forrest","United States"],[31,"Shavon Shields","Denmark"],[43,"Ignas Sargiūnas","Lithuania"]]],
   ["Forwards",[[12,"Braxton Key","United States"],[21,"Will Clyburn","United States"],[30,"Chris Silva","Gabon"]]],
   ["Bigs",[[1,"Marcus Bingham Jr.","United States"],[4,"Nicolò Melli","Italy"],[5,"Sertaç Şanlı","Turkey"]]]]},
 "womens-basketball":{asof:"Signings announced for 2026–27; the full roster has not been published in a source we could verify",
  groups:[["New signings",[[null,"Lauren Betts","United States"],[null,"Luisa Geiselsöder","Germany"],[null,"Laura Juškaitė","Lithuania"],[null,"Leila Lacan","France"],[null,"Nell Angloma","France"],[null,"Tima Pouye","France"],[null,"Zeynep Şevval Gül","Turkey"],[null,"Manolya Kurtulmuş","Turkey"]]]],
  notes:["The team plays as Fenerbahçe Tarfin in 2026–27.","Left in the summer: Sevgi Uzun (to Galatasaray) and Tilbe Şenyürek (to Girona)."]},
 volleyball:{asof:"Confirmed for 2026–27 in club and press reports; not a full roster",
  groups:[["Confirmed players",[[null,"Eda Erdem Dündar","Turkey"],[null,"Hande Baladın","Turkey"],[null,"Alessia Orro","Italy"],[null,"Gizem Örge","Turkey"],[null,"Saliha Şahin","Turkey"],[null,"Kübra Akman","Turkey"],[null,"Sinead Jack-Kısal","Turkey"],[null,"Brenda Castillo","Dominican Republic"]]]],
  notes:["Left in the summer: Aslı Kalaç and Yaasmeen Bedart-Ghani. Agnieszka Korneluk retired."]}};

const VENUES={
 football:{name:"Şükrü Saracoğlu Stadium",area:"Kadıköy, Istanbul",cap:"47,911 seats",
  facts:["Opened in 1908 as the Union Club Field and Fenerbahçe's home ever since. The club bought it from the state in 1933.","Named after Şükrü Saracoğlu in 1998, then rebuilt stand by stand between 1999 and 2006 with a new roof.","Hosted the 2009 UEFA Cup final, won 2–1 by Shakhtar Donetsk against Werder Bremen.","Its sponsored name is Chobani Stadyumu."],
  travel:["Söğütlüçeşme station, on Marmaray and the Metrobüs line, is right next to the stadium.","Kadıköy ferry pier is about a 15-minute walk away, with boats from Eminönü and Beşiktaş."]},
 basketball:{name:"Ülker Sports and Event Hall",area:"Ataşehir, Istanbul",cap:"13,059 seats, up to 13,800 with lounges",
  facts:["Opened on 25 January 2012.","Built for about ₺200 million and designed by Ömerler Architecture.","Hosted the finals of the 2014 FIBA Women's World Championship.","Also a concert venue, with shows from Jennifer Lopez to Cirque du Soleil."],
  travel:["The hall is in Ataşehir on the Asian side. A journey planner gives the best metro or bus route on match days."]},
 "womens-basketball":{name:"Metro Enerji Sports Hall",area:"Istanbul",cap:"",
  facts:["The home court of the women's team."],travel:[]},
 volleyball:{name:"Burhan Felek Sport Hall",area:"Üsküdar, Istanbul",cap:"7,000 seats",
  facts:["Opened on 19 November 2010.","Hosted Women's CEV Champions League finals matches in 2011 and the CEV Cup final in 2012.","Both Fenerbahçe volleyball teams play their league matches here."],travel:[]}};

/* Higher or Lower: club records (Wikipedia list of records; goals list dated 2016, appearances 2019) */
const HOL_SETS=[
 {key:"goals",label:"goals for Fenerbahçe",items:[["Lefter Küçükandonyadis",215],["Melih Kotanca",172],["Alex de Souza",171],["Aykut Kocaman",167],["Naci Bastoncu",162],["Cemil Turan",127],["Fikret Arıcan",109],["Ogün Altıparmak",89],["Şeref Has",89],["Semih Şentürk",86]]},
 {key:"apps",label:"appearances for Fenerbahçe",items:[["Müjdat Yetkiner",570],["Volkan Demirel",525],["Cem Pamiroğlu",396],["Şeref Has",382],["Rüştü Reçber",381],["Gökhan Gönül",361],["Lefter Küçükandonyadis",349],["Ziya Şengül",342],["Alex de Souza",341],["Selçuk Şahin",326]]},
 {key:"titles",label:"titles",items:[["Football: Turkish championships",28],["Men's basketball: Turkish league titles",16],["Women's basketball: Turkish league titles",20],["Volleyball: Turkish league titles",15],["Rowing: Turkish championships",44],["Swimming: women's national titles",33],["Athletics: men's league titles",20],["Football: Turkish Cups",7],["Men's basketball: Turkish Cups",10],["Women's basketball: Turkish Cups",15],["Volleyball: Turkish Cups",5],["Football: Super Cups",10],["Men's basketball: Presidential Cups",9]]}];

const TABS_FULL=[["matches","Matches"],["standings","Standings"],["games","Big Games"],["trophies","Trophies"],["legends","Legends"],["history","History"],["play","Play"]];
const TABS_MORE=[["branches","Branches"],["legends","Legends"],["history","History"],["play","Play"]];
/* ===== Extension points =====
   Features plug in here instead of wrapping core functions:
   tabs(id, list)      add or reorder tabs for a branch
   panels[tab](p, s)   draw a whole tab
   afterPanel(p, s)    adjust a tab after it is drawn
   home(p)             add sections to the All branches page
   play(p, game)       adjust a Play game after it is drawn
   matchPage(b, i)     add sections to a match page
   comm()              add cards to the fan community box
   collect(o)          add numbers to the leaderboard sync
   result(game)        result-image text for a game (return null to pass)
   kan(id, o)          add data for Kanarya about a branch
   search(list)        add entries to the search index
   szPre(b, el, ...)   take over the season view (return true)
   szAfter(b, el, ...) add cards under a simulated season */
const EXT={szPre:[],tabs:[],panels:{},afterPanel:[],home:[],play:[],matchPage:[],comm:[],collect:[],result:[],kan:[],search:[],szAfter:[]};
const runExt=(k,...a)=>EXT[k].forEach(f=>f(...a));
function tabsFor(id){const base=id==="more"?TABS_MORE.slice():TABS_FULL.filter(x=>x[0]!=="play");
  if(id!=="more"){if(id==="football")base.push(["derbies","Derbies"]);base.push(["squad","Squad"],["venue","Venue"],["play","Play"])}
  if(SPORTS[id])runExt("tabs",id,base);return base}
const $=id=>document.getElementById(id);
/* date formatting: one Intl formatter per language and format, reused (building one per date was slow) */
const DTF=new Map();
function fmtDay(d,opts){if(!(d instanceof Date)||isNaN(d))return "";const k=LOC()+JSON.stringify(opts);let f=DTF.get(k);if(!f){f=new Intl.DateTimeFormat(LOC(),opts);DTF.set(k,f)}return f.format(d)}
let current="football",tab="matches",gameFilter="All",mFilter="All",mAll=false;
function esc(s){return String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]))}
function fmtDate(iso){if(iso.length===4)return iso;const full=iso.length>7;const d=new Date((full?iso:iso+"-01")+"T12:00:00");return fmtDay(d,full?{day:"numeric",month:"short",year:"numeric"}:{month:"short",year:"numeric"})}
const CUP='<svg viewBox="0 0 20 24" aria-hidden="true"><path d="M4 1h12v2h3v3c0 3-2 5-4.5 5.4C13.6 13.5 12 14.6 11 15v3h3v2H6v-2h3v-3c-1-.4-2.6-1.5-3.5-3.6C3 11 1 9 1 6V3h3V1zm-1 4v1c0 1.6.9 2.8 2.2 3.3C5 8.4 4.9 7.3 4.9 5H3zm14 0h-1.9c0 2.3-.1 3.4-.3 4.3C16.1 8.8 17 7.6 17 6V5zM5 22h10v2H5z"/></svg>';
function render(){if(current==="home"){renderHome();return}const s=SPORTS[current];applyHero(current);
  $("sport").value=current;$("heroTr").textContent=LANG==="tr"?s.label:s.tr;$("heroTitle").textContent=t(s.title);$("heroNick").textContent=t(s.nick);$("heroLede").textContent=t(s.lede);$("kitNum").textContent=s.num;
  $("stats").innerHTML=s.stats.map(([v,k])=>`<div class="stat"><span class="v">${esc(t(v))}</span><span class="k">${esc(t(k))}</span></div>`).join("");
  $("home").innerHTML=`<span class="label">${esc(t(s.home[0]))}</span><b>${esc(t(s.home[1]))}</b>`;
  const tabs=tabsFor(current);if(!tabs.some(t=>t[0]===tab))tab=tabs[0][0];
  renderTabs(tabs);$("panel").setAttribute("aria-labelledby","tab-"+tab);renderPanel();renderNextBanner()}
/* tabs come in three groups: This season, Club, Play */
/* one row of sections; Standings and Club hold a few pages each, shown as small links under the row */
const TAB_GROUP={matches:"matches",standings:"table",race:"table",squad:"squad",games:"club",trophies:"club",records:"club",europe:"club",legends:"club",history:"club",derbies:"club",venue:"club",branches:"club",play:"play"};
const GROUP_NAME={matches:"Matches",table:"Standings",squad:"Squad",club:"Club",play:"Play"},GROUP_ORDER=["matches","table","squad","club","play"];
const lastTabOf={};
function renderTabs(tabs){const el=$("tabs");el.removeAttribute("role");el.classList.add("grouped");
  const groups=GROUP_ORDER.filter(g=>tabs.some(x=>TAB_GROUP[x[0]]===g)),cur=TAB_GROUP[tab]||groups[0],sub=tabs.filter(x=>TAB_GROUP[x[0]]===cur);lastTabOf[current+cur]=tab;
  el.innerHTML=`<div class="tgroups" role="tablist" aria-label="${t("Sections")}">${groups.map(g=>`<button class="tg ${g==="play"?"play":""}" role="tab" aria-selected="${g===cur}" data-tg="${g}">${g==="play"?`<span class="ball" aria-hidden="true"></span>`:""}${t(GROUP_NAME[g])}</button>`).join("")}</div>
   ${sub.length>1?`<div class="tsub" role="tablist" aria-label="${esc(t(GROUP_NAME[cur]))}" data-grp="${cur}">${sub.map(([id,l])=>`<button class="tab" role="tab" id="tab-${id}" aria-selected="${id===tab}" tabindex="${id===tab?0:-1}" data-tab="${id}">${t(l)}</button>`).join("")}</div>`:`<span id="tab-${sub[0][0]}" hidden></span>`}`}
function renderPanel(){if(current==="home")return;const s=SPORTS[current],p=$("panel");
  if(EXT.panels[tab])EXT.panels[tab](p,s);
  else if(tab==="play")renderPlay(p);
  else if(tab==="matches")renderMatches(p);
  else if(tab==="standings")renderStandings(p);
  else if(tab==="squad")renderSquad(p);
  else if(tab==="venue")renderVenue(p);
  else if(tab==="derbies")renderDerbies(p);
  else if(tab==="history")p.innerHTML=`<h2>${t("History")}</h2><p class="intro">${esc(tf("The milestones that made {x} at Fenerbahçe what it is.",{x:lbl(s)}))}</p>${current==="football"?seasonChart():""}<ol class="timeline">${s.history.map(([y,h,x])=>`<li><span class="yr">${y}</span><div><h3>${esc(t(h))}</h3><p>${esc(t(x))}</p></div></li>`).join("")}</ol>`;
  else if(tab==="games"){const list=s.games.filter(g=>gameFilter==="All"||g.tag===gameFilter);
    p.innerHTML=`<h2>${t("Big Games")}</h2><p class="intro">${t("Wins to remember, and one or two that still hurt.")}</p><div class="filter" role="group" aria-label="${t("Filter games")}">${s.filters.map(f=>`<button data-filter="${f}" aria-pressed="${f===gameFilter}">${esc(t(f))}</button>`).join("")}</div><div class="games">${list.map(gameCard).join("")}</div>`}
  else if(tab==="legends")renderLegends(p,s);
  else if(tab==="trophies")p.innerHTML=`<h2>${t("Trophy Cabinet")}</h2><p class="intro">${t("Major honours, with one cup drawn for every title.")}</p><div class="cabinet">${s.trophies.map(([c,n,y,era],ti)=>{const hd="";const k=parseInt(c,10),cups=(k&&k<=30)?`<div class="cups">${CUP.repeat(k)}</div>`:"";return hd+`<div class="trophy card"><span class="count">${c}</span><div><h3>${esc(t(n))}</h3><p class="years">${esc(t(y))}</p>${cups}</div></div>`}).join("")}</div>`;
  else if(tab==="branches")p.innerHTML=`<h2>${t("Branches")}</h2><p class="intro">${t("The rest of the Fenerbahçe family.")}</p><div class="branches">${s.branches.map(([n,x])=>`<article class="branch card"><h3>${esc(t(n))}</h3><p>${esc(t(x))}</p></article>`).join("")}</div>`;
  runExt("afterPanel",p,s)}
function gameCard(g){const fbHome=g.home==="Fenerbahçe",chip=g.out==="win"?`<span class="chip win">${t("Win")}</span>`:g.out==="loss"?`<span class="chip loss">${t("Loss")}</span>`:`<span class="chip loss">${t("Draw")}</span>`;
  const center=g.res?`<div class="score"><span class="team ${fbHome?"fb":""}">${esc(g.home)}</span><span class="res">${esc(g.res)}</span><span class="team ${!fbHome?"fb":""}">${esc(g.away)}</span></div>`:`<div class="title">${esc(t(g.title))}</div>`;
  return `<article class="game card"><div class="meta"><span class="label">${fmtDate(g.date)}</span>${chip}</div><span class="label" style="color:var(--ink)">${esc(t(g.comp))}</span>${center}<p>${esc(t(g.note))}</p><div class="where">${esc(t(g.where))}</div></article>`}
function renderOnThisDay(){renderNextBanner()}
function syncHash(){const h=current==="home"?"all":current+(tab==="play"?"-play":"");if(location.hash.slice(1)!==h){try{history.replaceState(null,"","#"+h)}catch(e){}}}
function setSport(id,toPlay){if(id!=="home"&&!SPORTS[id])id="home";current=id;if(id==="home"){syncHash();render();return}gameFilter="All";mFilter="All";mAll=false;if(toPlay)tab="play";if(!tabsFor(id).some(x=>x[0]===tab))tab="matches";syncHash();render()}
function fromHash(){let h=location.hash.slice(1);if(h==="games")return ["football",true];const play=h.endsWith("-play");if(play)h=h.slice(0,-5);return [!h||h==="all"||h==="home"?"home":h,play]}
$("sport").addEventListener("change",e=>setSport(e.target.value));
$("tabs").addEventListener("click",e=>{const b=e.target.closest("[data-tab]");if(!b)return;tab=b.dataset.tab;syncHash();render()});
$("tabs").addEventListener("click",e=>{const g=e.target.closest("[data-tg]");if(!g)return;const tabs=tabsFor(current),grp=g.dataset.tg,first=tabs.find(x=>TAB_GROUP[x[0]]===grp);
  const keep=lastTabOf[current+grp];tab=keep&&tabs.some(x=>x[0]===keep)?keep:first[0];syncHash();render();const f=$("tabs").querySelector(`[data-tg="${grp}"]`);if(f)f.focus()});
$("tabs").addEventListener("keydown",e=>{if(e.key!=="ArrowRight"&&e.key!=="ArrowLeft")return;const btns=[...$("tabs").querySelectorAll(".tab")],i=btns.findIndex(b=>b.dataset.tab===tab),n=btns[(i+(e.key==="ArrowRight"?1:-1)+btns.length)%btns.length];tab=n.dataset.tab;syncHash();render();$("tab-"+tab).focus()});
$("panel").addEventListener("click",e=>{const f=e.target.closest("[data-filter]");if(f){gameFilter=f.dataset.filter;renderPanel();return}
  const m=e.target.closest("[data-mf]");if(m){mFilter=m.dataset.mf;mAll=false;renderPanel();return}
  if(e.target.closest("[data-mall]")){mAll=!mAll;renderPanel();return}
  const g=e.target.closest("[data-goto]");if(g){tab=g.dataset.goto;syncHash();render();$("tabs").scrollIntoView({block:"nearest"})}});
window.addEventListener("hashchange",()=>{const [h,play]=fromHash();if((SPORTS[h]||h==="home")&&(h!==current||(play&&tab!=="play")))setSport(h,play)});

/* ---------- Matches & Standings (season snapshot) ---------- */
const DAY=864e5;
/* result marker: coloured dot, with the word for screen readers */
function rdot(o){return `<span class="rdot ${o}" role="img" aria-label="${esc(t({W:"Win",D:"Draw",L:"Loss"}[o]))}" title="${esc(t({W:"Win",D:"Draw",L:"Loss"}[o]))}"></span>`}
function isoDay(iso){return new Date(iso+"T12:00:00")}
function mDate(iso,short){if(!iso)return "";if(iso.length===7)return fmtDay(new Date(iso+"-15T12:00:00"),{month:"short",year:"numeric"});return fmtDay(isoDay(iso),short?{day:"numeric",month:"short"}:{weekday:"short",day:"numeric",month:"short",year:"numeric"})}
function outcome(r){const a=+r[4],b=+r[5];return a>b?"W":a<b?"L":"D"}
function compKey(c){return c.replace(/\s+/g,"-").toLowerCase()}
function todayISO(){const d=new Date();return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0")}
function renderMatches(p){const L=LIVE[current];if(!L){p.innerHTML="";return}
  const comps=["All",...new Set([...L.last.map(r=>r[1]),...L.next.map(r=>r[2])])];
  const today=todayISO(),fut=L.next.filter(n=>!n[0]||n[0]>=today),past=L.next.filter(n=>n[0]&&n[0]<today);
  const nx=fut[0],form=L.last.slice(0,5).reverse();
  const res=L.last.filter(r=>mFilter==="All"||r[1]===mFilter),shown=mAll?res:res.slice(0,8);
  const up=fut.filter(n=>mFilter==="All"||n[2]===mFilter);
  const wdl=L.last.reduce((a,r)=>(a[outcome(r)]++,a),{W:0,D:0,L:0});
  const hero=nx?(()=>{const days=Math.round((isoDay(nx[0])-isoDay(today))/DAY);return `<article class="nextup card"><span class="label">${t("Next up")} · ${esc(t(nx[2]))}</span>
      <div class="nx-teams"><span class="${nx[3]==="H"?"fb":""}">${esc(nx[3]==="H"?"Fenerbahçe":nx[4])}</span><span class="vs">${t("vs")}</span><span class="${nx[3]==="A"?"fb":""}">${esc(nx[3]==="A"?"Fenerbahçe":nx[4])}</span></div>
      <div class="nx-meta"><b>${mDate(nx[0])}</b>${nx[1]?`<span>${esc(nx[1])}</span>`:""}<span class="chip">${t(nx[3]==="H"?"Home":"Away")}</span><span class="chip win">${days===0?t("Today"):days===1?t("Tomorrow"):tf("In {n} days",{n:days})}</span></div>${calLinks(nx,true)}<div id="predBox" class="predbox"></div></article>`})():`<article class="nextup card"><span class="label">${t("Next up")}</span><p class="muted">${t("No upcoming fixtures in this snapshot.")}</p></article>`;
  const intro="",
    msum=`<div class="msum">${L.summary.map(([v,k])=>`<div class="mstat"><b>${esc(t(v))}</b><span>${esc(t(k))}</span></div>`).join("")}</div>`;
  const formCard=`<article class="formcard card"><span class="label">${t("Form · last five, latest on the right")}</span><div class="form">${form.map(r=>{const o=outcome(r);return `<span class="fo ${o}" title="${esc(r[3]+" "+r[4]+"-"+r[5])}">${t("res:"+o)}</span>`}).join("")}</div>
    <p class="muted">${tf(wdl.D?"{n} competitive games: <b>{w}</b> won, <b>{d}</b> drawn, <b>{l}</b> lost.":"{n} competitive games: <b>{w}</b> won, <b>{l}</b> lost.",{n:L.last.length,w:wdl.W,d:wdl.D,l:wdl.L})}</p></article>`;
  p.innerHTML=`<h2 class="vh">${t("Matches")}</h2>
  <div class="mgrid"><div class="mmain">
   <div class="mtop">${hero}</div>
   <section class="card mcard"><header class="mch"><h3>${t("Latest results")}</h3>${res.length>8?`<button class="linkbtn" data-mall>${mAll?t("Show fewer"):tf("Show all {n} results",{n:res.length})}</button>`:""}</header>
    <div class="filter mf" role="group" aria-label="${t("Filter by competition")}">${comps.map(c=>`<button data-mf="${esc(c)}" aria-pressed="${c===mFilter}">${esc(t(c))}</button>`).join("")}</div>
    <ol class="mlist srows">${shown.map(r=>srowResult(current,r,L.last.indexOf(r))).join("")||`<li class="muted">${t("Nothing in this competition yet.")}</li>`}</ol></section>
   <section class="card mcard"><header class="mch"><h3>${t("Coming up")}</h3></header><ol class="mlist srows">${up.map(n=>srowFixture(current,n,false)).join("")||`<li class="muted">${t("No fixtures listed in this competition.")}</li>`}</ol>
    <p class="fine">${esc(t(L.timeNote))}${past.length?" "+tf(past.length>1?"{n} listed fixtures have been played since this snapshot.":"1 listed fixture has been played since this snapshot.",{n:past.length}):""}</p></section>
  </div><aside class="mside">${formCard}${miniTable(current)}${miniSquad(current)}
   <section class="card mcard"><header class="mch"><h3>${t("Season so far")}</h3></header>${msum}</section></aside></div>
  ${intro}<div id="commBox"></div>${srcLine(L)}`;xMatchesExtras(L,nx)}
/* ---------- Stacked match rows (home team on top, each score next to its team) ---------- */
function sides(r){const away=r[2]==="A";return away?[[r[3],r[5]],["Fenerbahçe",r[4]]]:[["Fenerbahçe",r[4]],[r[3],r[5]]]}
function srowTeams(pair,o,withScore){const a=parseFloat(pair[0][1]),b=parseFloat(pair[1][1]);
  return `<div class="tm">${pair.map(([n,sc],k)=>{const fb=n==="Fenerbahçe",lost=withScore&&!isNaN(a)&&!isNaN(b)&&(k===0?a<b:b<a);return `<span class="tl${fb?" fb":""}">${teamBadge(n)}<span class="tn">${esc(n)}</span>${withScore?`<b class="ts${lost?" lo":""}">${esc(sc)}</b>`:""}</span>`}).join("")}</div>`}
function srowResult(b,r,i,showBr){const o=outcome(r);
  return `<li class="srow mrow ${o} mclick" data-mi="${i}" data-mb="${b}" tabindex="0" role="button" aria-label="${esc(tf("Match details: Fenerbahçe {a}–{b} {o}",{a:r[4],b:r[5],o:r[3]}))}">
    <div class="st">${showBr?`<b>${t("FT")}</b>`:`<b>${r[0]?mDate(r[0],true):esc(t(r[6]||""))}</b><span>${t("FT")}</span>`}</div>
    <div class="sm"><span class="cm">${showBr?brIcon(b):""}${esc(t(r[1]))}${r[6]&&r[0]?` · ${esc(t(r[6])).replace(/(\d)-(\d)/g,"$1\u2011$2")}`:""}</span>${srowTeams(sides(r),o,true)}</div>
    <div class="rx">${rdot(o)}</div></li>`}
function srowFixture(b,n,showBr){const pair=n[3]==="A"?[[n[4]],["Fenerbahçe"]]:[["Fenerbahçe"],[n[4]]];
  return `<li class="srow mrow fx"${showBr?` data-gosport="${b}" tabindex="0" role="button"`:""}>
    <div class="st">${showBr?`<b>${n[1]?esc(n[1]):t("TBC")}</b>`:`<b>${n[0]?mDate(n[0],true):esc(t(n[5]||""))}</b><span>${n[1]?esc(n[1]):t("TBC")}</span>`}</div>
    <div class="sm"><span class="cm">${showBr?brIcon(b):""}${esc(t(n[2]))}</span>${srowTeams(pair,"",false)}</div>
    <div class="rx">${showBr?`<span class="hl-go" aria-hidden="true">›</span>`:calLinks(n,false)}</div></li>`}
/* ---------- Small cards for the side column ---------- */
function tNs(ns,k){const r=t(ns+k);return r===ns+k?t(k):r}
function miniTable(b){const L=LIVE[b];const T=L&&L.tables.find(x=>x.rows&&x.cols.includes("P")&&x.rows.some(r=>r[0]==="Fenerbahçe"));if(!T)return "";
  const fi=T.rows.findIndex(r=>r[0]==="Fenerbahçe"),st=Math.max(0,Math.min(fi-2,T.rows.length-5)),rows=T.rows.slice(st,st+5),P=T.cols.indexOf("P"),K=T.key;
  return `<section class="card mcard mini"><header class="mch"><h3>${esc(t(T.comp))}</h3><button class="linkbtn" data-goto="standings">${t("Full table")} ›</button></header>
   <table class="mtab"><thead><tr><th>#</th><th>${t("Team")}</th><th>${esc(tNs("col:","P"))}</th><th>${esc(tNs("col:",T.cols[K]||"Pts"))}</th></tr></thead><tbody>${rows.map((r,j)=>`<tr class="${r[0]==="Fenerbahçe"?"fb":""}"><td>${st+j+1}</td><td><span class="tl">${teamBadge(r[0])}<span class="tn">${esc(r[0])}</span></span></td><td>${esc(r[P+1])}</td><td><b>${esc(r[K+1])}</b></td></tr>`).join("")}</tbody></table></section>`}
function miniSquad(b){const S=SQUADS[b];if(!S||!S.groups||!tabsFor(b).some(x=>x[0]==="squad"))return "";const n=S.groups.reduce((a,g)=>a+g[1].length,0);
  return `<section class="card mcard mini"><header class="mch"><h3>${t("Squad")}</h3><button class="linkbtn" data-goto="squad">${t("Full squad")} ›</button></header>
   <p class="muted">${S.coach?`${t("Head coach")}: <b>${esc(S.coach)}</b><br>`:""}${tf("{n} players",{n})}</p></section>`}
function srcLine(L){return `<details class="srcs"><summary>${t("Sources")}</summary><p class="fine">${L.sources.map(([x,u])=>`<a href="${esc(u)}" target="_blank" rel="noopener">${esc(t(x))}</a>`).join(" · ")}</p></details>`}
function renderStandings(p){const L=LIVE[current];if(!L){p.innerHTML="";return}
  p.innerHTML=`<h2>${t("Standings")}</h2><p class="intro">${t("Every competition Fenerbahçe are in this season. Our row is highlighted.")}</p>
  <nav class="tjump" aria-label="${t("Competitions")}">${L.tables.map((x,i)=>`<a href="#" data-tj="${i}">${esc(t(x.comp))}</a>`).join("")}</nav>
  <div class="tables">${L.tables.map((x,i)=>tableCard(x,i)).join("")}</div>${srcLine(L)}`;
  p.querySelectorAll("[data-tj]").forEach(a=>a.addEventListener("click",e=>{e.preventDefault();document.getElementById("tb-"+a.dataset.tj).scrollIntoView({behavior:"smooth",block:"start"})}))}
const tt=x=>t(x);
function tableCard(T,i){const t=T,head=`<header><h3>${esc(tt(t.comp))}</h3><span class="label">${esc(tt(t.sub||""))}</span></header>`;
  if(!t.rows)return `<article class="tcard card" id="tb-${i}">${head}<p class="tnote">${esc(tt(t.note))}</p></article>`;
  const hide=c=>["GF","GA","PF","PA"].includes(c)?' class="hm"':"";
  const ranks=t.rows.map((r,k)=>t.tied?1+t.rows.filter(x=>x[t.key+1]>r[t.key+1]).length:k+1);
  const zoneOf=pos=>t.zones?t.zones.findIndex(z=>pos>=z[0]&&pos<=z[1]):-1;
  const body=t.rows.map((r,k)=>{const pos=ranks[k],tie=t.tied&&ranks.filter(x=>x===pos).length>1,fb=r[0]==="Fenerbahçe",z=zoneOf(k+1);
    return `<tr class="${fb?"fbrow":""} ${z>=0?"z"+z:""}"><td class="pos">${pos}${tie?"=":""}</td><td class="tm">${esc(r[0])}</td>${t.cols.map((c,j)=>`<td${hide(c)}${j===t.key?' class="kc"':""}>${esc(r[j+1])}</td>`).join("")}</tr>`}).join("");
  const legend=t.zones?`<div class="zleg">${t.zones.map((z,k)=>`<span><i class="z${k}"></i>${esc(tt(z[2]))} (${z[0]}–${z[1]})</span>`).join("")}</div>`:"";
  const fbi=t.rows.findIndex(r=>r[0]==="Fenerbahçe"),fbPos=fbi>=0?ranks[fbi]:null;
  return `<article class="tcard card" id="tb-${i}">${head}${fbPos&&t.rows.some(r=>+r[1]>0)?`<div class="tpos"><b>${ordL(fbPos)}</b><span>${tf("of {n}",{n:t.rows.length})}</span></div>`:""}
   <div class="tscroll"><table class="stand"><thead><tr><th class="pos">#</th><th class="tm">${tt("Team")}</th>${t.cols.map((c,j)=>`<th${hide(c)}${j===t.key?' class="kc"':""} title="${esc(tt("colt:"+c))}">${esc(tt("col:"+c))}</th>`).join("")}</tr></thead><tbody>${body}</tbody></table></div>${legend}${t.note?`<p class="tnote">${esc(tt(t.note))}</p>`:""}</article>`}
function ordL(n){return LANG==="en"?n+ordSfx(n):LANG==="es"?n+".º":LANG==="fr"?n+(n===1?"er":"e"):LANG==="ar"?String(n):n+"."}
function ordSfx(n){const s=["th","st","nd","rd"],v=n%100;return s[(v-20)%10]||s[v]||s[0]}

/* ---------- FAN GAMES ---------- */
const norm = s => String(s).toLocaleLowerCase("tr").replace(/ç/g,"c").replace(/ğ/g,"g").replace(/ı/g,"i").replace(/ö/g,"o").replace(/ş/g,"s").replace(/ü/g,"u").replace(/æ/g,"ae").replace(/ø/g,"o").normalize("NFD").replace(/[̀-ͯ]/g,"").replace(/[^a-z ]/g," ").replace(/\s+/g," ").trim();
const shuffle = a => {a=[...a];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
const store = {get(k,d){try{const v=localStorage.getItem(k);return v==null?d:JSON.parse(v)}catch(e){return d}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const rnd=(a,b)=>a+Math.random()*(b-a);
const pickW=(items,wf)=>{const ws=items.map(wf);let t=ws.reduce((a,b)=>a+b,0)*Math.random();for(let i=0;i<items.length;i++){t-=ws[i];if(t<=0)return items[i]}return items[items.length-1]};
function lev(a,b){const m=a.length,n=b.length;if(Math.abs(m-n)>2)return 9;const d=Array.from({length:m+1},(_,i)=>[i]);for(let j=1;j<=n;j++)d[0][j]=j;for(let i=1;i<=m;i++)for(let j=1;j<=n;j++)d[i][j]=Math.min(d[i-1][j]+1,d[i][j-1]+1,d[i-1][j-1]+(a[i-1]===b[j-1]?0:1));return d[m][n]}
const closeEnough=(v,a)=>v===a||(a.length>=5&&lev(v,a)<=(a.length>=8?2:1));
const lastName=n=>{const w=n.split(" ");return w.length>1?w.slice(1).join(" "):n};
const seasonLabel=id=>id.replace("-","–");
const CUR=2026;

/* ===== Player database ===== */
const NAT={TUR:"Turkey",BRA:"Brazil",GER:"Germany",CRO:"Croatia",CHI:"Chile",URU:"Uruguay",SVK:"Slovakia",POR:"Portugal",DEN:"Denmark",NGA:"Nigeria",NED:"the Netherlands",SUI:"Switzerland",GHA:"Ghana",FRA:"France",ISR:"Israel",ARG:"Argentina",ESP:"Spain",POL:"Poland",SRB:"Serbia",BIH:"Bosnia and Herzegovina",SEN:"Senegal",MAR:"Morocco",ECU:"Ecuador",COL:"Colombia",CMR:"Cameroon",KOR:"South Korea",HUN:"Hungary",KOS:"Kosovo"};
const P_RAW=[
 ["Rüştü Reçber","GK","",86,"TUR",1994,2007,"Rüştü"],["Volkan Demirel","GK","",84,"TUR",2002,2019,"Volkan"],["Harald Schumacher","GK","",84,"GER",1988,1991,"Schumacher"],["Ederson","GK","",86,"BRA",2025,2026],["Dominik Livaković","GK","",81,"CRO",2023,2025],["Altay Bayındır","GK","",77,"TUR",2019,2023],["Mert Günok","GK","",76,"TUR",2008,2015],
 ["Gökhan Gönül","RB","",80,"TUR",2007,2017],["Mert Müldür","RB","LB",78,"TUR",2024,2026],["Önder Turacı","RB","CB",76,"TUR",2004,2010],["Fatih Akyel","RB","",77,"TUR",2002,2004],["Mauricio Isla","RB","W",77,"CHI",2017,2020],["Şener Özbayraklı","RB","",75,"TUR",2014,2018],
 ["Diego Lugano","CB","",84,"URU",2006,2011],["Edu Dracena","CB","",81,"BRA",2006,2009],["Milan Škriniar","CB","",85,"SVK",2025,2026],["Bruno Alves","CB","",81,"POR",2013,2016],["Simon Kjær","CB","",81,"DEN",2015,2017],["Joseph Yobo","CB","",79,"NGA",2010,2014],["Ogün Temizkanoğlu","CB","CM",80,"TUR",1990,2003],["Çağlar Söyüncü","CB","",79,"TUR",2023,2026],["Jayden Oosterwolde","CB","LB",79,"NED",2022,2026],["Serdar Aziz","CB","",77,"TUR",2018,2024],["Egemen Korkmaz","CB","",76,"TUR",2011,2015],["Bekir İrtegün","CB","",75,"TUR",2010,2015],
 ["Fábio Luciano","CB","",80,"BRA",2003,2006],["Kim Min-jae","CB","",84,"KOR",2021,2022,"Kim Min-jae"],["Martin Škrtel","CB","",81,"SVK",2016,2019],["Attila Szalai","CB","",79,"HUN",2020,2023],
 ["Roberto Carlos","LB","",87,"BRA",2007,2009,"Roberto Carlos"],["Ümit Özat","LB","CM",80,"TUR",1997,2007],["Ferdi Kadıoğlu","LB","RB,W",81,"TUR",2018,2024,"Ferdi"],["Hasan Ali Kaldırım","LB","",76,"TUR",2012,2019,"Hasan Ali"],["Reto Ziegler","LB","",76,"SUI",2011,2013],["Gökçek Vederson","LB","W",75,"TUR",2007,2010,"Vederson"],["Levent Mercan","LB","",75,"TUR",2024,2026],["André Santos","LB","W",79,"BRA",2009,2011],["Filip Kostić","LB","W",79,"SRB",2024,2025],
 ["Emre Belözoğlu","CM","AM",85,"TUR",2008,2020,"Emre"],["Mehmet Aurélio","CM","",81,"TUR",2003,2008,"Aurélio"],["Stephen Appiah","CM","",81,"GHA",2005,2008],["Fred","CM","",83,"BRA",2023,2026],["Mattéo Guendouzi","CM","",83,"FRA",2025,2026],["Raul Meireles","CM","",80,"POR",2012,2016],["Josef de Souza","CM","",80,"BRA",2015,2019,"Josef"],["Oğuz Çetin","CM","AM",80,"TUR",1988,1996],["Selçuk Şahin","CM","",76,"TUR",2003,2015],["İsmail Yüksek","CM","",77,"TUR",2019,2026,"İsmail"],["Cristian Baroni","CM","",78,"BRA",2009,2014,"Cristian"],["Mehmet Topal","CM","CB",78,"TUR",2012,2019],["Mehmet Topuz","CM","W",77,"TUR",2009,2014],["Claudio Maldonado","CM","",76,"CHI",2007,2009],["Deivid","CM","ST",76,"BRA",2006,2009],["Willian Arão","CM","",77,"BRA",2022,2023],["Luiz Gustavo","CM","",81,"BRA",2019,2022],
 ["Alex de Souza","AM","",91,"BRA",2004,2012,"Alex"],["Jay-Jay Okocha","AM","CM",86,"NGA",1996,1998,"Okocha"],["Rıdvan Dilmen","AM","",85,"TUR",1985,1994,"Rıdvan"],["Haim Revivo","AM","W",83,"ISR",1997,2002],["Ariel Ortega","AM","",82,"ARG",2002,2003],["Can Bartu","AM","ST",87,"TUR",1955,1970,"Can Bartu"],["Diego Ribas","AM","",80,"BRA",2014,2016,"Diego"],["Mesut Özil","AM","",79,"GER",2021,2022],["Marco Asensio","AM","W",83,"ESP",2025,2026],["Sebastian Szymański","AM","CM",81,"POL",2023,2025],["Arda Güler","AM","W",82,"TUR",2021,2023,"Arda"],["Anderson Talisca","AM","ST",84,"BRA",2025,2026,"Talisca"],["Mathieu Valbuena","AM","W",80,"FRA",2017,2019],
 ["Dušan Tadić","W","AM",84,"SRB",2023,2025],["Dirk Kuyt","W","ST",84,"NED",2012,2015],["Kerem Aktürkoğlu","W","",81,"TUR",2025,2026,"Kerem"],["İrfan Can Kahveci","W","AM",80,"TUR",2021,2026,"Kahveci"],["Miroslav Stoch","W","",79,"SVK",2011,2014],["Uğur Boral","W","",77,"TUR",2006,2011],["Tuncay Şanlı","W","ST,AM",82,"TUR",2002,2007,"Tuncay"],["Caner Erkin","W","LB",78,"TUR",2010,2021,"Caner"],["Allan Saint-Maximin","W","",80,"FRA",2024,2025],["Anthony Musaba","W","",76,"NED",2025,2026],["Nani","W","",81,"POR",2015,2016],
 ["Lefter Küçükandonyadis","ST","AM",93,"TUR",1947,1964,"Lefter"],["Cemil Turan","ST","",85,"TUR",1972,1981],["Aykut Kocaman","ST","",86,"TUR",1988,1996,"Aykut"],["Tanju Çolak","ST","",86,"TUR",1991,1993,"Tanju"],["Elvir Bolić","ST","",82,"BIH",1995,2000],["Pierre van Hooijdonk","ST","",83,"NED",2003,2005,"Van Hooijdonk"],["Nicolas Anelka","ST","",84,"FRA",2005,2006],["Mateja Kežman","ST","",81,"SRB",2006,2008],["Semih Şentürk","ST","",80,"TUR",2000,2013,"Semih"],["Serhat Akın","ST","W",78,"TUR",1998,2005,"Serhat"],["Edin Džeko","ST","",85,"BIH",2023,2025],["Robin van Persie","ST","",83,"NED",2015,2017,"Van Persie"],["Moussa Sow","ST","W",81,"SEN",2011,2017],["Emmanuel Emenike","ST","",80,"NGA",2013,2016],["Youssef En-Nesyri","ST","",82,"MAR",2024,2026],["Enner Valencia","ST","",81,"ECU",2020,2023],["Jhon Durán","ST","",80,"COL",2025,2026],["Pierre Webó","ST","",76,"CMR",2012,2014],["Mamadou Niang","ST","",81,"SEN",2010,2011],["Dani Güiza","ST","",80,"ESP",2008,2010,"Güiza"],["Vedat Muriqi","ST","",80,"KOS",2019,2020],["Márcio Nobre","ST","",78,"BRA",2003,2006]
];
const PLAYERS=P_RAW.map(([n,pos,alt,r,nat,from,to,short])=>({n,pos,alt:alt?alt.split(","):[],r,nat,from,to,short:short||lastName(n)}));
const PBY=Object.fromEntries(PLAYERS.map(p=>[p.n,p]));
const ROLE={GK:"GK",LB:"LB",RB:"RB",CB:"CB",CM:"CM",AM:"AM",LW:"W",RW:"W",LM:"W",RM:"W",ST:"ST"};
const ROLE_NAME={GK:"Goalkeeper",LB:"Left-back",RB:"Right-back",CB:"Centre-back",CM:"Central midfielder",AM:"Attacking midfielder",W:"Winger",ST:"Striker"};
const LINE_OF={GK:"GK",CB:"DF",LB:"DF",RB:"DF",CM:"MF",AM:"MF",W:"MF",ST:"FW"};
const LINE_NAME={GK:"goalkeeper",DF:"defender",MF:"midfielder",FW:"forward"};
let CUR_SQ=null;const inCurSquad=n=>{if(!CUR_SQ){CUR_SQ=new Set();try{SQUADS.football.groups.forEach(g=>g[1].forEach(x=>CUR_SQ.add(x[1])))}catch(e){}}return CUR_SQ.has(n)};
const yrs=p=>p.to>=CUR&&inCurSquad(p.n)?`${p.from}–`:`${p.from}–${String(p.to).slice(2)}`;

/* People: everyone in the season XIs plus the legends pool */
const SHORT_X={"Mehmet Aurélio":"Aurélio","Alex de Souza":"Alex","Josef de Souza":"Josef","Diego Ribas":"Diego","Cristian Baroni":"Cristian","Gökçek Vederson":"Vederson","Giuliano de Paula":"Giuliano","Bright Osayi-Samuel":"Osayi-Samuel","Miguel Crespo":"Crespo","Anderson Talisca":"Talisca","Dorgeles Nene":"Nene","Nélson Semedo":"Semedo","Kim Min-jae":"Kim Min-jae","Hasan Ali Kaldırım":"Hasan Ali","İrfan Can Kahveci":"Kahveci","İrfan Can Eğribayat":"Eğribayat"};
const EXTRA_AL={"Kim Min-jae":["kim","minjae","min jae"],"Robin van Persie":["persie","rvp"],"Pierre van Hooijdonk":["hooijdonk"],"Gökçek Vederson":["wederson"],"Mehmet Aurélio":["aurelio","marco aurelio"],"Youssef En-Nesyri":["nesyri"],"Bright Osayi-Samuel":["osayi","samuel"],"İrfan Can Kahveci":["irfan can"],"Simon Kjær":["kjaer","kjer","kjar"],"Roberto Carlos":["carlos"],"Roman Neustädter":["neustaedter"],"Márcio Nobre":["marcio"],"Dani Güiza":["dani guiza"],"Jailson":["jailson siqueira"],"Lincoln":["lincoln henrique"],"Eljif Elmas":["elif elmas"]};
const PEOPLE={};
function person(n){if(!PEOPLE[n]){const p=PBY[n];PEOPLE[n]={n,short:p?p.short:(SHORT_X[n]||lastName(n)),line:p?LINE_OF[p.pos]:null,seasons:[],p}}return PEOPLE[n]}
PLAYERS.forEach(p=>person(p.n));
SEASONS.forEach(([id,,,rows])=>rows.forEach((r,ri)=>r.forEach(n=>{const x=person(n);x.seasons.push(id);if(!x.p)x.line=x.line||["FW","MF","DF","GK"][ri]})));
function aliasesOf(n){const x=PEOPLE[n]||{short:lastName(n)},parts=norm(n).split(" "),al=new Set([norm(n),norm(x.short),norm(lastName(n))]);if(parts[0].length>=4)al.add(parts[0]);(EXTRA_AL[n]||[]).forEach(a=>al.add(norm(a)));return [...al].filter(Boolean)}
const initialsOf=n=>n.split(/[\s-]+/).map(w=>w[0].toLocaleUpperCase("tr")+".").join(" ");

function updateArcadeStats(){}
/* ===== 1. ALL-TIME XI DRAFT + LEGENDS CUP ===== */
const B4=[["GK",50,90],["LB",13,70],["CB",37,75],["CB",63,75],["RB",87,70]],B3=[["GK",50,90],["CB",24,74],["CB",50,77],["CB",76,74]];
const FORMS={
 "4-3-3":B4.concat([["CM",26,49],["CM",50,54],["CM",74,49],["LW",16,22],["ST",50,12],["RW",84,22]]),
 "4-4-2":B4.concat([["LM",12,42],["CM",37,48],["CM",63,48],["RM",88,42],["ST",36,14],["ST",64,14]]),
 "4-2-3-1":B4.concat([["CM",37,55],["CM",63,55],["LW",14,30],["AM",50,33],["RW",86,30],["ST",50,11]]),
 "4-1-4-1":B4.concat([["CM",50,58],["LM",12,37],["CM",37,40],["CM",63,40],["RM",88,37],["ST",50,12]]),
 "4-4-1-1":B4.concat([["LM",12,46],["CM",37,51],["CM",63,51],["RM",88,46],["AM",50,29],["ST",50,11]]),
 "4-3-1-2":B4.concat([["CM",26,54],["CM",50,57],["CM",74,54],["AM",50,35],["ST",36,14],["ST",64,14]]),
 "3-5-2":B3.concat([["LM",10,45],["CM",32,52],["AM",50,36],["CM",68,52],["RM",90,45],["ST",36,13],["ST",64,13]]),
 "3-4-3":B3.concat([["LM",10,48],["CM",37,52],["CM",63,52],["RM",90,48],["LW",16,20],["ST",50,12],["RW",84,20]]),
 "3-4-2-1":B3.concat([["LM",10,50],["CM",37,55],["CM",63,55],["RM",90,50],["AM",33,29],["AM",67,29],["ST",50,11]]),
 "5-3-2":[["GK",50,90],["LB",9,62],["CB",30,75],["CB",50,78],["CB",70,75],["RB",91,62],["CM",28,46],["CM",50,49],["CM",72,46],["ST",36,14],["ST",64,14]]
};
const slotRole=(form,i)=>ROLE[FORMS[form][i][0]];
function teamInfo(form,picks,cap){const idx=picks.map((p,i)=>p?i:-1).filter(i=>i>=0);
  const eff=picks.map((p,i)=>p?p.r-(p.pos===slotRole(form,i)?0:3)+(cap===i?2:0):null);
  if(!idx.length)return{eff,ovr:0,base:0};
  return{eff,ovr:idx.reduce((a,i)=>a+eff[i],0)/idx.length,base:idx.reduce((a,i)=>a+picks[i].r,0)/idx.length}}
let dr=null;
const drOrder=()=>{const S=FORMS[dr.form];return S.map((_,i)=>i).sort((a,b)=>S[b][2]-S[a][2]||S[a][1]-S[b][1])};
function newDraft(form){dr={form,picks:Array(11).fill(null),offers:{},active:0,rerolls:3,captain:null,phase:"pick",cup:null};dr.active=drOrder()[0]}
function getOffers(i){return chWith("football","rd",()=>getOffersRaw(i))}
function getOffersRaw(i){const used=new Set(dr.picks.filter(Boolean));
  if(!dr.offers[i]){const role=slotRole(dr.form,i);
    const nat=shuffle(PLAYERS.filter(p=>!used.has(p)&&p.pos===role)),alt=shuffle(PLAYERS.filter(p=>!used.has(p)&&p.pos!==role&&p.alt.includes(role)));
    const list=nat.slice(0,4);if(alt.length)list.push(alt[0]);else if(nat[4])list.push(nat[4]);dr.offers[i]=shuffle(list)}
  return dr.offers[i].filter(p=>!used.has(p))}
function pitch2(form,picks,o={}){const F=FORMS[form],info=o.info,tag=o.clickable?"button":"div";
  return `<div class="pitch2"><span class="box18 top"></span><span class="box18"></span>${F.map(([pos,x,y],i)=>{const p=picks[i],oop=p&&p.pos!==ROLE[pos];
    return `<${tag} class="ps ${p?"filled":""} ${o.active===i?"active":""} ${oop?"oop":""}" style="left:${x}%;top:${y}%" ${o.clickable?`type="button" data-slot="${i}"`:""} aria-label="${pos}${p?": "+esc(p.n):", empty"}"><span class="disc">${p?(info?info.eff[i]:p.r):pos}</span>${o.captain===i?'<span class="cap">C</span>':""}<span class="nm">${p?esc(p.short):""}</span></${tag}>`}).join("")}</div>`}
function tier(o){return o>=90?"Immortal. Lefter would approve.":o>=87?"Champions of Europe.":o>=84?"Title winners.":o>=81?"Champions League nights in Kadıköy.":o>=78?"A top-four side.":"A rebuild is needed."}
function renderDraft(p){
  if(!dr)newDraft("4-3-3");
  const info=teamInfo(dr.form,dr.picks,dr.captain),filled=dr.picks.filter(Boolean).length,best=store.get("fb-draft-best",null);
  let side="";
  if(dr.phase==="pick"){const i=dr.active,role=slotRole(dr.form,i);
    side=`<div class="box"><span class="label">Pick ${filled+1} of 11 · tap any empty spot to switch</span><h3 style="margin-top:4px">${ROLE_NAME[role]}</h3><div class="cands2">${getOffers(i).map((c,k)=>`<button class="cand2" data-cand="${k}"><span class="r">${c.r}</span><span class="info"><b>${esc(c.n)}</b><small>${c.nat} · ${yrs(c)} · ${c.pos==="W"?"Winger":c.pos}</small></span>${c.pos!==role?'<em class="tag bad">Out of position −3</em>':'<span></span>'}</button>`).join("")}</div>
      <div class="btns"><button class="btn ghost" data-d="reroll" ${dr.rerolls?"":"disabled"}>New options (${dr.rerolls} left)</button></div></div>`}
  else if(dr.phase==="captain")side=`<div class="box"><span class="label">Last step</span><h3 style="margin-top:4px">Choose your captain</h3><p style="margin-top:8px;color:var(--muted)">Tap a player on the pitch. The captain plays 2 above his rating.</p></div>`;
  else side=`<div class="box" id="cupBox"></div>`;
  const sum=`<div class="box"><span class="label">${dr.phase==="pick"?"Team so far":"Your XI"}</span><div class="ovr" style="margin-top:8px"><span class="big">${filled?info.ovr.toFixed(1):"–"}</span><dl><dt>Players</dt><dd>${filled}/11</dd><dt>Formation</dt><dd>${dr.form}</dd><dt>Best ever</dt><dd>${best!=null?Number(best).toFixed(1):"–"}</dd></dl></div></div>`;
  p.innerHTML=`<h2>All-Time XI Draft</h2><p class="intro">Pick a formation, then fill each spot from five Fenerbahçe players. Fill the spots in any order. Playing someone out of position costs 3 points, and your captain gets 2 extra. Then pick a season from 2000–01 onwards and play it through, game by game, in every competition the club entered that year.</p>
  <div class="filter" role="group" aria-label="Formation">${Object.keys(FORMS).map(f=>`<button data-form="${f}" aria-pressed="${f===dr.form}">${f}</button>`).join("")}</div>
  <div class="draft"><div>${pitch2(dr.form,dr.picks,{info,active:dr.phase==="pick"?dr.active:null,captain:dr.captain,clickable:true})}</div><div class="side">${side}${sum}</div></div>
  <p class="gnote">Ratings are fan ratings made for this game. Numbers on the pitch include position and captain adjustments. Changing formation starts a new draft.</p>`;
  p.querySelectorAll("[data-form]").forEach(b=>b.onclick=()=>{clearInterval(cupTimer);newDraft(b.dataset.form);renderPanel()});
  p.querySelectorAll("[data-slot]").forEach(b=>b.onclick=()=>{const i=+b.dataset.slot;
    if(dr.phase==="pick"&&!dr.picks[i]){dr.active=i;renderPanel()}
    else if(dr.phase==="captain"&&dr.picks[i]){dr.captain=i;dr.phase="done";const o=teamInfo(dr.form,dr.picks,i).ovr,bs=store.get("fb-draft-best",null);const nb=bs==null||o>bs;if(nb)store.set("fb-draft-best",Math.round(o*10)/10);dr.cup={round:0,results:[],live:null,opp:buildOpp(0),newBest:nb};updateArcadeStats();renderPanel()}});
  p.querySelectorAll("[data-cand]").forEach(b=>b.onclick=()=>{dr.picks[dr.active]=getOffers(dr.active)[+b.dataset.cand];const nx=drOrder().find(i=>!dr.picks[i]);if(nx==null){dr.phase="captain";dr.active=null}else dr.active=nx;renderPanel()});
  const rr=p.querySelector('[data-d="reroll"]');if(rr)rr.onclick=()=>{if(!dr.rerolls)return;dr.rerolls--;delete dr.offers[dr.active];renderPanel()};
  if(dr.phase==="done")renderCupBox();
}
const ROUNDS=[["Quarter-final","2010s Select",2010,2019,"4-4-2"],["Semi-final","2000s Select",2000,2009,"4-2-3-1"],["Final","Legends Select",0,0,"4-3-3"]];
function buildOpp(k){const [,name,a,b,form]=ROUNDS[k],used=new Set(dr.picks),picks=Array(11).fill(null);
  FORMS[form].forEach(([pos],i)=>{const role=ROLE[pos];let pool=PLAYERS.filter(p=>!used.has(p)&&p.pos===role&&(!a||(p.from<=b&&p.to>=a)));
    if(!pool.length)pool=PLAYERS.filter(p=>!used.has(p)&&p.pos===role);if(!pool.length)pool=PLAYERS.filter(p=>!used.has(p)&&p.alt.includes(role));
    pool.sort((x,y)=>y.r-x.r);const top=pool.slice(0,k===2?2:3);const pk=top[Math.floor(Math.random()*top.length)];picks[i]=pk;used.add(pk)});
  let cap=0;picks.forEach((p,i)=>{if(p.r>picks[cap].r)cap=i});return{name,form,picks,cap,info:teamInfo(form,picks,cap)}}

const SCW={ST:6,W:4,AM:4,CM:1.5,CB:.6,LB:.5,RB:.5,GK:0},ASW={AM:5,W:4,CM:3,ST:2,LB:2,RB:2,CB:.5,GK:.1};

const pensScore=p=>[p.h.filter(Boolean).length,p.a.filter(Boolean).length];
const won=res=>res.g[0]!==res.g[1]?res.g[0]>res.g[1]:pensScore(res.pens)[0]>pensScore(res.pens)[1];
function line(e,H,A){const T=e.t===0?H.name:A.name,r=a=>a[Math.floor((e.min*7+(e.s||"").length)%a.length)];
  if(e.type==="goal")return r([`GOAL! ${e.s} scores${e.a?` after a pass from ${e.a}`:""}.`,`GOAL! ${e.s} finishes it off${e.a?`. ${e.a} with the assist`:""}.`,`GOAL! What a strike from ${e.s}!`]);
  if(e.type==="save")return r([`${e.gk} saves from ${e.s}.`,`Big stop by ${e.gk}, denying ${e.s}.`,`${e.s} tests ${e.gk}, who holds on.`]);
  if(e.type==="miss")return r([`${e.s} drags it wide.`,`${e.s} heads over the bar.`,`Chance for ${e.s}, but it's blocked.`]);
  if(e.type==="card")return `Yellow card for ${e.s} (${T}).`;return e.type==="ht"?"Half-time.":"Full-time."}
let cupTimer=null;




/* ===== 3. NAME THE XI (every season) ===== */
const METRIC={minutes:"the most league minutes",starts:"the most league starts",apps:"the most league appearances (to March 2026)"};
let xi=null,xiTimer=null;const XI_TIME=150;
function newXI(id,mode){clearInterval(xiTimer);xi={id,mode:mode||(xi?xi.mode:"relaxed"),found:new Set(),hints:new Set(),wrong:0,ended:false,msg:"",cls:"",start:null}}
function xiPlayers(S){const rows=S[3],all=rows.flat(),cnt={};const al=all.map(n=>aliasesOf(n));al.forEach(a=>a.forEach(x=>cnt[x]=(cnt[x]||0)+1));
  const out=[];let k=0;rows.forEach((r,ri)=>r.forEach((n,ci)=>{const a=al[k++].filter(x=>cnt[x]===1||x===norm(n));out.push({key:ri+"-"+ci,name:n,line:["FW","MF","DF","GK"][ri],al:a})}));return out}
const xiScore=()=>Math.max(0,xi.found.size*10-xi.hints.size*4-xi.wrong*2);
const xiStars=()=>xi.found.size===11&&!xi.hints.size&&xi.wrong<=2?3:xi.found.size===11?2:xi.found.size>=6?1:0;
const xiLeft=()=>xi.start?Math.max(0,XI_TIME-Math.floor((Date.now()-xi.start)/1000)):XI_TIME;
const fmtClock=s=>`${Math.floor(s/60)}:${String(s%60).padStart(2,"0")}`;
function xiEnd(msg){if(xi.ended)return;xi.ended=true;clearInterval(xiTimer);xi.final=xiScore()+(xi.mode==="clock"&&xi.found.size===11?xiLeft():0);
  const best=store.get("fb-xi3",{}),b=best[xi.id]||{stars:0,score:0};best[xi.id]={stars:Math.max(b.stars,xiStars()),score:Math.max(b.score,xi.final)};store.set("fb-xi3",best);xi.msg=msg;xi.cls=xi.found.size===11?"good":"";updateArcadeStats()}
function renderXI(p){
  if(!xi)newXI(SEASONS[SEASONS.length-1][0]);
  const S=SEASONS.find(s=>s[0]===xi.id),si=SEASONS.indexOf(S),ps=xiPlayers(S),n=xi.found.size,best=store.get("fb-xi3",{});
  const locked=xi.ended||(xi.mode==="clock"&&!xi.start),rows=S[3],yStep=76/(rows.length-1);
  const slots=rows.map((r,ri)=>r.map((nm,ci)=>{const k=ri+"-"+ci,f=xi.found.has(k),show=f||xi.ended,x=(ci+1)/(r.length+1)*100,y=12+ri*yStep;
    const hint=xi.hints.has(k)?nm.split(/\s+/).map(w=>w[0]+"·".repeat(Math.min(w.length-1,6))).join(" "):"";
    return `<div class="ps ${f?"filled":xi.ended?"missed":""}" style="left:${x}%;top:${y}%"><span class="disc">${f?"✓":["FW","MF","DF","GK"][ri]}</span><span class="nm ${show?"":"dim"}">${show?esc(nm):esc(hint)}</span></div>`}).join("")).join("");
  const stars=s=>"★".repeat(s)+"☆".repeat(3-s);
  p.innerHTML=`<h2>Name the XI</h2><p class="intro">Every season from 2000–01 to 2025–26. Pick a season and name its eleven: the goalkeeper and ten outfield players with ${METRIC.minutes} for Fenerbahçe that year. Surnames work, and so do the names fans use. Each player is worth 10 points, a hint costs 4 and a wrong guess costs 2. Against the clock, the seconds left over are a bonus.</p>
  <div class="wtop"><div class="filter" role="group" aria-label="Mode"><button data-xm="relaxed" aria-pressed="${xi.mode==="relaxed"}">Relaxed</button><button data-xm="clock" aria-pressed="${xi.mode==="clock"}">Against the clock</button></div>
   <div class="btns" style="margin-top:0"><button class="btn ghost" data-x="prev" ${si===0?"disabled":""}>‹ Earlier</button><button class="btn ghost" data-x="rand">Random season</button><button class="btn ghost" data-x="nextS" ${si===SEASONS.length-1?"disabled":""}>Later ›</button></div></div>
  <div class="seasons" role="group" aria-label="Season">${SEASONS.map(s=>`<button data-xi="${s[0]}" aria-pressed="${s[0]===xi.id}"><b>${s[0].slice(2,4)}/${s[0].slice(5)}</b><span class="stars">${stars((best[s[0]]||{}).stars||0)}</span></button>`).join("")}</div>
  <div class="draft"><div class="pitch2 xi"><span class="box18 top"></span><span class="box18"></span>${slots}</div><div class="side"><div class="box">
    <span class="label">Most-used XI</span><h3 style="margin-top:4px">Fenerbahçe ${seasonLabel(S[0])}</h3>
    <div class="facts"><div><span class="label">Shape</span><b>${S[2]}</b></div><div><span class="label">Season</span><b>${seasonLabel(S[0])}</b></div></div>
    ${xi.mode==="clock"&&!xi.start&&!xi.ended?`<div class="btns"><button class="btn" data-x="start">Start the clock (${fmtClock(XI_TIME)})</button></div>`:
    `<form class="guessbar" id="xiForm" autocomplete="off"><input id="xiGuess" placeholder="Type a player…" aria-label="Player name" ${locked?"disabled":""}><button class="btn" ${locked?"disabled":""}>Guess</button></form>`}
    <p class="msg ${xi.cls}">${esc(xi.msg)}</p>
    <div class="xinums"><div><b class="count">${n}</b><span class="label">of 11</span></div><div><b class="count">${xi.ended?xi.final:xiScore()}</b><span class="label">points</span></div>${xi.mode==="clock"?`<div><b class="count" id="xiClock">${fmtClock(xiLeft())}</b><span class="label">left</span></div>`:""}</div>
    ${xi.ended?`<p style="margin-top:10px;font-size:22px;color:var(--accent)">${stars(xiStars())}</p>`:""}
    <div class="btns"><button class="btn ghost" data-x="hint" ${locked?"disabled":""}>Hint (−4)</button><button class="btn ghost" data-x="give" ${locked?"disabled":""}>Give up</button><button class="btn ghost" data-x="reset">Start over</button></div>
    <p class="gnote">Picked by ${METRIC[S[1]]} in the Süper Lig. The shape comes from each player's listed position, so it may not match the tactics every week.</p>
  </div></div></div>`;
  p.querySelectorAll("[data-xi]").forEach(b=>b.onclick=()=>{newXI(b.dataset.xi);renderPanel()});
  p.querySelectorAll("[data-xm]").forEach(b=>b.onclick=()=>{newXI(xi.id,b.dataset.xm);renderPanel()});
  const on=(k,fn)=>{const b=p.querySelector(`[data-x="${k}"]`);if(b)b.onclick=fn};
  on("prev",()=>{newXI(SEASONS[si-1][0]);renderPanel()});on("nextS",()=>{newXI(SEASONS[si+1][0]);renderPanel()});
  on("rand",()=>{newXI(SEASONS[Math.floor(Math.random()*SEASONS.length)][0]);renderPanel()});
  const f=p.querySelector("#xiForm");if(f)f.onsubmit=e=>{e.preventDefault();if(locked)return;const raw=p.querySelector("#xiGuess").value,v=norm(raw);if(!v)return;
    const hit=ps.find(x=>!xi.found.has(x.key)&&x.al.some(a=>closeEnough(v,a)))||ps.find(x=>x.al.some(a=>closeEnough(v,a)));
    if(!hit){xi.wrong++;xi.msg=`${raw} isn't in this XI (−2).`;xi.cls="bad"}else if(xi.found.has(hit.key)){xi.msg=`You already have ${hit.name}.`;xi.cls=""}
    else{xi.found.add(hit.key);xi.msg=`Yes: ${hit.name}.`;xi.cls="good";if(xi.found.size===11)xiEnd("All eleven!")}
    renderPanel();const i=document.getElementById("xiGuess");if(i&&!i.disabled)i.focus()};
  on("start",()=>{xi.start=Date.now();xiTimer=setInterval(()=>{const c=document.getElementById("xiClock"),l=xiLeft();if(c)c.textContent=fmtClock(l);if(l<=0){xiEnd(`Time's up! You found ${xi.found.size} of 11.`);if(c)renderPanel()}},250);renderPanel();const i=document.getElementById("xiGuess");if(i)i.focus()});
  on("hint",()=>{const left=ps.filter(x=>!xi.found.has(x.key)&&!xi.hints.has(x.key));if(left.length){xi.hints.add(left[Math.floor(Math.random()*left.length)].key);xi.msg="Hint: first letters of one player.";xi.cls=""}renderPanel()});
  on("give",()=>{xiEnd(`You found ${xi.found.size} of 11.`);renderPanel()});on("reset",()=>{newXI(xi.id);renderPanel()});
}

/* ===== 4. PENALTIES with the wheel ===== */
const PEN30=[["Lefter Küçükandonyadis","Lefter",93],["Melih Kotanca","Melih",86],["Alex de Souza","Alex",92],["Aykut Kocaman","Aykut",90],["Naci Bastoncu","Naci",84],["Cemil Turan","Cemil",88],["Fikret Arıcan","Fikret",82],["Ogün Altıparmak","Ogün",84],["Şeref Has","Şeref",83],["Semih Şentürk","Semih",84],
 ["Tanju Çolak","Tanju",89],["Can Bartu","Can Bartu",87],["Rıdvan Dilmen","Rıdvan",86],["Selçuk Yula","Selçuk Yula",84],["Elvir Bolić","Bolić",84],["Pierre van Hooijdonk","Van Hooijdonk",91],["Tuncay Şanlı","Tuncay",85],["Moussa Sow","Sow",83],["Emmanuel Emenike","Emenike",82],["Edin Džeko","Džeko",90],
 ["Dušan Tadić","Tadić",89],["Enner Valencia","Valencia",86],["Robin van Persie","Van Persie",88],["Emre Belözoğlu","Emre",88],["Mateja Kežman","Kežman",84],["Nicolas Anelka","Anelka",87],["Youssef En-Nesyri","En-Nesyri",83],["Dirk Kuyt","Kuyt",87],["Roberto Carlos","R. Carlos",85],["Anderson Talisca","Talisca",88]].map(([n,s,r])=>({n,short:s,r}));
const GW=7.32,GH=2.44,gx=x=>15+x/GW*70,gy=y=>49.3-y/GH*37.3;
const ZC=z=>[[1.25,3.66,6.07][z%3],[1.72,0.6][Math.floor(z/3)]];
const zoneOf=(x,y)=>(y>1.22?0:3)+(x<2.44?0:x<4.88?1:2);
const ZN=["top left","top middle","top right","bottom left","bottom middle","bottom right"];
let pk=null,pkRAF=null;
function newPK(){cancelAnimationFrame(pkRAF);pkRAF=null;const full=dr&&dr.picks.every(Boolean);
  pk={phase:"setup",takers:[],respins:3,spinning:false,rot:0,lastNew:-1,gk:full?dr.picks[0]:PBY["Volkan Demirel"],you:[],them:[],turn:"shoot",t0:0,cx:3.66,cy:1.2,hist:[0,0,0,0,0,0],bias:shuffle([3.2,2,1.4,1,.8,.6]),banner:"",over:null,anim:null,tell:null,shot:null}}
const wheelItems=()=>PEN30.filter(x=>!pk.takers.includes(x));
function drawWheel(cv){if(!cv)return;const items=wheelItems(),dpr=window.devicePixelRatio||1,W=cv.clientWidth||400;cv.width=W*dpr;cv.height=W*dpr;const c=cv.getContext("2d");c.scale(dpr,dpr);
  const cs=getComputedStyle(document.documentElement),Y=cs.getPropertyValue("--yellow").trim(),N=cs.getPropertyValue("--navy-3").trim(),N2=cs.getPropertyValue("--navy").trim(),INK=cs.getPropertyValue("--ink").trim(),D="#0a1530";
  const R=W/2,seg=2*Math.PI/items.length;c.translate(R,R);
  items.forEach((it,i)=>{const a0=pk.rot+i*seg;c.beginPath();c.moveTo(0,0);c.arc(0,0,R-2,a0,a0+seg);c.closePath();c.fillStyle=i%2?Y:(i%4===0?N:N2);c.fill();c.strokeStyle="rgba(0,0,0,.25)";c.lineWidth=1;c.stroke();
    c.save();c.rotate(a0+seg/2);c.textAlign="right";c.textBaseline="middle";c.fillStyle=i%2?D:INK;const fs=Math.max(9,Math.min(15,W/(items.length*1.55)));c.font=`700 ${fs}px "Barlow Condensed", Arial Narrow, sans-serif`;c.fillText(it.short.toUpperCase(),R-12,0);c.restore()})}
function spinWheel(){if(pk.spinning||pk.takers.length>=5)return;const items=wheelItems(),seg=2*Math.PI/items.length,start=pk.rot,target=start+2*Math.PI*(5+Math.random())+Math.random()*2*Math.PI;
  const dur=matchMedia("(prefers-reduced-motion: reduce)").matches?600:3800,t0=performance.now();pk.spinning=true;renderPanel();
  const step=now=>{const k=Math.min(1,(now-t0)/dur),e=1-Math.pow(1-k,3);pk.rot=start+(target-start)*e;drawWheel(document.getElementById("wheel"));
    if(k<1)requestAnimationFrame(step);else{pk.rot=target%(2*Math.PI);const a=((-Math.PI/2-pk.rot)%(2*Math.PI)+4*Math.PI)%(2*Math.PI);const idx=Math.floor(a/seg)%items.length;pk.takers.push(items[idx]);pk.lastNew=pk.takers.length-1;pk.spinning=false;renderPanel()}};
  requestAnimationFrame(step)}
const taker=()=>pk.takers[pk.you.length%pk.takers.length];
const tri=(t,per)=>{const ph=(t%(2*per))/per;return ph<1?ph:2-ph};
function pkLoop(){if(!pk||(pk.phase!=="aimX"&&pk.phase!=="aimY")){pkRAF=null;return}const el=document.getElementById("pkAim");if(!el){pkRAF=null;return}
  const r=taker().r,now=performance.now()-pk.t0;if(pk.phase==="aimX"){pk.cx=-0.7+tri(now,(0.95+(r-75)*0.05)*1000)*(GW+1.4);pk.cy=1.15}else pk.cy=tri(now,(0.75+(r-75)*0.04)*1000)*3.2;
  el.style.left=gx(pk.cx)+"%";el.style.top=gy(pk.cy)+"%";pkRAF=requestAnimationFrame(pkLoop)}
function pkOutcome(){const y=pk.you.filter(Boolean).length,t=pk.them.filter(Boolean).length,ny=pk.you.length,nt=pk.them.length;
  if(ny<=5&&nt<=5){if(y+(5-ny)<t)return"lose";if(t+(5-nt)<y)return"win"}if(ny>=5&&ny===nt&&y!==t)return y>t?"win":"lose";return null}
function pkLock(){if(!pk||pk.over)return;if(pk.phase==="aimX"){pk.ax=pk.cx;pk.phase="aimY";pk.t0=performance.now();renderPanel()}else if(pk.phase==="aimY"){pk.ay=pk.cy;pkShoot()}}
function pkResolve(scored,banner,ball,keeper,isYou){pk.phase="anim";pk.anim={ball,keeper,played:false};renderPanel();
  setTimeout(()=>{(isYou?pk.you:pk.them).push(scored);pk.banner=banner;const o=pkOutcome();if(o){pk.over=o;if(o==="win")store.set("fb-pk-wins",store.get("fb-pk-wins",0)+1)}renderPanel();
    setTimeout(()=>{pk.anim=null;pk.banner="";if(pk.over)pk.phase="over";else if(isYou){pk.turn="save";pkPrepSave()}else{pk.turn="shoot";pk.phase="aimX";pk.t0=performance.now()}renderPanel()},1300)},620)}
function pkShoot(){const x=pk.ax,y=pk.ay;let banner,scored=false;const dive=Math.random()<.12?null:pickW([0,1,2,3,4,5],z=>1+2*pk.hist[z]),[tx,ty]=dive==null?[3.66,1]:ZC(dive),reach=dive==null?.95:1.15;
  if(x<0||x>GW)banner="Wide!";else if(y>GH)banner="Over the bar!";
  else{pk.hist[zoneOf(x,y)]++;const post=x<.14||x>GW-.14||y>GH-.12;if(post&&Math.random()<.4)banner="Off the woodwork!";else if(Math.hypot(x-tx,(y-ty)*1.25)<reach)banner="Saved!";else{banner="Goal!";scored=true}}
  pkResolve(scored,banner,[x,Math.min(y,3.3)],[tx,ty,dive],true)}
function pkPrepSave(){const z=pickW([0,1,2,3,4,5],i=>pk.bias[i]),[cx,cy]=ZC(z);let x=clamp(cx+rnd(-.95,.95),.15,GW-.15),y=clamp(cy+rnd(-.45,.45),.15,GH-.12);
  const miss=Math.random()<.08;if(miss){if(Math.random()<.5)y=2.75;else x=x<GW/2?-.35:GW+.35}
  const col=z%3,tc=Math.random()<.62?col:[0,1,2].filter(c=>c!==col)[Math.floor(Math.random()*2)];pk.shot={x,y,miss};pk.tell=["the left side","the middle","the right side"][tc];pk.phase="dive"}
function pkDive(z){if(pk.phase!=="dive")return;const [tx,ty]=ZC(z),{x,y,miss}=pk.shot,saved=!miss&&Math.hypot(x-tx,(y-ty)*1.25)<1.15;
  pkResolve(!miss&&!saved,miss?(y>GH?"Over the bar!":"Wide!"):saved?"You saved it!":"They score.",[x,y],[tx,ty,z],false)}
function renderPK(p){
  if(!pk)newPK();cancelAnimationFrame(pkRAF);pkRAF=null;
  if(pk.phase==="setup"){const full=pk.takers.length>=5;
    p.innerHTML=`<h2>Penalty Shootout</h2><p class="intro">First, spin the wheel to pick your five penalty takers. The wheel holds 30 of the greatest goalscorers in Fenerbahçe history, and each one has a composure rating: the higher it is, the slower your aiming marker moves. You get three re-spins.</p>
    <div class="pk-wrap"><div><div class="wheelwrap"><span class="ptr" aria-hidden="true"></span><canvas id="wheel" aria-label="Wheel of 30 Fenerbahçe goalscorers"></canvas><span class="hub">${full?"5/5":"SPIN"}</span></div></div>
    <div class="side"><div class="box"><span class="label">Your takers</span><ol class="takers">${[0,1,2,3,4].map(i=>{const t=pk.takers[i];return t?`<li class="${i===pk.lastNew?"new":""}"><b>${esc(t.n)}</b><em>${t.r}</em></li>`:`<li class="empty"><span>Spin to fill</span><span></span></li>`}).join("")}</ol>
      <div class="btns"><button class="btn" data-pk="spin" ${pk.spinning||full?"disabled":""}>${pk.spinning?"Spinning…":"Spin the wheel"}</button><button class="btn ghost" data-pk="respin" ${pk.spinning||!pk.takers.length||!pk.respins?"disabled":""}>Re-spin last (${pk.respins} left)</button></div>
      <div class="btns"><button class="btn ${full?"":"ghost"}" data-pk="go" ${full&&!pk.spinning?"":"disabled"}>Start the shootout</button></div>
      <p class="gnote">In goal: ${esc(pk.gk.n)}${dr&&dr.picks.every(Boolean)?" (from your drafted XI)":""}. Composure ratings are made up for this game.</p></div></div></div>`;
    requestAnimationFrame(()=>drawWheel(document.getElementById("wheel")));
    const on=(k,f)=>{const b=p.querySelector(`[data-pk="${k}"]`);if(b)b.onclick=f};
    on("spin",spinWheel);on("respin",()=>{if(!pk.respins||pk.spinning)return;pk.respins--;pk.takers.pop();pk.lastNew=-1;spinWheel()});
    on("go",()=>{pk.phase="aimX";pk.t0=performance.now();renderPanel()});return}
  const dots=a=>{let h="";for(let i=0;i<Math.max(5,a.length);i++)h+=`<i class="dot ${a[i]===true?"g":a[i]===false?"m":""}"></i>`;return h};
  const t=taker(),aim=pk.phase==="aimX"||pk.phase==="aimY",youKeep=pk.turn==="save";
  const rot=k=>{if(!k||k[2]==null)return 0;const c=k[2]%3,top=k[2]<3;return c===1?0:(c===0?-1:1)*(top?70:55)};
  const kp=pk.anim&&pk.anim.played?pk.anim.keeper:[3.66,.95],bp=pk.anim&&pk.anim.played?pk.anim.ball:null;
  let hud;
  if(pk.over)hud=`<span class="label">Full time</span><p class="msg ${pk.over==="win"?"good":"bad"}" style="font-size:20px">${pk.over==="win"?"Fenerbahçe win the shootout!":"The opponents win this one."}</p>`;
  else if(pk.turn==="shoot")hud=`<span class="label">Your kick ${pk.you.length+1}${pk.you.length>=5?" · sudden death":""}</span><h3 style="margin-top:4px">${esc(t.n)} <span style="color:var(--muted);font-size:16px">composure ${t.r}</span></h3>
     <p style="margin-top:8px">${pk.phase==="aimX"?"Step 1: stop the marker to set the direction.":pk.phase==="aimY"?"Step 2: stop it again to set the height. Too high and it goes over.":"…"}</p>
     <p class="gnote">Tap the pitch, press Space or use the button. The keeper learns where you like to shoot.</p>${aim?`<div class="btns"><button class="btn" data-pk="lock">${pk.phase==="aimX"?"Set direction":"Shoot"}</button></div>`:""}`;
  else hud=`<span class="label">You're in goal · ${esc(pk.gk.n)}</span><h3 style="margin-top:4px">Their taker is eyeing ${pk.tell||"…"}</h3><p class="gnote">The read is right a bit more often than not. Tap where you want to dive.</p>`;
  p.innerHTML=`<h2>Penalty Shootout</h2><p class="intro">Five kicks each, then sudden death. To shoot, time two taps: one for direction, one for height. In goal, read the taker and dive.</p>
  <div class="pk-wrap"><div class="pk-field" id="pkf"><div class="pk-line"></div><div class="pk-box"></div><div class="pk-spot"></div>
    <div class="pk-goal">${pk.phase==="dive"?[0,1,2,3,4,5].map(z=>`<button class="pk-zone" data-z="${z}" aria-label="Dive ${ZN[z]}"></button>`).join(""):""}</div>
    <div class="pk-keeper ${youKeep?"":"them"} ${pk.anim&&pk.anim.played?"notrans":""}" id="pkk" style="left:${gx(kp[0])}%;top:${gy(kp[1])}%;--rot:${pk.anim&&pk.anim.played?rot(pk.anim.keeper):0}deg"></div>
    <div class="pk-ball ${bp?"notrans":""}" id="pkb" style="left:${bp?gx(bp[0]):50}%;top:${bp?gy(bp[1]):88}%;${bp?"width:2.6%":""}"></div>
    ${aim?`<div class="pk-aim" id="pkAim" style="left:${gx(pk.cx)}%;top:${gy(pk.cy)}%"></div>${pk.phase==="aimY"?`<div class="pk-guide" style="left:${gx(pk.ax)}%"></div>`:""}`:""}
    <div class="pk-banner">${esc(pk.banner)}</div></div>
  <div class="side"><div class="box">${hud}</div><div class="box">
    <div class="pk-score"><div class="pk-team"><span style="color:var(--accent)">Fener</span><div class="dots">${dots(pk.you)}</div><b>${pk.you.filter(Boolean).length}</b></div>
    <div class="pk-team"><span>Opponents</span><div class="dots">${dots(pk.them)}</div><b>${pk.them.filter(Boolean).length}</b></div></div>
    <p class="gnote">Order: ${pk.takers.map((x,i)=>`${i+1}. ${esc(x.short)}`).join(" · ")}</p>
    <div class="btns"><button class="btn ${pk.over?"":"ghost"}" data-pk="new">${pk.over?"New shootout":"Restart"}</button>${pk.over?`<button class="btn ghost" data-pk="same">Same takers</button>`:""}</div>
    <p class="gnote">Shootouts won: ${store.get("fb-pk-wins",0)}</p></div></div></div>`;
  p.querySelectorAll("[data-z]").forEach(b=>b.onclick=e=>{e.stopPropagation();pkDive(+b.dataset.z)});
  const lb=p.querySelector('[data-pk="lock"]');if(lb)lb.onclick=pkLock;
  p.querySelector('[data-pk="new"]').onclick=()=>{newPK();renderPanel()};
  const sm=p.querySelector('[data-pk="same"]');if(sm)sm.onclick=()=>{const tk=pk.takers;newPK();pk.takers=tk;pk.phase="aimX";pk.t0=performance.now();renderPanel()};
  p.querySelector("#pkf").onpointerdown=e=>{if(aim){e.preventDefault();pkLock()}};
  if(pk.anim&&!pk.anim.played){const a=pk.anim,b=p.querySelector("#pkb"),k=p.querySelector("#pkk");a.played=true;
    requestAnimationFrame(()=>requestAnimationFrame(()=>{b.style.left=gx(a.ball[0])+"%";b.style.top=gy(a.ball[1])+"%";b.style.width="2.6%";k.style.left=gx(a.keeper[0])+"%";k.style.top=gy(a.keeper[1])+"%";k.style.setProperty("--rot",rot(a.keeper)+"deg")}))}
  if(aim)pkRAF=requestAnimationFrame(pkLoop);
}

/* ===== 5. WHO AM I? (hard) ===== */
const SPECIAL={"Lefter Küçükandonyadis":"Fans called me 'Ordinaryüs', the Professor.","Can Bartu":"I also played basketball for the club, and later played in Italy.","Rıdvan Dilmen":"I later became one of Turkey's best-known TV pundits.","Aykut Kocaman":"I scored goals here and later coached the club to the 2012 cup.","Harald Schumacher":"I played in two World Cup finals for West Germany.","Jay-Jay Okocha":"I arrived from Eintracht Frankfurt and loved a step-over.","Tanju Çolak":"I crossed the city from Galatasaray to score for Fenerbahçe.","Haim Revivo":"I came from Celta Vigo and later played for Galatasaray.","Elvir Bolić":"I scored a famous Champions League winner at Old Trafford.","Oğuz Çetin":"I was a creative midfielder of the late 1980s and early 1990s.","Cemil Turan":"I was the goal machine of the 1970s title teams."};
let who=null;
function whoClues(x){const c=[];
  if(x.seasons.length){const s=x.seasons[Math.floor(Math.random()*x.seasons.length)],xi=SEASONS.find(q=>q[0]===s)[3].flat().filter(n=>n!==x.n),m=shuffle(xi).slice(0,2);
    c.push(`In ${seasonLabel(s)} I was in Fenerbahçe's most-used XI with ${m[0]} and ${m[1]}.`);
    c.push(x.seasons.length===1?"I was a regular for just one season.":`I was a regular in ${x.seasons.length} different seasons, between ${seasonLabel(x.seasons[0])} and ${seasonLabel(x.seasons[x.seasons.length-1])}.`);
    c.push(`I mostly played as a ${LINE_NAME[x.line]}${x.p?` and I'm from ${NAT[x.p.nat]}`:""}.`)}
  else{const p=x.p,m=shuffle(PLAYERS.filter(q=>together(p,q)&&q.r>=80)).slice(0,2);
    c.push(m.length?`At Fenerbahçe I played alongside ${m.map(q=>q.n).join(" and ")}.`:`My Fenerbahçe career started in ${p.from<1960?"the 1940s or 1950s":"the "+String(p.from).slice(0,3)+"0s"}.`);
    c.push(`My Fenerbahçe years were roughly ${p.from}–${p.to}.`);
    c.push(SPECIAL[x.n]||`I'm a ${ROLE_NAME[p.pos].toLowerCase()} from ${NAT[p.nat]}.`)}
  c.push(`My initials are ${initialsOf(x.n)}`);return c}
const together=(a,b)=>a!==b&&a.from<=b.to&&b.from<=a.to;
/* ===== 6. TIMELINE (hard) ===== */
const ARRIVALS=[["Alex de Souza",2004],["Roberto Carlos",2007],["Jay-Jay Okocha",1996],["Nicolas Anelka",2005],["Dirk Kuyt",2012],["Robin van Persie",2015],["Edin Džeko",2023],["Dušan Tadić",2023],["Milan Škriniar",2025],["Mattéo Guendouzi",2025],["Ederson",2025],["Mateja Kežman",2006],["Diego Lugano",2006],["Stephen Appiah",2005],["Harald Schumacher",1988],["Pierre van Hooijdonk",2003],["Raul Meireles",2012],["Diego Ribas",2014],["Fred",2023],["Mesut Özil",2021],["Marco Asensio",2025],["Haim Revivo",1997],["Ariel Ortega",2002],["Youssef En-Nesyri",2024],["Bruno Alves",2013],["Simon Kjær",2015],["Dominik Livaković",2023],["Sebastian Szymański",2023]];
function tlDeck(){const ev=[],seen=new Set(),add=(y,t,s)=>{if(!seen.has(t)){seen.add(t);ev.push({y,t,s})}};
  Object.values(SPORTS).forEach(s=>{(s.history||[]).forEach(([y,t])=>{if(/^\d{4}$/.test(y))add(+y,t,s.label)});(s.games||[]).forEach(g=>add(+g.date.slice(0,4),g.res?`${g.home} ${g.res} ${g.away} (${g.comp})`:`${g.title} (${g.comp})`,s.label))});
  ARRIVALS.forEach(([n,y])=>add(y,`${n} signs for Fenerbahçe`,"Transfers"));
  shuffle(Object.values(PEOPLE).filter(x=>x.seasons.length&&x.seasons[0]!=="2000-01")).slice(0,45).forEach(x=>add(+x.seasons[0].slice(0,4),`${x.n} becomes a first-team regular (season starts this year)`,"Squads"));
  return shuffle(ev)}

/* ================= SHARED GAME ENGINES ================= */
const gauss=()=>{let u=0,v=0;while(!u)u=Math.random();while(!v)v=Math.random();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v)};
const localDay=()=>Math.floor((Date.now()-new Date().getTimezoneOffset()*6e4)/864e5);
const DAY0=Math.floor(Date.UTC(2026,10,1)/864e5);
const SK=(b,k)=>`fb-${b}-${k}`;
const stars3=s=>"★".repeat(s)+"☆".repeat(3-s);
function rerender(){renderPanel()}

/* ---------- People for basketball and volleyball ---------- */
const PERSON_MAP={"Ali Muhammed":"Bobby Dixon","Eda Erdem":"Eda Erdem Dündar","Seda Aslanyürek":"Seda Tokatlıoğlu","Meliha Diken":"Meliha İsmailoğlu","Naz Aydemir":"Naz Aydemir"};
function buildPeople(pool,lineups,squads){const M={};pool.forEach(p=>M[p.n]={...p,apps:[],squads:[]});
  (lineups||[]).forEach(L=>{L.st.forEach(([pos,n,pts])=>add(n,{L,pts,starter:true,pos}));L.bench.forEach(([n,pts])=>add(n,{L,pts,starter:false,pos:null}))});
  (squads||[]).forEach(S=>S.sq.forEach(([num,n,pos])=>{const k=PERSON_MAP[n]||n;if(!M[k])M[k]={n:k,pos,alt:[],r:75,nat:null,short:k.split(" ").slice(-1)[0],ten:"",apps:[],squads:[]};if(!M[k].pos&&pos)M[k].pos=pos;M[k].squads.push({S,num,as:n})}));
  function add(n,a){const k=PERSON_MAP[n]||n;if(!M[k])M[k]={n:k,pos:a.pos,alt:[],r:75,nat:null,short:k.split(" ").slice(-1)[0],ten:"",apps:[],squads:[]};if(!M[k].pos&&a.pos)M[k].pos=a.pos;M[k].apps.push({...a,as:n})}
  return M}
const BPEOPLE={basketball:buildPeople(MB_P,MB_LINEUPS),"womens-basketball":buildPeople(WB_P,WB_LINEUPS),volleyball:buildPeople(VB_P,null,VB_SQUADS)};
function aliasB(n){const parts=norm(n).split(" "),al=new Set([norm(n),parts[parts.length-1]]);if(parts.length>2)al.add(parts.slice(-2).join(" "));if(parts[0].length>=4)al.add(parts[0]);
  const real=PERSON_MAP[n]||n;[n,real].forEach(k=>(ALIAS2[k]||[]).forEach(a=>al.add(norm(a))));const per=Object.values(BPEOPLE).map(M=>M[real]).find(Boolean);if(per)al.add(norm(per.short));return [...al].filter(x=>x.length>=2)}
function uniqueAliases(names){const all=names.map(aliasB),cnt={};all.forEach(a=>a.forEach(x=>cnt[x]=(cnt[x]||0)+1));return all.map((a,i)=>a.filter(x=>cnt[x]===1||x===norm(names[i])))}

/* ---------- QUIZ ---------- */
const quizS={};


/* ---------- FENERDLE (any branch) ---------- */
function wPool(M){const seen=new Set(),out=[];Object.values(M).forEach(x=>{const w=norm(x.short).toUpperCase(),L=w.replace(/ /g,"").length;if(L>=3&&L<=14&&w.split(" ").length<=3&&!seen.has(w)){seen.add(w);out.push({x,w})}});return out.sort((a,b)=>a.w<b.w?-1:1)}
const bEra=x=>x.ten?x.ten:x.apps&&x.apps.length?`In the ${[...new Set(x.apps.map(a=>a.L.label.slice(0,4)))].join(", ")} box score${x.apps.length>1?"s":""}`:x.squads&&x.squads.length?`${x.squads.map(s=>s.S.id).join(", ")} squad${x.squads.length>1?"s":""}`:"–";
const bHints={pos:["Position",x=>x.pos?BPOS[x.pos][0].toUpperCase()+BPOS[x.pos].slice(1):"–"],era:["Era",bEra],nat:["Country",x=>x.nat?NAT2[x.nat].replace(/^the /,"The "):`Starts with ${x.short[0]}`]};
const WCFG={
 football:{pool:()=>WP_FB,hints:{pos:["Position",x=>x.line?LINE_NAME[x.line][0].toUpperCase()+LINE_NAME[x.line].slice(1):"–"],era:["Era",x=>x.seasons.length?`Regular from ${seasonLabel(x.seasons[0])}`:x.p?`Joined around ${x.p.from}`:"–"],nat:["Country",x=>x.p?NAT[x.p.nat].replace(/^the /,"The "):`Starts with ${x.short[0]}`]},
   done:x=>x.seasons.length?`, a regular in ${x.seasons.length} season${x.seasons.length>1?"s":""}`:x.p?` (${yrs(x.p)})`:""},
 basketball:{pool:()=>wPool(BPEOPLE.basketball),hints:bHints,done:x=>x.pos?`, ${BPOS[x.pos]}`:""},
 "womens-basketball":{pool:()=>wPool(BPEOPLE["womens-basketball"]),hints:bHints,done:x=>x.pos?`, ${BPOS[x.pos]}`:""},
 volleyball:{pool:()=>wPool(BPEOPLE.volleyball),hints:bHints,done:x=>x.pos?`, ${BPOS[x.pos]}`:""}
};
let WP_FB=null;
const LENS={any:["Any length",()=>true],short:["Short · up to 5",n=>n<=5],mid:["Medium · 6–8",n=>n>=6&&n<=8],long:["Long · 9+",n=>n>=9]};
const letters=w=>w.replace(/ /g,"");
const wdS={};
function newWordle(b,daily,len){const C=WCFG[b],P=C.pool(),prev=wdS[b];len=len||(prev?prev.len:"any");const d=localDay(),salt=b.length*131;
  const pool=daily?P:P.filter(e=>LENS[len][1](letters(e.w).length)),e=daily?P[(d*7919+salt)%P.length]:pool[Math.floor(Math.random()*pool.length)];
  const wd={b,x:e.x,word:e.w,ans:letters(e.w),daily,len,day:d,num:d-DAY0+1,rows:[],hints:[],cur:"",done:false,won:false,msg:"",flip:-1,hard:store.get("fb-wd-hard",false),copied:"",size:P.length};
  if(daily){const s=store.get(SK(b,"wd-day"),null);if(s&&s.day===d&&s.word===e.w)Object.assign(wd,{rows:s.rows,hints:s.hints,done:s.done,won:s.won,hard:s.hard})}wdS[b]=wd;return wd}
function saveDaily(wd){if(wd.daily)store.set(SK(wd.b,"wd-day"),{day:wd.day,word:wd.word,rows:wd.rows,hints:wd.hints,done:wd.done,won:wd.won,hard:wd.hard})}
function scoreGuess(g,a){const r=Array(a.length).fill("absent"),c={};for(let i=0;i<a.length;i++){if(g[i]===a[i])r[i]="correct";else c[a[i]]=(c[a[i]]||0)+1}for(let i=0;i<a.length;i++){if(r[i]!=="correct"&&c[g[i]]>0){r[i]="present";c[g[i]]--}}return r}
function hardBreak(wd,g){for(const r of wd.rows){const sc=scoreGuess(r,wd.ans);for(let i=0;i<r.length;i++)if(sc[i]==="correct"&&g[i]!==r[i])return `Hard mode: letter ${i+1} must be ${r[i]}.`;
  const need={};[...r].forEach((c,i)=>{if(sc[i]!=="absent")need[c]=(need[c]||0)+1});for(const c in need)if([...g].filter(x=>x===c).length<need[c])return `Hard mode: your guess must use ${c}.`}return null}
function wdFinish(wd){if(!wd.daily)return;const k=SK(wd.b,"wd-stats"),st=store.get(k,{played:0,wins:0,streak:0,max:0,dist:[0,0,0,0,0,0],last:null});if(st.last===wd.day)return;
  st.played++;if(wd.won){st.wins++;st.streak=(st.last===wd.day-1?st.streak:0)+1;st.max=Math.max(st.max,st.streak);st.dist[wd.rows.length-1]++}else st.streak=0;st.last=wd.day;store.set(k,st)}
function wordleKey(k){const wd=wdS[current];if(!wd||wd.done)return;const L=wd.ans.length;wd.msg="";
  if(k==="ENTER"){if(wd.cur.length<L)wd.msg=`The name has ${L} letters.`;else{const hb=wd.hard?hardBreak(wd,wd.cur):null;if(hb)wd.msg=hb;else{wd.rows.push(wd.cur);wd.flip=wd.rows.length-1;const g=wd.cur;wd.cur="";if(g===wd.ans)wd.done=wd.won=true;else if(wd.rows.length>=6)wd.done=true;if(wd.done)wdFinish(wd);saveDaily(wd)}}}
  else if(k==="BACK")wd.cur=wd.cur.slice(0,-1);else if(/^[A-Z]$/.test(k)&&wd.cur.length<L)wd.cur+=k;rerender()}
function shareText(wd){const em={correct:"🟨",present:"🟦",absent:"⬛"};return `Fenerdle ${SPORTS[wd.b].label} #${wd.num} ${wd.won?wd.rows.length:"X"}/6${wd.hard?"*":""}${wd.hints.length?` (${wd.hints.length} hint${wd.hints.length>1?"s":""})`:""}\n`+wd.rows.map(r=>scoreGuess(r,wd.ans).map(s=>em[s]).join("")).join("\n")}
function gWordle(el){const b=current,C=WCFG[b];let wd=wdS[b]||newWordle(b,true);
  const chars=[...wd.word],n=chars.length,L=wd.ans.length,ks={},rank={absent:1,present:2,correct:3};
  const t=Math.max(22,Math.min(54,Math.floor((Math.min(window.innerWidth||600,620)-48-(n-1)*6)/n))),g=t<34?4:6;
  wd.rows.forEach(r=>scoreGuess(r,wd.ans).forEach((s,i)=>{if(!ks[r[i]]||rank[s]>rank[ks[r[i]]])ks[r[i]]=s}));
  const rowHTML=(lt,sc,flip)=>{let k=0;return chars.map(c=>{if(c===" ")return `<div class="tile sp"></div>`;const i=k++,ch=lt[i]||"";return `<div class="tile ${sc?sc[i]:ch?"filled":""} ${flip?"flip":""}" style="${flip?`animation-delay:${i*90}ms`:""}">${ch}</div>`}).join("")};
  let grid="";for(let r=0;r<6;r++){let inner;if(r<wd.rows.length)inner=rowHTML(wd.rows[r],scoreGuess(wd.rows[r],wd.ans),r===wd.flip);else if(r===wd.rows.length&&!wd.done)inner=rowHTML(wd.cur,null,false);else inner=rowHTML("",null,false);grid+=`<div class="wrow">${inner}</div>`}
  wd.flip=-1;
  const kb=["QWERTYUIOP","ASDFGHJKL","^ZXCVBNM<"].map(r=>`<div class="kbr">${[...r].map(c=>c==="^"?`<button class="key wide" data-k="ENTER">Enter</button>`:c==="<"?`<button class="key wide" data-k="BACK" aria-label="Delete">⌫</button>`:`<button class="key ${ks[c]||""}" data-k="${c}">${c}</button>`).join("")}</div>`).join("");
  const hintBtns=Object.entries(C.hints).map(([k,[lab,f]])=>wd.hints.includes(k)||wd.done?`<div class="hint on"><span class="label">${lab}</span><b>${esc(f(wd.x))}</b></div>`:`<button class="hint" data-h="${k}"><span class="label">${lab}</span><b>Reveal</b></button>`).join("");
  const st=store.get(SK(b,"wd-stats"),{played:0,wins:0,streak:0,max:0,dist:[0,0,0,0,0,0]}),mx=Math.max(1,...st.dist);
  const words=wd.word.split(" ").map(w=>w.length).join(" + ");
  const status=wd.done?`<p class="msg ${wd.won?"good":"bad"}">${wd.won?`Got it in ${wd.rows.length}!`:"Out of guesses."} It was <b>${esc(wd.x.n)}</b>${esc(C.done(wd.x))}.</p>`
    :`<p class="msg ${wd.msg?"bad":""}">${wd.msg?esc(wd.msg):`${L} letters${n>L?` (${words})`:""} · ${6-wd.rows.length} guesses left · ${wd.daily?`daily puzzle #${wd.num}`:"practice round"}`}</p>`;
  el.innerHTML=`<h2>Fenerdle</h2><p class="intro">Guess the ${esc(SPORTS[b].label.toLowerCase())} player in six tries. Names can be from three to fourteen letters, and some have two or three words. You only type the letters; the gaps fill themselves. Turkish letters are written without accents (Ş becomes S).</p>
  <div class="wtop"><div class="filter" role="group" aria-label="Mode"><button data-wm="daily" aria-pressed="${wd.daily}">Daily</button>${Object.entries(LENS).map(([k,[lab]])=>`<button data-wl="${k}" aria-pressed="${!wd.daily&&wd.len===k}">${lab}</button>`).join("")}</div>
    <label class="toggle"><input type="checkbox" id="wdHard" ${wd.hard?"checked":""} ${wd.rows.length?"disabled":""}> Hard mode</label></div>
  <div class="wcenter" style="margin-top:12px">${status}</div>
  <div class="wgame"><div class="wgrid" translate="no" style="--t:${t}px;--g:${g}px">${grid}</div>
   <div class="wside"><span class="label">Hints · they show in your shared result</span><div class="hints">${hintBtns}</div>
   ${wd.done?`<div class="btns">${wd.daily?`<button class="btn" data-w="share">Copy result</button>`:""}<button class="btn ${wd.daily?"ghost":""}" data-w="new">${wd.daily?"Practice round":"Next player"}</button></div>${wd.copied?`<p class="msg good">${esc(wd.copied)}</p>`:""}<textarea id="wdShare" class="sharebox" readonly hidden>${esc(shareText(wd))}</textarea>`:""}
   <div class="box wstats"><span class="label">Daily stats · ${esc(SPORTS[b].label)}</span><div class="wnums"><div><b>${st.played}</b><span>Played</span></div><div><b>${st.played?Math.round(st.wins/st.played*100):0}</b><span>Win %</span></div><div><b>${st.streak}</b><span>Streak</span></div><div><b>${st.max}</b><span>Best</span></div></div>
   <div class="dist">${st.dist.map((c,i)=>`<div><span>${i+1}</span><i style="width:${Math.max(6,c/mx*100)}%" class="${wd.daily&&wd.won&&wd.rows.length===i+1?"hl":""}">${c}</i></div>`).join("")}</div></div></div></div>
  <div class="legendrow"><span><i style="background:var(--yellow)"></i>Right spot</span><span><i style="background:var(--present)"></i>In the name, wrong spot</span><span><i style="background:var(--absent)"></i>Not in the name</span></div>
  <div class="kb" translate="no">${kb}</div><p class="gnote wcenter">${wd.size} possible players.</p>`;
  el.querySelectorAll("[data-k]").forEach(x=>x.onclick=()=>wordleKey(x.dataset.k));
  el.querySelectorAll("[data-h]").forEach(x=>x.onclick=()=>{wd.hints.push(x.dataset.h);saveDaily(wd);rerender()});
  el.querySelector('[data-wm="daily"]').onclick=()=>{newWordle(b,true);rerender()};
  el.querySelectorAll("[data-wl]").forEach(x=>x.onclick=()=>{newWordle(b,false,x.dataset.wl);rerender()});
  el.querySelector("#wdHard").onchange=e=>{if(wd.rows.length)return;wd.hard=e.target.checked;store.set("fb-wd-hard",wd.hard);rerender()};
  const nw=el.querySelector('[data-w="new"]');if(nw)nw.onclick=()=>{newWordle(b,false);rerender()};
  const sh=el.querySelector('[data-w="share"]');if(sh)sh.onclick=()=>{const tx=shareText(wd),fb=()=>{wd.copied="Copy the text below.";rerender();const ta=document.getElementById("wdShare");if(ta){ta.hidden=false;ta.select()}};
    try{navigator.clipboard.writeText(tx).then(()=>{wd.copied="Copied to your clipboard.";rerender()},fb)}catch(e){fb()}}}

/* ---------- WHO AM I? (any branch) ---------- */
const SPECIAL_B={"Mirsad Türkcan":"My number 6 was retired by the club in 2012.","Ömer Onan":"My number 7 was retired by the club in 2014.","İbrahim Kutluay":"The club retired my shirt in December 2025.","Birsel Vardarlı":"I was captain from 2012 to 2019, and my number 7 is retired.","Alperi Onar":"I became club captain in 2023.","Tuğçe Canıtez":"I was club captain from 2019 to 2022.","Olcay Çakır":"I was captain in 2022–23 and had three separate spells at the club.","Ekpe Udoh":"I was MVP of the 2017 Final Four.","Nigel Hayes-Davis":"I was MVP of the 2025 Final Four.","Kayla McBride":"I was MVP of the 2024 Final Four.","Julie Allemand":"I was MVP of the 2026 Final Six.","Breanna Stewart":"I was MVP of the 2023 Final Four."};
function bClues(x,b){const app=x.apps.length?x.apps[Math.floor(Math.random()*x.apps.length)]:null,sq=x.squads.length?x.squads[Math.floor(Math.random()*x.squads.length)]:null;
  const c1=app?`In the ${app.L.label.toLowerCase()} against ${app.L.opp} I ${app.starter?"started":"was on the bench"}${app.pts==null?" but didn't get on the court":app.pts===0?" and didn't score":` and scored ${app.pts}`}.`
    :sq?`I ${sq.num?`wore number ${sq.num}`:"was"} in the ${sq.S.label.toLowerCase()} squad${sq.as!==x.n?` (listed as ${sq.as})`:""}.`:`My Fenerbahçe years: ${x.ten}.`;
  let c2;
  if(app){const ids=[...new Set(x.apps.map(a=>a.L.label))];c2=ids.length>1?`I appear in ${ids.length} of these box scores: ${ids.join(", ")}.`:"That's my only appearance in these box scores.";if(x.ten)c2+=` My Fenerbahçe years: ${x.ten}.`}
  else if(sq)c2=x.squads.length>1?`I was in ${x.squads.length} of these squads: ${x.squads.map(s=>s.S.id).join(", ")}.`:"That's the only one of these squads I was in.";
  const sp=SPECIAL_B[x.n]||VB_AWARDS[x.n]||(sq&&VB_AWARDS[sq.as])||"",pn=`I'm a ${BPOS[x.pos]}${x.nat?` from ${NAT2[x.nat]}`:""}.`;
  if(!app&&!sq)return [c1,sp||`I played as a ${BPOS[x.pos]}.`,x.nat?`I'm from ${NAT2[x.nat]}${sp?` and I played as a ${BPOS[x.pos]}`:""}.`:`I played as a ${BPOS[x.pos]}.`,`My initials are ${initialsOf(x.n)}`];
  return [c1,c2,sp?`${sp} ${pn}`:pn,`My initials are ${initialsOf(x.n)}`]}
const WHOCFG={
 football:()=>{const seasonPool=Object.values(PEOPLE).filter(x=>x.seasons.length),legends=Object.values(PEOPLE).filter(x=>!x.seasons.length&&x.p&&x.p.from<2000);
   return shuffle(shuffle(seasonPool).slice(0,8).concat(shuffle(legends).slice(0,2))).map(x=>({name:x.n,al:aliasesOf(x.n),clues:whoClues(x)}))},
 basketball:()=>bWho("basketball"),"womens-basketball":()=>bWho("womens-basketball"),volleyball:()=>bWho("volleyball")};
function bWho(b){const M=BPEOPLE[b],pool=Object.values(M).filter(x=>(x.apps.length||x.squads.length||x.ten)&&x.pos);return shuffle(pool).slice(0,10).map(x=>({name:x.n,al:aliasB(x.n),clues:bClues(x,b)}))}
const whoS={};
function gWho(el){const b=current;let w=whoS[b];if(!w)w=whoS[b]={q:WHOCFG[b](),i:0,shown:1,score:0,state:null,msg:"",guesses:[]};const N=w.q.length;
  const head=`<h2>Who Am I?</h2><p class="intro">${N} mystery ${esc(SPORTS[b].label.toLowerCase())} players. You start with one clue, and the next one only appears when you ask or guess wrong. Each player is worth 4 points with one clue, down to 1 with all four. Type the name. Small typos are fine.</p>`;
  if(w.i>=N){const best=store.get(SK(b,"who"),0);if(w.score>best)store.set(SK(b,"who"),w.score);
    el.innerHTML=head+`<div class="quiz"><span class="label">Final score</span><div class="final">${w.score}/${N*4}</div><p style="font-size:18px;margin-top:6px">${w.score>=N*3?"Encyclopedic. The club museum should hire you.":w.score>=N*1.8?"Proper Fenerbahçeli.":"Tough one. The lineup games will teach you the squads."}</p><p class="gnote">Best: ${Math.max(best,w.score)}/${N*4}</p><button class="btn" data-wh="again" style="margin-top:14px">Play again</button></div>`;
    el.querySelector('[data-wh="again"]').onclick=()=>{whoS[b]=null;rerender()};return}
  const r=w.q[w.i],pts=5-w.shown,done=w.state!=null;
  el.innerHTML=head+`<div class="quiz"><div class="top"><span class="label">Player ${w.i+1} of ${N}</span><span class="label">Score ${w.score}</span></div><div class="progress"><i style="width:${w.i/N*100}%"></i></div>
    <ol class="clues">${r.clues.map((c,i)=>i<w.shown||done?`<li><span>${i+1}</span><div>${esc(c)}</div></li>`:`<li class="locked"><span>${i+1}</span><div>Hidden clue</div></li>`).join("")}</ol>
    ${done?`<p class="explain"><b>${w.state==="win"?`Correct, +${w.got}.`:"Not this time."}</b> It was ${esc(r.name)}.</p><button class="btn" data-wh="next" style="margin-top:14px">${w.i+1<N?"Next player":"See score"}</button>`:
    `<form class="guessbar" id="whoForm" autocomplete="off"><input id="whoGuess" placeholder="Who am I?" aria-label="Your guess"><button class="btn">Guess</button></form><p class="msg bad">${esc(w.msg)}</p>
     <div class="btns">${w.shown<4?`<button class="btn ghost" data-wh="more">Next clue (−1)</button>`:""}<button class="btn ghost" data-wh="give">Give up</button></div><p class="gnote">Worth ${pts} point${pts>1?"s":""} right now.${w.guesses.length?` Tried: ${w.guesses.map(esc).join(", ")}`:""}</p>`}</div>`;
  const on=(k,f)=>{const x=el.querySelector(`[data-wh="${k}"]`);if(x)x.onclick=f};
  on("more",()=>{w.shown++;w.msg="";rerender()});on("give",()=>{w.state="lose";rerender()});on("next",()=>{w.i++;w.shown=1;w.state=null;w.msg="";w.guesses=[];rerender()});
  const f=el.querySelector("#whoForm");if(f)f.onsubmit=e=>{e.preventDefault();const raw=el.querySelector("#whoGuess").value,v=norm(raw);if(!v)return;
    if(r.al.some(a=>closeEnough(v,a))){w.state="win";w.got=pts;w.score+=pts}else{w.guesses.push(raw);if(w.shown>=4)w.state="lose";else{w.shown++;w.msg=`Not ${raw}. Here's another clue.`}}
    rerender();const i=document.getElementById("whoGuess");if(i)i.focus()}}

/* ---------- TIMELINE (any branch) ---------- */
function branchDeck(b,extra){const ev=[],seen=new Set(),add=(y,t,s)=>{if(!seen.has(t)){seen.add(t);ev.push({y,t,s})}},S=SPORTS[b];
  (S.history||[]).forEach(([y,t])=>{if(/^\d{4}$/.test(y))add(+y,t,"History")});(S.games||[]).forEach(g=>add(+g.date.slice(0,4),g.res?`${g.home} ${g.res} ${g.away} (${g.comp})`:`${g.title} (${g.comp})`,"Big games"));
  extra.forEach(([y,t,s])=>add(y,t,s));return shuffle(ev)}
const TLCFG={football:{title:"Timeline",intro:"Club football moments, famous signings, and the first season each regular broke into the XI.",deck:()=>tlDeck()},
 basketball:{title:"Timeline",intro:"Titles, cups, coaches, Final Fours and retired shirts from the men's basketball team.",deck:()=>branchDeck("basketball",MB_EVENTS)},
 "womens-basketball":{title:"Timeline",intro:"Twenty league titles, European finals, coaches and captains from the women's basketball team.",deck:()=>branchDeck("womens-basketball",WB_EVENTS)},
 volleyball:{title:"Timeline",intro:"Volleyball from 1928 to today: titles, coaches, captains and European nights, men's team included.",deck:()=>branchDeck("volleyball",VB_EVENTS)},
 more:{title:"Club Timeline",intro:"Nearly 120 years across every branch, from the founding in 1907 to women's football's first league title.",deck:()=>shuffle(CLUB_EVENTS.map(([y,t,s])=>({y,t,s})))}};
const tlS={};
function tlNext(tl){const D=tl.deck;if(!D.length)return null;const ys=tl.placed.map(e=>e.y);let bi=0,bs=1e9;
  for(let i=0;i<Math.min(D.length,18);i++){const d=Math.min(...ys.map(y=>Math.abs(y-D[i].y))),sc=d===0?6:d<=3?d:10+d;if(sc<bs){bs=sc;bi=i}}return D.splice(bi,1)[0]}
function newTL(b,expert){const deck=TLCFG[b].deck(),prev=tlS[b],tl={b,deck,placed:[deck.shift()],lives:2,score:0,last:null,over:false,expert:expert!=null?expert:(prev?prev.expert:false),moves:0};tl.cur=tlNext(tl);tlS[b]=tl;return tl}
function gTimeline(el){const b=current,C=TLCFG[b];let tl=tlS[b]||newTL(b,false);
  const hide=tl.expert&&!tl.over,slot=k=>tl.over?"":`<li class="ins"><button data-ins="${k}">Place it here</button></li>`;
  let list=slot(0);tl.placed.forEach((e,i)=>{list+=`<li class="card ${e.st||""} ${tl.last&&tl.last.c.t===e.t?"just":""}"><span class="y ${hide?"q":""}">${hide?"????":e.y}</span><span class="t"><small>${esc(e.s)}</small>${esc(e.t)}</span></li>`+slot(i+1)});
  const best=store.get(SK(b,"tl"),0);
  el.innerHTML=`<h2>${C.title}</h2><p class="intro">${C.intro} Place each new card where it belongs, oldest at the top. New cards tend to land close in time to ones already placed. You have two lives. Expert mode hides the years until the end and doubles your points.</p>
  <div class="wtop"><div class="tlhead"><div><b class="count">${tl.score}</b><span class="label">points</span></div><div class="lives" aria-label="${tl.lives} lives left">${[0,1].map(i=>`<i class="${i<tl.lives?"on":""}"></i>`).join("")}</div><div><b class="count">${best}</b><span class="label">record</span></div></div>
   <label class="toggle"><input type="checkbox" id="tlExp" ${tl.expert?"checked":""} ${tl.moves?"disabled":""}> Expert mode</label></div>
  ${tl.over?`<div class="box" style="margin-top:16px"><h3>${tl.record?"New record! ":""}You scored ${tl.score}.</h3><div class="btns"><button class="btn" data-tl="new">Play again</button></div></div>`:`<div class="tlcur"><span class="label">Where does this go?</span><p><small>${esc(tl.cur.s)}</small>${esc(tl.cur.t)}</p></div>`}
  ${tl.last&&!tl.over?`<p class="msg ${tl.last.ok?"good":"bad"}">${tl.last.ok?"Correct.":`Not quite${hide?"":`. That was ${tl.last.c.y}`}.`}</p>`:""}
  <ol class="tl2">${list}</ol>`;
  el.querySelectorAll("[data-ins]").forEach(x=>x.onclick=()=>{const k=+x.dataset.ins,c=tl.cur,P=tl.placed,ok=(k===0||P[k-1].y<=c.y)&&(k===P.length||c.y<=P[k].y);tl.moves++;
    if(ok){P.splice(k,0,{...c,st:"ok"});tl.score+=tl.expert?2:1}else{tl.lives--;let j=P.findIndex(e=>e.y>c.y);if(j<0)j=P.length;P.splice(j,0,{...c,st:"no"})}
    tl.last={ok,c};tl.cur=tlNext(tl);if(tl.lives<=0||!tl.cur){tl.over=true;if(tl.score>store.get(SK(b,"tl"),0)){store.set(SK(b,"tl"),tl.score);tl.record=true}}rerender()});
  const n=el.querySelector('[data-tl="new"]');if(n)n.onclick=()=>{newTL(b);rerender()};
  el.querySelector("#tlExp").onchange=e=>{if(tl.moves)return;newTL(b,e.target.checked);rerender()}}

/* ---------- NAME THE LINEUP / SQUAD ---------- */
const LUCFG={basketball:{items:MB_LINEUPS,kind:"bb",title:"Name the Lineup",note:DATA_NOTE.MB},"womens-basketball":{items:WB_LINEUPS,kind:"bb",title:"Name the Lineup",note:DATA_NOTE.WB},volleyball:{items:VB_SQUADS,kind:"vb",title:"Name the Squad",note:DATA_NOTE.VB}};
const luS={};
function luSlots(C,it){if(C.kind==="bb"){const out=it.st.map(([pos,n,pts],i)=>({n,lab:pos,sub:pts==null?"":`${pts} pts`,starter:true,i}));it.bench.forEach(([n,pts],i)=>out.push({n,lab:"Bench",sub:pts==null?"DNP":`${pts} pts`,starter:false,i:5+i}));return out}
  return it.sq.map(([num,n,pos],i)=>({n,lab:num!=null?`#${num}`:"",sub:pos?BPOS[pos]:"",starter:false,i}))}
function gLineup(el){const b=current,C=LUCFG[b];let s=luS[b];if(!s)s=luS[b]={id:C.items[0].id,found:new Set(),hints:new Set(),wrong:0,ended:false,msg:"",cls:""};
  const it=C.items.find(x=>x.id===s.id),slots=luSlots(C,it),al=uniqueAliases(slots.map(x=>x.n)),N=slots.length,best=store.get(SK(b,"lu"),{});
  const score=()=>Math.max(0,s.found.size*10-s.hints.size*4-s.wrong*2),stars=()=>s.found.size===N&&!s.hints.size&&s.wrong<=2?3:s.found.size===N?2:s.found.size>=Math.ceil(N/2)?1:0;
  const end=msg=>{s.ended=true;const bb=best[s.id]||{stars:0};best[s.id]={stars:Math.max(bb.stars,stars())};store.set(SK(b,"lu"),best);s.msg=msg;s.cls=s.found.size===N?"good":""};
  const slotHTML=x=>{const f=s.found.has(x.i),show=f||s.ended,hint=s.hints.has(x.i)?x.n.split(/[\s-]+/).map(w=>w[0]+"·".repeat(Math.min(w.length-1,6))).join(" "):"";return `<div class="ps ${f?"filled":s.ended?"missed":""}" style="${x.pos||""}"><span class="disc">${f?"✓":esc(x.lab||"?")}</span><span class="nm ${show?"":"dim"}">${show?esc(x.n):esc(hint||x.sub)}</span></div>`};
  let visual;
  if(C.kind==="bb"){const P=[[50,82],[17,58],[83,58],[30,28],[70,28]];slots.filter(x=>x.starter).forEach((x,k)=>x.pos=`left:${P[k][0]}%;top:${P[k][1]}%`);
    visual=`<div class="court bb">${courtBB()}${slots.filter(x=>x.starter).map(slotHTML).join("")}</div>${it.bench.length?`<div class="bench"><span class="label">Bench · ${it.bench.length} more in the box score</span><div class="benchgrid">${slots.filter(x=>!x.starter).map(x=>slotHTML({...x,pos:""})).join("")}</div></div>`:`<p class="gnote">Only the starting five are on record for this game.</p>`}`}
  else visual=`<div class="squadgrid">${slots.map(x=>slotHTML({...x,pos:""})).join("")}</div>`;
  el.innerHTML=`<h2>${C.title}</h2><p class="intro">${C.kind==="bb"?"Pick a big game and name everyone in Fenerbahçe's box score: the starting five by position, then the bench. Points scored are shown as a clue.":"Pick a famous squad and name every player. Shirt numbers and positions are shown as clues."} Each player is worth 10 points, a hint costs 4 and a wrong guess costs 2.</p>
  <div class="seasons" role="group" aria-label="Game">${C.items.map(x=>`<button data-lu="${x.id}" aria-pressed="${x.id===s.id}"><b>${esc(x.label)}</b><span class="stars">${stars3((best[x.id]||{}).stars||0)}</span></button>`).join("")}</div>
  <div class="draft"><div>${visual}</div><div class="side"><div class="box">
    <span class="label">${esc(it.title)}${it.date?` · ${esc(it.date)}`:""}</span><h3 style="margin-top:4px">${it.opp?`vs ${esc(it.opp)}, ${esc(it.score)}`:esc(it.label)}</h3>
    <p class="gnote">${it.where?`${esc(it.where)} · coach ${esc(it.coach)}`:esc(it.note)}</p>
    <form class="guessbar" id="luForm" autocomplete="off"><input id="luGuess" placeholder="Type a player…" aria-label="Player name" ${s.ended?"disabled":""}><button class="btn" ${s.ended?"disabled":""}>Guess</button></form>
    <p class="msg ${s.cls}">${esc(s.msg)}</p>
    <div class="xinums"><div><b class="count">${s.found.size}</b><span class="label">of ${N}</span></div><div><b class="count">${score()}</b><span class="label">points</span></div></div>
    ${s.ended?`<p style="margin-top:10px;font-size:22px;color:var(--accent)">${stars3(stars())}</p>`:""}
    <div class="btns"><button class="btn ghost" data-l="hint" ${s.ended?"disabled":""}>Hint (−4)</button><button class="btn ghost" data-l="give" ${s.ended?"disabled":""}>Give up</button><button class="btn ghost" data-l="reset">Start over</button></div>
    <p class="gnote">${esc(C.note)}</p></div></div></div>`;
  el.querySelectorAll("[data-lu]").forEach(x=>x.onclick=()=>{luS[b]={id:x.dataset.lu,found:new Set(),hints:new Set(),wrong:0,ended:false,msg:"",cls:""};rerender()});
  el.querySelector("#luForm").onsubmit=e=>{e.preventDefault();if(s.ended)return;const raw=el.querySelector("#luGuess").value,v=norm(raw);if(!v)return;
    const k=slots.findIndex((x,i)=>!s.found.has(x.i)&&al[i].some(a=>closeEnough(v,a))),k2=k<0?slots.findIndex((x,i)=>al[i].some(a=>closeEnough(v,a))):k;
    if(k2<0){s.wrong++;s.msg=`${raw} isn't in this one (−2).`;s.cls="bad"}else if(s.found.has(slots[k2].i)){s.msg=`You already have ${slots[k2].n}.`;s.cls=""}
    else{s.found.add(slots[k2].i);s.msg=`Yes: ${slots[k2].n}.`;s.cls="good";if(s.found.size===N)end("Everyone named!")}
    rerender();const i=document.getElementById("luGuess");if(i&&!i.disabled)i.focus()};
  const on=(k,f)=>{const x=el.querySelector(`[data-l="${k}"]`);if(x)x.onclick=f};
  on("hint",()=>{const left=slots.filter(x=>!s.found.has(x.i)&&!s.hints.has(x.i));if(left.length){s.hints.add(left[Math.floor(Math.random()*left.length)].i);s.msg="Hint: first letters of one player.";s.cls=""}rerender()});
  on("give",()=>{end(`You named ${s.found.size} of ${N}.`);rerender()});on("reset",()=>{luS[b]={id:s.id,found:new Set(),hints:new Set(),wrong:0,ended:false,msg:"",cls:""};rerender()})}
function courtBB(){return `<svg class="lines" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true"><rect x="34" y="0" width="32" height="38" class="key"/><path d="M34 38 A16 12 0 0 0 66 38"/><path d="M6 0 V14 A44 44 0 0 0 94 14 V0"/><circle cx="50" cy="7" r="2.2"/><path d="M45 3 H55"/><path d="M38 100 A12 9 0 0 1 62 100"/></svg>`}
function courtFB(){return `<svg class="lines" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true"><path d="M0 50 H100"/><circle cx="50" cy="50" r="10"/><rect x="28" y="0" width="44" height="13"/><rect x="28" y="87" width="44" height="13"/></svg>`}
function courtVB(){return `<svg class="lines" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true"><path d="M0 9 H100" class="net"/><path d="M0 40 H100"/></svg>`}

/* ---------- TEAM DRAFT (basketball five + sixth man, volleyball six + libero) ---------- */
const TDCFG={
 basketball:{pool:MB_P,court:"bb",slots:[["PG",50,70],["SG",17,52],["SF",83,52],["PF",30,26],["C",70,26],["6TH",50,89]],rounds:[["Semi-final","Lacivert Select"],["Final","Legends Select"]],cup:"Final Four",unit:"five",sim:"bb"},
 "womens-basketball":{pool:WB_P,court:"bb",slots:[["PG",50,70],["SG",17,52],["SF",83,52],["PF",30,26],["C",70,26],["6TH",50,89]],rounds:[["Quarter-final","Sarı Select"],["Semi-final","Lacivert Select"],["Final","Legends Select"]],cup:"Final Six",unit:"five",sim:"bb"},
 volleyball:{pool:VB_P,court:"vb",slots:[["OH",18,26],["MB",50,26],["OP",82,26],["OH",18,64],["MB",50,64],["S",82,64],["L",50,88]],rounds:[["Semi-final","Lacivert Select"],["Final","Legends Select"]],cup:"Final Four",unit:"six",sim:"vb"}};
const SLOTNAME={GK:"goalkeeper",DF:"defender",MF:"midfielder",FW:"forward","6TH":"sixth man",PG:"point guard",SG:"shooting guard",SF:"small forward",PF:"power forward",C:"center",S:"setter",OP:"opposite",OH:"outside hitter",MB:"middle blocker",L:"libero"};
const tdS={};

const tdEff=(sp,p)=>p.r-(sp==="6TH"||p.pos===sp?0:3);
function tdInfo(C,picks){const idx=picks.map((p,i)=>p?i:-1).filter(i=>i>=0),eff=picks.map((p,i)=>p?tdEff(C.slots[i][0],p):null);if(!idx.length)return{eff,ovr:0};
  const w=i=>C.slots[i][0]==="6TH"?.5:C.slots[i][0]==="L"?.7:1;let sw=0,s=0;idx.forEach(i=>{s+=eff[i]*w(i);sw+=w(i)});return{eff,ovr:s/sw}}
function newTD(b){const C=TDCFG[b];tdS[b]={picks:Array(C.slots.length).fill(null),offers:{},active:0,rerolls:3,phase:"pick",cup:null};return tdS[b]}
function tdOffers(C,s,i){return chWith(current,"rd",()=>tdOffersRaw(C,s,i))}
function tdOffersRaw(C,s,i){const used=new Set(s.picks.filter(Boolean));if(!s.offers[i]){const sp=C.slots[i][0],nat=shuffle(C.pool.filter(p=>!used.has(p)&&(sp==="6TH"?p.pos!=="L":p.pos===sp))),alt=sp==="6TH"?[]:shuffle(C.pool.filter(p=>!used.has(p)&&p.pos!==sp&&p.alt.includes(sp)));
  const list=nat.slice(0,4);if(alt.length)list.push(alt[0]);else if(nat[4])list.push(nat[4]);s.offers[i]=shuffle(list)}return s.offers[i].filter(p=>!used.has(p))}




function gTeamDraft(el){const b=current,C=TDCFG[b];let s=tdS[b]||newTD(b);const info=tdInfo(C,s.picks),filled=s.picks.filter(Boolean).length,best=store.get(SK(b,"td"),null);
  const vis=`<div class="court ${C.court}">${C.court==="bb"?courtBB():C.court==="fb"?courtFB():courtVB()}${C.slots.map(([sp,x,y],i)=>{const p=s.picks[i],oop=p&&sp!=="6TH"&&p.pos!==sp;
    return `<button type="button" class="ps ${p?"filled":""} ${s.phase==="pick"&&s.active===i?"active":""} ${oop?"oop":""} ${sp==="6TH"||sp==="L"?"extra":""}" style="left:${x}%;top:${y}%" data-ts="${i}" aria-label="${SLOTNAME[sp]}${p?": "+esc(p.n):", empty"}"><span class="disc">${p?info.eff[i]:(sp==="6TH"?"6th":sp)}</span><span class="nm">${p?esc(p.short):""}</span></button>`}).join("")}</div>`;
  let side;
  if(s.phase==="pick"){const i=s.active,sp=C.slots[i][0];side=`<div class="box"><span class="label">Pick ${filled+1} of ${C.slots.length} · tap any empty spot to switch</span><h3 style="margin-top:4px">${SLOTNAME[sp][0].toUpperCase()+SLOTNAME[sp].slice(1)}</h3>
    <div class="cands2">${tdOffers(C,s,i).map((c,k)=>`<button class="cand2" data-tc="${k}"><span class="r">${c.r}</span><span class="info"><b>${esc(c.n)}</b><small>${c.nat||""} · ${c.pos}${c.ten?` · ${esc(c.ten)}`:""}</small></span>${sp!=="6TH"&&c.pos!==sp?'<em class="tag bad">Out of position −3</em>':'<span></span>'}</button>`).join("")}</div>
    <div class="btns"><button class="btn ghost" data-t="reroll" ${s.rerolls?"":"disabled"}>New options (${s.rerolls} left)</button></div></div>`}
  else side=`<div class="box" id="tdCup"></div>`;
  const sum=`<div class="box"><span class="label">${s.phase==="pick"?"Team so far":"Your team"}</span><div class="ovr" style="margin-top:8px"><span class="big">${filled?info.ovr.toFixed(1):"–"}</span><dl><dt>Players</dt><dd>${filled}/${C.slots.length}</dd><dt>Best ever</dt><dd>${best!=null?Number(best).toFixed(1):"–"}</dd><dt>Most trophies in a season</dt><dd>${store.get(SK(b,"sz-best"),0)}</dd></dl></div></div>`;
  el.innerHTML=`<h2>${C.unit==="eleven"?"XI Draft":C.unit==="five"?"Starting Five Draft":"Starting Six Draft"}</h2><p class="intro">${C.unit==="eleven"?"Fill a 4-3-3 from Fenerbahçe players, a few options at a time. Playing someone out of position costs 3 points.":C.unit==="five"?"Fill a starting five and a sixth man from Fenerbahçe greats, five options at a time. Playing someone out of position costs 3 points.":"Fill a starting six plus a libero from Fenerbahçe greats, five options at a time. Playing someone out of position costs 3 points."} Then pick a season and play it through, game by game, in every competition the club entered that year.</p>
  <div class="draft"><div>${vis}</div><div class="side">${side}${sum}</div></div><p class="gnote">Ratings are fan ratings made for this game, not official numbers.</p>`;
  el.querySelectorAll("[data-ts]").forEach(x=>x.onclick=()=>{const i=+x.dataset.ts;if(s.phase==="pick"&&!s.picks[i]){s.active=i;rerender()}});
  el.querySelectorAll("[data-tc]").forEach(x=>x.onclick=()=>{s.picks[s.active]=tdOffers(C,s,s.active)[+x.dataset.tc];const nx=s.picks.findIndex(p=>!p);
    if(nx<0){s.phase="done";const o=tdInfo(C,s.picks).ovr,bs=store.get(SK(b,"td"),null);if(bs==null||o>bs)store.set(SK(b,"td"),Math.round(o*10)/10);s.cup={}}else s.active=nx;rerender()});
  const rr=el.querySelector('[data-t="reroll"]');if(rr)rr.onclick=()=>{if(!s.rerolls)return;s.rerolls--;delete s.offers[s.active];rerender()};
  if(s.phase==="done")tdCupRender(b)}


/* ---------- FREE THROWS (basketball) ---------- */
const FT_DEF={basketball:["Bogdan Bogdanović","Luigi Datome","Kostas Sloukas","Nando De Colo","Nigel Hayes-Davis","Marko Gudurić"],"womens-basketball":["Kayla McBride","Diana Taurasi","Breanna Stewart","Emma Meesseman","Julie Allemand","Kelsey Plum"]};
const ftS={};let ftRAF=null;
function ftPool(b){const C=TDCFG[b],s=tdS[b],P=C.pool,def=FT_DEF[b].map(n=>P.find(p=>p.n===n)).filter(Boolean);if(s&&s.picks.every(Boolean))return s.picks.concat(def.filter(d=>!s.picks.includes(d))).slice(0,9);return def}
function newFT(b,shooter){ftS[b]={shooter,shots:[],streak:0,score:0,phase:shooter?"aim":"pick",t0:performance.now(),val:0,res:null,anim:null};return ftS[b]}
const ftZone=s=>Math.max(3,6+(s.shooter.r-75)*.5-s.streak*.9),ftPer=s=>Math.max(520,1150-s.streak*55);
function ftLoop(){const s=ftS[current];if(!s||s.phase!=="aim"){ftRAF=null;return}const m=document.getElementById("ftMark");if(!m){ftRAF=null;return}const t=performance.now()-s.t0,per=ftPer(s),ph=(t%(2*per))/per;s.val=(ph<1?ph:2-ph)*100;m.style.left=s.val+"%";ftRAF=requestAnimationFrame(ftLoop)}
function ftShoot(){const b=current,s=ftS[b];if(!s||s.phase!=="aim")return;const d=Math.abs(s.val-50),w=ftZone(s);let r;
  if(d<=w*.4)r=["Swish!",3,true];else if(d<=w)r=["Good!",2,true];else if(d<=w+4)r=Math.random()<.45?["Rolled in!",1,true]:["Rim out!",0,false];else r=s.val<50?["Short!",0,false]:["Long!",0,false];
  s.phase="anim";s.res=r;s.anim={t0:performance.now(),make:r[2],kind:r[0],side:s.val<50?-1:1};rerender();
  setTimeout(()=>{s.shots.push(r[2]);s.score+=r[1]*(r[2]&&s.streak>=4?2:1);s.streak=r[2]?s.streak+1:0;if(s.shots.length>=10){s.phase="over";const k=SK(b,"ft"),bs=store.get(k,0);if(s.score>bs){store.set(k,s.score);s.rec=true}}else{s.phase="aim";s.t0=performance.now()}rerender()},1250)}
function gFT(el){const b=current;let s=ftS[b]||newFT(b,null);cancelAnimationFrame(ftRAF);ftRAF=null;
  if(s.phase==="pick"){el.innerHTML=`<h2>Free Throws</h2><p class="intro">Ten free throws, one shooter. Stop the marker inside the yellow zone. Better shooters get a wider zone, but it shrinks with every make in a row and the marker speeds up. A swish is worth 3, a clean make 2, a lucky roll 1, and every make from five in a row on counts double.</p>
    <span class="label">Choose your shooter${tdS[b]&&tdS[b].picks.every(Boolean)?" · your drafted team is listed first":""}</span><div class="shooters">${ftPool(b).map((p,i)=>`<button class="cand2" data-fs="${i}"><span class="r">${p.r}</span><span class="info"><b>${esc(p.n)}</b><small>${p.pos} · ${p.nat||""}</small></span><span></span></button>`).join("")}</div><p class="gnote">Best score: ${store.get(SK(b,"ft"),0)}. Shooter ratings are made up for this game.</p>`;
    el.querySelectorAll("[data-fs]").forEach(x=>x.onclick=()=>{newFT(b,ftPool(b)[+x.dataset.fs]);rerender()});return}
  const w=ftZone(s),dots=s.shots.map(v=>`<i class="dot ${v?"g":"m"}"></i>`).join("")+Array(10-s.shots.length).fill('<i class="dot"></i>').join("");
  el.innerHTML=`<h2>Free Throws</h2><p class="intro">Stop the marker in the yellow zone. Tap the court, press Space, or use the button.</p>
  <div class="pk-wrap"><div><div class="ftcourt" id="ftc"><svg viewBox="0 0 400 260" aria-hidden="true"><rect x="0" y="232" width="400" height="28" class="floor"/><rect x="352" y="40" width="8" height="110" class="board"/><rect x="330" y="72" width="22" height="26" class="board2"/><path d="M300 100 H352" class="rim"/><path d="M302 100 L310 128 H342 L350 100" class="net2"/>
    <circle cx="70" cy="196" r="26" class="shooter"/><text x="70" y="202" text-anchor="middle" class="shnum">${esc(String(s.shooter.r))}</text><circle id="ftBall" cx="96" cy="176" r="10" class="ball"/></svg>
    ${s.res&&s.phase!=="aim"?`<div class="pk-banner" style="top:8%">${esc(s.res[0])}</div>`:""}</div>
    <div class="meter"><div class="zone" style="left:${50-w}%;width:${2*w}%"></div><div class="zone in" style="left:${50-w*.4}%;width:${.8*w}%"></div>${s.phase==="aim"?`<div class="mark" id="ftMark" style="left:${s.val}%"></div>`:""}</div></div>
  <div class="side"><div class="box"><span class="label">${s.phase==="over"?"Finished":`Shot ${s.shots.length+1} of 10`}</span><h3 style="margin-top:4px">${esc(s.shooter.n)}</h3>
    <div class="xinums"><div><b class="count">${s.score}</b><span class="label">points</span></div><div><b class="count">${s.streak}</b><span class="label">in a row</span></div></div>
    <div class="dots" style="margin-top:12px">${dots}</div>
    ${s.phase==="aim"?`<div class="btns"><button class="btn" data-f="shoot">Shoot</button></div>`:""}
    ${s.phase==="over"?`<p class="msg good">${s.rec?"New record! ":""}You scored ${s.score}.</p><div class="btns"><button class="btn" data-f="again">Same shooter again</button><button class="btn ghost" data-f="pick">Change shooter</button></div>`:`<div class="btns"><button class="btn ghost" data-f="pick">Change shooter</button></div>`}
    <p class="gnote">Best: ${store.get(SK(b,"ft"),0)}</p></div></div></div>`;
  const on=(k,f)=>{const x=el.querySelector(`[data-f="${k}"]`);if(x)x.onclick=f};on("shoot",ftShoot);on("again",()=>{newFT(b,s.shooter);rerender()});on("pick",()=>{newFT(b,null);rerender()});
  el.querySelector("#ftc").onpointerdown=e=>{if(s.phase==="aim"){e.preventDefault();ftShoot()}};
  if(s.phase==="aim")ftRAF=requestAnimationFrame(ftLoop);
  if(s.phase==="anim"&&s.anim){const A=s.anim,ball=document.getElementById("ftBall"),reduce=matchMedia("(prefers-reduced-motion: reduce)").matches;
    const end=A.make?[326,104]:A.kind==="Short!"?[296,110]:A.kind==="Long!"?[352,92]:[302,98];
    const step=now=>{const k=Math.min(1,(now-A.t0)/(reduce?200:820)),x0=96,y0=176,cx=210,cy=-30;const t=k,x=(1-t)*(1-t)*x0+2*(1-t)*t*cx+t*t*end[0],y=(1-t)*(1-t)*y0+2*(1-t)*t*cy+t*t*end[1];
      if(ball){ball.setAttribute("cx",x);ball.setAttribute("cy",y)}if(k<1&&ball&&ftS[current]===s)requestAnimationFrame(step);else if(ball){const fy=A.make?150:200,fx=A.make?326:(A.kind==="Long!"?380:270);setTimeout(()=>{ball.style.transition="cx .35s, cy .35s";ball.setAttribute("cx",fx);ball.setAttribute("cy",fy)},60)}};
    requestAnimationFrame(step)}}

/* ---------- SERVE (volleyball) ---------- */
const SV_DEF=["Melissa Vargas","Kim Yeon-koung","Katarzyna Skowrońska","Magdalena Stysiak","Arina Fedorovtseva","Eda Erdem Dündar"];
const svS={};let svRAF=null;
const svX=x=>30+x/9*240,svY=d=>290-d/9*250;
function svPool(){const s=tdS.volleyball,def=SV_DEF.map(n=>VB_P.find(p=>p.n===n));if(s&&s.picks.every(Boolean))return s.picks.filter(p=>p.pos!=="L").concat(def.filter(d=>!s.picks.includes(d))).slice(0,9);return def}
function newSV(server){svS.v={server,n:0,score:0,log:[],phase:server?"aimX":"pick",t0:performance.now(),cx:4.5,cd:5,hist:[],res:null,def:[[1.5,2.6],[4.5,2.6],[7.5,2.6],[1.5,6.6],[4.5,6.6],[7.5,6.6]]};return svS.v}
const svTri=(t,per)=>{const ph=(t%(2*per))/per;return ph<1?ph:2-ph};
function svLoop(){const s=svS.v;if(!s||(s.phase!=="aimX"&&s.phase!=="aimD")){svRAF=null;return}const m=document.getElementById("svAim");if(!m){svRAF=null;return}const r=s.server.r,t=performance.now()-s.t0;
  if(s.phase==="aimX"){s.cx=-1+svTri(t,(0.9+(r-75)*.04)*1000)*11;s.cd=8}else s.cd=svTri(t,(0.8+(r-75)*.035)*1000)*10.6;m.setAttribute("cx",svX(s.cx));m.setAttribute("cy",svY(s.cd));svRAF=requestAnimationFrame(svLoop)}
function svLock(){const s=svS.v;if(!s)return;if(s.phase==="aimX"){s.ax=s.cx;s.phase="aimD";s.t0=performance.now();rerender()}else if(s.phase==="aimD"){s.ad=s.cd;svServe()}}
function svServe(){const s=svS.v,x=s.ax,d=s.ad;let r;
  if(d<0.6)r=["Into the net!",0];else if(x<0||x>9)r=["Wide! Out.",0];else if(d>9)r=["Long! Out.",0];
  else{const md=Math.min(...s.def.map(([px,pd])=>Math.hypot(px-x,pd-d)));r=md>1.8?["ACE!",3]:md>1?["Tough serve, shanked pass",2]:["Passed well",1];s.hist.push([x,d])}
  s.phase="anim";s.res=r;s.land=[x,Math.min(Math.max(d,0.2),10.4)];rerender();
  setTimeout(()=>{s.n++;s.score+=r[1];s.log.push(r[1]);
    if(s.hist.length){const h=s.hist.slice(-4),mx=h.reduce((a,v)=>a+v[0],0)/h.length,md=h.reduce((a,v)=>a+v[1],0)/h.length;s.def=s.def.map(([px,pd])=>[px+(mx-px)*.18,pd+(md-pd)*.12])}
    if(s.n>=12){s.phase="over";const bs=store.get("fb-volleyball-sv",0);if(s.score>bs){store.set("fb-volleyball-sv",s.score);s.rec=true}}else{s.phase="aimX";s.t0=performance.now()}rerender()},1300)}
function gServe(el){let s=svS.v||newSV(null);cancelAnimationFrame(svRAF);svRAF=null;
  if(s.phase==="pick"){el.innerHTML=`<h2>Serve</h2><p class="intro">Twelve serves at the opponent's court. Time two taps: one for direction, one for depth. Land it far from every receiver for an ace (3 points). A tough serve that forces a bad pass is worth 2, and a serve that's passed well is worth 1. Serve into the net or out and you get nothing. The receivers shift toward where you've been serving.</p>
    <span class="label">Choose your server${tdS.volleyball&&tdS.volleyball.picks.every(Boolean)?" · your drafted six are listed first":""}</span><div class="shooters">${svPool().map((p,i)=>`<button class="cand2" data-sv="${i}"><span class="r">${p.r}</span><span class="info"><b>${esc(p.n)}</b><small>${p.pos} · ${p.nat||""}</small></span><span></span></button>`).join("")}</div><p class="gnote">Best score: ${store.get("fb-volleyball-sv",0)} of 36. Server ratings are made up for this game.</p>`;
    el.querySelectorAll("[data-sv]").forEach(x=>x.onclick=()=>{newSV(svPool()[+x.dataset.sv]);rerender()});return}
  const aim=s.phase==="aimX"||s.phase==="aimD";
  el.innerHTML=`<h2>Serve</h2><p class="intro">Step 1 sets the direction, step 2 the depth. Tap the court, press Space, or use the button.</p>
  <div class="pk-wrap"><div class="svcourt" id="svc"><svg viewBox="0 0 300 330" aria-hidden="true"><rect x="30" y="40" width="240" height="250" class="vfloor"/><path d="M30 207 H270" class="vline"/><rect x="22" y="288" width="256" height="6" class="vnet"/>
    ${s.def.map(([px,pd])=>`<circle cx="${svX(px)}" cy="${svY(pd)}" r="11" class="rcv"/>`).join("")}
    ${s.hist.slice(-6).map(([x,d])=>`<circle cx="${svX(x)}" cy="${svY(d)}" r="3" class="trail"/>`).join("")}
    ${aim?`${s.phase==="aimD"?`<path d="M${svX(s.ax)} 30 V300" class="guide"/>`:""}<circle id="svAim" cx="${svX(s.cx)}" cy="${svY(s.cd)}" r="9" class="aim"/>`:""}
    ${s.phase==="anim"||s.phase==="over"&&s.land?`<circle cx="${svX(s.land[0])}" cy="${svY(s.land[1])}" r="7" class="vball"/>`:""}
    </svg>${s.res&&!aim?`<div class="pk-banner" style="top:42%">${esc(s.res[0])}</div>`:""}</div>
  <div class="side"><div class="box"><span class="label">${s.phase==="over"?"Finished":`Serve ${s.n+1} of 12`}</span><h3 style="margin-top:4px">${esc(s.server.n)}</h3>
    <div class="xinums"><div><b class="count">${s.score}</b><span class="label">points</span></div><div><b class="count">${s.log.filter(v=>v===3).length}</b><span class="label">aces</span></div></div>
    <div class="dots" style="margin-top:12px">${s.log.map(v=>`<i class="dot ${v===3?"g":v===0?"m":"half"}"></i>`).join("")}${Array(12-s.log.length).fill('<i class="dot"></i>').join("")}</div>
    ${aim?`<div class="btns"><button class="btn" data-s="lock">${s.phase==="aimX"?"Set direction":"Serve"}</button></div>`:""}
    ${s.phase==="over"?`<p class="msg good">${s.rec?"New record! ":""}You scored ${s.score} of 36.</p><div class="btns"><button class="btn" data-s="again">Serve again</button><button class="btn ghost" data-s="pick">Change server</button></div>`:`<div class="btns"><button class="btn ghost" data-s="pick">Change server</button></div>`}
    <p class="gnote">Best: ${store.get("fb-volleyball-sv",0)} · green = ace, red = error</p></div></div></div>`;
  const on=(k,f)=>{const x=el.querySelector(`[data-s="${k}"]`);if(x)x.onclick=f};on("lock",svLock);on("again",()=>{newSV(s.server);rerender()});on("pick",()=>{newSV(null);rerender()});
  el.querySelector("#svc").onpointerdown=e=>{if(aim){e.preventDefault();svLock()}};if(aim)svRAF=requestAnimationFrame(svLoop)}

/* ---------- WHICH BRANCH? and MEMORY (other branches) ---------- */
let whS=null;
function gWhich(el){if(!whS)whS={q:shuffle(BR_FACTS).slice(0,10).map(([f,a])=>({f,a,o:shuffle([a,...shuffle(BR_NAMES.filter(x=>x!==a)).slice(0,3)])})),i:0,score:0,picked:null};const s=whS;
  if(s.i>=s.q.length){const bs=store.get("fb-more-which",0);if(s.score>bs)store.set("fb-more-which",s.score);
    el.innerHTML=`<h2>Which Branch?</h2><div class="quiz"><span class="label">Final score</span><div class="final">${s.score}/10</div><p class="gnote">Best: ${Math.max(bs,s.score)}/10</p><button class="btn" data-wb="again" style="margin-top:14px">Play again</button></div>`;el.querySelector('[data-wb="again"]').onclick=()=>{whS=null;rerender()};return}
  const r=s.q[s.i];el.innerHTML=`<h2>Which Branch?</h2><p class="intro">Ten facts from across the club. Pick the department each one belongs to.</p>
  <div class="quiz"><div class="top"><span class="label">Fact ${s.i+1} of 10</span><span class="label">Score ${s.score}</span></div><div class="progress"><i style="width:${s.i*10}%"></i></div><h3>${esc(r.f)}</h3>
  <div class="opts">${r.o.map(o=>{let c="opt";if(s.picked!=null){if(o===r.a)c+=" right";else if(o===s.picked)c+=" wrong"}return `<button class="${c}" data-wo="${esc(o)}" ${s.picked!=null?"disabled":""}>${esc(o)}</button>`}).join("")}</div>
  ${s.picked!=null?`<p class="explain"><b>${s.picked===r.a?"Correct.":"Not quite."}</b> It's ${esc(r.a.toLowerCase())}.</p><button class="btn qnext" data-wb="next">${s.i<9?"Next fact":"See score"}</button>`:""}</div>`;
  el.querySelectorAll("[data-wo]").forEach(x=>x.onclick=()=>{s.picked=x.dataset.wo;if(s.picked===r.a)s.score++;rerender()});const n=el.querySelector('[data-wb="next"]');if(n)n.onclick=()=>{s.i++;s.picked=null;rerender()}}
let memS=null,memT=null;
function gMemory(el){if(!memS){const pairs=shuffle(MEM_PAIRS).slice(0,8);memS={cards:shuffle(pairs.flatMap(([a,b],i)=>[{t:a,p:i,k:"clue"},{t:b,p:i,k:"branch"}])),open:[],got:new Set(),moves:0,start:null,lock:false}}const s=memS,done=s.got.size===8;
  if(done&&!s.best){const bs=store.get("fb-more-mem",null);s.best=bs;if(bs==null||s.moves<bs)store.set("fb-more-mem",s.moves);s.secs=Math.round((Date.now()-s.start)/1000)}
  el.innerHTML=`<h2>Memory</h2><p class="intro">Sixteen cards, eight pairs. Match each athlete or achievement to its branch in as few moves as you can.</p>
  <div class="tlhead"><div><b class="count">${s.moves}</b><span class="label">moves</span></div><div><b class="count">${s.got.size}/8</b><span class="label">pairs</span></div><div><b class="count">${store.get("fb-more-mem","–")}</b><span class="label">best</span></div></div>
  ${done?`<p class="msg good">All pairs found in ${s.moves} moves and ${s.secs} seconds.</p><div class="btns"><button class="btn" data-m="again">Play again</button></div>`:""}
  <div class="memgrid">${s.cards.map((c,i)=>{const up=s.open.includes(i)||s.got.has(c.p);return `<button class="mem ${up?"up":""} ${s.got.has(c.p)?"got":""} mk-${c.k}" data-mc="${i}" ${up?"disabled":""} aria-label="${up?esc(c.t):"Hidden card"}"><span>${up?esc(c.t):"FB"}</span></button>`}).join("")}</div>`;
  el.querySelectorAll("[data-mc]").forEach(x=>x.onclick=()=>{if(s.lock)return;const i=+x.dataset.mc;if(!s.start)s.start=Date.now();s.open.push(i);
    if(s.open.length===2){s.moves++;const [a,b]=s.open.map(k=>s.cards[k]);if(a.p===b.p&&a.k!==b.k){s.got.add(a.p);s.open=[]}else{s.lock=true;clearTimeout(memT);memT=setTimeout(()=>{s.open=[];s.lock=false;rerender()},900)}}rerender()});
  const ag=el.querySelector('[data-m="again"]');if(ag)ag.onclick=()=>{memS=null;rerender()}}

/* ---------- PLAY TAB ---------- */
const PLAY={
 football:[["quiz","Quiz","Seven questions"],["draft","XI Draft","Spin the wheel, build an XI, play a season"],["wordle","Fenerdle","Guess the player"],["xi","Name the XI","Every season since 2000"],["penalties","Penalties","Spin the wheel, win the shootout"],["who","Who Am I?","Ten mystery players"],["timeline","Timeline","Put history in order"]],
 basketball:[["quiz","Quiz","Seven questions"],["draft5","Starting Five","Draft a five, play a season"],["wordle","Fenerdle","Guess the player"],["lineup","Name the Lineup","Final Four box scores"],["ft","Free Throws","Ten shots under pressure"],["who","Who Am I?","Ten mystery players"],["timeline","Timeline","Titles, coaches, Final Fours"]],
 "womens-basketball":[["quiz","Quiz","Seven questions"],["draft5","Starting Five","Draft a five, play a season"],["wordle","Fenerdle","Guess the player"],["lineup","Name the Lineup","EuroLeague final box scores"],["ft","Free Throws","Ten shots under pressure"],["who","Who Am I?","Ten mystery players"],["timeline","Timeline","Twenty titles in order"]],
 volleyball:[["quiz","Quiz","Six questions"],["draft6","Starting Six","Draft a six, play a season"],["wordle","Fenerdle","Guess the player"],["squad","Name the Squad","Four famous squads"],["serve","Serve","Twelve serves, hunt for aces"],["who","Who Am I?","Ten mystery players"],["timeline","Timeline","1928 to today"]],
 more:[["quiz","Quiz","Six questions"],["which","Which Branch?","Match facts to departments"],["memory","Memory","Pair athletes and branches"],["timeline","Club Timeline","Every branch, 1907 to today"]]};
const XTRA=[["daily","Daily Mix","Five questions a day"],["hol","Higher or Lower","Club records head to head"],["gts","Guess the Score","Name the real result"],["board","Leaderboard","Fans' best scores"],["badges","Badges","Your achievements"]];
Object.keys(PLAY).forEach(k=>{PLAY[k].splice(1,0,XTRA[0]);PLAY[k].push(...XTRA.slice(1))});
const GAME_FN={daily:gDaily,hol:gHoL,gts:gGTS,board:gBoard,badges:gBadges,quiz:gQuiz,draft:p=>renderDraft(p),wordle:gWordle,xi:p=>renderXI(p),penalties:p=>renderPK(p),who:gWho,timeline:gTimeline,draft5:gTeamDraft,draft6:gTeamDraft,draft11:gTeamDraft,lineup:gLineup,squad:gLineup,ft:gFT,serve:gServe,which:gWhich,memory:gMemory};
const playSel=(()=>{try{return JSON.parse(localStorage.getItem("fb-playsel")||"{}")}catch(e){return {}}})();
function renderPlay(p){renderPlayRaw(p);runExt("play",p,playSel[current])}

function xAfterGame(g){const ga=document.getElementById("gameArea");if(!ga)return;const old=document.getElementById("shareRow");if(old)old.remove();
  const r=xResultFor(g);if(r&&XC.dl){const d=document.createElement("div");d.id="shareRow";d.className="btns";d.innerHTML=`<button class="btn ghost" id="shareBtn">${t("Save result image")}</button>`;ga.appendChild(d);d.querySelector("button").onclick=e=>xShare(r,e.currentTarget)}
  xBadgeCheck();xSyncScores()}
document.addEventListener("keydown",e=>{
  if(tab!=="play"||e.metaKey||e.ctrlKey||e.altKey)return;
  if(e.target.closest&&e.target.closest("input,select,textarea"))return;
  if(e.target.closest&&e.target.closest("button")&&(e.key===" "||e.key==="Enter"))return;
  const g=playSel[current];
  if(g==="wordle"){if(e.key==="Enter"){e.preventDefault();wordleKey("ENTER")}else if(e.key==="Backspace"){e.preventDefault();wordleKey("BACK")}else if(e.key.length===1){const c=norm(e.key).toUpperCase();if(/^[A-Z]$/.test(c))wordleKey(c)}return}
  if(e.key!==" "&&e.key!=="Enter")return;
  if(g==="penalties"&&current==="football"&&pk&&(pk.phase==="aimX"||pk.phase==="aimY")){e.preventDefault();pkLock()}
  if(g==="ft"&&ftS[current]&&ftS[current].phase==="aim"){e.preventDefault();ftShoot()}
  if(g==="serve"&&svS.v&&(svS.v.phase==="aimX"||svS.v.phase==="aimD")){e.preventDefault();svLock()}
});
let rzT;window.addEventListener("resize",()=>{clearTimeout(rzT);rzT=setTimeout(()=>{const g=playSel[current];if(tab==="play"&&(g==="wordle"||(g==="penalties"&&pk&&pk.phase==="setup"&&!pk.spinning)))renderPanel()},200)});

/* ================= NEW SECTIONS ================= */
function xFlag(c){return esc(t(c))}
function renderSquad(p){const S=SQUADS[current];if(!S){p.innerHTML="";return}
  const coach=S.coach?`<div class="coach card"><span class="label">${t("Head coach")}</span><b>${esc(S.coach)}</b>${S.coachNote?`<p class="muted">${esc(t(S.coachNote))}</p>`:""}</div>`:"";
  const groups=(S.groups||[]).map(([g,list])=>`<section class="sqgroup"><h3 class="mh">${esc(t(g))} <span class="cnt">${list.length}</span></h3><ul class="sqlist">${list.map(([n,name,nat])=>`<li class="card"><span class="no">${n==null?"–":n}</span><span class="nm">${esc(name)}</span><span class="nat">${xFlag(nat)}</span></li>`).join("")}</ul></section>`).join("");
  p.innerHTML=`<h2>${t("Squad")}</h2><p class="intro">${esc(t(S.asof))}</p>${coach}<div class="sqgroups">${groups}</div>${(S.notes||[]).map(n=>`<p class="fine">${esc(t(n))}</p>`).join("")}`}
function renderVenue(p){const V=VENUES[current];if(!V){p.innerHTML="";return}
  const map="https://www.google.com/maps/search/?api=1&query="+encodeURIComponent(V.name+", "+V.area);
  p.innerHTML=`<h2>${t("Venue")}</h2><article class="venue card"><span class="label">${esc(t(V.area))}</span><h3>${esc(t(V.name))}</h3>${V.cap?`<p class="vcap">${esc(t(V.cap))}</p>`:""}
   <ul class="vfacts">${V.facts.map(f=>`<li>${esc(t(f))}</li>`).join("")}</ul>
   ${V.travel.length?`<h4 class="mh">${t("Getting there")}</h4><ul class="vfacts">${V.travel.map(f=>`<li>${esc(t(f))}</li>`).join("")}</ul>`:""}
   <a class="linkbtn" href="${map}" target="_blank" rel="noopener">${t("Open in Google Maps →")}</a></article>`}
function recBar(r){const tot=r.w+r.d+r.l,pc=x=>(x/tot*100).toFixed(1);
  return `<div class="rec"><span class="label">${esc(t(r.label))}</span><div class="rbar" role="img" aria-label="${esc(tf("{w} wins, {d} draws, {l} defeats",{w:r.w,d:r.d,l:r.l}))}"><i class="w" style="width:${pc(r.w)}%"></i><i class="d" style="width:${pc(r.d)}%"></i><i class="l" style="width:${pc(r.l)}%"></i></div>
   <div class="rnums"><span><b>${r.w}</b> ${t("wins")}</span><span><b>${r.d}</b> ${t("draws")}</span><span><b>${r.l}</b> ${t("defeats")}</span>${r.gf!=null?`<span>${t("Goals")} <b>${r.gf}–${r.ga}</b></span>`:""}<span class="muted">${tf("{n} games",{n:tot})}</span></div></div>`}
function renderDerbies(p){
  p.innerHTML=`<h2>${t("Derbies")}</h2><p class="intro">${t("Fenerbahçe against their three great rivals. Records come from the dated sources shown; recent meetings are listed underneath.")}</p>
  <div class="rleg"><span><i class="w"></i>${t("Fenerbahçe wins")}</span><span><i class="d"></i>${t("Draws")}</span><span><i class="l"></i>${t("Rival wins")}</span></div>
  <div class="derbies">${DERBIES.map(D=>`<article class="derby card"><span class="label">${esc(t(D.since))}</span><h3>${t("vs")} ${esc(D.opp)}</h3><p class="dname">${esc(t(D.name))}</p>
   ${recBar(D.all)}${recBar(D.league)}
   <ul class="vfacts">${D.facts.map(f=>`<li>${esc(t(f))}</li>`).join("")}</ul>
   <h4 class="mh">${t("Recent meetings")}</h4><ul class="drecent">${D.recent.map(([d,c,ha,a,b])=>{const o=a>b?"W":a<b?"L":"D";return `<li><span class="fo ${o}">${t("res:"+o)}</span><span>${mDate(d,true)} ${isoDay(d).getFullYear()}</span><span class="muted">${esc(t(c))} · ${t(ha==="H"?"Home":ha==="A"?"Away":"Neutral")}</span><b>${a}–${b}</b></li>`}).join("")}</ul></article>`).join("")}</div>
  <p class="fine src">${t("Sources:")} <a href="https://wiki.riteme.site/wiki/Intercontinental_Derby" target="_blank" rel="noopener">Intercontinental Derby (Wikipedia)</a> · <a href="https://tr.euronews.com/2026/09/05/fenerbahce-besiktas-rekabetinde-365-randevu-tarihi-derbide-rakamlar-ne-soyluyor" target="_blank" rel="noopener">Euronews</a> · <a href="https://kureansiklopedi.com/en/detay/trabzonsporfenerbahce-derby-14-february-2026-1b02f" target="_blank" rel="noopener">Küre Ansiklopedi</a></p>`}
function seasonChart(){const W=1000,H=280,L=34,R=12,T=16,B=34,N=SEASON_POS.length,maxP=10,x=i=>L+i*(W-L-R)/(N-1),y=pos=>T+(pos-1)*(H-T-B)/(maxP-1);
  const pts=SEASON_POS.map(([s,pos],i)=>[x(i),y(pos)]),line=pts.map((q,i)=>(i?"L":"M")+q[0].toFixed(1)+" "+q[1].toFixed(1)).join(" ");
  const grid=[1,2,3,5,10].map(v=>`<line x1="${L}" x2="${W-R}" y1="${y(v)}" y2="${y(v)}" class="gl"/><text x="${L-8}" y="${y(v)+4}" text-anchor="end" class="ax">${v}</text>`).join("");
  const xt=SEASON_POS.map(([s],i)=>[s,i]).filter(([s])=>/^(19[6-9]0|20[0-2]0)–/.test(s)).map(([s,i])=>`<text x="${x(i)}" y="${H-10}" text-anchor="middle" class="ax">${s.slice(0,4)}</text>`).join("");
  const dots=SEASON_POS.map(([s,pos],i)=>`<g class="pt" data-tip="${esc(s+" · "+ordL(pos))}"><circle cx="${x(i)}" cy="${y(pos)}" r="14" class="hit"/><circle cx="${x(i)}" cy="${y(pos)}" r="${pos===1?6:4}" class="${pos===1?"ch":"ot"}"/></g>`).join("");
  const titles=SEASON_POS.filter(q=>q[1]===1).length;
  return `<figure class="schart card"><figcaption><span class="label">${t("Süper Lig finish, every season since 1959")}</span><b>${tf("{n} titles, never lower than 10th",{n:titles})}</b></figcaption>
   <div class="sleg"><span><i class="ch"></i>${t("Champions")}</span><span><i class="ot"></i>${t("Other finish")}</span></div>
   <div class="swrap"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(t("Line chart of Fenerbahçe's league position by season"))}">${grid}<path d="${line}" class="ln"/>${dots}${xt}</svg><div class="stip" hidden></div></div>
   <details><summary>${t("Show as a table")}</summary><div class="stable">${SEASON_POS.map(([s,pos])=>`<span class="${pos===1?"c":""}">${s}<b>${ordL(pos)}</b></span>`).join("")}</div></details></figure>`}
document.addEventListener("pointerover",e=>{const g=e.target.closest&&e.target.closest(".schart .pt");const wrap=e.target.closest&&e.target.closest(".swrap");if(!wrap)return;const tip=wrap.querySelector(".stip");if(!g){tip.hidden=true;return}
  const r=g.querySelector(".hit").getBoundingClientRect(),w=wrap.getBoundingClientRect();tip.textContent=g.dataset.tip;tip.hidden=false;tip.style.left=Math.min(w.width-110,Math.max(0,r.left-w.left+r.width/2-55))+"px";tip.style.top=(r.top-w.top-34)+"px"});

/* calendar links (fixtures are in Turkey time, UTC+3) */
function calLinks(n,big){if(!n||!n[0])return "";const [d,time,comp,ha,opp]=n,ttl=(ha==="H"?`Fenerbahçe – ${opp}`:`${opp} – Fenerbahçe`)+` (${t(comp)})`;
  const [Y,M,D]=d.split("-").map(Number);let g,o;const p2=v=>String(v).padStart(2,"0");
  if(time){const [h,mi]=time.split(":").map(Number),s=new Date(Date.UTC(Y,M-1,D,h-3,mi)),e=new Date(s.getTime()+2*36e5),gz=x=>x.toISOString().replace(/[-:]/g,"").replace(/\.\d{3}/,"");
    g=`https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(ttl)}&dates=${gz(s)}/${gz(e)}`;o=`https://outlook.live.com/calendar/0/deeplink/compose?subject=${encodeURIComponent(ttl)}&startdt=${s.toISOString()}&enddt=${e.toISOString()}`}
  else{const nx=new Date(Date.UTC(Y,M-1,D+1)),a=`${Y}${p2(M)}${p2(D)}`,b=`${nx.getUTCFullYear()}${p2(nx.getUTCMonth()+1)}${p2(nx.getUTCDate())}`;
    g=`https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(ttl)}&dates=${a}/${b}`;o=`https://outlook.live.com/calendar/0/deeplink/compose?subject=${encodeURIComponent(ttl)}&allday=true&startdt=${d}&enddt=${nx.toISOString().slice(0,10)}`}
  return big?`<p class="cal">${t("Add to calendar:")} <a href="${g}" target="_blank" rel="noopener">Google</a> · <a href="${o}" target="_blank" rel="noopener">Outlook</a></p>`
    :`<span class="calmini"><a href="${g}" target="_blank" rel="noopener" title="${esc(t("Add to Google Calendar"))}">+ Google</a><a href="${o}" target="_blank" rel="noopener" title="${esc(t("Add to Outlook"))}">+ Outlook</a></span>`}

/* ================= COMMUNITY (shared db) ================= */
const XC={db:null,user:null,me:null,on:false,noWrite:false,docs:{predictions:{},motm:{},scores:{},ratings:{},seasons:{},challenges:{},watch:{}},names:{},dl:null};
const xKey=(b,d,opp)=>`${b}|${d}|${opp}`;
async function initCommunity(){try{if(!window.claude||!window.claude.use)return;
  claude.use("downloads").then(d=>{XC.dl=d;if(!d)return;if(current==="home")render();else if(tab==="play"||tab==="matches")renderPanel()}).catch(()=>{});
  const [db,user]=await Promise.all([claude.use("db"),claude.use("user")]);if(!db||!user)return;const me=await user.id();if(!me)return;
  Object.assign(XC,{db,user,me,on:true});if(typeof paintLiveNotes==="function")paintLiveNotes();
  ["predictions","motm","scores","ratings","seasons","challenges","watch"].forEach(col=>db.collection(col).onSnapshot(snap=>{const m={};snap.docs.forEach(d=>{if(d.exists)m[d.id]=d.data()});XC.docs[col]=m;xNames(Object.keys(m));xRefresh()},()=>{}));
  xSyncScores()}catch(e){}finally{XC.tried=true;if(typeof paintLiveNotes==="function")paintLiveNotes()}}

async function xNames(ids){if(!XC.user)return;const need=ids.filter(i=>XC.names[i]==null);if(!need.length)return;try{const ps=await XC.user.profiles(need);need.forEach(i=>XC.names[i]=(ps[i]&&ps[i].name)||"");xRefresh()}catch(e){}}
let xName=id=>id===XC.me?t("You"):(XC.names[id]||t("A fan"));
function xRefresh(){const f=document.activeElement;if(f&&f.closest&&f.closest("#panel")&&/INPUT|SELECT/.test(f.tagName))return;if(current==="home"&&typeof fillLeague==="function"){fillLeague();return}if(typeof szLiveBoards==="function")szLiveBoards();
  if(tab==="matches"&&XM.L)xFillMatches();else if(tab==="play"&&playSel[current]==="board")renderPanel()}
async function xWrite(col,data){if(!XC.on||XC.noWrite)return false;try{await XC.db.doc(col+"/"+XC.me).set(data);return true}catch(e){XC.noWrite=true;return false}}
const xPreds=()=>store.get("fb-preds",{}),xVotes=()=>store.get("fb-motm",{});
function xAllDocs(col,local,field){const m={};Object.entries(XC.docs[col]).forEach(([id,d])=>m[id]=(d&&d[field])||{});m[XC.me||"me"]=local;return m}
function xResults(){const R={};Object.keys(LIVE).forEach(b=>LIVE[b].last.forEach(r=>{if(r[0])R[xKey(b,r[0],r[3])]=[+r[4],+r[5],b]}));return R}
function xPoints(pred,res){if(!pred||!res)return null;const [a,b]=pred,[x,y]=res,sg=v=>Math.sign(v);if(a===x&&b===y)return 3;return sg(a-b)===sg(x-y)?1:0}
function xTable(){const R=xResults(),all=xAllDocs("predictions",xPreds(),"p");return Object.entries(all).map(([id,p])=>{let pts=0,n=0,ex=0;Object.entries(p).forEach(([k,v])=>{const s=xPoints(v,R[k]);if(s!=null){n++;pts+=s;if(s===3)ex++}});return {id,pts,n,ex}}).filter(r=>r.n>0).sort((a,b)=>b.pts-a.pts||b.ex-a.ex)}
let XM={L:null,nx:null};
function xMatchesExtras(L,nx){XM={L,nx};xFillMatches()}
function xFillMatches(){xFillPred();xFillComm()}
function xFillPred(){const el=document.getElementById("predBox"),nx=XM.nx;if(!el||!nx||!nx[0])return;
  const key=xKey(current,nx[0],nx[4]),[Y,M,D]=nx[0].split("-").map(Number),[h,mi]=(nx[1]||"12:00").split(":").map(Number),closed=Date.now()>=Date.UTC(Y,M-1,D,h-3,mi);
  const mine=xPreds()[key],home=nx[3]==="H",fbLab="Fenerbahçe",opLab=nx[4];
  const all=xAllDocs("predictions",xPreds(),"p"),list=Object.values(all).map(p=>p[key]).filter(Boolean);
  let crowd="";if(list.length){const cnt={};list.forEach(([a,b])=>{const k=a+"–"+b;cnt[k]=(cnt[k]||0)+1});const top=Object.entries(cnt).sort((a,b)=>b[1]-a[1])[0],win=Math.round(list.filter(([a,b])=>a>b).length/list.length*100);
    crowd=`<p class="muted">${tf(list.length===1?"1 prediction so far. Most picked: {s}. {w}% expect a Fenerbahçe win.":"{n} predictions so far. Most picked: {s}. {w}% expect a Fenerbahçe win.",{n:list.length,s:"Fenerbahçe "+top[0],w:win})}</p>`}
  const inp=(id,v,lab)=>`<label class="pin"><span>${esc(lab)}</span><input id="${id}" type="number" min="0" max="${current.includes("basketball")?199:current==="volleyball"?3:20}" inputmode="numeric" value="${v==null?"":v}" ${closed?"disabled":""}></label>`;
  const pair=home?inp("pFb",mine&&mine[0],fbLab)+`<span class="dash">–</span>`+inp("pOp",mine&&mine[1],opLab):inp("pOp",mine&&mine[1],opLab)+`<span class="dash">–</span>`+inp("pFb",mine&&mine[0],fbLab);
  if(closed&&!mine&&!list.length){el.innerHTML=`<span class="label">${t("Predictions closed")}</span><p class="fine">${t("This match has kicked off.")}</p>`;return}
  el.innerHTML=`<span class="label">${t(closed?"Predictions closed":"Predict the score")}</span><div class="prow">${closed?"":pair}${closed?"":`<button class="btn" id="pSave">${t(mine?"Update":"Save")}</button>`}</div>
   ${mine?`<p class="msg good">${tf("Your prediction: Fenerbahçe {a}–{b} {o}",{a:mine[0],b:mine[1],o:opLab})}</p>`:""}${crowd}${!XC.on||XC.noWrite?`<p class="fine">${t("Saved on this device. Predictions from other fans show up when the page can share them.")}</p>`:""}`;
  const sv=document.getElementById("pSave");if(sv)sv.onclick=async()=>{const a=parseInt(document.getElementById("pFb").value,10),b=parseInt(document.getElementById("pOp").value,10);if(isNaN(a)||isNaN(b)||a<0||b<0)return;
    const P=xPreds();P[key]=[a,b];store.set("fb-preds",P);xFillPred();await xWrite("predictions",{p:P,ts:Date.now()});xFillMatches();xBadgeCheck()}}
function xFillComm(){xFillCommRaw();if(document.getElementById("commBox"))runExt("comm")}
function xFillCommRaw(){const el=document.getElementById("commBox");if(!el)return;const L=XM.L,last=L.last.find(r=>r[0]),S=SQUADS[current];let motm="";const names=motmNames(current);
  if(last){const key=xKey(current,last[0],last[3]),mine=xVotes()[key];
    const all=xAllDocs("motm",xVotes(),"v"),cnt={};Object.values(all).forEach(v=>{if(v[key]&&!modBad(v[key]))cnt[v[key]]=(cnt[v[key]]||0)+1});const tot=Object.values(cnt).reduce((a,b)=>a+b,0),top=Object.entries(cnt).sort((a,b)=>b[1]-a[1]).slice(0,5);
    motm=`<article class="card commcard"><span class="label">${t("Player of the match")}</span><h3>${tf("Fenerbahçe {a}–{b} {o}",{a:last[4],b:last[5],o:last[3]})}</h3><p class="muted">${mDate(last[0])} · ${esc(t(last[1]))}</p>
     ${mine?`<p class="msg good">${tf("You voted for {p}.",{p:esc(mine)})}</p>`:`<div class="prow"><select id="mSel" aria-label="${t("Player of the match")}"><option value="">${t("Choose a player…")}</option>${names.map(n=>`<option>${esc(n)}</option>`).join("")}<option value="__other">${t("Someone else…")}</option></select><input id="mOther" maxlength="40" placeholder="${t("Player name")}" aria-label="${t("Player name")}" hidden><button class="btn" id="mVote">${t("Vote")}</button></div>`}
     ${tot?`<ol class="tally">${top.map(([n,c])=>`<li><span>${esc(n)}</span><i style="width:${Math.max(6,c/tot*100)}%"></i><b>${c}</b></li>`).join("")}</ol>`:`<p class="fine">${t("No votes yet. Be the first to pick the player of the match.")}</p>`}</article>`}
  const rows=xTable();xNames(rows.map(r=>r.id).filter(i=>i!=="me"));
  const table=`<article class="card commcard"><span class="label">${t("Predictor table")}</span><h3>${t("Who reads the game best?")}</h3><p class="muted">${t("3 points for the exact score, 1 for the right result.")}</p>
   ${rows.length?`<ol class="ptable">${rows.slice(0,10).map((r,i)=>`<li class="${r.id===XC.me||r.id==="me"?"me":""}" data-uid="${esc(r.id)}"><span class="rk">${i+1}</span><span class="nm">${esc(r.id==="me"?t("You"):xName(r.id))}</span><span class="muted">${tf("{n} scored",{n:r.n})}</span><b>${r.pts}</b></li>`).join("")}</ol>`:`<p class="fine">${t("Points appear once a predicted match has been played.")}</p>`}</article>`;
  el.innerHTML=`<div class="comm">${motm}${table}</div>`;
  const ms=document.getElementById("mSel"),mo=document.getElementById("mOther");if(ms&&mo)ms.onchange=()=>{mo.hidden=ms.value!=="__other";if(!mo.hidden)mo.focus()};
  const mv=document.getElementById("mVote");if(mv)mv.onclick=async()=>{let v=ms.value;if(v==="__other")v=mo.value.trim().replace(/\s+/g," ").slice(0,40);if(!v)return;if(modBad(v)){xToast(t("Please keep it friendly. Pick another name."));return}const key=xKey(current,last[0],last[3]),V=xVotes();V[key]=v;store.set("fb-motm",V);xFillComm();await xWrite("motm",{v:V,ts:Date.now()});xFillComm();xBadgeCheck()}}

/* scores for the leaderboard */
const BRS=["football","basketball","womens-basketball","volleyball"];
function xCollect(){const o=xCollectRaw();runExt("collect",o);return o}
function xCollectRaw(){const mx=f=>Math.max(0,...BRS.map(f));
  return {daily:store.get("fb-daily-stats",{max:0}).max||0,fenerdle:mx(b=>store.get(SK(b,"wd-stats"),{max:0}).max||0),hol:store.get("fb-hol-best",0),gts:store.get("fb-gts-best",0),
   tl:Math.max(mx(b=>store.get(SK(b,"tl"),0)),store.get(SK("more","tl"),0)),who:mx(b=>store.get(SK(b,"who"),0)),ft:Math.max(store.get(SK("basketball","ft"),0),store.get(SK("womens-basketball","ft"),0)),sv:store.get("fb-volleyball-sv",0),pk:store.get("fb-pk-wins",0)}}
let xLastSync="",xSyncT=null;
function xSyncScores(){clearTimeout(xSyncT);xSyncT=setTimeout(()=>{if(!XC.on||XC.noWrite)return;const s=xCollect(),j=JSON.stringify(s);if(j===xLastSync)return;xLastSync=j;xWrite("scores",{s,ts:Date.now()})},1500)}
const BOARDS=[["daily","Daily Mix · best streak"],["fenerdle","Fenerdle · best streak"],["hol","Higher or Lower · best run"],["gts","Guess the Score · best"],["tl","Timeline · record"],["who","Who Am I? · best"],["ft","Free Throws · best"],["sv","Serve · best"],["pk","Shootouts won"],["pred","Predictor points"]];
function gBoard(el){const mine=xCollect(),tbl=xTable();let sel=store.get("fb-board","daily");if(!BOARDS.some(b=>b[0]===sel))sel="daily";
  let rows;if(sel==="pred")rows=tbl.map(r=>({id:r.id,v:r.pts}));else{const m={};Object.entries(XC.docs.scores).forEach(([id,d])=>{const v=d&&d.s&&d.s[sel];if(typeof v==="number"&&v>0)m[id]=v});m[XC.me||"me"]=mine[sel]||0;rows=Object.entries(m).map(([id,v])=>({id,v})).filter(r=>r.v>0)}
  rows.sort((a,b)=>b.v-a.v);xNames(rows.map(r=>r.id).filter(i=>i!=="me"));
  el.innerHTML=`<h2>${t("Leaderboard")}</h2><p class="intro">${t(XC.on?"Best scores from fans who have played on this page. Your bests are shared automatically when you play.":"Your own best scores. Other fans' scores appear here when the page can share them, for example for people you invite to the artifact.")}</p>
   <div class="filter" role="group" aria-label="${t("Board")}">${BOARDS.map(([k,l])=>`<button data-bd="${k}" aria-pressed="${k===sel}">${esc(t(l))}</button>`).join("")}</div>
   ${rows.length?`<ol class="ptable big">${rows.slice(0,15).map((r,i)=>`<li class="${r.id===XC.me||r.id==="me"?"me":""}" data-uid="${esc(r.id)}"><span class="rk">${i+1}</span><span class="nm">${esc(r.id==="me"?t("You"):xName(r.id))}</span><b>${r.v}</b></li>`).join("")}</ol>${XC.dl?`<div class="btns"><button class="btn ghost sm" id="bdShare">${t("Save the board as an image")}</button></div>`:""}`
     :`<div class="empty"><p>${t("Nobody is on this board yet. Play a round and be the first.")}</p>${BOARD_GAME[sel]&&PLAY[current].some(x=>x[0]===BOARD_GAME[sel])?`<button class="btn" data-bdplay="${BOARD_GAME[sel]}">${t("Play now")}</button>`:""}</div>`}
   <p class="livenote" data-livenote></p>`;
  el.querySelectorAll("[data-bd]").forEach(b=>b.onclick=()=>{store.set("fb-board",b.dataset.bd);rerender()});
  const bp=el.querySelector("[data-bdplay]");if(bp)bp.onclick=()=>{playSel[current]=bp.dataset.bdplay;store.set("fb-playsel",playSel);renderPanel()};
  const sh=el.querySelector("#bdShare");if(sh)sh.onclick=e=>xShare({title:t("Leaderboard"),sub:t(BOARDS.find(x=>x[0]===sel)[1]),rows:rows.slice(0,8).map((r,i)=>[i+1,r.id==="me"?t("You"):xName(r.id),r.v])},e.currentTarget);
  if(typeof paintLiveNotes==="function")paintLiveNotes()}
const BOARD_GAME={daily:"daily",fenerdle:"wordle",hol:"hol",gts:"gts",tl:"timeline",who:"who",ft:"ft",sv:"serve",pk:"penalties"};

/* ================= BADGES ================= */
const BADGES=[
 ["fenerdle1","First Fenerdle","Solve a daily Fenerdle.",()=>BRS.some(b=>store.get(SK(b,"wd-stats"),{wins:0}).wins>0)],
 ["fenerdle5","On a roll","Reach a Fenerdle streak of 5.",()=>BRS.some(b=>(store.get(SK(b,"wd-stats"),{max:0}).max||0)>=5)],
 ["quiz","Perfect quiz","Get every question right in a quiz.",()=>Object.keys(SPORTS).some(b=>store.get(SK(b,"quiz"),0)>=SPORTS[b].quiz.length)],
 ["who","Encyclopedia","Score 30 or more in Who Am I?",()=>BRS.some(b=>store.get(SK(b,"who"),0)>=30)],
 ["tl","Historian","Set a Timeline record of 10 or more.",()=>[...BRS,"more"].some(b=>store.get(SK(b,"tl"),0)>=10)],
 ["xi","All eleven","Name a whole XI with three stars.",()=>Object.values(store.get("fb-xi3",{})).some(v=>v.stars>=3)],
 ["cup","Champions!","Win the Süper Lig in a simulated season with your XI.",()=>store.get("fb-cups",0)>0],
 ["ff","Champions of Europe","Win a European trophy in a simulated season.",()=>Object.keys(SPORTS).some(b=>store.get(SK(b,"cups"),0)>0)],
 ["pk","Ice cold","Win a penalty shootout.",()=>store.get("fb-pk-wins",0)>0],
 ["ft","Sharpshooter","Score 20 or more at the free-throw line.",()=>Math.max(store.get(SK("basketball","ft"),0),store.get(SK("womens-basketball","ft"),0))>=20],
 ["sv","Ace machine","Score 24 or more serving.",()=>store.get("fb-volleyball-sv",0)>=24],
 ["daily","Daily habit","Play the Daily Mix three days in a row.",()=>(store.get("fb-daily-stats",{max:0}).max||0)>=3],
 ["dailyp","Full marks","Get 5 out of 5 in a Daily Mix.",()=>store.get("fb-daily-perfect",0)>0],
 ["hol","Higher and higher","Reach a run of 10 in Higher or Lower.",()=>store.get("fb-hol-best",0)>=10],
 ["gts","Score whisperer","Guess 3 exact scores in Guess the Score.",()=>store.get("fb-gts-exact",0)>=3],
 ["pred","Prophet","Predict the score of an upcoming match.",()=>Object.keys(xPreds()).length>0],
 ["motm","Fan's voice","Vote for a player of the match.",()=>Object.keys(xVotes()).length>0]];
function xBadgeCheck(){const seen=store.get("fb-badges",[]),now=BADGES.filter(b=>{try{return b[3]()}catch(e){return false}}).map(b=>b[0]),fresh=now.filter(id=>!seen.includes(id));
  if(fresh.length){store.set("fb-badges",[...new Set([...seen,...fresh])]);const b=BADGES.find(x=>x[0]===fresh[0]);xToast("🏅 "+tf("Badge unlocked: {b}",{b:t(b[1])}))}}
function xToast(msg){let el=document.getElementById("toast");if(!el){el=document.createElement("div");el.id="toast";el.setAttribute("role","status");document.body.appendChild(el)}el.textContent=msg;el.classList.add("on");clearTimeout(el._t);el._t=setTimeout(()=>el.classList.remove("on"),3200)}
function gBadges(el){const got=BADGES.filter(b=>{try{return b[3]()}catch(e){return false}}).map(b=>b[0]);
  el.innerHTML=`<h2>${t("Badges")}</h2><p class="intro">${tf("{n} of {m} unlocked. Badges are kept in this browser.",{n:got.length,m:BADGES.length})}</p>
   <div class="badges">${BADGES.map(([id,n,d])=>`<div class="badge card ${got.includes(id)?"on":""}"><span class="medal" aria-hidden="true">${got.includes(id)?"★":"☆"}</span><b>${esc(t(n))}</b><span>${esc(t(d))}</span></div>`).join("")}</div>`}

/* ================= HIGHER OR LOWER ================= */
let hol=null;




/* ================= GUESS THE SCORE ================= */
function gtsPool(){const out=[],sc=s=>{const m=String(s).match(/^(\d+)–(\d+)$/);return m?[+m[1],+m[2]]:null};
  ["football","basketball","volleyball","womens-football","mens-volleyball"].forEach(b=>SPORTS[b].games.forEach(g=>{const r=sc(g.res);if(r&&g.date.length>=7)out.push({b,date:g.date,comp:g.comp,home:g.home,away:g.away,hs:r[0],as:r[1],where:g.where,note:g.note})}));
  DERBIES.forEach(D=>D.recent.forEach(([d,c,ha,a,b])=>{const fbH=ha!=="A";out.push({b:"football",date:d,comp:c,home:fbH?"Fenerbahçe":D.opp,away:fbH?D.opp:"Fenerbahçe",hs:fbH?a:b,as:fbH?b:a})}));
  ["football","basketball"].forEach(b=>LIVE[b].last.forEach(r=>{if(!r[0])return;const fbH=r[2]!=="A";out.push({b,date:r[0],comp:r[1],home:fbH?"Fenerbahçe":r[3],away:fbH?r[3]:"Fenerbahçe",hs:fbH?+r[4]:+r[5],as:fbH?+r[5]:+r[4],note:r[6]})}));
  const seen=new Set();return out.filter(x=>{const k=x.date+x.home+x.away;if(seen.has(k))return false;seen.add(k);return true})}
let gts=null;




/* ================= DAILY MIX ================= */
function mulberry(a){return()=>{a|=0;a=a+0x6D2B79F5|0;let t2=Math.imul(a^a>>>15,1|a);t2=t2+Math.imul(t2^t2>>>7,61|t2)^t2;return((t2^t2>>>14)>>>0)/4294967296}}
function dailySet(day){const r=mulberry(day*9973),pick=a=>a[Math.floor(r()*a.length)],sh=a=>{a=[...a];for(let i=a.length-1;i>0;i--){const j=Math.floor(r()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};const Q=[];
  const br=pick(Object.keys(SPORTS)),qq=pick(SPORTS[br].quiz);Q.push({kind:"quiz",tag:SPORTS[br].label,q:qq.q,o:qq.o,a:qq.o[qq.a]});
  const ev=pick(CLUB_EVENTS),yrs=new Set([ev[0]]);while(yrs.size<4){const d=Math.floor(r()*30)-15;if(d)yrs.add(ev[0]+d)}Q.push({kind:"year",tag:"Club history",ev:ev[1],o:[...yrs].sort((a,b)=>a-b).map(String),a:String(ev[0])});
  const set=pick(HOL_SETS);let A=pick(set.items),B=pick(set.items);let g=0;while((B[0]===A[0]||B[1]===A[1])&&g++<50)B=pick(set.items);Q.push({kind:"hol",tag:"Records",label:set.label,o:[A[0],B[0]],a:A[1]>B[1]?A[0]:B[0]});
  const f=pick(BR_FACTS);Q.push({kind:"which",tag:"Which branch?",q:f[0],o:sh([f[1],...sh(BR_NAMES.filter(x=>x!==f[1])).slice(0,3)]),a:f[1]});
  const gm=pick(gtsPool().filter(x=>x.b!=="basketball")),ok=`${gm.hs}–${gm.as}`,alts=new Set([ok]);let k=0;while(alts.size<4&&k++<60){const h=Math.max(0,gm.hs+Math.floor(r()*5)-2),a=Math.max(0,gm.as+Math.floor(r()*5)-2);alts.add(`${h}–${a}`)}
  Q.push({kind:"score",tag:"Results",home:gm.home,away:gm.away,comp:gm.comp,year:gm.date.slice(0,4),o:sh([...alts]),a:ok});return Q}
function dQ(q){if(q.kind==="quiz")return t(q.q);if(q.kind==="year")return tf("In which year: {e}?",{e:t(q.ev)});if(q.kind==="hol")return tf("Who has more {l}?",{l:t(q.label)});if(q.kind==="which")return t(q.q);return tf("{h} vs {a}, {c} {y}. What was the score?",{h:q.home,a:q.away,c:t(q.comp),y:q.year})}
let dlS=null;
function gDaily(el){const day=localDay();if(!dlS||dlS.day!==day){const sv=store.get("fb-daily-"+day,null);dlS={day,Q:dailySet(day),ans:sv?sv.ans:[]}}const S=dlS,N=S.Q.length,i=S.ans.length,score=S.ans.filter((a,k)=>a===S.Q[k].a).length;
  const st=store.get("fb-daily-stats",{last:null,streak:0,max:0,played:0});
  if(i>=N){el.innerHTML=`<h2>${t("Daily Mix")}</h2><div class="quiz"><span class="label">${tf("Today's mix · #{n}",{n:day-DAY0+1})}</span><div class="final">${score}/${N}</div>
     <p class="gnote">${tf("Streak: {s} days · Best streak: {m}",{s:st.streak,m:st.max})}</p><ol class="dlres">${S.Q.map((q,k)=>`<li class="${S.ans[k]===q.a?"ok":"no"}"><span>${S.ans[k]===q.a?"✓":"✗"}</span>${esc(dQ(q))} <b>${esc(t(q.a))}</b></li>`).join("")}</ol><p class="gnote">${t("A new mix arrives at midnight.")}</p></div>`;return}
  const q=S.Q[i],picked=S.pick;
  el.innerHTML=`<h2>${t("Daily Mix")}</h2><p class="intro">${t("Five questions from across the whole club, the same for everyone today. Keep your streak going by playing every day.")}</p>
   <div class="quiz"><div class="top"><span class="label">${tf("Question {i} of {n}",{i:i+1,n:N})} · ${esc(t(q.tag))}</span><span class="label">${tf("Streak {n}",{n:st.streak})}</span></div><div class="progress"><i style="width:${i/N*100}%"></i></div>
   <h3>${esc(dQ(q))}</h3><div class="opts">${q.o.map(o=>`<button class="opt" data-do="${esc(o)}">${esc(t(o))}</button>`).join("")}</div></div>`;
  el.querySelectorAll("[data-do]").forEach(b=>b.onclick=()=>{S.ans.push(b.dataset.do);store.set("fb-daily-"+day,{ans:S.ans});
    if(S.ans.length>=N){const s=S.ans.filter((a,k)=>a===S.Q[k].a).length,ST=store.get("fb-daily-stats",{last:null,streak:0,max:0,played:0});if(ST.last!==day){ST.streak=ST.last===day-1?ST.streak+1:1;ST.max=Math.max(ST.max,ST.streak);ST.played++;ST.last=day;store.set("fb-daily-stats",ST)}if(s===N)store.set("fb-daily-perfect",1);xSyncScores();xBadgeCheck()}
    const ok=b.dataset.do===q.a;b.classList.add(ok?"right":"wrong");if(!ok){const r=[...el.querySelectorAll("[data-do]")].find(x=>x.dataset.do===q.a);if(r)r.classList.add("right")}el.querySelectorAll("[data-do]").forEach(x=>x.disabled=true);setTimeout(rerender,900)})}

/* ================= SHARE IMAGES ================= */
function xResultFor(g){for(const f of EXT.result){const r=f(g);if(r!==undefined)return r}return xResultForRaw(g)}
function xResultForRaw(g){const b=current;try{
  if(g==="quiz"){const s=quizS[b],q=SPORTS[b].quiz;if(s&&s.i>=q.length)return{title:t("Quiz"),big:`${s.score}/${q.length}`}}
  if(g==="wordle"){const w=wdS[b];if(w&&w.done)return{title:"Fenerdle"+(w.daily?" #"+w.num:""),big:w.won?`${w.rows.length}/6`:"X/6",grid:w.rows.map(r=>scoreGuess(r,w.ans))}}
  if(g==="who"){const w=whoS[b];if(w&&w.i>=w.q.length)return{title:t("Who Am I?"),big:`${w.score}/${w.q.length*4}`}}
  if(g==="timeline"){const x=tlS[b];if(x&&x.over)return{title:t(TLCFG[b].title),big:String(x.score),sub:t("points")}}
  if(g==="xi"&&xi&&xi.ended)return{title:t("Name the XI")+" · "+seasonLabel(xi.id),big:`${xi.found.size}/11`};
  if(g==="penalties"&&pk&&pk.over)return{title:t("Penalty Shootout"),big:`${pk.you.filter(Boolean).length}–${pk.them.filter(Boolean).length}`,sub:t(pk.over==="win"?"Fenerbahçe win the shootout!":"The opponents win this one.")};
  if(["draft","draft5","draft6","draft11"].includes(g)&&szS[b]&&szS[b].S&&szS[b].S.done){const S=szS[b].S,tro=szTrophies(S);return{title:tf("Season {s}",{s:szDash(S.season)}),big:tro.length?`${tro.length} 🏆`:"0",sub:tro.length?tro.map(x=>t(x)).join(" · "):t("No trophies this time")}}
  if(g==="ft"&&ftS[b]&&ftS[b].phase==="over")return{title:t("Free Throws"),big:String(ftS[b].score),sub:t("points")};
  if(g==="serve"&&svS.v&&svS.v.phase==="over")return{title:t("Serve"),big:`${svS.v.score}/36`};
  if(g==="which"&&whS&&whS.i>=10)return{title:t("Which Branch?"),big:`${whS.score}/10`};
  if(g==="daily"&&dlS&&dlS.ans.length>=dlS.Q.length)return{title:t("Daily Mix")+" #"+(dlS.day-DAY0+1),big:`${dlS.ans.filter((a,k)=>a===dlS.Q[k].a).length}/5`};
  if(g==="hol"&&hol&&hol.over)return{title:t("Higher or Lower"),big:String(hol.streak),sub:t("run")};
  if(g==="gts"&&gts&&gts.i>=gts.items.length)return{title:t("Guess the Score"),big:`${gts.score}/${gts.items.length*3}`}}catch(e){}return null}
function xCard(r){const c=document.createElement("canvas"),S=1080;c.width=S;c.height=S;const x=c.getContext("2d"),cs=getComputedStyle(document.documentElement),Y=cs.getPropertyValue("--yellow").trim()||"#ffe500",N1="#0b1a3d",N2="#050d22",INK="#f3f6ff",MU="#9fb0d6",DISP='"Big Shoulders Display", "Barlow Condensed", Arial Narrow, sans-serif';
  const gr=x.createLinearGradient(0,0,0,S);gr.addColorStop(0,N1);gr.addColorStop(1,N2);x.fillStyle=gr;x.fillRect(0,0,S,S);
  for(let i=0;i<S;i+=88){x.fillStyle=Y;x.fillRect(i,0,44,14);x.fillRect(i+44,S-14,44,14)}
  x.fillStyle=Y;x.font=`900 64px ${DISP}`;x.fillText("FENERBAHÇE",80,150);x.fillStyle=MU;x.font=`600 30px "Barlow Condensed", Arial, sans-serif`;x.fillText(t("Fan Hub").toUpperCase(),82,195);
  x.fillStyle=INK;x.font=`800 64px ${DISP}`;x.fillText(r.title.toUpperCase().slice(0,30),80,330);
  if(r.rows){if(r.sub){x.fillStyle=MU;x.font=`600 34px "Barlow", Arial, sans-serif`;x.fillText(r.sub.slice(0,60),80,385)}
    r.rows.slice(0,8).forEach(([rk,nm,v],i)=>{const y=480+i*68;x.fillStyle=i===0?Y:MU;x.font=`900 46px ${DISP}`;x.fillText(String(rk),80,y);x.fillStyle=INK;x.font=`600 40px "Barlow", Arial, sans-serif`;let n=String(nm);while(x.measureText(n).width>640&&n.length>4)n=n.slice(0,-2);x.fillText(n===String(nm)?n:n+"…",160,y);
      x.fillStyle=Y;x.font=`900 50px ${DISP}`;x.textAlign="right";x.fillText(String(v),S-80,y);x.textAlign="left";x.fillStyle="rgba(255,255,255,.08)";x.fillRect(80,y+22,S-160,2)})}
  else if(r.grid){const n=r.grid[0]?r.grid[0].length:5,sz=Math.min(64,Math.floor(760/n)),col={correct:Y,present:"#3d6fe0",absent:"#25324f"};r.grid.forEach((row,i)=>row.forEach((s,j)=>{x.fillStyle=col[s];x.fillRect(80+j*(sz+8),400+i*(sz+8),sz,sz)}));x.fillStyle=Y;x.font=`900 150px ${DISP}`;x.fillText(r.big,80,960)}
  else{x.fillStyle=Y;x.font=`900 300px ${DISP}`;x.fillText(r.big,74,700);if(r.sub){x.fillStyle=INK;x.font=`600 44px "Barlow", Arial, sans-serif`;wrapText(x,r.sub,80,790,920,54)}}
  x.fillStyle=MU;x.font=`600 30px "Barlow Condensed", Arial, sans-serif`;x.fillText(fmtDay(new Date(),{day:"numeric",month:"long",year:"numeric"}),80,S-60);return c}
function wrapText(x,s,X,Y,w,lh){const words=s.split(" ");let line="",y=Y;words.forEach(wd=>{const tt=line?line+" "+wd:wd;if(x.measureText(tt).width>w&&line){x.fillText(line,X,y);line=wd;y+=lh}else line=tt});if(line)x.fillText(line,X,y)}
async function xShare(r,btn){if(!XC.dl)return;btn.disabled=true;try{const c=xCard(r);const blob=await new Promise(res=>c.toBlob(res,"image/png"));await XC.dl.save({filename:"fenerbahce-"+(r.title.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"")||"result")+".png",data:blob})}catch(e){}btn.disabled=false}

/* ===== Deeper legends, early titles, fuller history (researched 7 November 2026) ===== */
const LEG_FACTS={
 "Lefter Küçükandonyadis":["215 official goals, first on the club's all-time list.","349 appearances."],
 "Can Bartu":["The first Turkish player to appear in a European final, with Fiorentina."],
 "Cemil Turan":["127 goals, sixth on the club's all-time list."],
 "Alex de Souza":["171 goals, third on the club's all-time list.","341 appearances."],
 "Volkan Demirel":["525 appearances, second only to Müjdat Yetkiner."],
 "Željko Obradović":["Five straight Final Fours, 2015 to 2019."],
 "Ekpe Udoh":["18 points in the 2017 semi-final against Real Madrid."],
 "Bogdan Bogdanović":["17 points in the 2017 final."],
 "Nigel Hayes-Davis":["23 points in the 2025 final against Monaco."],
 "Breanna Stewart":["35 points in the 2023 final, a 99–60 win over ÇBK Mersin."],
 "Julie Allemand":["13 points, 8 rebounds and 10 assists in the 2026 final."],
 "Kim Yeon-koung":["Wore number 10 in the 2012 Champions League-winning squad."],
 "Katarzyna Skowrońska":["Wore number 1 in the 2010 world champion squad."],
 "Naz Aydemir":["In both the 2010 and 2012 winning squads."],
 "Eda Erdem Dündar":["The only player in the 2010, 2012 and 2023–24 squads on this site."]};
const LEG_ADD={
 football:[
  ["Zeki Rıza Sporel","Forward · 1915–1934","The first great star of Turkish football and the club's leading scorer of the early era.",["Scored Turkey's first international goal, against Romania in 1923.","Club records credit him with around 470 goals, unofficial matches included."]],
  ["Fikret Arıcan","Forward · 1928–1947","Almost two decades in yellow and navy.",["109 goals, seventh on the club's all-time list."]],
  ["Naci Bastoncu","Forward · 1934–1947","A goalscorer of the club's first golden age.",["162 goals, fifth on the club's all-time list."]],
  ["Melih Kotanca","Forward · 1938–1948","Prolific striker of the National Division sides of the 1940s.",["172 goals, second on the club's all-time list."]],
  ["Şeref Has","Forward · 1955–1969","A loyal servant for fourteen seasons.",["382 appearances, fourth on the all-time list.","89 goals."]],
  ["Ogün Altıparmak","Forward · 1963–1971","Pace and goals in the title sides of the 1960s.",["89 goals, joint eighth on the all-time list."]],
  ["Müjdat Yetkiner","Defender · 1979–1996","Seventeen seasons, and more games than anyone in the club's history.",["570 appearances, the club record."]],
  ["Aykut Kocaman","Striker · 1988–1996","A penalty-box predator who came back to coach the club.",["167 goals, fourth on the all-time list.","As coach: the 2010–11 title and the 2012 and 2013 Turkish Cups."]],
  ["Rüştü Reçber","Goalkeeper · 1994–2007","Turkey's goalkeeper at the 2002 World Cup, where Turkey finished third.",["381 appearances for the club.","Named in the 2002 World Cup all-star team."]],
  ["Uche Okechukwu","Defender · 1990s","Nigerian centre-back who became the longest-serving foreign player in Turkish football.",[]],
  ["Tuncay Şanlı","Forward · 2002–2007","Versatile forward remembered for a Champions League hat-trick.",["Scored all three goals in a 3–0 win over Manchester United in December 2004."]],
  ["Zico","Head coach · 2006–2008","The Brazilian great won the 2006–07 title and took the team to the 2008 Champions League quarter-finals.",[]],
  ["Emre Belözoğlu","Midfielder · 2008–2020, with spells away","Captain and playmaker, and from November 2026 the head coach.",["Appointed head coach on 3 November 2026."]],
  ["Dirk Kuyt","Forward · 2012–2015","Tireless Dutch forward of the 2013–14 champions.",[]]],
 basketball:[
  ["Kostas Sloukas","Point guard · 2015–2021","Greek playmaker of the 2017 champions and five straight Final Fours.",[]],
  ["Luigi Datome","Forward · 2015–2019","Italian shooter and one of the leaders of the 2017 title team.",[]],
  ["Nikola Kalinić","Forward · 2016–2019","Two-way wing of the 2017 champions.",["17 points in the 2017 final."]],
  ["Bobby Dixon","Guard · 2014–2019","American-born guard who played for Turkey as Ali Muhammed.",["Part of the 2017 EuroLeague-winning team."]],
  ["Nicolò Melli","Forward · 2015–2019, 2024–","Scored 28 in the 2018 final, then came back to win the 2025 title.",["Still on the roster in 2026–27."]],
  ["Marko Gudurić","Guard · 2025 champion","19 points in the 2025 final, second only to Hayes-Davis.",["19 points against Monaco."]],
  ["Wade Baldwin IV","Guard · 2024–","A key guard in the 2025 title run.",["13 points in the 2025 final."]],
  ["İbrahim Kutluay","Shooting guard","One of the great shooters of Turkish basketball.",["The club retired his shirt in December 2025."]]],
 "womens-basketball":[
  ["Olcay Çakır","Guard","A club captain who came back again and again.",["Captain in 2022–23.","Three separate spells at the club."]],
  ["Tuğçe Canıtez","Center","A leader of the side that kept reaching European finals.",["Club captain from 2019 to 2022."]],
  ["Napheesa Collier","Forward · 2023–24","American star of the 2024 European title.",["33 points in the 2024 final against Villeneuve d'Ascq."]],
  ["Marina Maljković","Head coach · 2022–2023","Turned four lost finals into the first European title.",["Won the 2023 EuroLeague Women in Prague."]],
  ["Valérie Garnier","Head coach · 2023–2024","Coach of the perfect season.",["35–0 in the league and the 2024 EuroLeague, won in Mersin."]],
  ["Miguel Méndez","Head coach · 2025–","Led the 46–1 season and the third European title.",["2026 EuroLeague Women champion in Zaragoza."]]],
 volleyball:[
  ["Seda Tokatlıoğlu","Opposite · 2010 world champion","A two-time captain.",["Captain in 2005–06 and again from 2011 to 2014."]],
  ["Çiğdem Can Rasna","Middle blocker","Captain of the world champion era.",["Club captain from 2008 to 2011.","In the 2010 world champion squad."]],
  ["Fofão","Setter · 2010","Brazilian setting great who ran the offence of the 2010 world champions.",[]],
  ["Logan Tom","Outside hitter · 2012","US international in the 2012 Champions League-winning squad.",[]],
  ["Fabiana Claudino","Middle blocker · 2012","Brazilian Olympic champion who wore number 1 in the 2012 squad.",[]],
  ["Zé Roberto","Head coach · 2010–2012","Brazil's Olympic-winning coach took Fenerbahçe to the top of Europe.",["Coach of the 2012 Champions League win in Baku."]],
  ["Stefano Lavarini","Head coach · 2023–2024","Won the 2023–24 league and cup double.",[]]],
 more:[
  ["Ramil Guliyev","Athletics · sprinter","The fastest man in the club's history.",["200 m world champion in 2017.","European champion in 2018."]],
  ["Eşref Apak","Athletics · hammer","An Olympic medal in the hammer throw.",["Silver at the 2004 Athens Olympics."]],
  ["Ruhi Sarıalp","Athletics · triple jump","A pioneer of Turkish athletics.",["Bronze at the 1948 London Olympics."]],
  ["Yasmani Copello","Athletics · 400 m hurdles","Olympic medallist for Turkey in Rio.",["Bronze at the 2016 Rio Olympics."]],
  ["Karin Melis Mey","Athletics · long jump","A world championship medal in the long jump.",["Bronze at the 2009 World Championships."]],
  ["Tonguç Türsan","Rowing","The rower who gave Turkey its first international success in the sport.",["Silver at the 1955 Mediterranean Games."]],
  ["Tuğçe Subaşı","Sailing","A world champion on the water.",["Laser 4.7 world champion in 2002."]],
  ["Hikmet Topuzer","Club pioneer","The man behind the badge.",["Designed the club crest in 1910."]]]};
const HIST_ADD={
 football:[["1908","A home ground in Kadıköy","The Union Club Field opens on the spot where Şükrü Saracoğlu stands today, and Fenerbahçe play there. The club joins the Istanbul Football League a year later."],
  ["1912","First Istanbul League title","The 1911–12 Istanbul Football League is the club's first title, the start of a record 16."],
  ["1933","Champions of Turkey, owners of their ground","Fenerbahçe win the Turkish Football Championship for the first time and buy their ground from the state on 27 May."],
  ["1937","First National Division title","The nationwide National Division (Milli Küme) starts, and Fenerbahçe win it. Five more follow by 1950."],
  ["1960","Europe for the first time","A first European Cup campaign ends in a play-off against Nice."],
  ["1968","Manchester City knocked out","Under Ignác Molnár, Fenerbahçe knock the English champions out of the European Cup in the first round."],
  ["1996","A win at Old Trafford","A 1–0 Champions League win at Manchester United ends their 40-year unbeaten home record in European competition."],
  ["2001","Galatasaray's run ended","Fenerbahçe win the title and stop Galatasaray's streak of four in a row."],
  ["2004","Tuncay's hat-trick","Tuncay Şanlı scores all three in a 3–0 Champions League win over Manchester United in Istanbul."],
  ["2007","Zico's champions","Brazilian coach Zico leads Fenerbahçe to the 2006–07 title, the club's 17th."],
  ["2009","A European final in Kadıköy","Şükrü Saracoğlu hosts the UEFA Cup final, won 2–1 by Shakhtar Donetsk against Werder Bremen."],
  ["2011","Champions under Aykut Kocaman","A former goal machine of the club coaches Fenerbahçe to the 2010–11 title, number 18."],
  ["2013","Europa League semi-final","Fenerbahçe reach the last four, where Benfica win the tie."],
  ["2024","Conference League quarter-finals","A run to the last eight ends against Olympiacos."]],
 basketball:[["1957","First Turkish title","The first of 16 Turkish championships."],["1967","First Turkish Cup","The first of 10 Turkish Cups."],["2010","Into the Sinan Erdem Dome","Home games move to the Sinan Erdem Dome."],
  ["2015","First Final Four","A first EuroLeague Final Four, in Madrid, under Željko Obradović."],["2019","Five in a row","The Final Four in Vitoria-Gasteiz is the fifth in a row."],["2022","A museum for the branch","The Fenerbahçe Basketball Museum opens."],
  ["2024","Back among Europe's best","Under Šarūnas Jasikevičius, Fenerbahçe return to the Final Four, in Berlin."]],
 "womens-basketball":[["2014","Another final","A second straight EuroLeague final ends in defeat."],["2017","Third final","Another EuroLeague final, another runner-up medal."],
  ["2022","Fourth final, new coach","A fourth lost EuroLeague final. Marina Maljković takes over and builds the team that wins it a year later."],["2025","Miguel Méndez arrives","The new coach leads the 46–1 season that follows."]],
 volleyball:[["1977","The section closes","The volleyball section closes for lack of funds, before coming back."],["2009","First modern league title","The first Turkish league title in the current format. The men win the Balkan Cup."],
  ["2011","Third in Europe","A Champions League podium the year after reaching the final."],["2015","League and cup","A league title and Turkish Cup double."],["2016","Third again","Another Champions League bronze."],
  ["2017","Double again","League title and Turkish Cup once more."],["2023","Champions again","A first league title since 2017."],["2025","Cup winners","The Turkish Cup, a fifth in the club's history."]]};
const TROPHY_PRE=[["16","Istanbul Football League","1911–12, 1913–14, 1914–15, 1920–21, 1922–23, 1929–30, 1932–33, 1934–35, 1935–36, 1936–37, 1943–44, 1946–47, 1947–48, 1952–53, 1956–57, 1958–59","pre"],
 ["6","National Division (Milli Küme)","1937, 1940, 1943, 1945, 1946, 1950","pre"],["3","Turkish Football Championship","1933, 1935, 1944","pre"],["4","Istanbul Shield","1929–30, 1933–34, 1937–38, 1938–39","pre"]];
/* runs after buildI18n(), so the translation packs still zip against the original arrays */
function mergeContent(){
  Object.entries(LEG_ADD).forEach(([b,list])=>{const S=SPORTS[b];S.legends=(S.legends||[]).concat(list)});
  Object.values(SPORTS).forEach(S=>(S.legends||[]).forEach(l=>{if(!l[3])l[3]=LEG_FACTS[l[0]]||[]}));
  Object.entries(HIST_ADD).forEach(([b,list])=>{const S=SPORTS[b];S.history=S.history.concat(list).sort((a,c)=>parseInt(a[0],10)-parseInt(c[0],10))});
  SPORTS.more.history=CLUB_EVENTS.filter(e=>[1907,1910,1913,1914,1917,1928,1932,1948,1995,2002,2004,2015,2016,2017,2024,2026].includes(e[0])).filter((e,i,a)=>a.findIndex(x=>x[0]===e[0])===i).map(([y,txt,br])=>[String(y),txt,br]);
  const F=SPORTS.football;F.trophies[0]=["28","Turkish championship","1933, 1935, 1937, 1940, 1943, 1944, 1945, 1946, 1950, 1959, 1961, 1964, 1965, 1968, 1970, 1974, 1975, 1978, 1983, 1985, 1989, 1996, 2001, 2004, 2005, 2007, 2011, 2014"];
  F.trophies.splice(3,0,TROPHY_PRE[0].slice(0,3),TROPHY_PRE[3].slice(0,3));F.stats[0]=["28","Turkish championships"];
  F.history=F.history.map(h=>h[0]==="2014"&&/19/.test(h[1])?["2014","Title number 28","Fenerbahçe win the 2013–14 Süper Lig, their 28th national title in the club's count and their most recent league crown."]:h);
}

/* ===== Branch-specific Higher or Lower and Guess the Score ===== */
function luPoints(items,label){const out=[];(items||[]).forEach(L=>{L.st.forEach(([p,n,pts])=>{if(pts)out.push([n+" · "+L.label,pts])});L.bench.forEach(([n,pts])=>{if(pts)out.push([n+" · "+L.label,pts])})});return {key:"pts",label,items:out}}
const evYears=(list,label)=>({key:"year",label,year:true,items:list.map(([y,tx])=>[tx,y])});
const HOL_BY={
 football:()=>[HOL_SETS[0],HOL_SETS[1],{key:"titles",label:"titles",items:[["Turkish championships",28],["Turkish Cups",7],["Turkish Super Cups",10],["Istanbul Football League titles",16],["Istanbul Shields",4]]}],
 basketball:()=>[luPoints(MB_LINEUPS,"points in that Final Four game"),evYears(MB_EVENTS,"year it happened")],
 "womens-basketball":()=>[luPoints(WB_LINEUPS,"points in that final"),evYears(WB_EVENTS,"year it happened")],
 volleyball:()=>[evYears(VB_EVENTS,"year it happened"),{key:"titles",label:"titles",items:[["Turkish league titles",15],["Turkish Cups",5],["CEV Champions League titles",1],["Club World titles",1],["CEV Cups",1],["Men's Balkan Cups",2],["Men's CEV Challenge Cups",1]]}],
 more:()=>[HOL_SETS[2],evYears(CLUB_EVENTS,"year it happened")]};
const HOL_CACHE={};const holSets=b=>HOL_CACHE[b]||(HOL_CACHE[b]=HOL_BY[b]().filter(s=>s.items.length>2));
const holsS={};
function holPick2(set,not){const pool=set.items.filter(x=>!not.includes(x[0]));return pool[Math.floor(Math.random()*pool.length)]}
function newHolB(b,mode){const sets=holSets(b),prev=holsS[b];mode=mode||(prev?prev.mode:"mixed");const set=mode==="mixed"?sets[Math.floor(Math.random()*sets.length)]:sets.find(s=>s.key===mode)||sets[0];const a=holPick2(set,[]);holsS[b]={b,mode,set,a,b2:holPick2(set,[a[0]]),streak:0,phase:"ask",last:null,over:false};return holsS[b]}
function gHoL(el){const b=current,sets=holSets(b);let H=holsS[b]||newHolB(b,"mixed");hol=H;const best=store.get("fb-hol-best",0);
  const val=(x,set)=>set.year?String(x[1]):x[1],card=(x,show,cls)=>`<div class="holcard card ${cls||""}"><span class="label">${esc(t(H.set.label))}</span><b>${esc(t(x[0]))}</b><span class="hv">${show?val(x,H.set):"?"}</span></div>`;
  const modes=[["mixed","Mixed"]].concat(sets.map(s=>[s.key,{goals:"Goals",apps:"Appearances",titles:"Titles",pts:"Points",year:"Years"}[s.key]]));
  el.innerHTML=`<h2>${t("Higher or Lower")}</h2><p class="intro">${t(H.set.year?"Did the second event happen later than the first? Higher means a later year.":"Does the second record beat the first? Guess higher or lower and keep the run going. Equal numbers count either way.")}</p>
   <div class="filter" role="group" aria-label="${t("Category")}">${modes.map(([k,l])=>`<button data-hm="${k}" aria-pressed="${H.mode===k}">${t(l)}</button>`).join("")}</div>
   <div class="tlhead"><div><b class="count">${H.streak}</b><span class="label">${t("run")}</span></div><div><b class="count">${best}</b><span class="label">${t("record")}</span></div></div>
   <div class="holrow">${card(H.a,true)}<span class="vsx">${t("vs")}</span>${card(H.b2,H.phase!=="ask",H.last==null?"":H.last?"ok":"no")}</div>
   ${H.phase==="ask"?`<div class="btns"><button class="btn" data-hl="hi">▲ ${t(H.set.year?"Later":"Higher")}</button><button class="btn" data-hl="lo">▼ ${t(H.set.year?"Earlier":"Lower")}</button></div>`
    :H.over?`<p class="msg bad">${tf("Run over at {n}.",{n:H.streak})}</p><div class="btns"><button class="btn" data-hl="again">${t("Play again")}</button></div>`
    :`<p class="msg good">${t("Correct.")}</p><div class="btns"><button class="btn" data-hl="next">${t("Next")}</button></div>`}
   <p class="gnote">${t(b==="football"?"Goals as listed in the club records up to 2016, appearances up to 2019, titles as shown on this site.":b.includes("basketball")?"Points come from the box scores in Name the Lineup.":"Years and titles as shown on this site.")}</p>`;
  el.querySelectorAll("[data-hm]").forEach(x=>x.onclick=()=>{newHolB(b,x.dataset.hm);rerender()});
  el.querySelectorAll("[data-hl]").forEach(x=>x.onclick=()=>{const k=x.dataset.hl;
    if(k==="hi"||k==="lo"){const ok=k==="hi"?H.b2[1]>=H.a[1]:H.b2[1]<=H.a[1];H.last=ok;H.phase="show";if(ok){H.streak++;if(H.streak>store.get("fb-hol-best",0))store.set("fb-hol-best",H.streak)}else H.over=true;xBadgeCheck();xSyncScores()}
    else if(k==="next"){if(H.mode==="mixed"&&Math.random()<.4){H.set=sets[Math.floor(Math.random()*sets.length)];H.a=holPick2(H.set,[])}else H.a=H.b2;H.b2=holPick2(H.set,[H.a[0]]);H.phase="ask";H.last=null}
    else newHolB(b);rerender()})}
function gtsPoolB(b){const all=gtsPool().filter(x=>x.b===b),sc=s=>{const m=String(s).match(/^(\d+)–(\d+)/);return m?[+m[1],+m[2]]:null};
  if(b==="basketball"||b==="womens-basketball")(b==="basketball"?MB_LINEUPS:WB_LINEUPS).forEach(L=>{const r=sc(L.score);if(r&&L.date)all.push({b,date:L.date,comp:L.title,home:"Fenerbahçe",away:L.opp,hs:r[0],as:r[1],where:L.where,neutral:true})});
  if(b!=="football"&&b!=="basketball")(LIVE[b]||(b==="more"?LIVE["womens-football"]:null)||{last:[]}).last.forEach(r=>{const fbH=r[2]!=="A";all.push({b,date:r[0]||"",comp:r[1],home:fbH?"Fenerbahçe":r[3],away:fbH?r[3]:"Fenerbahçe",hs:fbH?+r[4]:+r[5],as:fbH?+r[5]:+r[4],note:r[6]})});
  if(b==="womens-basketball")SPORTS[b].games.forEach(g=>{const r=sc(g.res);if(r)all.push({b,date:g.date,comp:g.comp,home:g.home,away:g.away,hs:r[0],as:r[1],where:g.where,note:g.note})});
  const seen=new Set();return all.filter(x=>{const k=x.home+x.away+x.hs+x.as;if(seen.has(k))return false;seen.add(k);return true})}
const gtsS={};
function newGtsB(b){gtsS[b]={items:shuffle(gtsPoolB(b)).slice(0,8),i:0,score:0,ex:0,ans:null};return gtsS[b]}
function gGTS(el){const b=current;let G=gtsS[b]||newGtsB(b);gts=G;const N=G.items.length;
  if(!N){el.innerHTML=`<h2>${t("Guess the Score")}</h2><p class="intro">${t("No results with scores yet for this branch.")}</p>`;return}
  if(G.i>=N){const best=store.get("fb-gts-best",0);if(G.score>best)store.set("fb-gts-best",G.score);
    el.innerHTML=`<h2>${t("Guess the Score")}</h2><div class="quiz"><span class="label">${t("Final score")}</span><div class="final">${G.score}/${N*3}</div><p class="gnote">${tf("Exact scores: {n}. Best: {b}/{m}",{n:G.ex,b:Math.max(best,G.score),m:24})}</p><button class="btn" data-g="again" style="margin-top:14px">${t("Play again")}</button></div>`;
    el.querySelector('[data-g="again"]').onclick=()=>{newGtsB(b);rerender()};xSyncScores();xBadgeCheck();return}
  const x=G.items[G.i],bb=x.b.includes("basketball"),max=bb?199:x.b.includes("volleyball")?3:20,dt=x.date.length===10?mDate(x.date):x.date.length>=4?x.date.slice(0,4):"";
  el.innerHTML=`<h2>${t("Guess the Score")}</h2><p class="intro">${t(bb?"Eight real Fenerbahçe results with the score hidden. The right winner earns 1 point, and 3 if both scores are within 5 points.":x.b.includes("volleyball")?"Real Fenerbahçe results with the score in sets hidden. 3 points for the exact score, 1 for the right winner.":"Eight real Fenerbahçe results with the score hidden. 3 points for the exact score, 1 for the right result.")}</p>
   <div class="quiz"><div class="top"><span class="label">${tf("Match {i} of {n}",{i:G.i+1,n:N})}</span><span class="label">${tf("Score {n}",{n:G.score})}</span></div><div class="progress"><i style="width:${G.i/N*100}%"></i></div>
    <span class="label" style="margin-top:12px;display:block">${esc(t(x.comp))}${dt?` · ${dt}`:""}${x.where?` · ${esc(t(x.where))}`:""}</span>
    <div class="gtsrow"><label class="pin"><span>${esc(x.home)}</span><input id="gH" type="number" min="0" max="${max}" inputmode="numeric" ${G.ans?"disabled":""} value="${G.ans?G.ans[0]:""}"></label><span class="dash">–</span><label class="pin"><span>${esc(x.away)}</span><input id="gA" type="number" min="0" max="${max}" inputmode="numeric" ${G.ans?"disabled":""} value="${G.ans?G.ans[1]:""}"></label></div>
    ${G.ans?`<p class="explain"><b>${G.ans[2]===3?t("Spot on! +3"):G.ans[2]?tf("Right result, +{n}",{n:G.ans[2]}):t("Not this time.")}</b> ${tf("It finished {h}–{a}.",{h:x.hs,a:x.as})} ${x.note&&x.date?esc(t(x.note)):""}</p><button class="btn" data-g="next" style="margin-top:12px">${G.i+1<N?t("Next match"):t("See score")}</button>`
     :`<div class="btns"><button class="btn" data-g="go">${t("Lock it in")}</button></div>`}</div>`;
  const on=(k,f)=>{const q=el.querySelector(`[data-g="${k}"]`);if(q)q.onclick=f};
  on("go",()=>{const h=parseInt(el.querySelector("#gH").value,10),a=parseInt(el.querySelector("#gA").value,10);if(isNaN(h)||isNaN(a))return;const sg=v=>Math.sign(v),out=sg(h-a)===sg(x.hs-x.as)?1:0;
    const p=bb?out+(out&&Math.abs(h-x.hs)<=5&&Math.abs(a-x.as)<=5?2:0):(h===x.hs&&a===x.as?3:out);G.ans=[h,a,p];G.score+=p;if(p===3){G.ex++;store.set("fb-gts-exact",store.get("fb-gts-exact",0)+1)}rerender()});
  on("next",()=>{G.i++;G.ans=null;rerender()})}

/* ===== Themes ===== */
const THEMES=[["light","Light","#eef1f6","#0d1c3d"],["night","Kadıköy Night","#0d1c3d","#ffe500"],["day","Matchday","#f3f0e6","#1b3878"],["canary","Canary","#ffd60a","#0d1c3d"],["retro","1907 Retro","#efe4cc","#1d2f5c"],["flood","Floodlights","#000000","#ffe500"],["clean","Clean","#ffffff","#1b3878"],["bosphorus","Bosphorus","#04212b","#ffe500"],["pitch","Saracoğlu Pitch","#062014","#ffe500"],["sunset","Kadıköy Sunset","#fbeee2","#b8461b"],["sky","Sky Blue","#eaf3fb","#1660b8"]];
/* Matchday is the default design (v28). Anyone still on the old default (Light) moves to it once; a design someone picked themselves is kept */
let THEME=(()=>{try{const v=localStorage.getItem("fb-theme");if(localStorage.getItem("fb-look")!=="28"){localStorage.setItem("fb-look","28");if(!v||v==="light"){localStorage.setItem("fb-theme","day");return "day"}}
  if(THEMES.some(x=>x[0]===v))return v}catch(e){}return "day"})();
const FONT_EXTRA={retro:"https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&display=swap",ar:"https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap"};
function applyTheme(v){THEME=v;if(v==="retro"&&window.loadFont)loadFont(FONT_EXTRA.retro);document.documentElement.dataset.theme=v;try{localStorage.setItem("fb-theme",v)}catch(e){}const T=THEMES.find(x=>x[0]===v);const sw=document.getElementById("themeSw");if(sw){sw.style.background=`linear-gradient(135deg,${T[2]} 50%,${T[3]} 50%)`;sw.style.boxShadow="0 0 0 1.5px var(--line-2)"}
  const s=document.getElementById("theme");if(s)s.value=v;if(tab==="play"&&playSel[current]==="penalties"&&typeof drawWheel==="function")drawWheel(document.getElementById("wheel"))}
function initTheme(){const s=document.getElementById("theme");s.innerHTML=THEMES.map(([k,n])=>`<option value="${k}">${esc(t(n))}</option>`).join("");s.onchange=e=>applyTheme(e.target.value);applyTheme(THEME)}
function themeTexts(){const s=document.getElementById("theme");if(!s)return;[...s.options].forEach((o,i)=>o.textContent=t(THEMES[i][1]));s.setAttribute("aria-label",t("Design"));s.value=THEME}

/* ===== New branches: women's football and men's volleyball ===== */
SPORTS["womens-football"]={
  label:"Women's Football",tr:"Kadın Futbol",title:"Women's Football",num:"21",
  nick:"Fenerbahçe arsaVev, champions of Turkey",
  lede:"Founded in 1995, closed, then brought back in 2021, the women's team went from semi-finals to the title in five seasons. They won their first Super League in 2025–26 and played in Europe for the first time in 2026–27.",
  stats:[["1","Super League titles"],["1995","Team founded"],["2021","Team refounded"],["2026","First European season"]],
  home:["Home ground","Lefter Küçükandonyadis Stadium, Dereağzı, Kadıköy"],
  history:[
    ["1995","The first women's team","Fenerbahçe form a women's football team on 4 April 1995."],
    ["1996","A short first life","After finishing third in their group in 1995–96, the team is later closed for financial reasons."],
    ["2021","Back for good","The club announces the return of women's football on 26 August 2021. The new team tops its group and reaches the semi-finals."],
    ["2023","A first final","Fenerbahçe reach the Super League play-off final."],
    ["2024","Third place","Third in the Super League."],
    ["2025","Runners-up","Second place, one step from the title."],
    ["2026","Champions of Turkey","A 7–0 win at Giresun Sanayispor in May clinches the first league title with two rounds to spare."],
    ["2026","Europe for the first time","Out of the Champions League qualifiers on penalties against OH Leuven in August, then a 5–1 aggregate win over Minsk and a place in the last 16 of the Women's Europa Cup."],
    ["2026","Derby winner","Ece Türkoğlu's 89th-minute goal beats Galatasaray 1–0 on 7 November, Galatasaray's first league defeat of the season."]],
  games:[
    {date:"2026-11-07",comp:"Women's Super League",home:"Fenerbahçe",away:"Galatasaray",res:"1–0",out:"win",tag:"Derby",note:"Ece Türkoğlu scored in the 89th minute. It was Galatasaray's first league defeat of the season.",where:"Lefter Küçükandonyadis Stadium, Istanbul"},
    {date:"2025-12-07",comp:"Women's Super League",home:"Fenerbahçe",away:"Galatasaray",res:"1–0",out:"win",tag:"Derby",note:"Marta Cox scored a 64th-minute penalty on the way to the first title.",where:"Şükrü Saracoğlu, Istanbul"},
    {date:"2026-05",comp:"Women's Super League",home:"Giresun Sanayispor",away:"Fenerbahçe",res:"0–7",out:"win",tag:"League",note:"The win that sealed the first championship, with two rounds still to play.",where:"Çotanak Arena, Giresun"},
    {date:"2026-09-30",comp:"Women's Europa Cup",home:"Fenerbahçe",away:"Minsk",res:"1–0",out:"win",tag:"Europe",note:"Busem Şeker's goal completed a 5–1 aggregate win and a place in the last 16.",where:"Yusuf Ziya Öniş Stadium, Istanbul"},
    {date:"2026-08-08",comp:"Women's Champions League",home:"OH Leuven",away:"Fenerbahçe",res:"1–1",out:"loss",tag:"Europe",note:"Konya Plummer scored early, but Leuven equalised and won the shootout 4–2.",where:"Den Dreef, Leuven"}],
  filters:["All","Derby","League","Europe"],
  trophies:[["1","Super League","2025–26"]],
  legends:[
    ["Yağmur Uraz","Forward · captain","Club captain and one of the leaders of the first title-winning side.",["Captain of the 2025–26 champions."]],
    ["Ece Türkoğlu","Midfielder · vice-captain","Scored the 89th-minute winner against Galatasaray in November 2026.",["Vice-captain of the 2025–26 champions."]],
    ["Andrea Stašková","Forward","Czech striker and the leading scorer of the first title season.",["16 league goals by the day the title was won.","Hat-trick in the 12–0 win over Şile BilgiDoğa in September 2026."]],
    ["Marta Cox","Midfielder","Panama international who scored the penalty that beat Galatasaray in December 2025.",[]],
    ["Konya Plummer","Defender","Jamaica international who scored against OH Leuven in the 2026 Champions League qualifiers.",[]],
    ["Gökhan Bozkaya","Head coach · 2023–","Took over in 2023: third, then second, then the first league title.",["2025–26 Super League champion."]]],
  quiz:[
    {q:"In which year was Fenerbahçe's first women's football team founded?",o:["1995","2007","2015","2021"],a:0,e:"1995. The team was later closed and came back in 2021."},
    {q:"Which season brought the first Super League title?",o:["2022–23","2023–24","2024–25","2025–26"],a:3,e:"2025–26, clinched with a 7–0 win at Giresun Sanayispor."},
    {q:"Who scored the winner against Galatasaray on 7 November 2026?",o:["Ece Türkoğlu","Yağmur Uraz","Andrea Stašková","Marta Cox"],a:0,e:"Ece Türkoğlu, in the 89th minute."},
    {q:"Who knocked Fenerbahçe out of the 2026–27 Champions League qualifiers?",o:["OH Leuven","Minsk","Real Sociedad","Slavia Prague"],a:0,e:"OH Leuven, 4–2 on penalties after a 1–1 draw."},
    {q:"Who is the head coach?",o:["Gökhan Bozkaya","Nihan Su","Özkan Beceren","Serhat Deniz"],a:0,e:"Gökhan Bozkaya, in charge since 2023."},
    {q:"Where does the team play most home games?",o:["Lefter Küçükandonyadis Stadium","Ülker Sports and Event Hall","Burhan Felek Sport Hall","Atatürk Olympic Stadium"],a:0,e:"At the Lefter Küçükandonyadis Stadium in Dereağzı, Kadıköy."}]};

SPORTS["mens-volleyball"]={
  label:"Men's Volleyball",tr:"Erkek Voleybol",title:"Men's Volleyball",num:"14",
  nick:"Fenerbahçe Medicana, the men's team",
  lede:"Five-time champions of Turkey and winners of the CEV Challenge Cup in 2014. The team was refounded in 1976, reached the top flight in 1985 and won its first league title in 2008.",
  stats:[["5","Turkish league titles"],["5","Turkish Cups"],["4","Turkish Super Cups"],["1","CEV Challenge Cup"]],
  home:["Home court","Burhan Felek Sport Hall, Üsküdar · 7,000 seats"],
  history:[
    ["1927","The first team","Fenerbahçe start a men's volleyball team, which comes and goes over the following decades."],
    ["1976","A fresh start","The team is refounded in its present form and starts in Istanbul's fourth division."],
    ["1985","Into the top flight","After three promotions, Fenerbahçe win the Istanbul First League and step up to the national league."],
    ["2008","First league title","Under György Demeter, Fenerbahçe win the Turkish league and the Turkish Cup."],
    ["2009","Balkan Cup","The first international trophy for the men's team."],
    ["2012","Three in a row","A third straight league title, together with the Turkish Cup."],
    ["2014","European champions","Fenerbahçe beat Andreoli Latina 3–0 in Istanbul to win the CEV Challenge Cup, on the same day the women won the CEV Cup."],
    ["2019","League and cup double","The fifth league title arrives together with the Turkish Cup."],
    ["2025","Cup winners again","Fenerbahçe win the 2024–25 Turkish Cup, their fifth."],
    ["2026","New coach","Taner Atik takes over as head coach in January 2026."]],
  games:[
    {date:"2014-03-29",comp:"CEV Challenge Cup Final",home:"Fenerbahçe",away:"Andreoli Latina",res:"3–0",out:"win",tag:"Europe",note:"25–22, 25–19, 25–17 in front of 6,500 fans, after a five-set defeat in the first leg in Italy.",where:"Istanbul"},
    {date:"2014-03-26",comp:"CEV Challenge Cup Final",home:"Andreoli Latina",away:"Fenerbahçe",res:"3–2",out:"loss",tag:"Europe",note:"A five-set defeat in the first leg left everything to play for in Istanbul.",where:"Italy"},
    {date:"2026-10-31",comp:"Efeler Ligi",home:"İBB Spor Kulübü",away:"Fenerbahçe",res:"1–3",out:"win",tag:"League",note:"After losing the first set, Fenerbahçe won the next three 25–18, 25–21 and 25–15.",where:"Cebeci Sports Complex, Istanbul"},
    {date:"2026-10-24",comp:"Efeler Ligi",home:"Gaziantep Gençlik Spor",away:"Fenerbahçe",res:"2–3",out:"win",tag:"League",note:"The first win of the season, in five sets.",where:"Gaziantep"}],
  filters:["All","Europe","League"],
  trophies:[["5","Turkish League","2008, 2010, 2011, 2012, 2019"],["5","Turkish Cup","2008, 2012, 2017, 2019, 2025"],["4","Turkish Super Cup","2011, 2012, 2017, 2020"],["2","Balkan Cup","2009, 2013"],["1","CEV Challenge Cup","2014"]],
  legends:[
    ["İsmail Vuran","Head coach · 1985–1990, 1993–2001","Coached the team through its first years in the top flight, then again for most of the 1990s.",[]],
    ["György Demeter","Head coach · 2007–2011","Brought the first league title in 2008, then two more in 2010 and 2011.",[]],
    ["Daniel Castellani","Head coach · three spells","In charge in 2011–12, 2013–15 and 2021–23, including the 2012 title and the 2014 CEV Challenge Cup.",[]],
    ["Slobodan Kovač","Head coach · 2024–2026","Coached the team before Taner Atik took over in January 2026.",[]],
    ["Taner Atik","Head coach · 2026–","Appointed in January 2026.",[]],
    ["Matt Anderson","Outside hitter","US international in the 2026–27 squad.",[]],
    ["Mirza Lagumdžija","Outside hitter","Turkey international in the 2026–27 squad.",[]],
    ["Adis Lagumdžija","Opposite","Turkey international in the 2026–27 squad.",[]]],
  quiz:[
    {q:"In which season did the men win the CEV Challenge Cup?",o:["2009–10","2011–12","2013–14","2018–19"],a:2,e:"2013–14, beating Andreoli Latina in the final."},
    {q:"How many Turkish league titles have the men won?",o:["3","5","7","9"],a:1,e:"Five: 2008, 2010, 2011, 2012 and 2019."},
    {q:"Who coached the first league title in 2008?",o:["György Demeter","Daniel Castellani","İsmail Vuran","Veljko Basić"],a:0,e:"György Demeter, coach from 2007 to 2011."},
    {q:"In which year was today's men's team refounded?",o:["1927","1959","1976","1985"],a:2,e:"1976, starting in Istanbul's fourth division."},
    {q:"Who became head coach in January 2026?",o:["Taner Atik","Slobodan Kovač","Daniel Castellani","Veljko Basić"],a:0,e:"Taner Atik, who followed Slobodan Kovač."},
    {q:"How many Balkan Cups have the men won?",o:["1","2","3","4"],a:1,e:"Two, in 2009 and 2013."}]};

/* Squads and venues */
/* the 2025–26 title-winning squad stays for the Name the Squad game */
const WF_CHAMP=[["Goalkeepers",[[25,"Zeynep Akdeniz","Turkey"],[71,"Natalia Munteanu","Moldova"]]],
   ["Defenders",[[2,"Konya Plummer","Jamaica"],[5,"Yaşam Göksu","Turkey"],[14,"Ümran Özev","Turkey"],[17,"İpek Kaya","Turkey"]]],
   ["Midfielders",[[6,"Regina Otu","Nigeria"],[8,"Cansu Gürel","Turkey"],[9,"Busem Şeker","Turkey"],[10,"Ece Türkoğlu","Turkey"],[16,"Peritan Bozdağ","Azerbaijan"],[19,"Mesude Alayont","Turkey"],[20,"Marta Cox","Panama"],[23,"Fatoş Yıldırım","Turkey"],[29,"Mevlüde Okuyan","Turkey"]]],
   ["Forwards",[[11,"Yağmur Uraz","Turkey"],[13,"Zeynep Kerimoğlu","Turkey"],[22,"Flourish Sabastine","Nigeria"],[77,"Andrea Stašková","Czech Republic"],[93,"Maria Alves","Brazil"]]]];
SQUADS["womens-football"]={coach:"Gökhan Bozkaya",asof:"UEFA squad list for the 2026–27 Women's Europa Cup",
  groups:[["Goalkeepers",[[21,"Soledad Belotto","Paraguay"],[40,"İlayda Demir","Turkey"],[71,"Natalia Munteanu","Moldova"]]],
   ["Defenders",[[2,"Konya Plummer","Jamaica"],[5,"Yaşam Göksu","Turkey"],[8,"Cansu Gürel","Turkey"],[14,"Katie Bowen","New Zealand"],[17,"İpek Kaya","Turkey"],[19,"Mesude Alayont","Turkey"],[24,"Fatma Şakar","Turkey"],[33,"Esmanur Teke","Turkey"],[38,"Edanur Gökçe","Turkey"]]],
   ["Midfielders",[[6,"Regina Otu","Nigeria"],[9,"Busem Şeker","Turkey"],[10,"Ece Türkoğlu","Turkey"],[13,"Zeynep Kerimoğlu","Turkey"],[16,"Peritan Bozdağ","Azerbaijan"],[26,"Suliat Abideen","Nigeria"],[32,"İdil Nas Acar","Turkey"],[34,"Belinay Tuğla","Turkey"],[35,"Rabia Akbaba","Turkey"]]],
   ["Forwards",[[11,"Yağmur Uraz","Turkey"],[30,"Marie Ngah","Cameroon"],[55,"Zsanett Kaján","Hungary"],[77,"Andrea Stašková","Czech Republic"],[93,"Maria Alves","Brazil"]]]]};
SQUADS["mens-volleyball"]={coach:"Taner Atik",coachNote:"Head coach since January 2026.",asof:"Squad list as of June 2026",
  groups:[["Setters",[[14,"Fernando Kreling","Brazil"],[17,"Muhammed Kaya","Turkey"]]],
   ["Outside hitters",[[7,"Mirza Lagumdžija","Turkey"],[8,"Burutay Subaşı","Turkey"],[13,"Yiğit Gülmezoğlu","Turkey"],[22,"Matt Anderson","United States"]]],
   ["Opposites",[[1,"Kaan Gürbüz","Turkey"],[12,"Adis Lagumdžija","Turkey"]]],
   ["Middle blockers",[[2,"Barthélémy Chinenyeze","France"],[5,"Mert Matić","Turkey"],[10,"Bedirhan Bülbül","Turkey"]]],
   ["Liberos",[[11,"Beytullah Hatipoğlu","Turkey"],[21,"Caner Dengin","Turkey"]]]]};
VENUES["womens-football"]={name:"Lefter Küçükandonyadis Stadium",area:"Dereağzı, Kadıköy, Istanbul",cap:"",
  facts:["Part of the club's Dereağzı complex, named after Lefter Küçükandonyadis, the club's record goalscorer.","The women's team play most home league games here, including the 1–0 win over Galatasaray in November 2026.","Bigger games sometimes move to the Şükrü Saracoğlu Stadium: the December 2025 derby was played there."],
  travel:["Dereağzı is in Kadıköy, close to the Şükrü Saracoğlu Stadium and Söğütlüçeşme station."]};
VENUES["mens-volleyball"]={name:"Burhan Felek Sport Hall",area:"Üsküdar, Istanbul",cap:"7,000 seats",
  facts:["Opened on 19 November 2010.","Both Fenerbahçe volleyball teams play their league matches here."],travel:[]};
/* runs after buildI18n(): the women's volleyball page gets its own name and loses the men's cup */
function mergeNew(){const V=SPORTS.volleyball;V.label="Women's Volleyball";V.title="Women's Volleyball";V.tr="Kadın Voleybol";
  V.trophies=V.trophies.filter(x=>!/\(men\)/.test(x[1]));V.games=V.games.filter(g=>g.tag!=="Men");V.filters=["All","Women"]}

/* People for the games */
Object.assign(BPOS,{GK:"goalkeeper",DF:"defender",MF:"midfielder",FW:"forward"});
Object.assign(NAT2,{JAM:"Jamaica",MDA:"Moldova",NGR:"Nigeria",AZE:"Azerbaijan",PAN:"Panama",PAR:"Paraguay",NZL:"New Zealand",CMR:"Cameroon",HUN:"Hungary"});
const WF_POOL=[["Zeynep Akdeniz","GK","",70,"TUR","Akdeniz",""],["Natalia Munteanu","GK","",72,"MDA","Munteanu",""],["Konya Plummer","DF","",80,"JAM","Plummer",""],["Yaşam Göksu","DF","",74,"TUR","Göksu",""],["Ümran Özev","DF","",72,"TUR","Özev",""],["İpek Kaya","DF","",74,"TUR","Kaya",""],
 ["Regina Otu","MF","",76,"NGR","Otu",""],["Cansu Gürel","MF","",72,"TUR","Gürel",""],["Busem Şeker","MF","",76,"TUR","Şeker",""],["Ece Türkoğlu","MF","",80,"TUR","Türkoğlu",""],["Peritan Bozdağ","MF","",70,"AZE","Bozdağ",""],["Mesude Alayont","MF","",70,"TUR","Alayont",""],["Marta Cox","MF","",80,"PAN","Cox",""],["Fatoş Yıldırım","MF","",72,"TUR","Yıldırım",""],["Mevlüde Okuyan","MF","",70,"TUR","Okuyan",""],
 ["Yağmur Uraz","FW","",82,"TUR","Uraz",""],["Zeynep Kerimoğlu","FW","",72,"TUR","Kerimoğlu",""],["Flourish Sabastine","FW","",78,"NGR","Sabastine",""],["Andrea Stašková","FW","",84,"CZE","Stašková",""],["Maria Alves","FW","",78,"BRA","Alves",""],
 ["Soledad Belotto","GK","",72,"PAR","Belotto",""],["İlayda Demir","GK","",66,"TUR","Demir",""],["Katie Bowen","DF","",80,"NZL","Bowen",""],["Fatma Şakar","DF","",68,"TUR","Şakar",""],["Esmanur Teke","DF","",66,"TUR","Teke",""],["Edanur Gökçe","DF","",66,"TUR","Gökçe",""],
 ["Suliat Abideen","MF","",76,"NGR","Abideen",""],["İdil Nas Acar","MF","",66,"TUR","Acar",""],["Belinay Tuğla","MF","",66,"TUR","Tuğla",""],["Rabia Akbaba","MF","",66,"TUR","Akbaba",""],["Marie Ngah","FW","",76,"CMR","Ngah",""],["Zsanett Kaján","FW","",78,"HUN","Kaján",""]];
const MV_POOL=[["Fernando Kreling","S","",84,"BRA","Kreling",""],["Muhammed Kaya","S","",72,"TUR","Kaya",""],["Mirza Lagumdžija","OH","",82,"TUR","Mirza",""],["Burutay Subaşı","OH","",76,"TUR","Subaşı",""],["Yiğit Gülmezoğlu","OH","",74,"TUR","Gülmezoğlu",""],["Matt Anderson","OH","",86,"USA","Anderson",""],
 ["Kaan Gürbüz","OP","",76,"TUR","Gürbüz",""],["Adis Lagumdžija","OP","",84,"TUR","Adis",""],["Barthélémy Chinenyeze","MB","",84,"FRA","Chinenyeze",""],["Mert Matić","MB","",78,"TUR","Matić",""],["Bedirhan Bülbül","MB","",78,"TUR","Bülbül",""],["Beytullah Hatipoğlu","L","",74,"TUR","Hatipoğlu",""],["Caner Dengin","L","",72,"TUR","Dengin",""]];
const WF_SQUADS=[{id:"2026-27",label:"2026–27 squad",title:"Women's Europa Cup",note:"UEFA squad list",sq:SQUADS["womens-football"].groups.flatMap(([g,l])=>l.map(([n,name])=>[n,name,WF_POOL.find(p=>p[0]===name)[1]]))},
 {id:"2026",label:"2025–26 champions",title:"Women's Super League",note:"First league title, won with two rounds to spare",sq:WF_CHAMP.flatMap(([g,l])=>l.map(([n,name])=>[n,name,WF_POOL.find(p=>p[0]===name)[1]]))}];
const MV_SQUADS=[{id:"2026-27",label:"2026–27 squad",title:"Efeler Ligi",note:"Coach Taner Atik",sq:SQUADS["mens-volleyball"].groups.flatMap(([g,l])=>l.map(([n,name])=>[n,name,MV_POOL.find(p=>p[0]===name)[1]]))},
 {id:"ibb",label:"Line-up at İBB, October 2026",title:"Efeler Ligi",note:"Starting line-up and libero in the 3–1 win on 31 October 2026",sq:[[1,"Kaan Gürbüz","OP"],[5,"Mert Matić","MB"],[10,"Bedirhan Bülbül","MB"],[8,"Burutay Subaşı","OH"],[22,"Matt Anderson","OH"],[14,"Fernando Kreling","S"],[11,"Beytullah Hatipoğlu","L"]]}];
BPEOPLE["womens-football"]=buildPeople(toPeople(WF_POOL),null,WF_SQUADS);
BPEOPLE["mens-volleyball"]=buildPeople(toPeople(MV_POOL),null,MV_SQUADS);
Object.assign(SPECIAL_B,{"Ece Türkoğlu":"I scored the 89th-minute winner against Galatasaray in November 2026.","Andrea Stašková":"I was the leading scorer of the first title season.","Marta Cox":"I scored the penalty that beat Galatasaray in December 2025.","Konya Plummer":"I scored against OH Leuven in the Champions League qualifiers.","Yağmur Uraz":"I captained the first title-winning team.","Busem Şeker":"My goal against Minsk took the team into the last 16 of the Europa Cup."});
const WF_EVENTS=[[1995,"Fenerbahçe form a women's football team","Firsts"],[2021,"The women's football team is refounded","Firsts"],[2023,"A first Super League play-off final","Titles"],[2025,"Runners-up in the Super League","Titles"],[2026,"First Super League title","Titles"],[2026,"First Champions League campaign","Europe"],[2026,"Into the last 16 of the Women's Europa Cup","Europe"],[2023,"Gökhan Bozkaya becomes head coach","Coaches"],[2021,"Nihan Su becomes head coach","Coaches"]];
const MV_EVENTS=[[1927,"Fenerbahçe start a men's volleyball team","Firsts"],[1976,"The men's team is refounded","Firsts"],[1985,"Promotion to the national top flight","Firsts"],[2008,"First Turkish league title","Titles"],[2010,"Second Turkish league title","Titles"],[2011,"Third Turkish league title","Titles"],[2012,"Fourth Turkish league title","Titles"],[2019,"Fifth Turkish league title","Titles"],[2009,"Men win the Balkan Cup","Europe"],[2013,"Men win a second Balkan Cup","Europe"],[2014,"Men win the CEV Challenge Cup","Europe"],[2017,"Turkish Cup winners","Cups"],[2025,"Turkish Cup winners","Cups"],[2007,"György Demeter becomes head coach","Coaches"],[2011,"Daniel Castellani becomes head coach","Coaches"],[2024,"Slobodan Kovač becomes head coach","Coaches"],[2026,"Taner Atik becomes head coach","Coaches"],[1985,"İsmail Vuran becomes head coach","Coaches"]];

/* Game configs */
WCFG["womens-football"]={pool:()=>wPool(BPEOPLE["womens-football"]),hints:bHints,done:x=>x.pos?`, ${BPOS[x.pos]}`:""};
WCFG["mens-volleyball"]={pool:()=>wPool(BPEOPLE["mens-volleyball"]),hints:bHints,done:x=>x.pos?`, ${BPOS[x.pos]}`:""};
WHOCFG["womens-football"]=()=>bWho("womens-football");WHOCFG["mens-volleyball"]=()=>bWho("mens-volleyball");
LUCFG["womens-football"]={items:WF_SQUADS,kind:"vb",title:"Name the Squad",note:"Squads come from the club's squad lists and match reports."};
LUCFG["mens-volleyball"]={items:MV_SQUADS,kind:"vb",title:"Name the Squad",note:"Squads come from the club's squad lists and match reports."};
TLCFG["womens-football"]={title:"Timeline",intro:"Women's football from 1995 to today: titles, coaches and the first European nights.",deck:()=>branchDeck("womens-football",WF_EVENTS)};
TLCFG["mens-volleyball"]={title:"Timeline",intro:"Men's volleyball from 1927 to today: titles, cups, coaches and the 2014 European win.",deck:()=>branchDeck("mens-volleyball",MV_EVENTS)};
PLAY["womens-football"]=[["quiz","Quiz","Six questions"],XTRA[0],["wordle","Fenerdle","Guess the player"],["squad","Name the Squad","The first champions"],["who","Who Am I?","Ten mystery players"],["timeline","Timeline","1995 to today"],...XTRA.slice(1)];
PLAY["mens-volleyball"]=[["quiz","Quiz","Six questions"],XTRA[0],["wordle","Fenerdle","Guess the player"],["squad","Name the Squad","This season's team"],["who","Who Am I?","Ten mystery players"],["timeline","Timeline","1927 to today"],...XTRA.slice(1)];
BRS.push("womens-football","mens-volleyball");
HOL_BY["womens-football"]=()=>[{key:"goals",label:"goals Fenerbahçe scored in that game",items:LIVE["womens-football"].last.map(r=>[`${r[3]} (${r[2]==="H"?"home":r[2]==="A"?"away":"neutral"})`,+r[4]])},evYears(WF_EVENTS,"year it happened")];
HOL_BY["mens-volleyball"]=()=>[evYears(MV_EVENTS,"year it happened"),{key:"titles",label:"titles",items:[["Turkish league titles",5],["Turkish Cups",5],["Turkish Super Cups",4],["Balkan Cups",2],["CEV Challenge Cups",1]]}];
HOL_BY.volleyball=()=>[evYears(VB_EVENTS,"year it happened"),{key:"titles",label:"titles",items:[["Turkish league titles",15],["Turkish Cups",5],["CEV Champions League titles",1],["Club World titles",1],["CEV Cups",1]]}];

/* Player of the match: everyone in the branch, plus a free choice */
const MOTM_GONE=["Sevgi Uzun","Tilbe Şenyürek"];
function motmNames(b){const S=SQUADS[b],out=new Set();(S&&S.groups||[]).forEach(g=>g[1].forEach(x=>out.add(x[1])));
  if(b==="womens-basketball"){const L=WB_LINEUPS.find(x=>x.id==="2026F")||WB_LINEUPS[0];if(L){L.st.forEach(x=>out.add(x[1]));L.bench.forEach(x=>out.add(x[0]))}}
  if(b==="womens-football")out.add("Divine Manga");
  MOTM_GONE.forEach(n=>out.delete(n));return [...out].sort((a,c)=>a.localeCompare(c,"tr"))}

/* The banner at the top: the next match of the branch being viewed */
function nextFixture(b){const L=LIVE[b];if(!L)return null;const today=todayISO(),list=L.next.filter(n=>!n[0]||n[0]>=today);return list[0]?{b,n:list[0]}:null}
function renderNextBanner(){let hit=nextFixture(current),other=false;
  if(!hit){other=true;const all=Object.keys(LIVE).map(nextFixture).filter(x=>x&&x.n[0]).sort((a,c)=>(a.n[0]+a.n[1]).localeCompare(c.n[0]+c.n[1]));hit=all[0]||null}
  const box=$("otd");if(!hit){box.hidden=true;return}
  const n=hit.n,h=n[3]==="H",teams=h?`Fenerbahçe – ${n[4]}`:`${n[4]} – Fenerbahçe`,when=n[0]?`${mDate(n[0])}${n[1]?", "+n[1]:""}`:t(n[5]||"TBC");
  $("otdLabel").textContent=t("Next match");$("otdText").textContent=`${when}: ${teams} (${t(n[2])}${other?", "+t(SPORTS[hit.b].label):""})`;box.hidden=false}

/* Drafts for the two new branches: they play a season like the others */
TDCFG["womens-football"]={pool:toPeople(WF_POOL),court:"fb",slots:[["GK",50,88],["DF",13,67],["DF",37,72],["DF",63,72],["DF",87,67],["MF",24,46],["MF",50,50],["MF",76,46],["FW",17,22],["FW",50,16],["FW",83,22]],rounds:[],cup:"Season",unit:"eleven",sim:"fb"};
TDCFG["mens-volleyball"]={pool:toPeople(MV_POOL),court:"vb",slots:[["OH",18,26],["MB",50,26],["OP",82,26],["OH",18,64],["MB",50,64],["S",82,64],["L",50,88]],rounds:[],cup:"Season",unit:"six",sim:"vb"};
PLAY["womens-football"].splice(2,0,["draft11","XI Draft","Draft an XI, play a season"]);
PLAY["mens-volleyball"].splice(2,0,["draft6","Starting Six","Draft a six, play a season"]);

/* ===== Kanarya, the fan helper (asks Claude through the page's sample capability) ===== */
const KAN_SVG=`<svg viewBox="0 0 64 64" aria-hidden="true">
 <path d="M30 9c2-5 7-6 9-3-3 0-5 2-5 4 2-3 7-3 8 0-3-1-6 1-7 3z" fill="#f5b700"/>
 <ellipse cx="33" cy="36" rx="21" ry="20" fill="#ffd60a"/>
 <ellipse cx="35" cy="42" rx="12" ry="11" fill="#fff2a8"/>
 <path d="M14 34c3 10 11 15 18 13-7-3-11-8-12-16z" fill="#1b2f63"/>
 <path d="M15 37l9 4M16 41l8 3" stroke="#ffd60a" stroke-width="1.6" stroke-linecap="round"/>
 <circle cx="41" cy="28" r="4.2" fill="#0d1c3d"/><circle cx="42.5" cy="26.6" r="1.5" fill="#fff"/>
 <path d="M51 31l9 3-9 4z" fill="#ff9f1c"/>
 <path d="M22 52c6 4 16 4 22 0l-2 5c-6 3-13 3-18 0z" fill="#1b2f63"/><path d="M27 54.5h12" stroke="#ffd60a" stroke-width="1.6"/>
</svg>`;
const KAN={open:false,turns:[],busy:false,ctl:null,sample:null,off:false};
const KAN_CHIPS_TAB={home:["Which team plays next?","How did the teams do last time out?","Which branch has won the most?"],
 matches:["When is the next match?","How did the last match go?","What is our form like?"],standings:["Where are we in the table?","How far behind the leader are we?","Who are the closest rivals?"],
 squad:["Who is the captain?","Who is the coach?","Who are the new signings?"],games:["What was the biggest win?","Tell me about a famous final.","Which game still hurts?"],
 trophies:["How many titles does this branch have?","When was the last title?","Which trophy is the rarest?"],legends:["Who are the legends here?","Who is the greatest of all?","Tell me a fun fact about a legend."],
 history:["When did this branch start?","What was the greatest era?","Tell me something surprising."],derbies:["Who wins the derby more often?","What was the biggest derby win?","When is the next derby?"],
 venue:["How big is the stadium?","How do I get to the ground?","What is the atmosphere like?"],branches:["Which other sports does the club play?","Tell me about the rowing team.","What are the youngest branches?"],
 play:["How do the games here work?","How do I get badges?","Any tips for the draft?"]};
const KAN_CHIPS_SZ=["How is my season going?","Who is my top scorer?","How did the real team do that season?"];
function kanChips(){if(current!=="home"&&tab==="play"&&szS[current]&&szS[current].S)return KAN_CHIPS_SZ;return KAN_CHIPS_TAB[current==="home"?"home":tab]||KAN_CHIPS_TAB.matches}
const KAN_CHIPS=Object.values(KAN_CHIPS_TAB).flat().concat(KAN_CHIPS_SZ);
function kanContext(){if(current==="home")return `The fan is on the club home page, which shows every branch, so questions may be about any branch.`;
  const T=(tabsFor(current).find(x=>x[0]===tab)||[,tab])[1];let s=`The fan is looking at the "${SPORTS[current].label}" page, on the ${T} tab, so treat questions as being about that branch unless they say otherwise.`;
  if(tab==="play"){const g=(PLAY[current]||[]).find(x=>x[0]===playSel[current]);if(g)s+=` They have the "${g[1]}" game open.`;
    const z=szS[current]&&szS[current].S;if(z){const lg=z.C[0],tab2=lg.stage&&lg.stage.rows?szSort(lg.stage.rows):lg.lastTab||[],pos=tab2.findIndex(r=>r.me)+1;
      const res=z.log.slice(0,12).map(e=>`${e.comp} ${e.round?("round "+e.round):""} ${e.ha===1?"home":e.ha===-1?"away":"neutral"} vs ${e.opp}: ${e.g.s[0]}-${e.g.s[1]}`);
      const sc=Object.entries(z.scorers||{}).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([n,g])=>`${n} ${g}`);
      s+=`\nSIMULATED SEASON (made up by the site's season mode, not real): the fan's team "${z.my.n}" (rating ${z.my.r.toFixed(1)}) is playing ${z.season}. ${z.done?"The season is finished.":"The season is still running."} League position: ${pos||"not started"} of ${tab2.length}. Competitions: ${z.C.map(c=>`${c.name} (${c.status||"running"})`).join(", ")}. Latest results, newest first, your team's score first: ${res.join("; ")||"none yet"}. Top scorers: ${sc.join(", ")||"none"}. What the real Fenerbahçe did that season: ${z.D.real!=null?("finished "+z.D.real+" in the league"):"unknown"}. Talk about this as a simulation.`}}
  return s}
function kanBranch(id){const o=kanBranchRaw(id);runExt("kan",id,o);return o}
function kanBranchRaw(id){const S=SPORTS[id],L=LIVE[id],Q=SQUADS[id],V=VENUES[id];
  return {name:S.label,nickname:S.nick,intro:S.lede,stats:S.stats,home:S.home&&S.home[1],trophies:(S.trophies||[]).map(x=>x.slice(0,3)),
   legends:(S.legends||[]).map(l=>[l[0],l[1],l[2]].concat(l[3]||[])),history:(S.history||[]).map(h=>h.slice(0,3)),
   bigGames:(S.games||[]).map(g=>[g.date,g.comp,g.home,g.res||g.title,g.away,g.note]),otherBranches:S.branches,
   season:L?{season:L.season,summary:L.summary,results:L.last.slice(0,12),fixtures:L.next.slice(0,6),tables:L.tables.map(x=>({comp:x.comp,sub:x.sub,cols:x.cols,rows:x.rows,note:x.note}))}:undefined,
   squad:Q&&Q.groups?{coach:Q.coach,asOf:Q.asof,players:Q.groups.flatMap(g=>g[1].map(x=>`${x[1]}${x[0]!=null?" #"+x[0]:""} (${g[0]})`))}:Q?{note:Q.asof}:undefined,
   venue:V?`${V.name}, ${V.area}`:undefined}}
let KAN_DATA=null;
function kanRules(){const lang=LANGS.find(l=>l[0]===LANG)[1];if(!KAN_DATA){const all={};Object.keys(SPORTS).forEach(id=>all[id]=kanBranch(id));KAN_DATA=JSON.stringify(all)}
  return `You are Kanarya, a cheerful cartoon canary who helps fans on an unofficial Fenerbahçe fan website (not run by the club). Reply in ${lang}.
Keep answers short: one to four sentences, or a short list when asked for several things. Plain text only: no Markdown headings, tables or bold.
Base every fact on the SITE DATA below. Season data is as of ${ASOF}; today is ${todayISO()}. ${kanContext()}
If the data doesn't answer the question, say you don't know rather than guessing, and point to the official site fenerbahce.org. Never invent scores, dates, players or statistics. Be friendly about rivals.
You can also explain the site: the branch menu, the design and language menus, the All branches home page, the search button (players, seasons, finals, scores), player profiles (click a name), the "Real data" and "Estimate" labels, the tab groups (This season: Matches, Standings, Squad; Club: Big Games, Trophies, Legends, History, Derbies, Venue; and Play), the games on the Play tab including season mode, score predictions and player-of-the-match votes.
In the data, results rows are [date, competition, H/A/N, opponent, Fenerbahçe score, opponent score, note] (volleyball scores are sets) and fixture rows are [date, kick-off in Turkey time, competition, H/A, opponent, label].

SITE DATA (JSON):
${KAN_DATA}`}
function kanEl(tag,cls,txt){const e=document.createElement(tag);if(cls)e.className=cls;if(txt!=null)e.textContent=txt;return e}
function initHelper(){
  const root=kanEl("div","kan");root.id="kan";root.hidden=true;root.setAttribute("translate","no");
  root.innerHTML=`<section class="kanpanel" id="kanPanel" role="dialog" aria-modal="false" hidden>
    <header class="kanhead"><span class="kanav">${KAN_SVG}</span><div><b>Kanarya</b><span id="kanSub"></span></div><button class="kanx" id="kanClose" type="button">✕</button></header>
    <div class="kanlog" id="kanLog" aria-live="polite"></div>
    <div class="kanchips" id="kanChips"></div>
    <form class="kanform" id="kanForm" autocomplete="off"><input id="kanIn" maxlength="400"><button class="btn" id="kanSend"></button><button class="btn ghost" id="kanStop" type="button" hidden></button></form>
    <p class="kanfine" id="kanFine"></p></section>
   <button class="kanbtn" id="kanBtn" type="button" aria-expanded="false" aria-controls="kanPanel">${KAN_SVG}</button>`;
  document.body.appendChild(root);
  const btn=$("kanBtn"),panel=$("kanPanel");
  btn.onclick=()=>kanToggle(!KAN.open);$("kanClose").onclick=()=>kanToggle(false);
  document.addEventListener("keydown",e=>{if(e.key==="Escape"&&KAN.open){kanToggle(false);btn.focus()}});
  $("kanForm").onsubmit=e=>{e.preventDefault();kanAsk($("kanIn").value)};
  $("kanStop").onclick=()=>{if(KAN.ctl)KAN.ctl.abort()};
  helperTexts();
  /* only show the helper where the page can actually ask Claude */
  if(window.claude&&typeof window.claude.use==="function")window.claude.use("sample").then(s=>{if(s){KAN.sample=s;root.hidden=false}}).catch(()=>{})}
function helperTexts(){if(!$("kanBtn"))return;$("kanBtn").setAttribute("aria-label",t("Ask Kanarya"));$("kanBtn").title=t("Ask Kanarya");$("kanPanel").setAttribute("aria-label",t("Ask Kanarya"));
  $("kanSub").textContent=t("Fan helper");$("kanClose").setAttribute("aria-label",t("Close"));$("kanIn").placeholder=t("Ask a question…");$("kanIn").setAttribute("aria-label",t("Your question"));
  $("kanSend").textContent=t("Send");$("kanStop").textContent=t("Stop");$("kanFine").textContent=t("Answers come from Claude and use your own Claude usage. They can be wrong.");kanRender()}
function kanToggle(v){KAN.open=v;$("kanPanel").hidden=!v;$("kanBtn").setAttribute("aria-expanded",String(v));$("kan").classList.toggle("open",v);if(v){kanRender();setTimeout(()=>$("kanIn").focus(),30)}}
function kanRender(){const log=$("kanLog");if(!log||!KAN.open)return;log.innerHTML="";
  log.appendChild(kanEl("p","kmsg bot",t("Hi! I'm Kanarya. Ask me anything about Fenerbahçe: matches, titles, legends or how this site works.")));
  KAN.turns.forEach(m=>log.appendChild(kanEl("p","kmsg "+(m.role==="user"?"me":"bot")+(m.err?" err":""),m.content)));
  if(KAN.busy&&KAN.live==null)log.appendChild(kanEl("p","kmsg bot wait",t("Thinking…")));
  if(KAN.busy&&KAN.live!=null){const b=kanEl("p","kmsg bot",KAN.live);b.id="kanLive";log.appendChild(b)}
  const ch=$("kanChips");ch.innerHTML="";if(!KAN.busy&&!KAN.off)kanChips().slice(0,KAN.turns.length?2:3).forEach(c=>{const b=kanEl("button","kchip",t(c));b.type="button";b.onclick=()=>kanAsk(t(c));ch.appendChild(b)});
  $("kanSend").hidden=KAN.busy;$("kanStop").hidden=!KAN.busy;$("kanIn").disabled=KAN.busy||KAN.off;requestAnimationFrame(()=>{log.scrollTop=log.scrollHeight})}
async function kanAsk(q){q=(q||"").trim();if(!q||KAN.busy||!KAN.sample||KAN.off)return;$("kanIn").value="";
  KAN.turns.push({role:"user",content:q});KAN.busy=true;KAN.live=null;kanRender();
  const ctl=new AbortController();KAN.ctl=ctl;
  const hist=KAN.turns.filter(m=>!m.err).slice(-10);while(hist.length&&hist[0].role!=="user")hist.shift();
  try{const {text}=await KAN.sample([{role:"user",content:kanRules()},...hist.map(m=>({role:m.role,content:m.content}))],{modelTier:"quick",cache:false,signal:ctl.signal,
      onText:({text})=>{KAN.live=text;const el=$("kanLive");if(el){el.textContent=text;$("kanLog").scrollTop=$("kanLog").scrollHeight}else kanRender()}});
    KAN.turns.push({role:"assistant",content:text})}
  catch(e){const code=e&&e.code;if(e&&e.text&&code!=="refused")KAN.turns.push({role:"assistant",content:e.text});
    if(code!=="cancelled"){let msg="Something went wrong. Try again.";
      if(["not_granted","sampling_disabled","not_declared","capability_disabled","capability_removed"].includes(code)){msg="The helper can't answer in this view.";KAN.off=true}
      else if(code==="rate_limited")msg="Too many questions right now. Try again in a little while.";
      else if(code==="session_expired")msg="Please sign in to Claude again.";
      KAN.turns.push({role:"assistant",content:t(msg),err:true})}}
  finally{KAN.busy=false;KAN.live=null;KAN.ctl=null;kanRender();if(!KAN.off)$("kanIn").focus()}}

/* ===== Season data for Season mode, 2000–01 onwards =====
   lg: league rivals [name, strength]; cup: domestic cup; sup: Super Cup opponent; eu: European entry stage; real: what the real team did.
   European entry points for football follow the club's actual route; other branches use the usual qualification rules.
   Rival line-ups and strengths are estimates made for this game. */
const SZ_POOLS={
 football:[["Galatasaray",83],["Beşiktaş",81],["Trabzonspor",80],["Başakşehir",78,2007],["Bursaspor",77,2006,2018],["Kayserispor",75,2004],["Sivasspor",75,2005],["Konyaspor",74,2003],["Antalyaspor",73],["Kasımpaşa",73,2007],["Gaziantepspor",74,2000,2016],["Gaziantep FK",72,2019],["Gençlerbirliği",74,2000,2018],["Ankaragücü",72,2000,2011],["Denizlispor",72,2000,2009],["Samsunspor",73],["Rizespor",72,2008],["Malatyaspor",72,2000,2005],["Yeni Malatyaspor",72,2017,2021],["Kocaelispor",72,2000,2008],["Göztepe",74,2017],["Alanyaspor",75,2016],["Eskişehirspor",74,2008,2015],["Manisaspor",71,2005,2012],["Sakaryaspor",71,2000,2006],["İstanbulspor",71,2000,2004],["Eyüpspor",73,2024],["Hatayspor",72,2020,2024],["Adana Demirspor",75,2021,2024],["Karagümrük",73,2020,2025],["Akhisarspor",72,2012,2018],["Mersin İdmanyurdu",71,2011,2015],["Diyarbakırspor",70,2000,2009],["Kocaelispor 2025",72,2025]],
 basketball:[["Anadolu Efes",86],["Galatasaray",80],["Beşiktaş",79],["Türk Telekom",76],["Darüşşafaka",77,2014],["Karşıyaka",78],["Tofaş",77],["Bahçeşehir Koleji",79,2018],["Bursaspor",75,2014],["Manisa",75,2021],["Aliağa Petkimspor",75,2014],["Büyükçekmece",73,2015,2022],["Trabzonspor",74,2011,2018],["Mersin",73,2009],["Merkezefendi",73,2019],["Banvit",76,2005,2018],["Bandırma",74,2019],["Gaziantep",73,2013,2022],["Ülker",80,2000,2005],["Erdemir",72,2000,2014],["Oyak Renault",72,2000,2010],["Tüyap",72,2000,2008],["Esenler",73,2025],["Antalya",72,2000,2013],["Kepez",70,2006,2012]],
 "womens-basketball":[["Galatasaray",83],["ÇBK Mersin",83,2018],["Beşiktaş",78],["Botaş",74],["Hatay BB",77,2011,2020],["Bellona Kayseri",75,2008],["Nesibe Aydın",75,2016],["Emlak Konut",75,2018],["İzmit Belediyespor",72,2017,2023],["Mersin BB",74,2008,2017],["Abdullah Gül Üniversitesi",73,2016],["Ormanspor",70,2012,2018],["Kayseri Kaski",74,2010,2016],["Tarsus",70,2014,2018],["Edremit",70,2023],["Danilos Pizza",71,2023],["Migrosspor",72,2000,2008],["Ceyhan",71,2000,2010],["İstanbul Üniversitesi",72,2000,2012],["Burhaniye",70,2005,2014],["Melikgazi",72,2023],["Bursa",71,2020]],
 volleyball:[["VakıfBank",88],["Eczacıbaşı",87],["Galatasaray",80],["Türk Hava Yolları",81,2014],["Beşiktaş",75],["Nilüfer",76],["Aras Kargo",76,2018],["Kuzeyboru",74,2021],["Zeren Spor",73,2022],["İlbank",73],["Karayolları",72],["Bursa BBSK",74,2009,2021],["Manisa BB",74,2018],["Göztepe",74,2022],["Sarıyer",74,2015,2020],["Yeşilyurt",74,2009,2018],["Çanakkale",72,2016,2020],["Seramiksan",70,2015,2018],["PTT",73,2014,2021],["İdmanocağı",71,2009,2014],["Afyon",72,2023],["Türk Telekom",74,2000,2013],["Karşıyaka",72,2005,2015],["Erdemir",72,2000,2011]],
 "mens-volleyball":[["Halkbank",82],["Ziraat Bankkart",82,2012],["Arkas Spor",78],["Galatasaray",78],["İstanbul BBSK",74,2006],["Afyon",74,2018],["Maliye Milli Piyango",75,2006],["Spor Toto",75],["Alanya Belediyespor",76,2016],["Cizre",74,2020,2025],["Gebze Belediyespor",76,2021],["Altekma",74,2018],["Sorgun",72,2016,2021],["Akkuş",72,2015,2023],["Bursa BBSK",74,2013,2019],["Erdemir",73,2000,2014],["Tokat",72,2010,2019],["Jeopark Kula",72,2014,2019],["İnegöl",72,2014,2019],["Sungurlu",71,2023],["Sultanbeyli",70,2024],["Gaziantep Gençlik",72,2024],["Netaş",72,2000,2010],["Emlak Toki",71,2000,2012],["Ankara PTT",71,2000,2012]],
 "womens-football":[["Galatasaray",79],["Beşiktaş",76],["Ankara BB Fomget",78],["Trabzonspor",74],["Hakkarigücü",72],["Yüksekova",72,2023],["Kayseri",69],["Sultanbeyli Gücü",70,2024],["Amed",74],["Ünye",70],["Antalyaspor",70,2023],["Haymana",70,2024],["Bakırköy",68],["Şile Bilgidoğa",64,2025],["Giresun Sanayispor",62,2025],["ALG Spor",77,2021,2022],["Beylerbeyi",70,2021,2023],["Konak Belediyespor",72,2021,2022],["Kireçburnu",68,2021,2023],["Fatih Vatan",70,2021,2023],["Dudullu",68,2021,2023],["Altay",68,2021,2022]]};
const SZ_SIZE={football:17,basketball:15,"womens-basketball":13,volleyball:13,"mens-volleyball":13,"womens-football":15};
const SZ_FIRST={football:2000,basketball:2000,"womens-basketball":2000,volleyball:2000,"mens-volleyball":2000,"womens-football":2021};
/* titles by the calendar year the season ended */
const SZ_HIST={
 basketball:{t:[2007,2008,2010,2011,2014,2016,2017,2018,2022,2024,2025,2026],c:[2010,2011,2013,2016,2019,2020,2024,2025,2026]},
 "womens-basketball":{t:[1999,2002,2004,2006,2007,2008,2009,2010,2011,2012,2013,2016,2018,2019,2021,2022,2023,2024,2025,2026],c:[2000,2001,2004,2005,2006,2007,2008,2009,2015,2016,2019,2020,2024,2026]},
 volleyball:{t:[2009,2010,2011,2015,2017,2023,2024],c:[2010,2015,2017,2024,2025]},
 "mens-volleyball":{t:[2008,2010,2011,2012,2019],c:[2008,2012,2017,2019,2025],p2:[2004,2006,2009,2014,2021,2024],p3:[2007,2017,2022,2023,2025]},
 "womens-football":{t:[2026],p2:[2023,2025],p3:[2024]}};
/* football: the club's real European route and Super Cups */
const SZ_EU_FB={2001:"CL-Q3",2002:"CL-Q3",2004:"CL-G",2005:"CL-G",2006:"CL-Q2",2007:"CL-Q3",2008:"CL-Q2",2009:"EL-Q3",2010:"CL-Q3",2012:"CL-Q3",2013:"CL-Q3",2015:"CL-Q3",2016:"CL-Q3",2017:"EL-Q3",2018:"CL-Q3",2021:"EL-PO",2022:"CL-Q2",2023:"ECL-Q2",2024:"CL-Q2",2025:"CL-Q3",2026:"CL-Q2"};
const SZ_GROUPS_FB={2001:["Barcelona","Bayer Leverkusen","Lyon"],2004:["Manchester United","Lyon","Sparta Prague"],2007:["Inter","PSV","CSKA Moscow"]};
const SZ_SUP_FB={2007:"Beşiktaş",2009:"Beşiktaş",2012:"Galatasaray",2013:"Galatasaray",2014:"Galatasaray",2023:"Galatasaray",2025:"Galatasaray"};
function szRng(seed){let a=seed>>>0;return ()=>{a=(a+0x6D2B79F5)>>>0;let t=Math.imul(a^(a>>>15),1|a);t=(t+Math.imul(t^(t>>>7),61|t))^t;return ((t^(t>>>14))>>>0)/4294967296}}
function szRivals(b,y){const P=SZ_POOLS[b].filter(x=>(x[2]==null||y>=x[2])&&(x[3]==null||y<=x[3])).map(x=>[x[0].replace(/ 2025$/,""),x[1]]),seen=new Set(),U=P.filter(x=>!seen.has(x[0])&&seen.add(x[0]));
  const big=U.slice(0,b==="football"?3:2),rest=U.slice(big.length),r=szRng(y*31+b.length*7);rest.sort(()=>r()-.5);
  return big.concat(rest.slice(0,SZ_SIZE[b]-big.length)).sort((a,c)=>c[1]-a[1])}
const SZ_DATA=(()=>{const D={};Object.keys(SZ_POOLS).forEach(b=>{D[b]={};for(let y=SZ_FIRST[b];y<=2026;y++){const key=`${y}-${String(y+1).slice(2)}`,H=SZ_HIST[b]||{},prevT=(H.t||[]).includes(y),prevC=(H.c||[]).includes(y);
  const d={lg:szRivals(b,y),cup:b!=="womens-football"};
  if(b==="football"){if(SZ_EU_FB[y])d.eu={e:SZ_EU_FB[y],g:SZ_GROUPS_FB[y]||[]};if(SZ_SUP_FB[y])d.sup=SZ_SUP_FB[y];const fp=SEASON_POS.find(x=>x[0]===seaKey(y));if(fp)d.real=fp[1]}
  else{const top=d.lg[0][0];if((prevT||prevC)&&b!=="womens-football")d.sup=top;
    if(b==="basketball")d.eu={e:y>=2006?"EL-RS":"EC-RS"};
    else if(b==="womens-basketball")d.eu={e:"EL-RS"};
    else if(b==="volleyball")d.eu={e:y>=2008?"CL-G":"CC-R16"};
    else if(b==="mens-volleyball")d.eu={e:prevT?"CL-G":(H.p2.includes(y)||H.p3.includes(y))?"CC-R16":"CH-R32"};
    else if(b==="womens-football"&&prevT)d.eu={e:"WCL-Q1"};
    d.real=(H.t||[]).includes(y+1)?1:(H.p2||[]).includes(y+1)?2:(H.p3||[]).includes(y+1)?3:null}
  D[b][key]=d}});return D})();
function seaKey(y){return y===1999?"1999–2000":`${y}–${String(y+1).slice(2)}`}

/* ===== Season mode: take a drafted team through a real Fenerbahçe season ===== */
const SZ_KIND={football:"fb",basketball:"bb","womens-basketball":"wb",volleyball:"vb","mens-volleyball":"vb","womens-football":"fb"};
const SZ_LN={football:"Süper Lig",basketball:"BSL","womens-basketball":"KBSL",volleyball:"Sultanlar Ligi","mens-volleyball":"Efeler Ligi","womens-football":"Women's Super League"};
const szDash=s=>s.replace("-","–");
const szS={};
function poisson(l){const L=Math.exp(-l);let k=0,p=1;do{k++;p*=Math.random()}while(p>L);return k-1}

/* --- single games: ha = 1 home, -1 away, 0 neutral --- */
function szGame(kind,r1,r2,ha){
  if(kind==="fb"){const h=ha*.13,l1=1.32*Math.exp(.08*(r1-r2)+h),l2=1.32*Math.exp(.08*(r2-r1)-h);return {s:[poisson(l1),poisson(l2)]}}
  if(kind==="vb"){const q=clamp(.5+(r1-r2)*.0065+ha*.008,.4,.6),w=[0,0],sets=[];
    while(w[0]<3&&w[1]<3){const tg=w[0]+w[1]===4?15:25;let a=0,c=0;while(!((a>=tg||c>=tg)&&Math.abs(a-c)>=2)){if(Math.random()<q)a++;else c++}sets.push([a,c]);w[a>c?0:1]++}
    return {s:w,sets}}
  const base=kind==="wb"?74:80,m=(r1-r2)*1.5+ha*3;let a=Math.round(base+m/2+gauss()*8),b=Math.round(base-m/2+gauss()*8),ot=0;
  while(a===b){a+=Math.max(2,Math.round(6+gauss()*3+m*.1));b+=Math.max(2,Math.round(6+gauss()*3-m*.1));ot++}
  return {s:[a,b],ot}}
const szWin=g=>g.s[0]>g.s[1]?0:g.s[1]>g.s[0]?1:-1;
/* football knock-out decider after a level score: extra time, then penalties */
function szDecide(kind,g,r1,r2){if(kind!=="fb"||szWin(g)>=0&&!g.forceDecide)return g;
  if(Math.random()<.35){const t=Math.random()<clamp(.5+(r1-r2)*.03,.2,.8)?0:1;g.s[t]++;g.aet=true;return g}
  g.pens=Math.random()<clamp(.5+(r1-r2)*.012,.35,.65)?[5,4]:[4,5];if(Math.random()<.3)g.pens=g.pens[0]>g.pens[1]?[4,3]:[3,4];return g}
const szGW=g=>g.pens?(g.pens[0]>g.pens[1]?0:1):szWin(g);

/* --- table helpers --- */
function szRow(n,r,me){return {n,r,me:!!me,p:0,w:0,d:0,l:0,f:0,a:0,pts:0}}
function szApply(kind,A,B,g){A.p++;B.p++;A.f+=g.s[0];A.a+=g.s[1];B.f+=g.s[1];B.a+=g.s[0];const w=szWin(g);
  if(kind==="fb"){if(w===0){A.w++;B.l++;A.pts+=3}else if(w===1){B.w++;A.l++;B.pts+=3}else{A.d++;B.d++;A.pts++;B.pts++}}
  else if(kind==="vb"){const [x,y]=g.s;if(w===0){A.w++;B.l++;A.pts+=y===2?2:3;B.pts+=y===2?1:0}else{B.w++;A.l++;B.pts+=x===2?2:3;A.pts+=x===2?1:0}}
  else{if(w===0){A.w++;B.l++;A.pts+=2;B.pts+=1}else{B.w++;A.l++;B.pts+=2;A.pts+=1}}}
const szSort=rows=>rows.slice().sort((a,b)=>b.pts-a.pts||(b.f-b.a)-(a.f-a.a)||b.f-a.f||b.r-a.r);
/* circle method: list of rounds, each a list of [i,j] (i at home) */
function szRounds(n,legs){const ids=[...Array(n).keys()];if(n%2)ids.push(-1);const m=ids.length,R=[];let arr=ids.slice();
  for(let r=0;r<m-1;r++){const pr=[];for(let i=0;i<m/2;i++){const a=arr[i],b=arr[m-1-i];if(a>=0&&b>=0)pr.push(r%2?[b,a]:[a,b])}R.push(pr);arr=[arr[0],arr[m-1],...arr.slice(1,m-1)]}
  return legs===2?R.concat(R.map(pr=>pr.map(([a,b])=>[b,a]))):R}
function szDates(a,b,n){return Array.from({length:n},(_,i)=>n===1?a:a+(b-a)*i/(n-1))}

/* --- stage builders --- */
/* round robin: teams[0] is you */
function stRR(name,teams,legs,from,to,next){const R=szRounds(teams.length,legs).filter(pr=>pr.some(p=>p.includes(0)));return {t:"rr",name,rows:teams.map(x=>szRow(x.n,x.r,x.me)),R,ri:0,dates:szDates(from,to,R.length),next}}
/* league phase: you + 35 others, n games each */
function stLP(name,pool,n,from,to,next,size){const opp=shuffle(pool).slice(0,n),others=shuffle(pool.filter(x=>!opp.includes(x))).slice(0,(size||36)-1-n),all=[{n:"__me"},...opp,...others];
  return {t:"lp",name,rows:all.map((x,i)=>szRow(i?x[0]:"",i?x[1]:0,!i)),opp:opp.map((x,i)=>({o:i+1,ha:i%2?-1:1})),ri:0,dates:szDates(from,to,n),next}}
/* knock-out tie: fmt "1" | "1N" (neutral) | "2L" | "bo3" | "bo5" | "bo7" */
function stKO(name,fmt,pick,dates,next){return {t:"ko",name,fmt,pick,dates,games:[],next}}

/* --- opponent pools (club ratings are game estimates) --- */
const EU_FB=[["Real Madrid",91],["Barcelona",90],["Bayern Munich",90],["Manchester City",89],["Liverpool",88],["Paris Saint-Germain",88],["Chelsea",87],["Manchester United",87],["Juventus",87],["Inter",87],["AC Milan",86],["Arsenal",86],["Atlético Madrid",86],["Borussia Dortmund",85],["Napoli",84],["Tottenham",84],["Bayer Leverkusen",84],["Porto",83],["Benfica",83],["RB Leipzig",83],["Ajax",82],["Lyon",82],["Valencia",82],["Roma",82],["Sevilla",82],["Villarreal",81],["Lazio",81],["Sporting CP",81],["Zenit",81],["Shakhtar Donetsk",81],["PSV",81],["Marseille",80],["Monaco",80],["Atalanta",82],["Fiorentina",80],["Real Sociedad",80],["Lille",80],["Feyenoord",79],["Celtic",78],["Club Brugge",79],["Olympiacos",78],["Dynamo Kyiv",78],["Red Bull Salzburg",79],["Braga",78],["Eintracht Frankfurt",80],["West Ham",79],["Rangers",77],["Anderlecht",77],["Basel",77],["Galatasaray",80],["Dinamo Zagreb",76],["Red Star Belgrade",76],["Slavia Prague",76],["PAOK",76],["Young Boys",76],["Copenhagen",76],["AZ",77],["Gent",75],["Partizan",74],["Ferencváros",74],["Viktoria Plzeň",75],["Maccabi Tel Aviv",74],["Ludogorets",74],["Legia Warsaw",73],["Bodø/Glimt",76],["Midtjylland",75],["Molde",73],["Sheriff Tiraspol",72],["Slovan Bratislava",72],["Malmö",74],["Qarabağ",74],["Rapid Wien",74],["Sparta Prague",75],["Steaua Bucharest",74],["CSKA Moscow",78],["Spartak Moscow",78],["Lokomotiv Moscow",77],["Rennes",79],["Nice",78],["Hertha Berlin",77],["Werder Bremen",79],["Schalke",80],["Wolfsburg",79],["Stuttgart",79],["Hamburg",78],["Deportivo La Coruña",82],["Parma",80],["Leeds United",80],["Aston Villa",80],["Newcastle United",79],["Everton",78],["Twente",76],["Heerenveen",74],["Standard Liège",75],["Sion",72],["Aris",72],["AEK Athens",75],["Panathinaikos",76],["APOEL",73],["Maccabi Haifa",73],["Hapoel Tel Aviv",72],["Unirea Urziceni",71],["Dnipro",76],["Metalist Kharkiv",76],["Vitesse",74],["Mlada Boleslav",71],["Elfsborg",71],["Austria Wien",72],["Sturm Graz",73],["LASK",73]];
const EU_BB=[["Real Madrid",88],["CSKA Moscow",88],["Olympiacos",87],["Panathinaikos",87],["Barcelona",87],["Anadolu Efes",86],["Maccabi Tel Aviv",84],["Žalgiris Kaunas",83],["Virtus Bologna",83],["Olimpia Milano",84],["Baskonia",84],["Monaco",86],["Partizan",84],["Crvena zvezda",83],["Bayern Munich",83],["Valencia Basket",82],["Unicaja",82],["ALBA Berlin",80],["Paris Basketball",82],["Khimki",81],["Lokomotiv Kuban",81],["UNICS Kazan",81],["Montepaschi Siena",84],["Lietuvos rytas",80],["Cibona",79],["Real Betis",76],["Fenerbahçe B",80],["ASVEL",79],["Brose Bamberg",80],["Galatasaray",80],["Darüşşafaka",79],["Gran Canaria",80],["Budućnost",78],["Hapoel Jerusalem",79],["Lyon-Villeurbanne",79],["Pau-Orthez",77],["Prokom Trefl Sopot",77],["Union Olimpija",77],["Benetton Treviso",82],["Kinder Bologna",84],["Tau Cerámica",84],["Joventut",80],["Dynamo Moscow",79],["Le Mans",77]].filter(x=>x[0]!=="Fenerbahçe B");
const EU_WB=[["Ekaterinburg",89],["Spartak Moscow Region",88],["USK Prague",86],["Perfumerías Avenida",85],["Sopron",82],["Schio",84],["Bourges",84],["Villeneuve d'Ascq",83],["Galatasaray",84],["ÇBK Mersin",84],["Girona",82],["Lyon ASVEL Féminin",83],["Basket Landes",81],["Dynamo Kursk",86],["Sparta&K",84],["Wisła Kraków",79],["Polkowice",79],["Gdynia",80],["Valencia Basket",82],["Rivas Ecópolis",80],["Nadezhda Orenburg",82],["Beşiktaş",79],["Venezia",82],["Montpellier",80],["Salamanca",84],["Zaragoza",79],["Zabiny Brno",76],["Kayseri",76]];
const EU_VB=[["VakıfBank",89],["Imoco Conegliano",90],["Eczacıbaşı",88],["Vero Volley Milano",87],["Dinamo Kazan",87],["Rabita Baku",85],["Novara",86],["Scandicci",85],["Dinamo Moscow",85],["Chemik Police",83],["LKS Łódź",80],["Galatasaray",83],["THY",82],["Pesaro",83],["Bergamo",84],["RC Cannes",83],["Volero Zürich",83],["Uralochka",82],["Developres Rzeszów",82],["Mulhouse",78],["Béziers",76],["Dresdner SC",77],["Schwerin",78],["Maritza Plovdiv",72],["Hylo Volley Lódź",76],["Calcit Kamnik",72],["Olympiacos",74],["Budowlani Łódź",76],["Allianz Stuttgart",80],["Zeren Spor",78],["Aydın",78],["Nilüfer",76]];
const EU_MV=[["Zenit Kazan",91],["Perugia",90],["Trentino",90],["Lube Civitanova",89],["Jastrzębski Węgiel",88],["ZAKSA Kędzierzyn-Koźle",88],["Asseco Resovia",86],["Modena",86],["Halkbank",84],["Ziraat Bankkart",84],["Dynamo Moscow",85],["Kuzbass Kemerovo",84],["Berlin Recycling Volleys",82],["Piacenza",84],["Friedrichshafen",80],["Tours",80],["Chaumont",78],["ACH Volley Ljubljana",79],["Olympiacos",78],["Knack Roeselare",79],["Arkas Spor",80],["Fakel Novy Urengoy",82],["Lokomotiv Novosibirsk",83],["Bełchatów",83],["Latina",80],["Panathinaikos",76],["Budvanska Rivijera",73],["Dukla Liberec",74],["Toulouse",76],["Mladost Zagreb",72],["Hypo Tirol",75],["Vojvodina",72],["Aalst",74],["Lycurgus Groningen",73],["Benfica",77],["Sporting CP",76],["Ravenna",77],["Montpellier",77],["Prague",71],["Maribor",72]];
const EU_WF=[["Barcelona",92],["Lyon",91],["Chelsea",90],["Arsenal",89],["Wolfsburg",87],["Bayern Munich",87],["Manchester City",87],["Paris Saint-Germain",86],["Real Madrid",85],["Juventus",82],["Atlético Madrid",80],["Roma",81],["Benfica",80],["Hammarby",77],["Twente",78],["Häcken",76],["Brann",76],["Real Sociedad",76],["Ajax",76],["Slavia Prague",76],["Sparta Prague",74],["St. Pölten",74],["OH Leuven",74],["Rosengård",74],["Glasgow City",70],["Anderlecht",70],["Breiðablik",70],["Vllaznia",64],["Minsk",66],["Apollon Ladies",64],["Mura",62],["Racing Union",62],["Ferencváros",66],["Sporting CP",72],["Celtic",70],["Valur",68]];
const szPoolEU=b=>b==="football"?EU_FB:b==="basketball"?EU_BB:b==="womens-basketball"?EU_WB:b==="mens-volleyball"?EU_MV:b==="womens-football"?EU_WF:EU_VB;
function szPickEU(b,lo,hi,used){const P=szPoolEU(b).filter(x=>x[1]>=lo&&x[1]<=hi&&!used.has(x[0]));const L=P.length?P:szPoolEU(b).filter(x=>!used.has(x[0]));const x=L[Math.floor(Math.random()*L.length)];used.add(x[0]);return {n:x[0],r:x[1]}}
function szFind(b,name,def){const x=szPoolEU(b).find(y=>y[0]===name);return {n:name,r:x?x[1]:def}}

/* --- Europe formats (football) ---
   each returns a map of stage keys -> builders; the entry key comes from the season data */
function szEuroFB(S,season,eu){const y=+season.slice(0,4),used=new Set(eu.g||[]),real=eu.g||[],ko=(name,lo,hi,dates,next)=>stKO(name,"2L",()=>szPickEU("football",lo,hi,used),dates,next);
  const grp=(comp,name,pots,from,to,next)=>()=>{const opps=real.length===3?real.map((n,i)=>szFind("football",n,[84,80,76][i])):pots.map(([lo,hi])=>szPickEU("football",lo,hi,used));
    return stRR(name,[{n:"__me",me:true},...opps],2,from,to,next)};
  const UC=y<=2003?{"UC-Q2":()=>ko("UEFA Cup · Second qualifying round",70,77,[-.1,-.07],{w:"UC-R1"}),"UC-R1":()=>ko("UEFA Cup · First round",72,80,[.08,.12],{w:"UC-R2"}),"UC-R2":()=>ko("UEFA Cup · Second round",74,81,[.2,.24],{w:"UC-R3"}),"UC-R3":()=>ko("UEFA Cup · Third round",76,83,[.38,.42],{w:"UC-R4"}),"UC-R4":()=>ko("UEFA Cup · Fourth round",77,84,[.55,.58],{w:"UC-QF"}),"UC-QF":()=>ko("UEFA Cup · Quarter-final",78,85,[.7,.73],{w:"UC-SF"}),"UC-SF":()=>ko("UEFA Cup · Semi-final",79,86,[.82,.85],{w:"UC-F"}),"UC-F":()=>stKO("UEFA Cup · Final","1N",()=>szPickEU("football",80,87,used),[.995],{w:"WIN"}),"UC-R32":()=>ko("UEFA Cup · Third round",76,83,[.38,.42],{w:"UC-R4"})}
   :{"UC-Q2":()=>ko("UEFA Cup · Second qualifying round",70,77,[-.1,-.07],{w:"UC-R1"}),"UC-R1":()=>ko("UEFA Cup · First round",72,80,[.06,.1],{w:"UC-G"}),"UC-G":()=>{const opps=[[80,86],[77,82],[74,79],[71,76]].map(([lo,hi])=>szPickEU("football",lo,hi,used));return {...stRR("UEFA Cup · Group stage",[{n:"__me",me:true},...opps],1,.2,.4),next:{pos:{1:"UC-R32",2:"UC-R32",3:"UC-R32"}}}},
    "UC-R32":()=>ko("UEFA Cup · Round of 32",74,83,[.55,.58],{w:"UC-R16"}),"UC-R16":()=>ko("UEFA Cup · Round of 16",76,84,[.63,.66],{w:"UC-QF"}),"UC-QF":()=>ko("UEFA Cup · Quarter-final",78,86,[.74,.77],{w:"UC-SF"}),"UC-SF":()=>ko("UEFA Cup · Semi-final",79,87,[.84,.87],{w:"UC-F"}),"UC-F":()=>stKO("UEFA Cup · Final","1N",()=>szPickEU("football",80,88,used),[.995],{w:"WIN"})};
  const ELnew=y>=2024,EL21=y>=2021;
  const EL=ELnew?{"EL-Q3":()=>ko("Europa League · Third qualifying round",70,78,[-.1,-.07],{w:"EL-PO",l:"ECL-PO"}),"EL-PO":()=>ko("Europa League · Play-off round",72,79,[-.05,-.02],{w:"EL-LP",l:"ECL-LP"}),
     "EL-LP":()=>stLP("Europa League · League phase",EU_FB.filter(x=>x[1]<=85),8,.08,.5,{lp:true,top:"EL-R16",mid:"EL-KO"}),"EL-KO":()=>ko("Europa League · Knockout play-off",76,83,[.55,.58],{w:"EL-R16"}),
     "EL-R16":()=>ko("Europa League · Round of 16",77,85,[.65,.68],{w:"EL-QF"}),"EL-QF":()=>ko("Europa League · Quarter-final",78,86,[.75,.78],{w:"EL-SF"}),"EL-SF":()=>ko("Europa League · Semi-final",79,86,[.85,.88],{w:"EL-F"}),"EL-F":()=>stKO("Europa League · Final","1N",()=>szPickEU("football",80,87,used),[.995],{w:"WIN"})}
    :{"EL-Q3":()=>ko("Europa League · Third qualifying round",70,78,[-.1,-.07],{w:"EL-PO",l:EL21?"ECL-PO":"OUT"}),"EL-PO":()=>ko("Europa League · Play-off round",72,79,[-.05,-.02],{w:"EL-G",l:EL21?"ECL-G":"OUT"}),
     "EL-G":grp("EL","Europa League · Group stage",[[80,86],[76,82],[72,78]],.08,.42,{pos:EL21?{1:"EL-R16",2:"EL-KO",3:"ECL-KO"}:{1:"EL-R32",2:"EL-R32"}}),
     "EL-R32":()=>ko("Europa League · Round of 32",74,83,[.55,.58],{w:"EL-R16"}),"EL-KO":()=>ko("Europa League · Knockout play-off",77,84,[.55,.58],{w:"EL-R16"}),"EL-R16":()=>ko("Europa League · Round of 16",77,85,[.65,.68],{w:"EL-QF"}),
     "EL-QF":()=>ko("Europa League · Quarter-final",78,86,[.75,.78],{w:"EL-SF"}),"EL-SF":()=>ko("Europa League · Semi-final",79,86,[.85,.88],{w:"EL-F"}),"EL-F":()=>stKO("Europa League · Final","1N",()=>szPickEU("football",80,87,used),[.995],{w:"WIN"})};
  const ECL=y>=2024?{"ECL-Q3":()=>ko("Conference League · Third qualifying round",68,76,[-.1,-.07],{w:"ECL-PO"}),"ECL-PO":()=>ko("Conference League · Play-off round",70,77,[-.05,-.02],{w:"ECL-LP"}),
     "ECL-LP":()=>stLP("Conference League · League phase",EU_FB.filter(x=>x[1]<=81),6,.08,.45,{lp:true,top:"ECL-R16",mid:"ECL-KO"}),"ECL-KO":()=>ko("Conference League · Knockout play-off",72,79,[.55,.58],{w:"ECL-R16"}),
     "ECL-R16":()=>ko("Conference League · Round of 16",73,80,[.65,.68],{w:"ECL-QF"}),"ECL-QF":()=>ko("Conference League · Quarter-final",74,81,[.75,.78],{w:"ECL-SF"}),"ECL-SF":()=>ko("Conference League · Semi-final",75,82,[.85,.88],{w:"ECL-F"}),"ECL-F":()=>stKO("Conference League · Final","1N",()=>szPickEU("football",76,83,used),[.995],{w:"WIN"})}
    :{"ECL-Q2":()=>ko("Conference League · Second qualifying round",64,72,[-.16,-.13],{w:"ECL-Q3"}),"ECL-Q3":()=>ko("Conference League · Third qualifying round",67,75,[-.1,-.07],{w:"ECL-PO"}),"ECL-PO":()=>ko("Conference League · Play-off round",70,77,[-.05,-.02],{w:"ECL-G"}),"ECL-G":grp("ECL","Conference League · Group stage",[[76,81],[72,77],[69,74]],.08,.42,{pos:{1:"ECL-R16",2:"ECL-KO"}}),
     "ECL-KO":()=>ko("Conference League · Knockout play-off",72,79,[.55,.58],{w:"ECL-R16"}),"ECL-R16":()=>ko("Conference League · Round of 16",73,80,[.65,.68],{w:"ECL-QF"}),"ECL-QF":()=>ko("Conference League · Quarter-final",74,81,[.75,.78],{w:"ECL-SF"}),"ECL-SF":()=>ko("Conference League · Semi-final",75,82,[.85,.88],{w:"ECL-F"}),"ECL-F":()=>stKO("Conference League · Final","1N",()=>szPickEU("football",76,83,used),[.995],{w:"WIN"})};
  const drop3=y<=2008?"UC-R32":y<=2020?"EL-R32":"EL-KO",dropQ=y<=2008?"UC-R1":"EL-PO",dropPO=y<=2008?"UC-R1":"EL-G";
  const CL=y>=2024?{"CL-Q2":()=>ko("Champions League · Second qualifying round",70,78,[-.14,-.11],{w:"CL-Q3",l:"EL-Q3"}),"CL-Q3":()=>ko("Champions League · Third qualifying round",72,80,[-.1,-.07],{w:"CL-PO",l:"EL-PO"}),"CL-PO":()=>ko("Champions League · Play-off round",74,81,[-.05,-.02],{w:"CL-LP",l:"EL-LP"}),
     "CL-LP":()=>stLP("Champions League · League phase",EU_FB.filter(x=>x[1]>=74),8,.08,.5,{lp:true,top:"CL-R16",mid:"CL-KO"}),"CL-KO":()=>ko("Champions League · Knockout play-off",81,86,[.55,.58],{w:"CL-R16"}),
     "CL-R16":()=>ko("Champions League · Round of 16",82,90,[.65,.68],{w:"CL-QF"}),"CL-QF":()=>ko("Champions League · Quarter-final",84,91,[.75,.78],{w:"CL-SF"}),"CL-SF":()=>ko("Champions League · Semi-final",85,91,[.85,.88],{w:"CL-F"}),"CL-F":()=>stKO("Champions League · Final","1N",()=>szPickEU("football",86,91,used),[.995],{w:"WIN"})}
    :{"CL-Q2":()=>ko("Champions League · Second qualifying round",70,78,[-.14,-.11],{w:"CL-Q3",l:dropQ}),"CL-Q3":()=>ko("Champions League · Third qualifying round",72,80,[-.1,-.07],{w:y>=2009?"CL-PO":"CL-G",l:dropQ}),"CL-PO":()=>ko("Champions League · Play-off round",74,81,[-.05,-.02],{w:"CL-G",l:dropPO}),
     "CL-G":grp("CL","Champions League · Group stage",[[86,91],[80,85],[76,81]],.08,.42,{pos:y<=2002?{1:"CL-G2",2:"CL-G2",3:drop3}:{1:"CL-R16",2:"CL-R16",3:drop3}}),
     "CL-G2":()=>{const opps=[[86,91],[83,88],[80,85]].map(([lo,hi])=>szPickEU("football",lo,hi,used));return stRR("Champions League · Second group stage",[{n:"__me",me:true},...opps],2,.5,.68,{pos:{1:"CL-QF",2:"CL-QF"}})},
     "CL-R16":()=>ko("Champions League · Round of 16",82,90,[.62,.65],{w:"CL-QF"}),"CL-QF":()=>ko("Champions League · Quarter-final",84,91,[.75,.78],{w:"CL-SF"}),"CL-SF":()=>ko("Champions League · Semi-final",85,91,[.85,.88],{w:"CL-F"}),"CL-F":()=>stKO("Champions League · Final","1N",()=>szPickEU("football",86,91,used),[.995],{w:"WIN"})};
  return {...UC,...EL,...ECL,...CL}}

/* --- Europe formats (basketball and volleyball) --- */
function szEuroCourt(b,season,eu){const y=+season.slice(0,4),used=new Set(),P=(lo,hi)=>()=>szPickEU(b,lo,hi,used),grp=(name,n,lo,hi,legs,from,to,next)=>()=>{const opps=Array.from({length:n},(_,i)=>szPickEU(b,hi-(hi-lo)*i/Math.max(1,n-1)-2,hi-(hi-lo)*i/Math.max(1,n-1)+2,used));return stRR(name,[{n:"__me",me:true},...opps],legs,from,to,next)};
  if(b==="basketball")return {
    "EL-RS":y>=2016?()=>{const n=y>=2019?17:15,opps=Array.from({length:n},(_,i)=>szPickEU(b,88-i*0.7-1.5,88-i*0.7+1.5,used));return stRR("EuroLeague · Regular season",[{n:"__me",me:true},...opps],2,.04,.72,{pos:y>=2023?{1:"EL-PO",2:"EL-PO",3:"EL-PO",4:"EL-PO",5:"EL-PO",6:"EL-PO",7:"EL-PI",8:"EL-PI",9:"EL-PI",10:"EL-PI"}:{1:"EL-PO",2:"EL-PO",3:"EL-PO",4:"EL-PO",5:"EL-PO",6:"EL-PO",7:"EL-PO",8:"EL-PO"}})}
      :grp("EuroLeague · Regular season",5,78,87,2,.04,.4,{pos:{1:"EL-T16",2:"EL-T16",3:"EL-T16",4:"EL-T16"}}),
    "EL-T16":grp("EuroLeague · Top 16",3,82,88,2,.45,.65,{pos:{1:"EL-PO",2:"EL-PO"}}),
    "EL-PI":()=>stKO("EuroLeague · Play-in","1",P(82,86),[.73],{w:"EL-PO"}),
    "EL-PO":()=>stKO("EuroLeague · Playoffs","bo5",P(83,88),szDates(.74,.79,5),{w:"EL-F4"}),
    "EL-F4":()=>stKO("EuroLeague · Final Four semi-final","1N",P(84,89),[.86],{w:"EL-F"}),
    "EL-F":()=>stKO("EuroLeague · Final","1N",P(85,89),[.87],{w:"WIN"}),
    "EC-RS":grp("EuroCup · Regular season",5,74,82,2,.04,.4,{pos:{1:"EC-T16",2:"EC-T16",3:"EC-T16",4:"EC-T16"}}),
    "EC-T16":grp("EuroCup · Top 16",3,77,83,2,.45,.62,{pos:{1:"EC-QF",2:"EC-QF"}}),
    "EC-QF":()=>stKO("EuroCup · Quarter-final","bo3",P(77,83),szDates(.66,.7,3),{w:"EC-SF"}),
    "EC-SF":()=>stKO("EuroCup · Semi-final","bo3",P(78,84),szDates(.74,.78,3),{w:"EC-F"}),
    "EC-F":()=>stKO("EuroCup · Final","bo3",P(79,85),szDates(.82,.86,3),{w:"WIN"})};
  if(b==="womens-basketball")return {
    "EL-RS":grp("EuroLeague Women · Regular season",7,76,88,2,.04,.5,{pos:{1:"EL-QF",2:"EL-QF",3:"EL-QF",4:"EL-QF"}}),
    "EL-QF":()=>stKO("EuroLeague Women · Quarter-final","bo3",P(80,86),szDates(.58,.62,3),{w:"EL-F4"}),
    "EL-F4":()=>stKO(y>=2025?"EuroLeague Women · Final Six semi-final":"EuroLeague Women · Final Four semi-final","1N",P(83,89),[.8],{w:"EL-F"}),
    "EL-F":()=>stKO("EuroLeague Women · Final","1N",P(84,89),[.81],{w:"WIN"}),
    "EC-RS":grp("EuroCup Women · Group stage",3,70,80,2,.04,.3,{pos:{1:"EC-R16",2:"EC-R16"}}),
    "EC-R16":()=>stKO("EuroCup Women · Round of 16","2L",P(72,80),[.4,.42],{w:"EC-QF"}),
    "EC-QF":()=>stKO("EuroCup Women · Quarter-final","2L",P(74,81),[.5,.52],{w:"EC-SF"}),
    "EC-SF":()=>stKO("EuroCup Women · Semi-final","2L",P(75,82),[.6,.62],{w:"EC-F"}),
    "EC-F":()=>stKO("EuroCup Women · Final","2L",P(76,83),[.7,.72],{w:"WIN"})};
  return {
    "CL-G":grp("CEV Champions League · Pool phase",3,74,87,2,.08,.4,{pos:{1:"CL-QF",2:y>=2019?"CL-QF":"CL-PO"}}),
    "CL-PO":()=>stKO("CEV Champions League · Playoffs","2L",P(80,86),[.5,.52],{w:"CL-QF"}),
    "CL-QF":()=>stKO("CEV Champions League · Quarter-final","2L",P(82,88),[.6,.62],{w:"CL-SF"}),
    "CL-SF":()=>stKO(y>=2019?"CEV Champions League · Semi-final":"CEV Champions League · Final Four semi-final",y>=2019?"2L":"1N",P(84,89),y>=2019?[.72,.74]:[.85],{w:"CL-F"}),
    "CL-F":()=>stKO("CEV Champions League · Final","1N",P(85,90),[.86],{w:"WIN"}),
    "CC-R16":()=>stKO("CEV Cup · Round of 16","2L",P(70,78),[.2,.22],{w:"CC-QF"}),"CC-QF":()=>stKO("CEV Cup · Quarter-final","2L",P(72,80),[.4,.42],{w:"CC-SF"}),
    "CC-SF":()=>stKO("CEV Cup · Semi-final","2L",P(74,82),[.55,.57],{w:"CC-F"}),"CC-F":()=>stKO("CEV Cup · Final","2L",P(76,83),[.7,.72],{w:"WIN"}),
    "CH-R32":()=>stKO("CEV Challenge Cup · Round of 32","2L",P(66,74),[.12,.14],{w:"CH-R16"}),"CH-R16":()=>stKO("CEV Challenge Cup · Round of 16","2L",P(68,76),[.25,.27],{w:"CH-QF"}),
    "CH-QF":()=>stKO("CEV Challenge Cup · Quarter-final","2L",P(70,78),[.42,.44],{w:"CH-SF"}),"CH-SF":()=>stKO("CEV Challenge Cup · Semi-final","2L",P(72,80),[.56,.58],{w:"CH-F"}),"CH-F":()=>stKO("CEV Challenge Cup · Final","2L",P(74,82),[.7,.72],{w:"WIN"})}}
/* --- Europe for women's football: Champions League qualifiers, then the Women's Europa Cup if they go out --- */
function szEuroWF(b,season,eu){const used=new Set(),P=(lo,hi)=>()=>szPickEU(b,lo,hi,used);
  return {"WCL-Q1":()=>stKO("Women's Champions League · Second qualifying round, semi-final","1",P(62,70),[-.2],{w:"WCL-Q2",l:"WEC-Q2"}),
   "WCL-Q2":()=>stKO("Women's Champions League · Second qualifying round, final","1",P(70,76),[-.19],{w:"WCL-Q3",l:"WEC-Q2"}),
   "WCL-Q3":()=>stKO("Women's Champions League · Third qualifying round","2L",P(74,82),[-.12,-.1],{w:"WCL-LP",l:"WEC-R16"}),
   "WCL-LP":()=>stLP("Women's Champions League · League phase",EU_WF.filter(x=>x[1]>=74),6,.1,.4,{lp:true,top:"WCL-QF",mid:"WCL-KO",cut:[4,12]},18),
   "WCL-KO":()=>stKO("Women's Champions League · Knockout play-off","2L",P(82,87),[.5,.52],{w:"WCL-QF"}),
   "WCL-QF":()=>stKO("Women's Champions League · Quarter-final","2L",P(85,90),[.62,.64],{w:"WCL-SF"}),
   "WCL-SF":()=>stKO("Women's Champions League · Semi-final","2L",P(87,91),[.75,.77],{w:"WCL-F"}),
   "WCL-F":()=>stKO("Women's Champions League · Final","1N",P(88,92),[.97],{w:"WIN"}),
   "WEC-Q2":()=>stKO("Women's Europa Cup · Second qualifying round","2L",P(62,70),[-.05,-.03],{w:"WEC-R16"}),
   "WEC-R16":()=>stKO("Women's Europa Cup · Round of 16","2L",P(72,79),[.2,.24],{w:"WEC-QF"}),
   "WEC-QF":()=>stKO("Women's Europa Cup · Quarter-final","2L",P(74,81),[.5,.53],{w:"WEC-SF"}),
   "WEC-SF":()=>stKO("Women's Europa Cup · Semi-final","2L",P(76,83),[.7,.73],{w:"WEC-F"}),
   "WEC-F":()=>stKO("Women's Europa Cup · Final","2L",P(77,84),[.88,.91],{w:"WIN"})}}
const szEuroKeys=(b,season,eu)=>b==="football"?szEuroFB(b,season,eu):b==="womens-football"?szEuroWF(b,season,eu):szEuroCourt(b,season,eu);

/* --- build a season --- */
function szLeagueField(b,D){const kind=SZ_KIND[b],top={fb:83,bb:84,wb:84,vb:87}[kind],bot={fb:71,bb:72,wb:66,vb:70}[kind],n=D.lg.length;
  return D.lg.map((x,i)=>Array.isArray(x)?{n:x[0],r:x[1]}:{n:x,r:+(top-(top-bot)*i/Math.max(1,n-1)).toFixed(1)})}
/* challenge codes: everyone with the same code gets the same draft offers and the same luck in the games */
let CH=null;
function chWith(b,k,fn){if(!CH||CH.b!==b)return fn();const o=Math.random;Math.random=CH[k]||(CH[k]=szRng(CH.seed*13+5));try{return fn()}finally{Math.random=o}}
function szNewSeason(b,season,myR,myName){if(CH&&CH.b===b&&season===CH.season){CH.rs=szRng(CH.seed*13+5);const S=chWith(b,"rs",()=>szNewSeasonRaw(b,season,myR,myName));S.ch=CH.code;return S}return szNewSeasonRaw(b,season,myR,myName)}
function szNewSeasonRaw(b,season,myR,myName){const kind=SZ_KIND[b],D=SZ_DATA[b][season],field=szLeagueField(b,D),C=[];
  const LN=D.league||SZ_LN[b];
  const lgEnd=kind==="fb"?.97:.74;
  /* league */
  const lg={id:"lg",name:LN,kind:"league",keys:{},stage:null,path:[],status:"in"};
  lg.stage=stRR(LN,[{n:"__me",me:true,r:myR},...field],2,.02,lgEnd,kind==="fb"?null:{playoffs:true});
  C.push(lg);
  /* super cup */
  if(D.sup){const o=field.find(x=>x.n===D.sup)||{n:D.sup,r:80};C.push({id:"sup",name:{fb:"Turkish Super Cup",bb:"Presidential Cup",wb:"Turkish Super Cup",vb:"Turkish Super Cup"}[kind],kind:"cup",stage:stKO({fb:"Turkish Super Cup",bb:"Presidential Cup",wb:"Turkish Super Cup",vb:"Turkish Super Cup"}[kind]+" · Final","1N",()=>o,[-.15],{w:"WIN"}),path:[],status:"in"})}
  /* domestic cup */
  if(D.cup!==false){const used=new Set(),opp=(lo,hi)=>()=>{const L=field.filter(x=>!used.has(x.n)&&x.r>=lo&&x.r<=hi),pool=L.length?L:field.filter(x=>!used.has(x.n)),o=pool[Math.floor(Math.random()*pool.length)];used.add(o.n);return o};
    const CN=kind==="fb"?"Turkish Cup":"Turkish Cup",rs=kind==="fb"?[["Round of 16",.45,"1",65,80],["Quarter-final",.6,"1",68,82],["Semi-final",.8,"1",72,84],["Final",.985,"1N",74,84]]:[["Quarter-final",.5,"1N",70,80],["Semi-final",.505,"1N",74,84],["Final",.51,"1N",76,88]];
    const keys={};rs.forEach(([nm,d,f,lo,hi],i)=>keys["C"+i]=()=>stKO(CN+" · "+nm,f,opp(lo,hi),[d],{w:i===rs.length-1?"WIN":"C"+(i+1)}));
    C.push({id:"cup",name:CN,kind:"cup",keys,stage:keys.C0(),path:[],status:"in",needTop8:kind!=="fb"})}
  /* Europe */
  if(D.eu){const keys=szEuroKeys(b,season,D.eu);C.push({id:"eu",name:"Europe",kind:"eu",keys,stage:keys[D.eu.e](),path:[],status:"in"})}
  return {b,kind,season,D,my:{n:myName,r:myR},C,log:[],done:false,scorers:{}}}

/* --- the next match in calendar order --- */
function szNext(S){let best=null;S.C.forEach(c=>{if(c.status!=="in"||!c.stage)return;const st=c.stage;let d=null;
  if(st.t==="rr"||st.t==="lp")d=st.ri<st.dates.length?st.dates[st.ri]:null;
  else if(st.t==="ko")d=st.dates[Math.min(st.games.length,st.dates.length-1)];
  if(d!=null&&(!best||d<best.d))best={c,d}});return best}

function szPlay(S){return S.ch&&CH&&CH.code===S.ch?chWith(S.b,"rs",()=>szPlayRaw(S)):szPlayRaw(S)}
function szPlayRaw(S){const nx=szNext(S);if(!nx){S.done=true;return null}const c=nx.c,st=c.stage,kind=S.kind;let entry=null;
  if(c.id==="cup"&&c.needTop8&&!c.checked){c.checked=true;const lg=S.C[0].stage,pos=szSort(lg.rows).findIndex(r=>r.me)+1;if(pos>8){c.status="out";c.path.push({st:st.name,txt:"Not in the top eight at the halfway point",win:false});return szPlay(S)}}
  if(st.t==="rr"){const pr=st.R[st.ri],mine=pr.find(p=>p.includes(0)),others=pr.filter(p=>p!==mine);
    const [h,a]=mine,ha=h===0?1:-1,o=st.rows[h===0?a:h],g=szGame(kind,S.my.r,o.r,ha);
    const A=st.rows[0];if(h===0)szApply(kind,A,o,g);else szApply(kind,o,A,{s:[g.s[1],g.s[0]]});
    others.forEach(([x,y])=>szApply(kind,st.rows[x],st.rows[y],szGame(kind,st.rows[x].r,st.rows[y].r,1)));
    entry={c:c.id,comp:st.name,round:st.ri+1,opp:o.n,ha,g};st.ri++;
    if(c.id==="lg"){S.line=S.line||[];S.line.push([A.pts,Math.max(...st.rows.map(r=>r.pts))])}
    if(st.ri>=st.R.length)szFinishRR(S,c,st)}
  else if(st.t==="lp"){const sl=st.opp[st.ri],o=st.rows[sl.o],g=szGame(kind,S.my.r,o.r,sl.ha);szApply(kind,st.rows[0],o,sl.ha===1?g:g);
    const others=shuffle(st.rows.slice(1).filter(r=>r!==o));for(let i=0;i+1<others.length;i+=2)szApply(kind,others[i],others[i+1],szGame(kind,others[i].r,others[i+1].r,1));
    entry={c:c.id,comp:st.name,round:st.ri+1,opp:o.n,ha:sl.ha,g};st.ri++;if(st.ri>=st.opp.length)szFinishRR(S,c,st)}
  else{if(!st.opp)st.opp=st.pick();const o=st.opp,i=st.games.length,f=st.fmt;
    const hi=st.homeFirst!==false,seq=f==="bo3"?[1,-1,1]:[1,1,-1,-1,1,-1,1],ha=f==="1N"?0:f==="1"?(st.ha1!=null?st.ha1:(st.ha1=Math.random()<.5?1:-1)):f==="2L"?(i===0?-1:1):seq[i]*(hi?1:-1);
    let g=szGame(kind,S.my.r,o.r,ha);
    if(f==="1"||f==="1N")g=szDecide(kind,g,S.my.r,o.r);
    if(f==="2L"&&i===1){const ag=[st.games[0].s[0]+g.s[0],st.games[0].s[1]+g.s[1]];
      if(kind==="vb"){const wins=[0,0];[st.games[0],g].forEach(x=>wins[szWin(x)]++);if(wins[0]===wins[1]){g.golden=Math.random()<clamp(.5+(S.my.r-o.r)*.02,.2,.8)?0:1}}
      else if(ag[0]===ag[1]){if(kind==="fb"){g.forceDecide=true;const t=szDecide("fb",{s:[0,0],forceDecide:true},S.my.r,o.r);if(t.aet){g.s[szWin(t)]++;g.aet=true}else g.pens=t.pens}else{g.s[Math.random()<.5?0:1]+=3;g.ot=1}}}
    st.games.push(g);entry={c:c.id,comp:st.name,opp:o.n,ha,g,leg:f==="2L"?i+1:f.startsWith("bo")?i+1:0,fmt:f};
    const res=szTieDone(kind,st);if(res!=null){entry.tie=res;szFinishKO(S,c,st,res)}}
  if(kind==="fb"&&entry)szScore(S,entry.g.s[0]);
  S.log.unshift(entry);if(!szNext(S))S.done=true;return entry}
/* tie state: null = still running, 0 = you went through, 1 = out */
function szTieDone(kind,st){const G=st.games,f=st.fmt;
  if(f==="1"||f==="1N")return szGW(G[0]);
  if(f==="2L"){if(G.length<2)return null;const L=G[1];if(L.golden!=null)return L.golden;if(L.pens)return L.pens[0]>L.pens[1]?0:1;
    if(kind==="vb"){const w=[0,0];G.forEach(x=>w[szWin(x)]++);return w[0]>w[1]?0:1}
    const a=G[0].s[0]+G[1].s[0],b=G[0].s[1]+G[1].s[1];return a>b?0:1}
  const need={bo3:2,bo5:3,bo7:4}[f],w=[0,0];G.forEach(x=>w[szWin(x)]++);return w[0]>=need?0:w[1]>=need?1:null}
function szFinishRR(S,c,st){const tab=szSort(st.rows),pos=tab.findIndex(r=>r.me)+1;st.final=tab;if(c.id==="lg")c.lastTab=tab;
  c.path.push({st:st.name,txt:`pos:${pos}/${tab.length}`,pos,win:true,table:true});
  if(c.id==="lg"){c.pos=pos;if(st.next&&st.next.playoffs){const n=tab.length,cut=Math.min(8,n);if(pos<=cut){c.po={tab,pos,cut};c.stage=szPlayoff(S,c,"QF");return}c.status="done";c.stage=null;return}
    c.status=pos===1?"won":"done";c.stage=null;return}
  const nx=st.next||{};let key=null;
  if(nx.lp){const [c1,c2]=nx.cut||[8,24];key=pos<=c1?nx.top:pos<=c2?nx.mid:null}else key=(nx.pos||{})[pos]||null;
  szGo(S,c,key)}
function szFinishKO(S,c,st,res){const w=res===0;c.path.push({st:st.name,opp:st.opp.n,games:st.games.slice(),win:w});
  if(c.id==="lg"){if(!w){c.status="done";c.stage=null;return}c.stage=c.poNext?c.poNext():null;if(!c.stage){c.status="won";c.poWon=true}return}
  const key=w?st.next.w:(st.next.l||null);if(key==="WIN"){c.status="won";c.stage=null;return}szGo(S,c,key)}
function szGo(S,c,key){if(!key||key==="OUT"||!c.keys[key]){c.status="out";c.stage=null;return}c.stage=c.keys[key]()}
/* league play-offs: seeds from the final table */
function szPlayoff(S,c,rd){const {tab,pos}=c.po,kind=S.kind,mirror=tab[tab.length>=8?8-pos:Math.max(0,tab.length-pos)]||tab[tab.length-1];
  const fmt={bb:{QF:"bo3",SF:"bo5",F:"bo7"},wb:{QF:"bo3",SF:"bo3",F:"bo5"},vb:{QF:"bo3",SF:"bo3",F:"bo3"}}[kind],used=new Set([mirror.n]);
  const pick=r=>()=>{if(r==="QF")return mirror;const L=tab.filter(x=>!x.me&&!used.has(x.n)).slice(0,r==="SF"?4:3);const o=pickW(L,x=>Math.pow(1.35,x.r-70));used.add(o.n);return o};
  const dates={QF:szDates(.78,.82,3),SF:szDates(.84,.88,5),F:szDates(.9,.96,7)},nm={QF:"Quarter-final",SF:"Semi-final",F:"Final"};
  const order=["QF","SF","F"],i=order.indexOf(rd);c.poNext=i<2?()=>szPlayoff(S,c,order[i+1]):null;
  const k=stKO(c.name+" · Play-off "+nm[rd].toLowerCase(),fmt[rd],pick(rd),dates[rd],{});k.homeFirst=rd==="QF"?pos<=4:pos===1;return k}
/* football scorers for the season summary */
function szScore(S,n){if(!n)return;let L=null;
  if(S.b==="football"){if(!dr||!dr.picks)return;const info=teamInfo(dr.form,dr.picks,dr.captain);L=dr.picks.map((p,j)=>({n:p.n,w:SCW[slotRole(dr.form,j)]*info.eff[j]/80}))}
  else{const s=tdS[S.b],C=TDCFG[S.b];if(!s||!C)return;const W={FW:6,MF:2.2,DF:.6,GK:0};L=s.picks.map((p,j)=>({n:p.n,w:(W[C.slots[j][0]]||1)*p.r/80}))}
  L=L.filter(x=>x.w>0);for(let k=0;k<n;k++){const nm=pickW(L,x=>x.w).n;S.scorers[nm]=(S.scorers[nm]||0)+1}}
function szRun(S,n){for(let i=0;i<n&&!S.done;i++)szPlay(S)}

/* --- results and trophies --- */
function szTrophies(S){const out=[];S.C.forEach(c=>{if(c.status!=="won")return;out.push(c.id==="lg"?(c.poWon||S.kind==="fb"?S.C[0].name:S.C[0].name):c.id==="eu"?c.path[c.path.length-1].st.split(" · ")[0]:c.name)});return out}
function szScoreTxt(S,e){const g=e.g;let s=`${g.s[0]}–${g.s[1]}`;if(g.ot)s+=" (OT)";if(g.aet)s+=" (aet)";if(g.pens)s+=` (${g.pens[0]}–${g.pens[1]} pens)`;if(g.golden!=null)s+=` · ${t(g.golden===0?"golden set won":"golden set lost")}`;return s}
function szStageName(st){const p=st.split(" · ");return p.map(x=>t(x)).join(" · ")}

/* --- UI --- */
const szReal=x=>typeof x==="number"?(x===1?t("Champions"):tf("Finished {p}",{p:ordL(x)})):t(x);
function szAllSeasons(b){return Object.keys(SZ_DATA[b]||{}).sort()}
function szSeasons(b){return CH&&CH.b===b?[CH.season]:szAllSeasons(b)}
function szEntryText(b,season,D){const parts=[t(D.league||SZ_LN[b])];if(D.cup!==false)parts.push(t("Turkish Cup"));if(D.sup)parts.push(t(SZ_KIND[b]==="bb"?"Presidential Cup":"Turkish Super Cup"));
  if(D.eu){const k=szEuroKeys(b,season,{e:D.eu.e,g:[]});const st=(k[D.eu.e]||(()=>({name:D.eu.e})))();parts.push(szStageName(st.name))}return parts.join(" · ")}
function szRender(b,el,myR,myName,onNew){if(EXT.szPre.some(f=>f(b,el,myR,myName,onNew)))return;szRenderRaw(b,el,myR,myName,onNew);runExt("szAfter",b,el,myR,myName,onNew)}
function szRenderRaw(b,el,myR,myName,onNew){const s=szS[b];
  if(!s||!s.S){const list=szSeasons(b),sel=s&&s.sel||list[list.length-1];szS[b]={sel};const D=SZ_DATA[b][sel];
    el.innerHTML=`<div class="szpick card"><span class="label">${t("Season mode")}</span><h3>${t("Pick a season to play")}</h3><p class="muted">${t("Your team replaces Fenerbahçe and plays every competition the club entered that season, game by game.")}</p>
      <div class="szyears" role="group" aria-label="${t("Season")}">${list.map(x=>`<button data-szy="${x}" aria-pressed="${x===sel}">${szDash(x)}</button>`).join("")}</div>
      ${D?`<div class="szinfo"><b>${szDash(sel)}</b><span>${esc(szEntryText(b,sel,D))}</span>${D.real!=null?`<span class="muted">${esc(tf("The real Fenerbahçe: {x}",{x:szReal(D.real)}))}</span>`:""}</div>`:""}
      <div class="btns"><button class="btn" data-sz="start">${t("Start the season")}</button>${onNew?`<button class="btn ghost" data-sz="new">${t("New draft")}</button>`:""}</div></div>`;
    el.querySelectorAll("[data-szy]").forEach(x=>x.onclick=()=>{szS[b].sel=x.dataset.szy;szRender(b,el,myR,myName,onNew)});
    el.querySelector('[data-sz="start"]').onclick=()=>{szS[b].S=szNewSeason(b,szS[b].sel,myR,myName);szRender(b,el,myR,myName,onNew)};
    const nw=el.querySelector('[data-sz="new"]');if(nw)nw.onclick=onNew;return}
  const S=s.S,kind=S.kind,lg=S.C[0],last=S.log[0],nx=szNext(S),played=S.log.length;
  const tblRows=st=>{const tab=st.final||szSort(st.rows),me=tab.findIndex(r=>r.me),show=tab.length>12&&!s.full?tab.map((r,i)=>i<6||Math.abs(i-me)<=2||i>=tab.length-2?i:-1).filter(i=>i>=0):tab.map((_,i)=>i);
    let prev=-1;return show.map(i=>{const r=tab[i],gap=prev>=0&&i>prev+1?`<tr class="gap"><td colspan="6">…</td></tr>`:"";prev=i;return gap+`<tr class="${r.me?"fbrow":""}"><td class="pos">${i+1}</td><td class="tm">${esc(r.me?S.my.n:r.n)}</td><td>${r.p}</td><td>${kind==="fb"?`${r.w}-${r.d}-${r.l}`:`${r.w}-${r.l}`}</td><td class="hm">${r.f}:${r.a}</td><td class="kc">${r.pts}</td></tr>`}).join("")};
  const table=(st,title)=>`<div class="tscroll"><table class="stand sztab"><thead><tr><th class="pos">#</th><th class="tm">${t("Team")}</th><th>${t("col:P")}</th><th>${t(kind==="fb"?"W-D-L":"W-L")}</th><th class="hm">${t(kind==="vb"?"Sets":kind==="fb"?"Goals":"Points")}</th><th class="kc">${t("col:Pts")}</th></tr></thead><tbody>${tblRows(st)}</tbody></table></div>`;
  const pathLi=p=>p.table?`<li class="w"><span class="label">${esc(szStageName(p.st))}</span><b>${tf("Finished {p} of {n}",{p:ordL(p.pos),n:p.txt.split("/")[1]})}</b></li>`
    :p.games?`<li class="${p.win?"w":"l"}"><span class="label">${esc(szStageName(p.st))}</span><b>${esc(p.opp)}</b><span class="res">${p.games.map(g=>szScoreTxt(S,{g})).join(", ")}</span></li>`:`<li class="l"><span class="label">${esc(szStageName(p.st))}</span><b>${esc(t(p.txt))}</b></li>`;
  const compCard=c=>{const live=c.stage&&(c.stage.t==="rr"||c.stage.t==="lp")&&c.id!=="lg"?table(c.stage):"";const st=c.status==="won"?`<span class="chip win">${t("Winners")}</span>`:c.status==="out"?`<span class="chip loss">${t("Out")}</span>`:c.status==="done"?"":`<span class="chip">${t("Still in")}</span>`;
    return `<article class="card szcomp"><header><h3>${esc(c.id==="eu"?szStageName((c.stage?c.stage.name:c.path[c.path.length-1].st).split(" · ")[0]):t(c.name))}</h3>${st}</header><ol class="szpath">${c.path.filter(p=>c.id!=="lg"||!p.table).map(pathLi).join("")}${c.stage&&c.stage.t==="ko"?`<li class="next"><span class="label">${esc(szStageName(c.stage.name))}</span><b>${c.stage.opp?esc(c.stage.opp.n):t("Draw to come")}</b></li>`:""}</ol>${live}</article>`};
  const lastCard=last?`<article class="card szlast"><span class="label">${esc(szStageName(last.comp))}${last.round?` · ${tf("Matchday {n}",{n:last.round})}`:""}${last.leg&&last.fmt==="2L"?` · ${tf("Leg {n}",{n:last.leg})}`:last.leg?` · ${tf("Game {n}",{n:last.leg})}`:""}</span>
     <div class="szscore"><span class="${last.ha!==-1?"fb":""}">${esc(last.ha===-1?last.opp:S.my.n)}</span><b>${last.ha===-1?`${last.g.s[1]}–${last.g.s[0]}`:`${last.g.s[0]}–${last.g.s[1]}`}</b><span class="${last.ha===-1?"fb":""}">${esc(last.ha===-1?S.my.n:last.opp)}</span></div>
     ${(()=>{const ex=[],g=last.g;if(g.ot)ex.push(t("Overtime"));if(g.aet)ex.push(t("After extra time"));if(g.pens)ex.push(tf("{a}–{b} on penalties",{a:g.pens[0],b:g.pens[1]}));if(g.sets)ex.push((last.ha===-1?g.sets.map(x=>[x[1],x[0]]):g.sets).map(x=>x.join("–")).join(", "));if(g.golden!=null)ex.push(t(g.golden===0?"golden set won":"golden set lost"));if(last.tie!=null)ex.push(`<b>${t(last.tie===0?"Through":"Knocked out")}</b>`);return ex.length?`<p class="muted">${ex.join(" · ")}</p>`:""})()}</article>`:"";
  const tro=szTrophies(S),scorers=Object.entries(S.scorers).sort((a,b)=>b[1]-a[1]).slice(0,3);
  const summary=S.done?`<article class="card szsum"><span class="label">${tf("Season {s} · final whistle",{s:szDash(S.season)})}</span><h3>${tro.length===1?t("1 trophy"):tro.length?tf("{n} trophies",{n:tro.length}):t("No trophies this time")}</h3>
     ${tro.length?`<div class="cups">${CUP.repeat(tro.length)}</div><p>${tro.map(x=>esc(t(x))).join(" · ")}</p>`:""}
     <p class="muted">${tf("League: {p}",{p:ordL(lg.pos||0)})}${S.D.real!=null?` · ${esc(tf("The real Fenerbahçe: {x}",{x:szReal(S.D.real)}))}`:""}</p>${scorers.length?`<p class="muted">${t("Top scorers")}: ${scorers.map(([n,g])=>`${esc(n)} ${g}`).join(", ")}</p>`:""}</article>`:"";
  if(S.done&&!S.saved){S.saved=true;const k=SK(b,"sz-best"),best=store.get(k,0);if(tro.length>best)store.set(k,tro.length);store.set(SK(b,"sz-titles"),store.get(SK(b,"sz-titles"),0)+tro.length);
    if(b==="football"&&S.C[0].status==="won")store.set("fb-cups",store.get("fb-cups",0)+1);if(S.C.some(c=>c.id==="eu"&&c.status==="won"))store.set(SK(b,"cups"),store.get(SK(b,"cups"),0)+1);if(typeof xBadgeCheck==="function")xBadgeCheck()}
  el.innerHTML=`<div class="szhead"><div><span class="label">${t("Season mode")} · ${szDash(S.season)}</span><h3>${esc(S.my.n)} · ${S.my.r.toFixed(1)}</h3></div><span class="muted">${tf("{n} games played",{n:played})}</span></div>
    ${summary}
    <div class="btns">${S.done?`<button class="btn" data-sz="again">${t("Play this season again")}</button><button class="btn ghost" data-sz="other">${t("Pick another season")}</button>`:`<button class="btn" data-sz="one">${nx?esc(tf("Next: {x}",{x:szStageName(nx.c.stage.name)})):t("Next match")}</button><button class="btn ghost" data-sz="five">${t("Play 5 games")}</button><button class="btn ghost" data-sz="all">${t("Play to the end")}</button><button class="btn ghost" data-sz="other">${t("Pick another season")}</button>`}${onNew?`<button class="btn ghost" data-sz="new">${t("New draft")}</button>`:""}</div>
    ${lastCard}
    <div class="szgrid"><article class="card szcomp szleague"><header><h3>${esc(t(lg.name))}</h3>${lg.status==="won"?`<span class="chip win">${t("Champions")}</span>`:""}</header>${typeof seasonLine==="function"?seasonLine(S):""}${table(lg.stage&&lg.stage.t==="rr"?lg.stage:{rows:[],final:lg.lastTab||[]})}
      ${lg.path.some(p=>!p.table)||lg.stage&&lg.stage.t==="ko"?`<ol class="szpath">${lg.path.filter(p=>!p.table).map(pathLi).join("")}${lg.stage&&lg.stage.t==="ko"?`<li class="next"><span class="label">${esc(szStageName(lg.stage.name))}</span><b>${lg.stage.opp?esc(lg.stage.opp.n):t("Draw to come")}</b></li>`:""}</ol>`:""}
      <button class="linkbtn" data-sz="full">${s.full?t("Show fewer"):t("Show the full table")}</button></article>
      ${S.C.slice(1).map(compCard).join("")}</div>
    <details class="szlog"><summary>${tf("All results ({n})",{n:played})}</summary><ol>${S.log.map(e=>`<li><span class="label">${esc(szStageName(e.comp))}</span><span>${t(e.ha===1?"ha:H":e.ha===-1?"ha:A":"ha:N")} ${esc(e.opp)}</span><b>${szScoreTxt(S,e)}</b></li>`).join("")}</ol></details>
    <p class="gnote">${t("Rivals and their strengths are estimates made for this game, and formats are simplified. Cup and European draws are random among clubs of a similar level.")}</p>`;
  const on=(k,f)=>{const x=el.querySelector(`[data-sz="${k}"]`);if(x)x.onclick=f},re=()=>szRender(b,el,myR,myName,onNew);
  on("one",()=>{szPlay(S);re()});on("five",()=>{szRun(S,5);re()});on("all",()=>{szRun(S,400);re()});on("full",()=>{s.full=!s.full;re()});
  on("again",()=>{s.S=szNewSeason(b,S.season,myR,myName);re()});on("other",()=>{s.sel=S.season;s.S=null;re()});if(onNew)on("new",onNew)}

/* --- hook into the drafts: replaces the Legends Cup and the Final Four --- */
function szArea(host){let a=document.getElementById("szArea");if(!a){a=document.createElement("div");a.id="szArea";a.className="szarea";host.insertAdjacentElement("afterend",a)}return a}
function renderCupBox(){const el=document.getElementById("cupBox");if(!el||!dr)return;const info=teamInfo(dr.form,dr.picks,dr.captain);
  el.innerHTML=`<span class="label">${t("Your XI")}</span><h3 style="margin-top:4px">${t(tier(info.ovr))}</h3><p class="gnote">${t("Pick a season below and play it through.")}</p>`;
  const host=el.closest(".draft");if(!host)return;szRender("football",szArea(host),info.ovr,t("Your XI"),()=>{szS.football=null;newDraft(dr.form);renderPanel()})}
function tdCupRender(b){const el=document.getElementById("tdCup"),C=TDCFG[b],s=tdS[b];if(!el||!s)return;const me=tdInfo(C,s.picks);
  el.innerHTML=`<span class="label">${t(C.unit==="five"?"Your five":C.unit==="eleven"?"Your XI":"Your six")}</span><h3 style="margin-top:4px">${t(me.ovr>=88?"A dynasty in the making.":me.ovr>=85?"Title favourites.":me.ovr>=82?"Contenders.":"Underdogs, but anything can happen.")}</h3><p class="gnote">${t("Pick a season below and play it through.")}</p>`;
  const host=el.closest(".draft");if(!host)return;szRender(b,szArea(host),me.ovr,t(C.unit==="five"?"Your five":C.unit==="eleven"?"Your XI":"Your six"),()=>{szS[b]=null;newTD(b);rerender()})}

/* ===== Look & feel: hero scenes, tab groups, club home, charts, legends, player pages, search, data labels ===== */

/* ---------- 1. Hero scene and accent per branch ---------- */
const BR_ACCENT={home:"#ffe500",football:"#ffe500",basketball:"#ff9f1c","womens-basketball":"#ff7a8a",volleyball:"#3fd0c9","mens-volleyball":"#5aa9ff","womens-football":"#7be495",more:"#ffe500"};
let LIGHTHOUSE_SVG=null;
const sceneStars=(n,seed)=>{const r=szRng(seed);let s="";for(let i=0;i<n;i++)s+=`<circle cx="${(r()*400).toFixed(0)}" cy="${(r()*120).toFixed(0)}" r="${(0.6+r()*1.1).toFixed(1)}" fill="#fff" opacity="${(0.35+r()*0.5).toFixed(2)}"${i%5===0?' class="twinkle"':""}/>`;return s};
const sceneCrowd=(y0,y1,seed)=>{const r=szRng(seed);let s="";for(let i=0;i<170;i++){const x=r()*400,y=y0+r()*(y1-y0);s+=`<circle cx="${x.toFixed(0)}" cy="${y.toFixed(0)}" r="${(1.2+r()*1.2).toFixed(1)}" fill="${r()<.45?"var(--br)":r()<.6?"#f5f3ea":"#1b3878"}" opacity="${(0.35+r()*0.5).toFixed(2)}"/>`}return s};
const SCENES={
 football:()=>`<defs><linearGradient id="scP" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1f7a43"/><stop offset="1" stop-color="#0b3a20"/></linearGradient><radialGradient id="scF"><stop offset="0" style="stop-color:#fff;stop-opacity:.95"/><stop offset=".35" style="stop-color:var(--br);stop-opacity:.45"/><stop offset="1" style="stop-color:var(--br);stop-opacity:0"/></radialGradient></defs>
  ${sceneStars(26,7)}<path d="M0 150 L400 150 L400 250 L0 250Z" fill="#0a1736"/>${sceneCrowd(156,240,11)}
  <g opacity=".9"><path d="M46 250 V70 M354 250 V70" stroke="#26375f" stroke-width="5"/><rect x="26" y="52" width="40" height="22" rx="3" fill="#dfe6ff"/><rect x="334" y="52" width="40" height="22" rx="3" fill="#dfe6ff"/></g>
  <circle cx="46" cy="63" r="70" fill="url(#scF)"/><circle cx="354" cy="63" r="70" fill="url(#scF)"/>
  <polygon points="60,250 340,250 420,400 -20,400" fill="url(#scP)"/>
  ${[0,1,2,3,4].map(i=>`<polygon points="${60+i*56},250 ${88+i*56},250 ${(-20+i*88+44).toFixed(0)},400 ${(-20+i*88).toFixed(0)},400" fill="#fff" opacity=".045"/>`).join("")}
  <g fill="none" stroke="#e9f5ec" stroke-opacity=".75" stroke-width="2"><polygon points="72,256 328,256 392,394 8,394"/><path d="M40 318 H360"/><ellipse cx="200" cy="318" rx="58" ry="16"/><polygon points="140,256 260,256 266,272 134,272"/></g>
  <circle cx="246" cy="352" r="11" fill="#f5f3ea"/><polygon points="246,347.5 250.3,350.6 248.6,355.6 243.4,355.6 241.7,350.6" fill="#0a1530"/>`,
 "womens-football":()=>`<defs><linearGradient id="scP2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1b6e3c"/><stop offset="1" stop-color="#0a3520"/></linearGradient><radialGradient id="scG"><stop offset="0" style="stop-color:var(--br);stop-opacity:.5"/><stop offset="1" style="stop-color:var(--br);stop-opacity:0"/></radialGradient></defs>
  ${sceneStars(30,3)}<circle cx="200" cy="120" r="170" fill="url(#scG)"/>
  <rect x="0" y="282" width="400" height="118" fill="url(#scP2)"/><path d="M0 300 H400" stroke="#e9f5ec" stroke-opacity=".5" stroke-width="2"/>
  <g stroke="#e9f5ec" stroke-opacity=".28" stroke-width="1">${Array.from({length:15},(_,i)=>`<path d="M${104+i*13} 166 L${128+i*10.3} 250"/>`).join("")}${Array.from({length:7},(_,i)=>`<path d="M${104+i*1.7} ${166+i*12} H${296-i*1.7}"/>`).join("")}</g>
  <path d="M104 290 V164 H296 V290" fill="none" stroke="#f5f3ea" stroke-width="7" stroke-linejoin="round"/><path d="M104 164 L128 250 H272 L296 164" fill="none" stroke="#f5f3ea" stroke-opacity=".5" stroke-width="2"/>
  <path d="M218 214 q14 18 34 20" stroke="var(--br)" stroke-width="2" fill="none" opacity=".8"/>
  <circle cx="232" cy="236" r="13" fill="#f5f3ea"/><polygon points="232,230.5 237.2,234.3 235.2,240.4 228.8,240.4 226.8,234.3" fill="#0a1530"/>
  <path d="M70 330 q60 -40 150 -88" stroke="var(--br)" stroke-width="2.5" stroke-dasharray="3 7" fill="none" opacity=".7"/>`,
 basketball:()=>`<defs><linearGradient id="scW" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#b46a2d"/><stop offset="1" stop-color="#6e3b16"/></linearGradient><radialGradient id="scS" cx=".5" cy="0" r="1"><stop offset="0" style="stop-color:var(--br);stop-opacity:.38"/><stop offset="1" style="stop-color:var(--br);stop-opacity:0"/></radialGradient></defs>
  ${sceneStars(18,5)}<polygon points="150,0 250,0 330,260 70,260" fill="url(#scS)"/>
  <polygon points="0,262 400,262 400,400 0,400" fill="url(#scW)"/>${Array.from({length:9},(_,i)=>`<path d="M0 ${270+i*15} H400" stroke="#000" stroke-opacity=".12"/>`).join("")}
  <polygon points="150,262 250,262 284,400 116,400" style="fill:var(--br)" opacity=".25"/><path d="M150 262 L116 400 M250 262 L284 400" stroke="#f5f3ea" stroke-opacity=".7" stroke-width="2"/>
  <path d="M200 262 V110" stroke="#26375f" stroke-width="7"/><rect x="152" y="70" width="96" height="62" rx="4" fill="#f5f3ea" fill-opacity=".12" stroke="#f5f3ea" stroke-width="3"/><rect x="184" y="92" width="32" height="24" fill="none" stroke="#f5f3ea" stroke-width="2.5"/>
  <ellipse cx="200" cy="138" rx="24" ry="6" fill="none" style="stroke:var(--br)" stroke-width="4"/>
  <path d="M178 140 L186 168 M190 141 L193 170 M200 142 V170 M210 141 L207 170 M222 140 L214 168 M184 154 H216 M188 164 H212" stroke="#f5f3ea" stroke-opacity=".75" stroke-width="1.4" fill="none"/>
  <path d="M86 214 Q120 60 186 120" stroke="var(--br)" stroke-width="2.5" stroke-dasharray="3 7" fill="none" opacity=".75"/>
  <circle cx="86" cy="220" r="20" fill="#e2762c"/><path d="M66 220 H106 M86 200 V240 M72 206 q14 14 0 28 M100 206 q-14 14 0 28" stroke="#3b1a07" stroke-width="1.8" fill="none"/>`,
 "womens-basketball":()=>`<defs><linearGradient id="scW2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#a85e2a"/><stop offset="1" stop-color="#5f3214"/></linearGradient><radialGradient id="scS2" cx=".72" cy=".2" r=".7"><stop offset="0" style="stop-color:var(--br);stop-opacity:.42"/><stop offset="1" style="stop-color:var(--br);stop-opacity:0"/></radialGradient></defs>
  ${sceneStars(22,9)}<rect width="400" height="400" fill="url(#scS2)"/>
  <polygon points="0,280 400,250 400,400 0,400" fill="url(#scW2)"/>${Array.from({length:8},(_,i)=>`<path d="M0 ${290+i*15} L400 ${262+i*17}" stroke="#000" stroke-opacity=".12"/>`).join("")}
  <g transform="translate(-20,80)"><path d="M352 250 V60" stroke="#26375f" stroke-width="8"/><rect x="300" y="44" width="16" height="74" rx="3" fill="#f5f3ea" fill-opacity=".2" stroke="#f5f3ea" stroke-width="3"/>
  <path d="M316 104 H352" stroke="#26375f" stroke-width="5"/><ellipse cx="282" cy="110" rx="26" ry="7" fill="none" style="stroke:var(--br)" stroke-width="4"/>
  <path d="M258 112 L266 146 M270 114 L273 148 M282 115 V150 M294 114 L291 148 M306 112 L298 146 M262 130 H302 M267 142 H297" stroke="#f5f3ea" stroke-opacity=".8" stroke-width="1.4" fill="none"/>
  <circle cx="282" cy="132" r="17" fill="#e2762c"/><path d="M265 132 H299 M282 115 V149 M270 120 q11 12 0 24 M294 120 q-11 12 0 24" stroke="#3b1a07" stroke-width="1.6" fill="none"/>
  <path d="M230 96 q20 -10 34 6 M226 112 q14 -6 26 0" stroke="var(--br)" stroke-width="3" stroke-linecap="round" fill="none"/>
  </g><path d="M60 300 Q140 100 242 184" stroke="#f5f3ea" stroke-opacity=".35" stroke-width="2" stroke-dasharray="2 8" fill="none"/>`,
 volleyball:()=>`<defs><linearGradient id="scV" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1d5d8f"/><stop offset="1" stop-color="#0b2a4a"/></linearGradient><radialGradient id="scVG"><stop offset="0" style="stop-color:var(--br);stop-opacity:.45"/><stop offset="1" style="stop-color:var(--br);stop-opacity:0"/></radialGradient></defs>
  ${sceneStars(24,13)}<circle cx="200" cy="90" r="120" fill="url(#scVG)"/>
  <polygon points="0,272 400,272 400,400 0,400" fill="url(#scV)"/><polygon points="60,272 340,272 380,400 20,400" fill="#e07a2f" opacity=".55"/><path d="M60 272 L20 400 M340 272 L380 400 M200 272 V400" stroke="#f5f3ea" stroke-opacity=".7" stroke-width="2"/>
  <path d="M30 290 V140 M370 290 V140" stroke="#dfe6ff" stroke-width="6"/>
  <g stroke="#f5f3ea" stroke-opacity=".35" stroke-width="1">${Array.from({length:22},(_,i)=>`<path d="M${30+i*16} 152 V212"/>`).join("")}${[0,1,2,3].map(i=>`<path d="M30 ${152+i*20} H370"/>`).join("")}</g>
  <rect x="30" y="146" width="340" height="9" fill="#f5f3ea"/><rect x="30" y="210" width="340" height="4" fill="#f5f3ea" opacity=".8"/>
  <circle cx="214" cy="86" r="22" fill="#f5f3ea"/><path d="M194 80 q20 -8 40 4 M198 100 q8 -22 30 -30 M206 66 q-6 22 10 40" style="stroke:var(--br)" stroke-width="3" fill="none"/>
  <path d="M150 50 l30 18 M140 72 l34 10 M156 30 l26 26" stroke="#f5f3ea" stroke-opacity=".5" stroke-width="2.5" stroke-linecap="round"/>`,
 "mens-volleyball":()=>`<defs><linearGradient id="scV2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#173f73"/><stop offset="1" stop-color="#081a35"/></linearGradient><radialGradient id="scVG2" cx=".3" cy=".25"><stop offset="0" style="stop-color:var(--br);stop-opacity:.5"/><stop offset="1" style="stop-color:var(--br);stop-opacity:0"/></radialGradient></defs>
  ${sceneStars(20,17)}<rect width="400" height="400" fill="url(#scVG2)"/>
  <polygon points="0,300 400,300 400,400 0,400" fill="url(#scV2)"/><path d="M0 330 H400" stroke="#f5f3ea" stroke-opacity=".5" stroke-width="2"/>
  <path d="M10 320 V170 M390 320 V170" stroke="#dfe6ff" stroke-width="6"/>
  <g stroke="#f5f3ea" stroke-opacity=".3" stroke-width="1">${Array.from({length:24},(_,i)=>`<path d="M${10+i*16.5} 184 V250"/>`).join("")}${[0,1,2,3].map(i=>`<path d="M10 ${184+i*22} H390"/>`).join("")}</g>
  <rect x="10" y="176" width="380" height="10" fill="#f5f3ea"/>
  <path d="M60 30 L250 150" stroke="var(--br)" stroke-width="10" stroke-linecap="round" opacity=".25"/><path d="M90 50 L250 150" stroke="#f5f3ea" stroke-width="3" stroke-linecap="round" opacity=".5"/>
  <circle cx="262" cy="160" r="22" fill="#f5f3ea"/><path d="M242 156 q20 -10 40 2 M248 176 q6 -22 28 -32 M254 140 q-4 22 14 40" style="stroke:var(--br)" stroke-width="3" fill="none"/>
  <path d="M300 236 l14 40 M318 232 l8 44 M336 236 l-2 42" stroke="#f5f3ea" stroke-opacity=".45" stroke-width="5" stroke-linecap="round"/>`};
const SCENE_CAP={football:"Kadıköy under the floodlights","womens-football":"Top corner","basketball":"Nothing but net","womens-basketball":"Swish","volleyball":"Over the net","mens-volleyball":"The spike"};
function applyHero(b){const hero=document.querySelector(".hero");if(!hero)return;hero.style.setProperty("--br",BR_ACCENT[b]||"#ffe500");hero.dataset.br=b;
  const svg=document.querySelector(".scene svg");if(!svg)return;if(!LIGHTHOUSE_SVG)LIGHTHOUSE_SVG=svg.innerHTML;
  const k=SCENES[b]?b:"light",cap=document.querySelector(".scene .cap");if(cap){cap.removeAttribute("data-t");cap.textContent=t(SCENE_CAP[b]||"Fener · the lighthouse that named the club")}if(svg.dataset.scene===k)return;svg.dataset.scene=k;svg.innerHTML=SCENES[b]?SCENES[b]():LIGHTHOUSE_SVG}

/* ---------- 3. Club home ---------- */
const HOME_BR=["football","basketball","womens-basketball","volleyball","mens-volleyball","womens-football"];
function homeFixtures(){const today=todayISO(),out=[];HOME_BR.forEach(b=>{const L=LIVE[b];if(!L)return;L.next.filter(n=>n[0]&&n[0]>=today).forEach(n=>out.push({b,n}))});return out.sort((a,c)=>(a.n[0]+a.n[1]).localeCompare(c.n[0]+c.n[1]))}
function renderHome(){$("sport").value="home";applyHero("home");
  $("heroTr").textContent="Kadıköy · 1907";$("heroTitle").textContent="Fenerbahçe";$("heroNick").textContent=t("One club, every branch");
  $("heroLede").textContent=t("Football, basketball, volleyball and more, all on one page. Pick a branch to dive in, or see what is coming up across the club below.");$("kitNum").textContent="07";
  $("stats").innerHTML=[["28","Turkish football championships"],["2","EuroLeague titles"],["3","EuroLeague Women titles"],["1907","Club founded"]].map(([v,k])=>`<div class="stat"><span class="v">${v}</span><span class="k">${esc(t(k))}</span></div>`).join("");
  $("home").innerHTML=`<span class="label">${esc(t("Base"))}</span><b>${esc(t("Kadıköy, Istanbul, with facilities across the city"))}</b>`;
  $("tabs").innerHTML="";$("tabs").classList.add("grouped");
  const today=todayISO(),fx=homeFixtures().slice(0,8);
  const card=b=>{const S=SPORTS[b],L=LIVE[b],nx=nextFixture(b),last=L&&L.last.find(r=>r[0]),o=last?outcome(last):null;
    return `<article class="hcard card" style="--br:${BR_ACCENT[b]}"><div class="hhead"><div><h3>${esc(t(S.label))}</h3><p class="muted">${esc(t(S.nick))}</p></div></div>
     ${L?`<dl class="hrows"><dt>${t("Next match")}</dt><dd>${nx?`<b>${nx.n[0]?mDate(nx.n[0],true):esc(t(nx.n[5]||""))}${nx.n[1]?" · "+nx.n[1]:""}</b><br>${esc(nx.n[3]==="A"?nx.n[4]+" – Fenerbahçe":"Fenerbahçe – "+nx.n[4])} <span class="muted">· ${esc(t(nx.n[2]))}</span>`:`<span class="muted">${t("No upcoming fixtures in this snapshot.")}</span>`}</dd>
       <dt>${t("Latest result")}</dt><dd>${last?`<span class="fo ${o}">${t("res:"+o)}</span> ${esc(last[3])} <b>${last[4]}–${last[5]}</b> <span class="muted">${mDate(last[0],true)}</span>`:"–"}</dd>
       <dt>${esc(t(L.summary[0][1]))}</dt><dd><b>${esc(t(L.summary[0][0]))}</b></dd></dl>`:""}
     <button class="btn ghost" data-gosport="${b}">${esc(tf("Open {x}",{x:t(S.label)}))} →</button></article>`};
  $("panel").removeAttribute("aria-labelledby");
  $("panel").innerHTML=`<h2>${t("All branches")}</h2><p class="intro">${t("Every Fenerbahçe team on this site.")}</p>
   <div class="hgrid">${HOME_BR.map(card).join("")}</div>
   <h3 class="mh" style="margin-top:28px">${t("Coming up across the club")}</h3>
   <ol class="hfx">${fx.map(({b,n})=>`<li class="hfrow card"><div class="md"><b>${mDate(n[0],true)}</b><span>${n[1]||""}</span></div><div class="mm"><span class="mcomp">${brIcon(b)}${esc(t(n[2]))}</span><span class="mopp">${esc(vsOpp(n[3],n[4]))}</span></div><div class="ms"><button class="linkbtn" data-gosport="${b}">${t("Open")} →</button></div></li>`).join("")||`<li class="muted">${t("No upcoming fixtures in this snapshot.")}</li>`}</ol>
   <article class="card hmore"><div><h3>${esc(t(SPORTS.more.label))}</h3><p class="muted">${esc(t("Esports, athletics, rowing, sailing, swimming, table tennis, boxing and wheelchair basketball."))}</p></div><button class="btn ghost" data-gosport="more">${esc(tf("Open {x}",{x:t(SPORTS.more.label)}))} →</button></article>`;
  runExt("home",$("panel"));renderNextBanner();if(typeof kanRender==="function")kanRender()}
document.addEventListener("click",e=>{const g=e.target.closest("[data-gosport]");if(!g)return;setSport(g.dataset.gosport);window.scrollTo({top:0,behavior:"smooth"})});

/* ---------- 4. Charts ---------- */
const TL_DATA={
 football:()=>({series:[["Istanbul League",TROPHY_PRE[0][2].split(", ").map(x=>+x.slice(0,4)+1)],["Turkish champions",SPORTS.football.trophies[0][2].split(", ").map(Number)],["Turkish Cups",[1968,1974,1979,1983,2012,2013,2023]]]}),
 basketball:()=>({series:[["Turkish champions",[1957,1959,1965,1991,2007,2008,2010,2011,2014,2016,2017,2018,2022,2024,2025,2026]],["Turkish Cups",[1967,2010,2011,2013,2016,2019,2020,2024,2025,2026]],["European titles",[2017,2025]]]}),
 "womens-basketball":()=>({series:[["Turkish champions",SZ_HIST["womens-basketball"].t],["European titles",[2023,2024,2026]]]}),
 volleyball:()=>({series:[["Turkish champions",SZ_HIST.volleyball.t],["Turkish Cups",SZ_HIST.volleyball.c],["European and world titles",[2010,2012,2014]]],note:"League titles shown for the current format only (7 of 15)."}),
 "mens-volleyball":()=>({series:[["Turkish champions",SZ_HIST["mens-volleyball"].t],["Turkish Cups",SZ_HIST["mens-volleyball"].c],["European titles",[2014]],["Balkan Cups",[2009,2013]]]}),
 "womens-football":()=>({series:[["Turkish champions",[2026]]]})};
function trophyChart(b){if(!TL_DATA[b])return "";const D=TL_DATA[b](),all=D.series.flatMap(s=>s[1]);if(all.length<2)return "";
  const d0=Math.floor(Math.min(...all)/10)*10,dec=[];for(let d=d0;d<=2020;d+=10)dec.push(d);
  const cnt=dec.map(d=>D.series.map(s=>s[1].filter(y=>y>=d&&y<d+10).length)),mx=Math.max(...cnt.map(c=>c.reduce((a,b)=>a+b,0)),1);
  const W=1000,H=250,L=30,R=10,T=14,B=30,bw=Math.min(56,(W-L-R)/dec.length*.62),x=i=>L+(i+.5)*(W-L-R)/dec.length,y=v=>H-B-v*(H-T-B)/mx;
  const ticks=[...new Set([0,Math.ceil(mx/2),mx])];
  const bars=dec.map((d,i)=>{let acc=0;return cnt[i].map((c,k)=>{if(!c)return "";const y1=y(acc),y2=y(acc+c);acc+=c;return `<rect x="${(x(i)-bw/2).toFixed(1)}" y="${(y2+1).toFixed(1)}" width="${bw.toFixed(1)}" height="${Math.max(1,y1-y2-2).toFixed(1)}" rx="3" class="s${k+1}"><title>${d}s · ${esc(t(D.series[k][0]))}: ${c}</title></rect>`}).join("")+`<rect x="${(x(i)-(W-L-R)/dec.length/2).toFixed(1)}" y="${T}" width="${((W-L-R)/dec.length).toFixed(1)}" height="${H-T-B}" fill="transparent"><title>${d}s: ${D.series.map((s,k)=>`${t(s[0])} ${cnt[i][k]}`).join(" · ")}</title></rect>`}).join("");
  return `<figure class="tlchart card"><figcaption><span class="label">${t("Titles by decade")}</span><span class="clegend">${D.series.map((s,k)=>`<span><i class="s${k+1}"></i>${esc(t(s[0]))} (${s[1].length})</span>`).join("")}</span></figcaption>
   <svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${t("Titles by decade")}">${ticks.map(v=>`<path d="M${L} ${y(v)} H${W-R}" class="grid"/><text x="${L-8}" y="${y(v)+4}" text-anchor="end" class="ax">${v}</text>`).join("")}${bars}${dec.map((d,i)=>`<text x="${x(i)}" y="${H-10}" text-anchor="middle" class="ax">${String(d).slice(0,2)==="19"?"’"+String(d).slice(2):d}s</text>`).join("")}</svg>
   ${D.note?`<p class="fine">${esc(t(D.note))}</p>`:""}
   <details><summary>${t("Show as a table")}</summary><div class="tscroll"><table class="stand"><thead><tr><th>${t("Decade")}</th>${D.series.map(s=>`<th>${esc(t(s[0]))}</th>`).join("")}</tr></thead><tbody>${dec.map((d,i)=>`<tr><td>${d}s</td>${cnt[i].map(c=>`<td>${c}</td>`).join("")}</tr>`).join("")}</tbody></table></div></details></figure>`}
function derbyOverview(){return `<figure class="h2h card"><figcaption class="label">${t("All meetings, head to head")}</figcaption>${DERBIES.map(D=>{const r=D.all,tot=r.w+r.d+r.l,pc=v=>(v/tot*100).toFixed(1);
   return `<div class="h2hrow"><b>${esc(D.opp)}</b><div class="rbar" title="${r.w}–${r.d}–${r.l}"><i class="w" style="width:${pc(r.w)}%"></i><i class="d" style="width:${pc(r.d)}%"></i><i class="l" style="width:${pc(r.l)}%"></i></div><span class="h2hnum">${r.w} · ${r.d} · ${r.l}</span></div>`}).join("")}</figure>`}
function seasonLine(S){const P=S.line||[];if(P.length<2)return "";const W=1000,H=190,L=34,R=12,T=12,B=26,n=P.length,mx=Math.max(...P.map(p=>p[1]),1),x=i=>L+i*(W-L-R)/Math.max(1,n-1),y=v=>H-B-v*(H-T-B)/mx;
  const line=k=>P.map((p,i)=>`${i?"L":"M"}${x(i).toFixed(1)} ${y(p[k]).toFixed(1)}`).join(" ");
  return `<figure class="szline"><figcaption><span class="label">${t("Points through the season")}</span><span class="clegend"><span><i class="s1"></i>${esc(S.my.n)}</span><span><i class="dash"></i>${t("League leader")}</span></span></figcaption>
   <svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${t("Points through the season")}"><path d="M${L} ${y(0)} H${W-R}" class="grid"/><path d="M${L} ${y(mx)} H${W-R}" class="grid"/><text x="${L-6}" y="${y(mx)+4}" text-anchor="end" class="ax">${mx}</text><text x="${L-6}" y="${y(0)+4}" text-anchor="end" class="ax">0</text>
   <path d="${line(1)}" class="ln2"/><path d="${line(0)}" class="ln1"/>${P.map((p,i)=>`<circle cx="${x(i).toFixed(1)}" cy="${y(p[0]).toFixed(1)}" r="9" fill="transparent"><title>${tf("Matchday {n}",{n:i+1})}: ${p[0]} · ${t("League leader")} ${p[1]}</title></circle>`).join("")}
   <text x="${L}" y="${H-6}" class="ax">1</text><text x="${W-R}" y="${H-6}" text-anchor="end" class="ax">${n}</text></svg></figure>`}

/* ---------- 5. Legend cards ---------- */
function renderLegends(p,s){p.innerHTML=`<h2>${t("Legends")} ${dchip("real")}</h2><p class="intro">${t("Names every Fenerbahçe fan should know.")}</p><div class="legends2">${s.legends.map(([n,r,x,fa])=>{const parts=t(r).split(" · "),key=fa&&fa[0],rest=(fa||[]).slice(1);
    return `<article class="legend2 card"><div class="lhead"><span>${esc(parts[0])}</span>${parts.length>1?`<span class="lyrs">${esc(parts.slice(1).join(" · "))}</span>`:""}</div>
     <div class="lbody"><button class="lname" data-player="${esc(n)}">${esc(n)}</button><p>${esc(t(x))}</p>${key?`<div class="lkey">${esc(t(key))}</div>`:""}${rest.length?`<ul class="lfacts">${rest.map(f=>`<li>${esc(t(f))}</li>`).join("")}</ul>`:""}</div>
     <div class="lfoot"><button class="linkbtn" data-player="${esc(n)}">${t("Profile")} →</button></div></article>`}).join("")}</div>`}

/* ---------- 6. Player pages ---------- */
let PPI=null;
const nk=s=>norm(s).replace(/[^a-z0-9 ]/g,"").trim();
function ppIndex(){if(PPI)return PPI;const M=new Map(),add=(n,b)=>{if(!n)return;const k=nk(n);let e=M.get(k);if(!e){e={n,b:new Set()};M.set(k,e)}e.b.add(b)};
  Object.keys(PEOPLE).forEach(n=>add(n,"football"));PLAYERS.forEach(p=>add(p.n,"football"));
  Object.entries(BPEOPLE).forEach(([b,P])=>Object.keys(P).forEach(n=>add(n,b)));
  Object.entries(SPORTS).forEach(([b,S])=>(S.legends||[]).forEach(l=>add(l[0],b)));
  Object.entries(SQUADS).forEach(([b,Q])=>(Q.groups||[]).forEach(g=>g[1].forEach(x=>add(x[1],b))));
  PPI=[...M.values()];return PPI}
function ppFind(n){const k=nk(n);return ppIndex().find(e=>nk(e.n)===k)||{n,b:new Set()}}
function ppMentions(n){const parts=n.split(" "),last=parts[parts.length-1],keys=[n];if(last.length>=5&&parts.length>1)keys.push(last);const hit=s=>s&&keys.some(k=>s.includes(k)),out=[];
  Object.entries(SPORTS).forEach(([b,S])=>{(S.games||[]).forEach((g,i)=>{if(hit(g.note)||hit(g.title))out.push({b,tb:"games",i,lab:g.res?`${g.home} ${g.res} ${g.away}`:t(g.title),sub:`${t(g.comp)} · ${fmtDate(g.date)}`,txt:t(g.note)})});
   (S.history||[]).forEach((h,i)=>{if(hit(h[2])||hit(h[1]))out.push({b,tb:"history",i,lab:`${h[0]} · ${t(h[1])}`,sub:t(S.label),txt:t(h[2])})})});return out.slice(0,8)}
function playerPage(n){const e=ppFind(n),brs=[...e.b],secs=[];
  const p=PBY[n],F=PEOPLE[n];let pos="",nat="",yrsT="",rating=null,ten="";
  if(p){pos=t(ROLE_NAME[ROLE[p.pos]]||p.pos);nat=t(NAT[p.nat]||"");yrsT=yrs(p);rating=p.r}
  brs.forEach(b=>{const X=BPEOPLE[b]&&(BPEOPLE[b][n]||BPEOPLE[b][PERSON_MAP[n]]);if(X){pos=pos||capFirst(t(BPOS[X.pos]||""));nat=nat||t((NAT2[X.nat]||"").replace(/^the /,""));ten=ten||X.ten;if(rating==null)rating=X.r}});
  brs.forEach(b=>{const l=(SPORTS[b].legends||[]).find(x=>x[0]===n);if(l)secs.push(`<section><h4 class="mh">${t("Legend")} · ${esc(t(SPORTS[b].label))}</h4><p class="lrole">${esc(t(l[1]))}</p><p>${esc(t(l[2]))}</p>${(l[3]||[]).length?`<ul class="lfacts">${l[3].map(f=>`<li>${esc(t(f))}</li>`).join("")}</ul>`:""}</section>`)});
  Object.entries(SQUADS).forEach(([b,Q])=>(Q.groups||[]).forEach(([g,list])=>list.forEach(([num,nm,c])=>{if(nm===n)secs.push(`<section><h4 class="mh">${t("Squad")} · ${esc(t(SPORTS[b].label))}</h4><p>${num!=null?`#${num} · `:""}${esc(t(g))} · ${esc(t(c))}</p><p class="fine">${esc(t(Q.asof))}</p></section>`)})));
  if(F&&F.seasons&&F.seasons.length)secs.push(`<section><h4 class="mh">${t("In the most-used XI")}</h4><p>${F.seasons.map(s=>seasonLabel(s)).join(", ")}</p></section>`);
  brs.forEach(b=>{const X=BPEOPLE[b]&&(BPEOPLE[b][n]||BPEOPLE[b][PERSON_MAP[n]]);if(!X)return;
    if(X.apps&&X.apps.length)secs.push(`<section><h4 class="mh">${t("Box scores")}</h4><ul class="pplist">${X.apps.map(a=>`<li><span>${esc(t(a.L.label))} · ${t("vs")} ${esc(a.L.opp)}</span><b>${a.pts==null?t("DNP"):tf("{n} pts",{n:a.pts})}</b></li>`).join("")}</ul></section>`);
    if(X.squads&&X.squads.length)secs.push(`<section><h4 class="mh">${t("Famous squads")}</h4><ul class="pplist">${X.squads.map(s=>`<li><span>${esc(t(s.S.label))}</span><b>${s.num!=null?"#"+s.num:""}</b></li>`).join("")}</ul></section>`)});
  const sp=SPECIAL[n]||SPECIAL_B[n]||VB_AWARDS[n];if(sp)secs.push(`<section><h4 class="mh">${t("Who Am I? clue")}</h4><p>${esc(t(sp))}</p></section>`);
  const men=ppMentions(n);if(men.length)secs.push(`<section><h4 class="mh">${t("Mentioned in")}</h4><ul class="pplist links">${men.map(m=>`<li><button class="linkbtn" data-goitem="${m.b}|${m.tb}|${m.i}">${esc(m.lab)}</button><span class="muted">${esc(m.sub)}</span></li>`).join("")}</ul></section>`);
  const facts=[pos&&[t("Position"),pos],nat&&[t("Country"),nat],(yrsT||ten)&&[t("Years at the club"),yrsT||ten],rating!=null&&[t("Rating in the games"),`${rating} ${dchip("est")}`]].filter(Boolean);
  ovOpen(`<article class="pp"><span class="label">${brs.map(b=>esc(t(SPORTS[b].label))).join(" · ")||t("Player")}</span><h2>${esc(n)}</h2>
   ${facts.length?`<dl class="ppfacts">${facts.map(([k,v])=>`<div><dt>${esc(k)}</dt><dd>${v}</dd></div>`).join("")}</dl>`:""}
   ${secs.join("")||`<p class="muted">${t("Not much on this player yet.")}</p>`}
   ${KAN&&KAN.sample&&!KAN.off?`<div class="btns"><button class="btn ghost" data-askp="${esc(n)}">${esc(tf("Ask Kanarya about {x}",{x:n}))}</button></div>`:""}</article>`,n)}
document.addEventListener("click",e=>{const p=e.target.closest("[data-player]");if(p){e.preventDefault();playerPage(p.dataset.player);return}
  const a=e.target.closest("[data-askp]");if(a){ovClose();kanToggle(true);kanAsk(tf("Tell me about {x}.",{x:a.dataset.askp}));return}
  const g=e.target.closest("[data-goitem]");if(g){const [b,tb,i]=g.dataset.goitem.split("|");goItem(b,tb,i)}});
function goItem(b,tb,i){ovClose();if(tb==="europe"&&i!=null&&isNaN(+i)){euQ=i;i=null}if(current!==b)setSport(b);gameFilter="All";mFilter="All";tab=tb;syncHash();render();
  const el=i!=null&&i!==""?document.querySelector(`[data-hk="${tb}-${i}"]`):null;const go=el||$("tabs");setTimeout(()=>{go.scrollIntoView({behavior:"smooth",block:el?"center":"start"});if(el){el.classList.add("flash");setTimeout(()=>el.classList.remove("flash"),2200)}},40)}

/* ---------- overlay shared by search and player pages ---------- */
let OV_RET=null;
function ovOpen(html,label){let ov=$("ov");if(!ov){ov=document.createElement("div");ov.id="ov";ov.className="ov";ov.hidden=true;ov.innerHTML=`<div class="ovbox card" role="dialog" aria-modal="true"><button class="ovx" type="button" data-ovx>✕</button><div id="ovBody"></div></div>`;document.body.appendChild(ov);
    ov.addEventListener("click",e=>{if(e.target===ov||e.target.closest("[data-ovx]"))ovClose()})}
  if(ov.hidden)OV_RET=document.activeElement;$("ovBody").innerHTML=html;ov.querySelector(".ovbox").setAttribute("aria-label",label||"");ov.querySelector("[data-ovx]").setAttribute("aria-label",t("Close"));ov.hidden=false;document.body.classList.add("ovopen");
  const f=ov.querySelector("input")||ov.querySelector("[data-ovx]");setTimeout(()=>f&&f.focus(),20)}
function ovClose(){const ov=$("ov");if(!ov||ov.hidden)return;ov.hidden=true;document.body.classList.remove("ovopen");if(OV_RET&&OV_RET.focus)OV_RET.focus()}
document.addEventListener("keydown",e=>{const ov=$("ov");if(e.key==="Escape"&&ov&&!ov.hidden){e.stopPropagation();ovClose()}
  if((e.key==="/"&&!e.target.closest("input,textarea,select"))||((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==="k")){e.preventDefault();openSearch()}},true);

/* ---------- 7. Search ---------- */
let SIX=null;
const sn=s=>String(s).toLocaleLowerCase("tr").replace(/ç/g,"c").replace(/ğ/g,"g").replace(/ı/g,"i").replace(/ö/g,"o").replace(/ş/g,"s").replace(/ü/g,"u").normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[–—−]/g,"-").replace(/\s*-\s*(?=\d)/g,"-").replace(/[^\p{L}\p{N}\- ]/gu," ").replace(/\s+/g," ").trim();
function searchIndex(){if(SIX)return SIX;const I=[],push=(kind,label,sub,hay,act,b)=>I.push({kind,label,sub,lab:sn(label),hay:sn(label+" "+(sub||"")+" "+String(hay||"").replace(/(\d{4})-(\d{2})(?:-(\d{2}))?/g,"$1 $2 $3")),act,b});
  ppIndex().forEach(e=>push("p",e.n,[...e.b].map(b=>t(SPORTS[b].label)).join(" · "),"",{player:e.n}));
  Object.entries(SPORTS).forEach(([b,S])=>{(S.games||[]).forEach((g,i)=>push("g",g.res?`${g.home} ${g.res} ${g.away}`:t(g.title),`${t(g.comp)} · ${fmtDate(g.date)} · ${t(S.label)}`,`${g.comp} ${g.date} ${g.note} ${g.tag}`,{b,tb:"games",i},b));
    (S.history||[]).forEach((h,i)=>push("h",`${h[0]} · ${t(h[1])}`,t(S.label),`${h[1]} ${h[2]}`,{b,tb:"history",i},b));
    (S.trophies||[]).forEach((x,i)=>push("t",`${x[0]} × ${t(x[1])}`,`${t(S.label)} · ${t(x[2])}`,x[1]+" "+x[2],{b,tb:"trophies"},b))});
  SEASON_POS.forEach(([s,pos])=>{if(+s.slice(0,4)>=1959)push("s",`${s} · ${t("Süper Lig")}`,pos===1?t("Champions"):tf("Finished {p}",{p:ordL(pos)}),"season sezon",{b:"football",tb:"history"},"football")});
  [["basketball",MB_LINEUPS],["womens-basketball",WB_LINEUPS]].forEach(([b,LS])=>LS.forEach(L=>push("g",`${L.label} · ${L.title}`,`${t("vs")} ${L.opp} · ${L.score} · ${t(SPORTS[b].label)}`,`${L.date} ${L.where}`,{b,play:"lineup",lu:L.id},b)));
  HOME_BR.forEach(b=>{const L=LIVE[b];if(!L)return;L.last.forEach(r=>push("m",`Fenerbahçe ${r[4]}–${r[5]} ${r[3]}`,`${t(r[1])} · ${r[0]?mDate(r[0],true):t(r[6]||"")} · ${t(SPORTS[b].label)}`,`${r[0]} ${r[6]||""}`,{b,tb:"matches"},b))});
  runExt("search",I,push);SIX=I;return I}
const SKIND={p:"Players",g:"Big games and finals",m:"This season's results",h:"History",t:"Trophies",s:"Seasons"};
function runSearch(q){const toks=sn(q).split(/\s+/).filter(Boolean);if(!toks.length)return [];const lq=sn(q);
  const scRx=toks.filter(k=>/^\d+-\d+$/.test(k)).map(k=>new RegExp("(^|[^\\d])"+k+"($|[^\\d])"));
  return searchIndex().map(it=>{if(!toks.every(k=>/^\d+-\d+$/.test(k)||it.hay.includes(k))||!scRx.every(r=>r.test(it.lab)||r.test(it.hay.replace(/\d{4} \d{2} \d{2}/g,""))))return null;let sc=0;const l=sn(it.label);if(l.startsWith(lq))sc+=5;if(l.includes(lq))sc+=3;if(it.kind==="p")sc+=2;if(it.b===current)sc+=1;return {it,sc}}).filter(Boolean).sort((a,b)=>b.sc-a.sc).slice(0,40).map(x=>x.it)}
function openSearch(){ovOpen(`<div class="srch"><h2>${t("Search")}</h2><input id="sq" type="search" autocomplete="off" placeholder="${t("Players, seasons, finals, scores…")}" aria-label="${t("Search")}"><p class="fine">${t("Try a name, a year, a competition or a score like 6–0.")}</p><div id="sres" aria-live="polite"></div></div>`,t("Search"));
  const inp=$("sq");let tm=null;inp.addEventListener("input",()=>{clearTimeout(tm);tm=setTimeout(()=>showResults(inp.value),120)});
  inp.addEventListener("keydown",e=>{if(e.key==="Enter"){const f=$("sres").querySelector("[data-sr]");if(f)f.click()}})}
let SRES=[];
function showResults(q){const R=runSearch(q);SRES=R;const box=$("sres");if(!q.trim()){box.innerHTML="";return}
  if(!R.length){box.innerHTML=`<p class="muted">${t("Nothing found.")}</p>`;return}
  const groups={};R.forEach((it,i)=>{(groups[it.kind]=groups[it.kind]||[]).push([it,i])});
  box.innerHTML=Object.entries(groups).map(([k,L])=>`<section><h4 class="mh">${t(SKIND[k])}</h4><ul class="sreslist">${L.slice(0,8).map(([it,i])=>`<li><button data-sr="${i}"><b>${esc(it.label)}</b><span>${esc(it.sub||"")}</span></button></li>`).join("")}</ul></section>`).join("");
  box.querySelectorAll("[data-sr]").forEach(x=>x.onclick=()=>{const a=SRES[+x.dataset.sr].act;if(a.player){playerPage(a.player);return}
    if(a.play){ovClose();playSel[a.b]=a.play;if(a.lu)luS[a.b]={id:a.lu,found:new Set(),hints:new Set(),wrong:0,ended:false,msg:"",cls:""};setSport(a.b,true);setTimeout(()=>$("tabs").scrollIntoView({behavior:"smooth"}),40);return}
    goItem(a.b,a.tb,a.i)})}

/* ---------- 8. Real data and estimates ---------- */
function dchip(kind,txt){return kind==="real"?`<span class="dchip real" title="${esc(t("Taken from the sources listed on the page."))}">${esc(txt||t("Real data"))}</span>`:`<span class="dchip est" title="${esc(t("Made up for the games on this site."))}">${esc(txt||t("Estimate"))}</span>`}

/* ---------- hooks into the page ---------- */
$("hSearch").addEventListener("click",openSearch);
EXT.afterPanel.push((p,s)=>{const h2=p.querySelector("h2");
  if(h2&&!h2.querySelector(".dchip")&&tab!=="play")h2.insertAdjacentHTML("beforeend"," "+(tab==="squad"&&SQUADS[current]&&/2025/.test(SQUADS[current].asof||"")?dchip("est",t("Older list")):dchip("real")));
  if(tab==="trophies"){const c=p.querySelector(".cabinet");if(c)c.insertAdjacentHTML("beforebegin",trophyChart(current))}
  if(tab==="derbies"){const r=p.querySelector(".rleg");if(r)r.insertAdjacentHTML("afterend",derbyOverview())}
  if(tab==="games"){const list=s.games.filter(g=>gameFilter==="All"||g.tag===gameFilter);p.querySelectorAll(".games .game").forEach((el,k)=>el.dataset.hk="games-"+s.games.indexOf(list[k]))}
  if(tab==="history")p.querySelectorAll(".timeline > li").forEach((el,k)=>el.dataset.hk="history-"+k);
  if(tab==="squad")p.querySelectorAll(".sqlist .nm").forEach(el=>{const n=el.textContent;el.innerHTML=`<button class="pname" data-player="${esc(n)}">${esc(n)}</button>`});
  if(typeof kanRender==="function"&&KAN&&KAN.open)kanRender()});
/* the draft and penalty games carry an "Estimate" label: their ratings are made up */
EXT.play.push((p,g)=>{const h=document.querySelector("#gameArea h2");if(h&&["draft","draft5","draft6","draft11","penalties","ft","serve"].includes(g)&&!h.querySelector(".dchip"))h.insertAdjacentHTML("beforeend"," "+dchip("est",t("Fan ratings")))});

/* Fenerbahçe in UEFA competitions, 1959–60 to 2026–27 qualifying. Source: Wikipedia, 'Fenerbahçe S.K. in European football' (record table as of 27 August 2026). Rows: [season, competition, round, opponent, country, Fenerbahçe home score, away score, extra] — scores are always Fenerbahçe first. */
const EU_TIES=[["1959–60","EC","Preliminary","Csepel SC","Hungary","1-1","3-2",""],["1959–60","EC","Round of 16","OGC Nice","France","2-1","1-2","replay 1-5"],["1961–62","EC","First round","1. FC Nürnberg","Germany","1-2","0-1",""],["1963–64","CWC","First round","Petrolul Ploiești","Romania","4-1","0-1",""],["1963–64","CWC","Second round","Linfield","Northern Ireland","4-1","0-2",""],["1963–64","CWC","Quarter-finals","MTK Budapest","Hungary","3-1","0-2","replay 0-1"],["1964–65","EC","Preliminary","AFC DWS","Netherlands","0-1","1-3",""],["1965–66","EC","Preliminary","RSC Anderlecht","Belgium","0-0","1-5",""],["1968–69","EC","First round","Manchester City","England","2-1","0-0",""],["1968–69","EC","Second round","AFC Ajax","Netherlands","0-2","0-2",""],["1970–71","EC","First round","Carl Zeiss Jena","East Germany","0-4","0-1",""],["1971–72","UC","First round","Ferencvárosi TC","Hungary","1-1","1-3",""],["1972–73","UC","First round","Ruch Chorzów","Poland","1-0","0-3",""],["1973–74","UC","First round","FC Argeș Pitești","Romania","5-1","1-1",""],["1973–74","UC","Second round","OGC Nice","France","2-0","0-4",""],["1974–75","EC","First round","Jeunesse Esch","Luxembourg","2-0","3-2",""],["1974–75","EC","Second round","Ruch Chorzów","Poland","0-2","1-2",""],["1975–76","EC","First round","Benfica","Portugal","1-0","0-7",""],["1976–77","UC","First round","Videoton","Hungary","2-1","0-4",""],["1977–78","UC","First round","Aston Villa","England","0-2","0-4",""],["1978–79","EC","First round","PSV Eindhoven","Netherlands","2-1","1-6",""],["1979–80","CWC","First round","Arsenal","England","0-0","0-2",""],["1980–81","UC","First round","Beroe Stara Zagora","Bulgaria","0-1","1-2",""],["1983–84","EC","First round","Bohemians 1905","Czechoslovakia","0-1","0-4",""],["1984–85","UC","First round","Fiorentina","Italy","0-1","0-2",""],["1985–86","EC","First round","Bordeaux","France","0-0","3-2",""],["1985–86","EC","Round of 16","IFK Göteborg","Sweden","2-1","0-4",""],["1989–90","EC","First round","Sparta Prague","Czechoslovakia","1-2","1-3",""],["1990–91","UC","First round","Vitória Guimarães","Portugal","3-0","3-2",""],["1990–91","UC","Second round","Atalanta","Italy","0-1","1-4",""],["1992–93","UC","First round","Botev Plovdiv","Bulgaria","3-1","2-2",""],["1992–93","UC","Second round","Sigma Olomouc","Czechoslovakia","1-0","1-7",""],["1994–95","UC","Preliminary","Turan Tovuz","Azerbaijan","5-0","2-0",""],["1994–95","UC","First round","Cannes","France","1-5","0-4",""],["1995–96","UC","Preliminary","Partizani Tirana","Albania","2-0","4-0",""],["1995–96","UC","First round","Real Betis","Spain","1-2","0-2",""],["1996–97","UCL","Qualifying","Maccabi Tel Aviv","Israel","1-1","1-0",""],["1996–97","UCL","Group C","Juventus","Italy","0-1","0-2","G3"],["1996–97","UCL","Group C","Manchester United","England","0-2","1-0","G3"],["1996–97","UCL","Group C","Rapid Wien","Austria","1-0","1-1","G3"],["1997–98","UC","First round","Steaua București","Romania","1-2","0-0",""],["1998–99","UC","Second qualifying","IFK Göteborg","Sweden","1-0","1-2","away"],["1998–99","UC","First round","Parma","Italy","1-0","1-3",""],["1999–2000","UC","First round","MTK Budapest","Hungary","0-2","0-0",""],["2001–02","UCL","Third qualifying","Rangers","Scotland","2-1","0-0",""],["2001–02","UCL","Group F","Barcelona","Spain","0-3","0-1","G4"],["2001–02","UCL","Group F","Bayer Leverkusen","Germany","1-2","1-2","G4"],["2001–02","UCL","Group F","Lyon","France","0-1","1-3","G4"],["2002–03","UCL","Third qualifying","Feyenoord","Netherlands","0-2","0-1",""],["2002–03","UC","First round","AIK","Sweden","3-1","3-3",""],["2002–03","UC","Second round","Panathinaikos","Greece","1-1","1-4",""],["2004–05","UCL","Group D","Lyon","France","1-3","2-4","G3"],["2004–05","UCL","Group D","Manchester United","England","3-0","2-6","G3"],["2004–05","UCL","Group D","Sparta Prague","Czech Republic","1-0","1-0","G3"],["2004–05","UC","Round of 32","Real Zaragoza","Spain","0-1","1-2",""],["2005–06","UCL","Group E","AC Milan","Italy","0-4","1-3","G4"],["2005–06","UCL","Group E","PSV Eindhoven","Netherlands","3-0","0-2","G4"],["2005–06","UCL","Group E","Schalke 04","Germany","3-3","0-2","G4"],["2006–07","UCL","Second qualifying","B36 Tórshavn","Faroe Islands","4-0","5-0",""],["2006–07","UCL","Third qualifying","Dynamo Kyiv","Ukraine","2-2","1-3",""],["2006–07","UC","First round","Randers","Denmark","2-1","3-0",""],["2006–07","UC","Group H","Newcastle United","England","-","0-1","G3"],["2006–07","UC","Group H","Celta Vigo","Spain","-","0-1","G3"],["2006–07","UC","Group H","Palermo","Italy","3-0","-","G3"],["2006–07","UC","Group H","Eintracht Frankfurt","Germany","2-2","-","G3"],["2006–07","UC","Round of 32","AZ Alkmaar","Netherlands","3-3","2-2","awayout"],["2007–08","UCL","Third qualifying","Anderlecht","Belgium","1-0","2-0",""],["2007–08","UCL","Group G","Inter","Italy","1-0","0-3","G2"],["2007–08","UCL","Group G","PSV Eindhoven","Netherlands","2-0","0-0","G2"],["2007–08","UCL","Group G","CSKA Moscow","Russia","3-1","2-2","G2"],["2007–08","UCL","Round of 16","Sevilla","Spain","3-2","2-3","pens 3-2"],["2007–08","UCL","Quarter-finals","Chelsea","England","2-1","0-2",""],["2008–09","UCL","Second qualifying","MTK Budapest","Hungary","2-0","5-0",""],["2008–09","UCL","Third qualifying","Partizan","Serbia","2-1","2-2",""],["2008–09","UCL","Group G","Porto","Portugal","1-2","1-3","G4"],["2008–09","UCL","Group G","Arsenal","England","2-5","0-0","G4"],["2008–09","UCL","Group G","Dynamo Kyiv","Ukraine","0-0","0-1","G4"],["2009–10","UEL","Third qualifying","Honvéd","Hungary","5-1","1-1",""],["2009–10","UEL","Play-off","Sion","Switzerland","2-2","2-0",""],["2009–10","UEL","Group H","Twente","Netherlands","1-2","1-0","G1"],["2009–10","UEL","Group H","Sheriff Tiraspol","Moldova","1-0","1-0","G1"],["2009–10","UEL","Group H","Steaua București","Romania","3-1","1-0","G1"],["2009–10","UEL","Round of 32","Lille","France","1-1","1-2",""],["2010–11","UCL","Third qualifying","Young Boys","Switzerland","0-1","2-2",""],["2010–11","UEL","Play-off","PAOK","Greece","1-1","0-1",""],["2012–13","UCL","Third qualifying","Vaslui","Romania","1-1","4-1",""],["2012–13","UCL","Play-off","Spartak Moscow","Russia","1-1","1-2",""],["2012–13","UEL","Group C","Borussia Mönchengladbach","Germany","0-3","4-2","G1"],["2012–13","UEL","Group C","Marseille","France","2-2","1-0","G1"],["2012–13","UEL","Group C","AEL Limassol","Cyprus","2-0","1-0","G1"],["2012–13","UEL","Round of 32","BATE Borisov","Belarus","1-0","0-0",""],["2012–13","UEL","Round of 16","Viktoria Plzeň","Czech Republic","1-1","1-0",""],["2012–13","UEL","Quarter-finals","Lazio","Italy","2-0","1-1",""],["2012–13","UEL","Semi-finals","Benfica","Portugal","1-0","1-3",""],["2013–14","UCL","Third qualifying","Red Bull Salzburg","Austria","3-1","1-1",""],["2013–14","UCL","Play-off","Arsenal","England","0-3","0-2",""],["2015–16","UCL","Third qualifying","Shakhtar Donetsk","Ukraine","0-0","0-3",""],["2015–16","UEL","Play-off","Atromitos","Greece","3-0","1-0",""],["2015–16","UEL","Group A","Molde","Norway","1-3","2-0","G2"],["2015–16","UEL","Group A","Ajax","Netherlands","1-0","0-0","G2"],["2015–16","UEL","Group A","Celtic","Scotland","1-1","2-2","G2"],["2015–16","UEL","Round of 32","Lokomotiv Moscow","Russia","2-0","1-1",""],["2015–16","UEL","Round of 16","Braga","Portugal","1-0","1-4",""],["2016–17","UCL","Third qualifying","Monaco","France","2-1","1-3",""],["2016–17","UEL","Play-off","Grasshopper","Switzerland","3-0","2-0",""],["2016–17","UEL","Group A","Manchester United","England","2-1","1-4","G1"],["2016–17","UEL","Group A","Feyenoord","Netherlands","1-0","1-0","G1"],["2016–17","UEL","Group A","Zorya Luhansk","Ukraine","2-0","1-1","G1"],["2016–17","UEL","Round of 32","Krasnodar","Russia","1-1","0-1",""],["2017–18","UEL","Third qualifying","Sturm Graz","Austria","1-1","2-1",""],["2017–18","UEL","Play-off","Vardar","North Macedonia","1-2","0-2",""],["2018–19","UCL","Third qualifying","Benfica","Portugal","1-1","0-1",""],["2018–19","UEL","Group D","Dinamo Zagreb","Croatia","0-0","1-4","G2"],["2018–19","UEL","Group D","Spartak Trnava","Slovakia","2-0","0-1","G2"],["2018–19","UEL","Group D","Anderlecht","Belgium","2-0","2-2","G2"],["2018–19","UEL","Round of 32","Zenit","Russia","1-0","1-3",""],["2021–22","UEL","Play-off","HJK","Finland","1-0","5-2",""],["2021–22","UEL","Group D","Eintracht Frankfurt","Germany","1-1","1-1","G3"],["2021–22","UEL","Group D","Olympiacos","Greece","0-3","0-1","G3"],["2021–22","UEL","Group D","Antwerp","Belgium","2-2","3-0","G3"],["2021–22","UECL","Knockout play-offs","Slavia Prague","Czech Republic","2-3","2-3",""],["2022–23","UCL","Second qualifying","Dynamo Kyiv","Ukraine","1-2","0-0",""],["2022–23","UEL","Third qualifying","Slovácko","Czech Republic","3-0","1-1",""],["2022–23","UEL","Play-off","Austria Wien","Austria","4-1","2-0",""],["2022–23","UEL","Group B","Rennes","France","3-3","2-2","G1"],["2022–23","UEL","Group B","AEK Larnaca","Cyprus","2-0","2-1","G1"],["2022–23","UEL","Group B","Dynamo Kyiv","Ukraine","2-1","2-0","G1"],["2022–23","UEL","Round of 16","Sevilla","Spain","1-0","0-2",""],["2023–24","UECL","Second qualifying","Zimbru Chișinău","Moldova","5-0","4-0",""],["2023–24","UECL","Third qualifying","Maribor","Slovenia","3-1","3-0",""],["2023–24","UECL","Play-off","Twente","Netherlands","5-1","1-0",""],["2023–24","UECL","Group H","Ludogorets","Bulgaria","3-1","0-2","G1"],["2023–24","UECL","Group H","Nordsjælland","Denmark","3-1","1-6","G1"],["2023–24","UECL","Group H","Spartak Trnava","Slovakia","4-0","2-1","G1"],["2023–24","UECL","Round of 16","Union Saint-Gilloise","Belgium","0-1","3-0",""],["2023–24","UECL","Quarter-finals","Olympiacos","Greece","1-0","2-3","penslost 2-3"],["2024–25","UCL","Second qualifying","Lugano","Switzerland","2-1","4-3",""],["2024–25","UCL","Third qualifying","Lille","France","1-1","1-2",""],["2024–25","UEL","League phase","Union Saint-Gilloise","Belgium","2-1","-","L24"],["2024–25","UEL","League phase","Twente","Netherlands","-","1-1","L24"],["2024–25","UEL","League phase","Manchester United","England","1-1","-","L24"],["2024–25","UEL","League phase","AZ Alkmaar","Netherlands","-","1-3","L24"],["2024–25","UEL","League phase","Slavia Prague","Czech Republic","-","2-1","L24"],["2024–25","UEL","League phase","Athletic Club","Spain","0-2","-","L24"],["2024–25","UEL","League phase","Lyon","France","0-0","-","L24"],["2024–25","UEL","League phase","Midtjylland","Denmark","-","2-2","L24"],["2024–25","UEL","Knockout play-offs","Anderlecht","Belgium","3-0","2-2",""],["2024–25","UEL","Round of 16","Rangers","Scotland","1-3","2-0","penslost 2-3"],["2025–26","UCL","Third qualifying","Feyenoord","Netherlands","5-2","1-2",""],["2025–26","UCL","Play-off","Benfica","Portugal","0-0","0-1",""],["2025–26","UEL","League phase","Dinamo Zagreb","Croatia","-","1-3","L19"],["2025–26","UEL","League phase","Nice","France","2-1","-","L19"],["2025–26","UEL","League phase","VfB Stuttgart","Germany","1-0","-","L19"],["2025–26","UEL","League phase","Viktoria Plzeň","Czech Republic","-","0-0","L19"],["2025–26","UEL","League phase","Ferencváros","Hungary","1-1","-","L19"],["2025–26","UEL","League phase","Brann","Norway","-","4-0","L19"],["2025–26","UEL","League phase","Aston Villa","England","0-1","-","L19"],["2025–26","UEL","League phase","FCSB","Romania","-","1-1","L19"],["2025–26","UEL","Knockout play-offs","Nottingham Forest","England","0-3","2-1",""],["2026–27","UCL","Second qualifying","Górnik Zabrze","Poland","1-0","1-1",""],["2026–27","UCL","Third qualifying","Sturm Graz","Austria","2-0","1-0",""],["2026–27","UCL","Play-off","Lyon","France","1-1","2-1",""]];
const EU_TOTAL=[["UEFA Champions League",121,39,25,57,142,194],["UEFA Cup Winners' Cup",9,3,1,5,11,11],["UEFA Cup / Europa League",158,68,41,49,220,198],["UEFA Conference League",18,12,0,6,44,23]];

/* ===== Club records per branch. Football tables: Wikipedia "List of Fenerbahçe S.K. records and statistics"
   (official games: goals as of 31 October 2016, appearances as of 30 May 2019) and "List of Fenerbahçe S.K. footballers"
   (all matches, correct to 17 May 2026). Other branches use facts already sourced on this site. ===== */
const RECORDS={
 football:{lists:[
   {title:"All-time top scorers",note:"Official matches only, as listed by Wikipedia in 2016.",unit:"Goals",rows:[["Lefter Küçükandonyadis","1947–1951, 1953–1964",215],["Melih Kotanca","1938–1948",172],["Alex de Souza","2004–2013",171],["Aykut Kocaman","1988–1996",167],["Naci Bastoncu","1934–1947",162],["Cemil Turan","1972–1981",127],["Fikret Arıcan","1928–1947",109],["Ogün Altıparmak","1963–1971",89],["Şeref Has","1955–1969",89],["Semih Şentürk","2000–2013",86]]},
   {title:"Most appearances",note:"Official matches only, as listed by Wikipedia in 2019.",unit:"Games",rows:[["Müjdat Yetkiner","1979–1996",570],["Volkan Demirel","2002–2019",525],["Cem Pamiroğlu","1976–1987",396],["Şeref Has","1955–1969",382],["Rüştü Reçber","1994–2003, 2004–2007",381],["Gökhan Gönül","2007–2016, 2020–2021",361],["Lefter Küçükandonyadis","1947–1951, 1953–1964",349],["Ziya Şengül","1964–1976",342],["Alex de Souza","2004–2013",341],["Selçuk Şahin","2003–2015",326]]},
   {title:"Top scorers, all matches",note:"A wider count that includes the early decades, from Wikipedia's list of Fenerbahçe footballers (correct to 17 May 2026).",unit:"Goals",rows:[["Zeki Rıza Sporel","1915–1934",470],["Lefter Küçükandonyadis","1947–1951, 1953–1964",423],["Alaattin Baydar","1915–1934",362],["Naci Bastoncu","1934–1944",232],["Fikret Arıcan","1927–1947",231],["Melih Kotanca","1939–1948",204],["Cemil Turan","1972–1980",194],["Şeref Has","1955–1969",168],["Aykut Kocaman","1988–1996",166],["Alex de Souza","2004–2012",166]]},
   {title:"Most appearances, all matches",note:"A wider count that includes the early decades, from Wikipedia's list of Fenerbahçe footballers (correct to 17 May 2026).",unit:"Games",rows:[["Müjdat Yetkiner","1979–1995",763],["Lefter Küçükandonyadis","1947–1951, 1953–1964",615],["Şeref Has","1955–1969",605],["Volkan Demirel","2002–2019",525],["Cem Pamiroğlu","1976–1986",508],["Naci Erdem","1953–1963",440],["Ziya Şengül","1964–1975",426],["Nedim Günar","1949–1963",416],["Nedim Doğan","1961–1973",416],["Alpaslan Eratlı","1973–1983",414]]}],
  facts:[
   ["28","Turkish championships","A record, counting the national titles before the Süper Lig began in 1959."],
   ["99","Most points in a league season","2023–24, from 38 games, and still second behind Galatasaray."],
   ["103","Most league goals in a season","1988–89."],
   ["6","Fewest league goals conceded in a season","1969–70."],
   ["6","Most goals by one player in a league game","Tanju Çolak, in a 7–1 win over Karşıyaka in 1992–93."],
   ["8–0","Biggest league win","Against Eyüpspor on 20 September 2026. The club's records list had two 8–1 wins, over Samsunspor and Kayserispor."],
   ["10–3","Biggest Turkish Cup win","Against Alanyaspor on 23 January 2008."],
   ["5–0","Biggest European wins","Turan Tovuz (1994), B36 Tórshavn (2006, away), MTK Budapest (2008, away) and Zimbru Chișinău (2023)."],
   ["0–7","Heaviest European defeat","Away at Benfica in the 1975–76 European Cup."],
   ["1968","First European trophy for a Turkish club","The 1966–67 Balkans Cup, won in a play-off against AEK Athens in May 1968."]],
  src:[["Wikipedia: List of Fenerbahçe S.K. records and statistics","https://en.wikipedia.org/wiki/List_of_Fenerbah%C3%A7e_S.K._records_and_statistics"],["Wikipedia: List of Fenerbahçe S.K. footballers","https://en.wikipedia.org/wiki/List_of_Fenerbah%C3%A7e_S.K._footballers"]]},
 basketball:{facts:[
   ["2","EuroLeague titles","2017 in Istanbul and 2025 in Abu Dhabi."],
   ["5","Final Fours in a row","2015 to 2019, all under Željko Obradović. Eight Final Fours in all."],
   ["24","Most three-pointers in a EuroLeague game","A EuroLeague record, in a 118–88 win over Valencia on 14 March 2024."],
   ["2025","First Triple Crown by a Turkish team","EuroLeague, Turkish league and Turkish Cup in the same season."],
   ["2012","First Turkish club to beat an NBA team","On 5 October 2012."],
   ["16","Turkish league titles","The first in 1957, the latest in 2026."]],
  src:[["EuroLeague: Fenerbahçe hits 24 threes vs Valencia","https://www.euroleaguebasketball.net/euroleague/news/fenerbahce-beko-hits-24-threes-vs-valencia-basket-breaks-all-time-record"]]},
 "womens-basketball":{facts:[
   ["20","Turkish league titles","A national record, from 1999 to 2026."],
   ["35–0","Perfect league season","2023–24, the year of the second EuroLeague title."],
   ["46–1","Record season","2025–26: every trophy, including the third EuroLeague Women."],
   ["99–60","Biggest EuroLeague final win","Against ÇBK Mersin in Prague, 2023."],
   ["35","Most points in a EuroLeague final","Breanna Stewart, in the 2023 final."],
   ["2","Triple Crowns","2024 and 2026."]]},
 volleyball:{facts:[
   ["2010","World champions without dropping a match","The FIVB Club World Championship in Doha."],
   ["2012","Champions of Europe","3–0 against RC Cannes in Baku. Kim Yeon-koung was MVP and top scorer."],
   ["2014","Two European cups in one day","The women won the CEV Cup and the men the CEV Challenge Cup, a first for a Turkish club."],
   ["15","Turkish league titles","Seven of them in the current league format."],
   ["1928","One of Turkey's first women's teams","Founded by Sabiha Gürayman, later Turkey's first female civil engineer."]]},
 "mens-volleyball":{facts:[
   ["3","League titles in a row","2010, 2011 and 2012."],
   ["5","Turkish league titles","2008, 2010, 2011, 2012 and 2019."],
   ["2014","European trophy","The CEV Challenge Cup, 3–0 against Andreoli Latina in Istanbul."],
   ["9","Years from the fourth division to the top flight","Refounded in 1976, in the national league by 1985."],
   ["3","League finals lost since 2013","2013–14, 2020–21 and 2023–24."],
   ["1927","First men's team","Aziz Torun was the first head coach."]],
  src:[["Wikipedia: Fenerbahçe S.K. (men's volleyball)","https://en.wikipedia.org/wiki/Fenerbah%C3%A7e_S.K._(men%27s_volleyball)"]]},
 "womens-football":{lists:[
   {title:"Top scorers, 2025–26",note:"The first title-winning season.",unit:"Goals",rows:[["Andrea Stašková","2025–26",20],["Yağmur Uraz","2025–26",16],["María Paula Salas","2025–26",15],["Flourish Sabastine","2025–26",12],["Busem Şeker","2025–26",8],["Marta Cox","2025–26",7],["Zeynep Kerimoğlu","2025–26",7],["Ece Türkoğlu","2025–26",6]]}],
  facts:[
   ["2026","First league title","Confirmed on 10 May 2026, with two rounds to spare."],
   ["83","Points in the title season","27 wins, 2 draws and 1 defeat from 30 games in 2025–26."],
   ["136–9","Goals for and against, 2025–26","136 scored and only 9 conceded in 30 league games."],
   ["18–0","Biggest win","Against ALG Spor on 25 January 2026. The away game at ALG Spor that season ended 15–0."],
   ["12–0","Biggest win of 2026–27 so far","Against Şile BilgiDoğa in September 2026, with a hat-trick from Andrea Stašková."],
   ["5–1","First European tie won","On aggregate against Minsk, Women's Europa Cup 2026–27."]],
  src:[["Wikipedia: 2025–26 Fenerbahçe S.K. (women's football) season","https://en.wikipedia.org/wiki/2025%E2%80%9326_Fenerbah%C3%A7e_S.K._(women%27s_football)_season"]]}};

/* ===== v13: calendar file, fan league, player ratings, season board, challenges, career mode, records, Europe, match pages ===== */
const BR_CODE={football:"FB",basketball:"MB","womens-basketball":"WB",volleyball:"WV","mens-volleyball":"MV","womens-football":"WF"};
const BR_OF_CODE=Object.fromEntries(Object.entries(BR_CODE).map(([b,c])=>[c,b]));
const p2=v=>String(v).padStart(2,"0");

/* ---------- new tabs: Records (all branches) and In Europe (football) ---------- */
EXT.tabs.push((id,T)=>{if(id==="more")return;const i=T.findIndex(x=>x[0]==="trophies");if(RECORDS[id])T.splice(i+1,0,["records","Records"]);if(id==="football")T.splice(i+2,0,["europe","In Europe"])});
EXT.panels.records=p=>renderRecords(p);
EXT.panels.europe=p=>renderEurope(p);
EXT.afterPanel.push(p=>{if(tab==="matches")matchesExtras(p)});

/* ---------- Records ---------- */
function renderRecords(p){const R=RECORDS[current],s=SPORTS[current];
  const facts=`<div class="recfacts">${R.facts.map(([v,k,d])=>`<article class="card recfact"><b class="rv">${esc(v)}</b><h3>${esc(t(k))}</h3><p>${esc(t(d))}</p></article>`).join("")}</div>`;
  const lists=(R.lists||[]).map(L=>`<article class="card reclist"><span class="label">${esc(t(L.title))}</span><p class="fine">${esc(t(L.note))}</p><ol>${L.rows.map(([n,y,v],i)=>`<li><span class="rk">${i+1}</span><span class="nm"><button class="pname" data-player="${esc(n)}">${esc(n)}</button><small>${esc(y)}</small></span><b>${v}</b></li>`).join("")}</ol><span class="fine">${esc(t(L.unit))}</span></article>`).join("");
  p.innerHTML=`<h2>${t("Records")} ${dchip("real")}</h2><p class="intro">${esc(tf("The numbers that stand out in the history of {x} at Fenerbahçe.",{x:lbl(s)}))}</p>${facts}${lists?`<div class="reclists">${lists}</div>`:""}
   ${R.src?`<p class="fine srcs">${t("Sources")}: ${R.src.map(([n,u])=>`<a href="${u}" target="_blank" rel="noopener">${esc(n)}</a>`).join(" · ")}</p>`:""}`}

/* match reports: a plain English string, or {en,tr,de,es,fr,ar} written by the data refresh */
const repTxt=r=>!r?"":typeof r==="string"?t(r):(r[LANG]||r.en||"");
/* ---------- In Europe (football) ---------- */
const EU_COMP={EC:"European Cup",CWC:"Cup Winners' Cup",UC:"UEFA Cup",UCL:"Champions League",UEL:"Europa League",UECL:"Conference League"};
const euSc=s=>s==="–"||!s?null:s.split("-").map(Number);
function euTie(r){const [,,,,,h,a,ex]=r,H=euSc(h),A=euSc(a);
  if(/^G\d/.test(ex))return {k:"grp",txt:tf("Group: {p}",{p:ordL(+ex.slice(1))})};
  if(/^L\d/.test(ex))return {k:"grp",txt:tf("League phase: {p}",{p:ordL(+ex.slice(1))})};
  const f=(H?H[0]:0)+(A?A[0]:0),o=(H?H[1]:0)+(A?A[1]:0);let win=f>o,how="";
  if(/^replay/.test(ex)){const x=ex.split(" ")[1].split("-").map(Number);win=x[0]>x[1];how=tf("replay {s}",{s:ex.split(" ")[1].replace("-","–")})}
  else if(/^pens/.test(ex)){const x=ex.split(" ")[1];win=ex.startsWith("pens ");how=tf("{s} on penalties",{s:x.replace("-","–")})}
  else if(ex==="away"){win=true;how=t("away goals")}else if(ex==="awayout"){win=false;how=t("away goals")}
  return {k:win?"W":"L",agg:`${f}–${o}`,txt:t(win?"Through":"Out"),how}}
function euRows(){const live=(LIVE.football.last||[]).filter(r=>r[1]==="Champions League"&&/^League phase/.test(r[6]||"")).reverse().map(r=>["2026–27","UCL","League phase",r[3],"",r[2]==="H"?`${r[4]}-${r[5]}`:"–",r[2]==="A"?`${r[4]}-${r[5]}`:"–","LIVE"]);return EU_TIES.concat(live)}
let euQ="",euC="All",euAll=false;
function renderEurope(p){const rows=euRows(),q=sn(euQ),list=rows.filter(r=>(euC==="All"||r[1]===euC||(euC==="UEL"&&r[1]==="UC")||(euC==="UCL"&&r[1]==="EC"))&&(!q||sn(r[3]+" "+r[4]+" "+r[0]).includes(q)));
  const tot=EU_TOTAL.reduce((a,r)=>a.map((v,i)=>v+(r[i+1]||0)),[0,0,0,0,0,0]),seasons=new Set(EU_TIES.map(r=>r[0])).size;
  const bySeason=[];list.forEach(r=>{let g=bySeason.find(x=>x.s===r[0]);if(!g){g={s:r[0],rows:[]};bySeason.push(g)}g.rows.push(r)});bySeason.reverse();const cut=!euAll&&!q&&euC==="All"&&bySeason.length>8,shownS=cut?bySeason.slice(0,8):bySeason;
  const opp=q&&list.length?(()=>{let W=0,D=0,L=0,F=0,A=0;list.forEach(r=>[r[5],r[6]].forEach(x=>{const s=euSc(x);if(!s)return;F+=s[0];A+=s[1];s[0]>s[1]?W++:s[0]<s[1]?L++:D++}));return `<p class="msg">${tf("Against your search: {p} games, {w} won, {d} drawn, {l} lost, goals {f}–{a}.",{p:W+D+L,w:W,d:D,l:L,f:F,a:A})}</p>`})():"";
  p.innerHTML=`<h2>${t("In Europe")} ${dchip("real")}</h2><p class="intro">${tf("Every European tie since Fenerbahçe first entered the European Cup in 1959. {n} seasons in UEFA competitions.",{n:seasons})}</p>
   <div class="msum">${[[tot[0],"Games"],[tot[1],"Won"],[tot[2],"Drawn"],[tot[3],"Lost"],[`${tot[4]}–${tot[5]}`,"Goals"]].map(([v,k])=>`<div class="mstat"><b>${v}</b><span>${esc(t(k))}</span></div>`).join("")}</div>
   <p class="fine">${t("Totals for UEFA competitions up to 27 August 2026, before this season's league phase.")}</p>
   <div class="eubar"><input id="euQ" type="search" placeholder="${t("Search an opponent, country or season…")}" aria-label="${t("Search an opponent, country or season…")}" value="${esc(euQ)}">
   <div class="filter" role="group" aria-label="${t("Competition")}">${[["All","All"],["UCL","European Cup / Champions League"],["UEL","UEFA Cup / Europa League"],["CWC","Cup Winners' Cup"],["UECL","Conference League"]].map(([k,l])=>`<button data-euc="${k}" aria-pressed="${k===euC}">${esc(t(l))}</button>`).join("")}</div></div>${opp}
   <div class="eulist">${shownS.map(g=>`<section class="card euseason"><h3><bdi>${g.s}</bdi></h3><table class="eut"><thead><tr><th>${t("Round")}</th><th>${t("Opponent")}</th><th>${t("Home")}</th><th>${t("Away")}</th><th></th></tr></thead><tbody>${g.rows.map(r=>{const T=r[7]==="LIVE"?{k:"grp",txt:t("This season")}:euTie(r);
     return `<tr><td><span class="label">${esc(t(EU_COMP[r[1]==="EC"?"EC":r[1]]))}</span><br>${esc(t(r[2]))}</td><td><b>${esc(r[3])}</b>${r[4]?`<small>${esc(t(r[4]))}</small>`:""}</td><td class="sc" data-l="${esc(t("Home"))}">${r[5].replace("-","–")}</td><td class="sc" data-l="${esc(t("Away"))}">${r[6].replace("-","–")}</td><td>${T.k==="grp"?`<span class="muted">${esc(T.txt)}</span>`:`<span class="chip ${T.k==="W"?"win":"loss"}">${esc(T.txt)}</span><small>${T.agg}${T.how?" · "+esc(T.how):""}</small>`}</td></tr>`}).join("")}</tbody></table></section>`).join("")||`<p class="muted">${t("Nothing found.")}</p>`}</div>${cut?`<button class="btn ghost" data-euall>${tf("Show all {n} seasons",{n:bySeason.length})}</button>`:""}
   <p class="fine srcs">${t("Sources")}: <a href="https://en.wikipedia.org/wiki/Fenerbah%C3%A7e_S.K._in_European_football" target="_blank" rel="noopener">Wikipedia: Fenerbahçe S.K. in European football</a>. ${t("Scores are shown with Fenerbahçe first.")}</p>`;
  const inp=$("euQ");let tm;inp.oninput=()=>{clearTimeout(tm);tm=setTimeout(()=>{euQ=inp.value;const pos=inp.selectionStart;renderEurope(p);const n=$("euQ");n.focus();try{n.setSelectionRange(pos,pos)}catch(e){}},180)};
  p.querySelectorAll("[data-euc]").forEach(b=>b.onclick=()=>{euC=b.dataset.euc;renderEurope(p)});const ea=p.querySelector("[data-euall]");if(ea)ea.onclick=()=>{euAll=true;renderEurope(p)}}

/* ---------- Match pages ---------- */
document.addEventListener("click",e=>{const m=e.target.closest("[data-mi]");if(!m||e.target.closest("a,button:not([data-mi])"))return;matchPage(m.dataset.mb||current,+m.dataset.mi)});
document.addEventListener("keydown",e=>{if((e.key==="Enter"||e.key===" ")&&e.target.matches&&e.target.matches("[data-mi]")){e.preventDefault();matchPage(e.target.dataset.mb||current,+e.target.dataset.mi)}});
function matchPage(b,i){matchPageRaw(b,i);runExt("matchPage",b,i)}
/* highlights: an official video page when the data refresh found one (details.hl = [[source, url], ...]),
   otherwise a YouTube search. Videos open on the broadcaster's own site; this page can't play them itself. */
const PLAY_ICON='<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="11" fill="currentColor" opacity=".18"/><path d="M10 8l6 4-6 4z" fill="currentColor"/></svg>';
function mpHighlights(b,r,d,T1,T2,s1,s2){const hl=(d.hl||[]).filter(x=>x&&/^https:\/\//.test(x[1]));
  const q=`${T1} ${s1}-${s2} ${T2} ${{basketball:"basketbol ","womens-basketball":"kadın basketbol ",volleyball:"kadın voleybol ","mens-volleyball":"erkek voleybol ","womens-football":"kadın futbol "}[b]||""}maç özeti ${String(r[0]||"").slice(0,4)}`.replace(/\s+/g," ").trim();
  const yt="https://www.youtube.com/results?search_query="+encodeURIComponent(q);
  return `<section class="mphl"><h4 class="mh">${t("Highlights")}</h4><div class="btns">${hl.map(([n,u])=>`<a class="btn hlbtn" href="${esc(u)}" target="_blank" rel="noopener">${PLAY_ICON}${esc(tf("Watch on {s}",{s:n}))} ↗</a>`).join("")}
    <a class="btn ${hl.length?"ghost":""} hlbtn" href="${yt}" target="_blank" rel="noopener">${PLAY_ICON}${t(hl.length?"More on YouTube":"Find highlights on YouTube")} ↗</a></div>
    <p class="fine">${t(hl.length?"Opens the broadcaster's page in a new tab.":"Opens a YouTube search in a new tab. Pick a video from an official channel, such as the club, the league or the broadcaster.")}</p></section>`}
function matchPageRaw(b,i){const L=LIVE[b];if(!L)return;const r=L.last[i];if(!r)return;const d=r[7]||{},o=outcome(r),home=r[2]!=="A",key=xKey(b,r[0],r[3]);
  const T1=home?"Fenerbahçe":r[3],T2=home?r[3]:"Fenerbahçe",s1=home?r[4]:r[5],s2=home?r[5]:r[4];
  const scl=(list)=>list&&list.length?`<ul class="scorers">${list.map(([n,m])=>`<li><bdi>${esc(n)}</bdi>${m?` <bdi class="muted">${esc(m)}</bdi>`:""}</li>`).join("")}</ul>`:"";
  const fbS=scl(d.fb),opS=scl(d.op),sc1=home?fbS:opS,sc2=home?opS:fbS;
  /* fans */
  const preds=Object.values(xAllDocs("predictions",xPreds(),"p")).map(p=>p&&p[key]).filter(Boolean),exact=preds.filter(([a,c])=>a===+r[4]&&c===+r[5]).length,right=preds.filter(([a,c])=>Math.sign(a-c)===Math.sign(r[4]-r[5])).length;
  const votes={};Object.values(xAllDocs("motm",xVotes(),"v")).forEach(v=>{if(v&&v[key])votes[v[key]]=(votes[v[key]]||0)+1});const topV=Object.entries(votes).sort((a,c)=>c[1]-a[1]).slice(0,3);
  const avg=ratingAverages(key).slice(0,5);
  const fans=[preds.length?`<p>${tf(preds.length===1?"1 fan predicted this match: {r} got the result right, {e} the exact score.":"{n} fans predicted this match: {r} got the result right, {e} the exact score.",{n:preds.length,r:right,e:exact})}</p>`:"",
    topV.length?`<p><b>${t("Player of the match vote")}:</b> ${topV.map(([n,c])=>`${esc(n)} (${c})`).join(", ")}</p>`:"",
    avg.length?`<p><b>${t("Best fan ratings")}:</b> ${avg.map(x=>`${esc(x.n)} ${x.a.toFixed(1)}`).join(", ")}</p>`:""].join("");
  const nav=`<div class="btns mpnav">${L.last[i+1]?`<button class="btn ghost" data-mpgo="${i+1}">← ${t("Previous match")}</button>`:""}${i>0?`<button class="btn ghost" data-mpgo="${i-1}">${t("Next match")} →</button>`:""}</div>`;
  ovOpen(`<article class="mp"><span class="label">${esc(t(SPORTS[b].label))} · ${esc(t(r[1]))}${r[6]&&r[0]?" · "+esc(t(r[6])):""}</span>
    <div class="mpscore"><div class="${T1==="Fenerbahçe"?"fb":""}"><b>${esc(T1)}</b>${sc1}</div><div class="mpres"><span>${s1}<em>–</em>${s2}</span><span class="fo ${o}">${t("res:"+o)}</span></div><div class="${T2==="Fenerbahçe"?"fb":""}"><b>${esc(T2)}</b>${sc2}</div></div>
    <dl class="ppfacts"><div><dt>${t("Date")}</dt><dd>${r[0]?mDate(r[0]):"–"}</dd></div><div><dt>${t("Venue")}</dt><dd>${esc(d.v||(r[2]==="H"&&VENUES[b]?VENUES[b].name:t(r[2]==="A"?"Away":"Neutral venue")))}</dd></div><div><dt>${t("Competition")}</dt><dd>${esc(t(r[1]))}</dd></div></dl>
    ${d.rep?`<section><h4 class="mh">${t("Match report")}</h4><p>${esc(repTxt(d.rep))}</p>${d.src?`<p class="fine">${t("Source")}: <a href="${d.src[1]}" target="_blank" rel="noopener">${esc(d.src[0])}</a></p>`:""}</section>`:`<section><p class="fine">${t("Scorers and a report are added for the latest football matches when the site is refreshed.")}</p></section>`}
    ${mpHighlights(b,r,d,T1,T2,s1,s2)}
    ${fans?`<section><h4 class="mh">${t("What the fans said")}</h4>${fans}</section>`:""}${nav}</article>`,`${T1} ${s1}–${s2} ${T2}`);
  document.querySelectorAll("[data-mpgo]").forEach(x=>x.onclick=()=>matchPage(b,+x.dataset.mpgo))}

/* ---------- Matches tab extras: calendar file, player ratings ---------- */
function matchesExtras(p){const L=LIVE[current];if(!L)return;const up=L.next.filter(n=>n[0]&&n[0]>=todayISO());
  if(up.length&&!p.querySelector(".calall"))p.insertAdjacentHTML("beforeend",`<article class="card calall"><div><span class="label">${t("Calendar")}</span><h3>${tf("All {n} upcoming fixtures in one file",{n:up.length})}</h3><p class="muted">${t("A CSV file you can import into Google Calendar or Outlook. Times are converted to your time zone.")}</p></div><button class="btn ghost" data-calcsv="${current}" ${XC.dl?"":"disabled"}>${t("Download fixtures (CSV)")}</button>${XC.dl?"":`<p class="fine">${t("Downloads aren't available in this view.")}</p>`}</article>`)}
document.addEventListener("click",e=>{const c=e.target.closest("[data-calcsv]");if(c)saveFixturesCsv(c.dataset.calcsv,c)});
function fixturesCsv(brs){const today=todayISO(),q=v=>`"${String(v).replace(/"/g,'""')}"`,us=d=>`${p2(d.getMonth()+1)}/${p2(d.getDate())}/${d.getFullYear()}`,tm=d=>{let h=d.getHours(),ap=h>=12?"PM":"AM";h=h%12||12;return `${p2(h)}:${p2(d.getMinutes())} ${ap}`};
  const rows=[["Subject","Start Date","Start Time","End Date","End Time","All Day Event","Location","Description"]];
  brs.forEach(b=>(LIVE[b]?LIVE[b].next:[]).forEach(n=>{if(!n[0]||n[0]<today)return;const [Y,M,D]=n[0].split("-").map(Number),subj=(n[3]==="H"?`Fenerbahçe – ${n[4]}`:`${n[4]} – Fenerbahçe`)+` (${t(SPORTS[b].label)}, ${t(n[2])})`;
    if(n[1]){const [h,mi]=n[1].split(":").map(Number),s=new Date(Date.UTC(Y,M-1,D,h-3,mi)),e=new Date(s.getTime()+2*36e5);rows.push([subj,us(s),tm(s),us(e),tm(e),"False",n[3]==="H"&&VENUES[b]?VENUES[b].name:"",t("Unofficial Fenerbahçe fan page")])}
    else{const s=new Date(Y,M-1,D);rows.push([subj,us(s),"",us(s),"","True","",t("Kick-off time to be confirmed")])}}));
  return rows.map(r=>r.map(q).join(",")).join("\r\n")}
async function saveFixturesCsv(which,btn){if(!XC.dl)return;btn.disabled=true;const brs=which==="all"?HOME_BR:[which];
  try{await XC.dl.save({filename:`fenerbahce-fixtures-${which}.csv`,data:"﻿"+fixturesCsv(brs)})}catch(e){if(e&&e.code&&!["declined","rate_limited"].includes(e.code))xToast(t("Downloads aren't available in this view."))}btn.disabled=false}

/* player ratings (1–10) for the latest match */
const xRates=()=>store.get("fb-ratings",{});
function ratingAverages(key){const all=xAllDocs("ratings",xRates(),"r"),sum={};Object.values(all).forEach(m=>{const x=m&&m[key];if(!x)return;Object.entries(x).forEach(([n,v])=>{v=+v;if(!(v>=1&&v<=10))return;const s=sum[n]||(sum[n]={n,t:0,c:0});s.t+=v;s.c++})});
  return Object.values(sum).map(s=>({n:s.n,a:s.t/s.c,c:s.c})).sort((a,b)=>b.a-a.a||b.c-a.c)}
EXT.comm.push(()=>{const el=document.getElementById("commBox");if(!el)return;const L=XM.L,li=L.last.findIndex(r=>r[0]),last=L.last[li];if(!last)return;
  const key=xKey(current,last[0],last[3]),mine=xRates()[key]||{},avg=ratingAverages(key),names=motmNames(current).filter(n=>n&&n.length<40);
  const card=document.createElement("article");card.className="card commcard ratecard";
  card.innerHTML=`<span class="label">${t("Fan ratings")}</span><h3>${t("Rate the players")}</h3><p class="muted">${tf("Give the players a mark from 1 to 10 for Fenerbahçe {a}–{b} {o}.",{a:last[4],b:last[5],o:esc(last[3])})} <button class="linkbtn" data-mi="${li}" data-mb="${current}">${t("Match details")} →</button></p>
   ${avg.length?`<ol class="tally rates">${avg.slice(0,8).map(x=>`<li><span>${esc(x.n)}</span><i style="width:${x.a*10}%"></i><b>${x.a.toFixed(1)}</b><small>${tf(x.c===1?"1 vote":"{n} votes",{n:x.c})}</small></li>`).join("")}</ol>`:`<p class="fine">${t("No ratings yet. Be the first to rate the players.")}</p>`}
   <details ${Object.keys(mine).length?"":"open"}><summary>${t(Object.keys(mine).length?"Change your ratings":"Your ratings")}</summary><div class="rategrid">${names.map((n,i)=>`<label><span>${esc(n)}</span><select data-rate="${i}"><option value="">–</option>${[...Array(10)].map((_,k)=>`<option ${+mine[n]===k+1?"selected":""}>${k+1}</option>`).join("")}</select></label>`).join("")}</div>
   <div class="btns"><button class="btn" id="rSave">${t("Save ratings")}</button></div></details>`;
  el.querySelector(".comm").appendChild(card);
  card.querySelector("#rSave").onclick=async()=>{const R=xRates(),m={};card.querySelectorAll("[data-rate]").forEach(s=>{if(s.value)m[names[+s.dataset.rate]]=+s.value});if(!Object.keys(m).length)return;R[key]=m;
    const keys=Object.keys(R);if(keys.length>40)keys.slice(0,keys.length-40).forEach(k=>delete R[k]);store.set("fb-ratings",R);xFillComm();await xWrite("ratings",{r:R,ts:Date.now()});xFillComm();xBadgeCheck()}});

/* ---------- Club home: fan league + calendar + clickable results ---------- */
EXT.home.push(p=>{
  p.querySelectorAll(".hcard").forEach(c=>{const b=c.querySelector("[data-gosport]").dataset.gosport,L=LIVE[b];if(!L)return;const li=L.last.findIndex(r=>r[0]);const dd=c.querySelectorAll(".hrows dd")[1];if(dd&&li>=0){dd.classList.add("mclick");dd.dataset.mi=li;dd.dataset.mb=b;dd.tabIndex=0;dd.setAttribute("role","button")}});
  const fx=p.querySelector(".hfx");if(fx)fx.insertAdjacentHTML("afterend",`<div class="btns"><button class="btn ghost" data-calcsv="all" ${XC.dl?"":"disabled"}>${t("Download all fixtures (CSV)")}</button></div>`);
  const more=p.querySelector(".hmore");more.insertAdjacentHTML("beforebegin",`<section id="leagueBox" class="league"></section>`);fillLeague()});
let lgB="all",lgP="all";
/* "week": matches played in the last 7 days */
const lgCut=()=>{const d=new Date(Date.now()-6*864e5);return d.toISOString().slice(0,10)};
function lgTable(b,per){const R=xResults(),all=xAllDocs("predictions",xPreds(),"p"),cut=per==="week"?lgCut():"";return Object.entries(all).map(([id,p])=>{let pts=0,n=0,ex=0,rt=0;Object.entries(p||{}).forEach(([k,v])=>{if(b!=="all"&&!k.startsWith(b+"|"))return;if(cut&&k.split("|")[1]<cut)return;const s=xPoints(v,R[k]);if(s!=null){n++;pts+=s;if(s===3)ex++;if(s>=1)rt++}});return {id,pts,n,ex,rt}}).filter(r=>r.n>0).sort((a,b)=>b.pts-a.pts||b.ex-a.ex||a.n-b.n)}
function fillLeague(){const box=$("leagueBox");if(!box)return;const f=document.activeElement;if(f&&box.contains(f)&&f.tagName==="INPUT")return;
  const rows=lgTable(lgB,lgP),wk=lgTable("all","week")[0];xNames(rows.concat(wk?[wk]:[]).map(r=>r.id).filter(i=>i!=="me"));const P=xPreds(),R=xResults(),now=Date.now();
  const nameOf=r=>r.id==="me"?t("You"):xName(r.id);
  const open=[];HOME_BR.forEach(b=>{(LIVE[b]?LIVE[b].next:[]).filter(n=>n[0]).slice(0,2).forEach(n=>{const [Y,M,D]=n[0].split("-").map(Number),[h,mi]=(n[1]||"12:00").split(":").map(Number);if(now<Date.UTC(Y,M-1,D,h-3,mi))open.push({b,n})})});
  open.sort((a,c)=>(a.n[0]+a.n[1]).localeCompare(c.n[0]+c.n[1]));
  const mine=Object.entries(P).filter(([k])=>R[k]).map(([k,v])=>{const [b,d,o]=k.split("|");return {b,d,o,v,res:R[k],pts:xPoints(v,R[k])}}).sort((a,c)=>c.d.localeCompare(a.d)).slice(0,6);
  box.innerHTML=`<h3 class="mh" style="margin-top:28px">${t("Fan prediction league")}</h3><p class="intro">${t("Predict any upcoming Fenerbahçe match. 3 points for the exact score, 1 for the right result. The table counts every branch.")}</p><p class="livenote" data-livenote></p>
   ${wk&&wk.pts>0?`<p class="lgstar"><span aria-hidden="true">★</span> ${esc(tf("Top predictor of the last 7 days: {n}, with {p} points.",{n:nameOf(wk),p:wk.pts}))}</p>`:""}
   <div class="lggrid"><article class="card"><span class="label">${t("Table")}</span><select id="lgSel" class="lgsel" aria-label="${t("Branch")}">${["all",...HOME_BR].map(b=>`<option value="${b}" ${b===lgB?"selected":""}>${esc(b==="all"?t("All branches"):t(SPORTS[b].label))}</option>`).join("")}</select>
     <div class="filter lgper" role="group" aria-label="${t("Period")}"><button data-lgp="all" aria-pressed="${lgP==="all"}">${t("Whole season")}</button><button data-lgp="week" aria-pressed="${lgP==="week"}">${t("Last 7 days")}</button></div>
     ${rows.length?`<ol class="ptable big">${rows.slice(0,15).map((r,i)=>`<li class="${r.id===XC.me||r.id==="me"?"me":""}" data-uid="${esc(r.id)}"><span class="rk">${i+1}</span><span class="nm">${esc(r.id==="me"?t("You"):xName(r.id))}</span><span class="muted">${tf("{n} played · {e} exact",{n:r.n,e:r.ex})}</span><b>${r.pts}</b></li>`).join("")}</ol>${XC.dl?`<div class="btns"><button class="btn ghost sm" data-lgshare>${t("Save the table as an image")}</button></div>`:""}`
       :`<p class="empty">${t(!Object.keys(P).length?"Nobody is on the table yet. Be the first: predict one of the next games.":lgP==="week"?"None of your predicted matches were played in the last 7 days.":"Points appear once a predicted match has been played.")}</p>`}</article>
    <article class="card"><span class="label">${t("Predict the next games")}</span>${open.length?`<ul class="lgpred">${open.slice(0,8).map(({b,n})=>{const k=xKey(b,n[0],n[4]),m=P[k],hm=n[3]==="H",inp=(w,v)=>`<input type="number" min="0" max="199" inputmode="numeric" data-lgk="${esc(k)}" data-lgw="${w}" value="${v==null?"":v}" aria-label="${esc(w==="f"?"Fenerbahçe":n[4])}">`;
       return `<li style="--br:${BR_ACCENT[b]}"><div><span class="label">${mDate(n[0],true)}${n[1]?" · "+n[1]:""} · ${esc(t(SPORTS[b].label))}</span><b>${esc(hm?"Fenerbahçe":n[4])} – ${esc(hm?n[4]:"Fenerbahçe")}</b></div><div class="lgin">${hm?inp("f",m&&m[0])+"<span>–</span>"+inp("o",m&&m[1]):inp("o",m&&m[1])+"<span>–</span>"+inp("f",m&&m[0])}</div></li>`}).join("")}</ul>
       <div class="btns"><button class="btn" id="lgSave">${t("Save predictions")}</button><span class="msg" id="lgMsg" aria-live="polite"></span></div>`:`<p class="fine">${t("No upcoming fixtures in this snapshot.")}</p>`}</article>
    <article class="card"><span class="label">${t("Your recent predictions")}</span>${mine.length?`<ul class="lgmine">${mine.map(x=>`<li><span>${esc(t(SPORTS[x.b].label))} · ${esc(x.o)}</span><span class="muted">${tf("You said {a}–{b}, it ended {c}–{d}",{a:x.v[0],b:x.v[1],c:x.res[0],d:x.res[1]})}</span><b class="${x.pts===3?"good":x.pts?"":"muted"}">${tf(x.pts===1?"1 pt":"{n} pts",{n:x.pts})}</b></li>`).join("")}</ul>`:`<p class="fine">${t("Your scored predictions will show here.")}</p>`}</article></div>`;
  const ls=$("lgSel");if(ls)ls.onchange=()=>{lgB=ls.value;fillLeague()};
  box.querySelectorAll("[data-lgp]").forEach(x=>x.onclick=()=>{lgP=x.dataset.lgp;fillLeague();const f=box.querySelector(`[data-lgp="${lgP}"]`);if(f)f.focus()});
  const sh=box.querySelector("[data-lgshare]");if(sh)sh.onclick=e=>xShare({title:t("Fan prediction league"),sub:(lgB==="all"?t("All branches"):t(SPORTS[lgB].label))+" · "+t(lgP==="week"?"Last 7 days":"Whole season"),rows:rows.slice(0,8).map((r,i)=>[i+1,nameOf(r),r.pts])},e.currentTarget);
  if(typeof paintLiveNotes==="function")paintLiveNotes();
  const sv=$("lgSave");if(sv)sv.onclick=async()=>{const P2=xPreds(),pend={};box.querySelectorAll("[data-lgk]").forEach(i=>{const k=i.dataset.lgk;(pend[k]=pend[k]||{})[i.dataset.lgw]=i.value});
    let n=0;Object.entries(pend).forEach(([k,v])=>{const a=parseInt(v.f,10),c=parseInt(v.o,10);if(isNaN(a)||isNaN(c)||a<0||c<0)return;P2[k]=[a,c];n++});if(!n){$("lgMsg").textContent=t("Fill in both scores for at least one match.");return}
    store.set("fb-preds",P2);await xWrite("predictions",{p:P2,ts:Date.now()});xBadgeCheck();fillLeague();const m=$("lgMsg");if(m)m.textContent=tf(n===1?"1 prediction saved.":"{n} predictions saved.",{n})}}

/* ---------- Challenges: same options and same luck for everyone with the code ---------- */
function chParse(code){const m=String(code||"").trim().toUpperCase().match(/^(FB|MB|WB|WV|MV|WF)-(\d{2})-(\d{4,6})$/);if(!m)return null;const b=BR_OF_CODE[m[1]],y=2000+(+m[2]),season=`${y}-${String(y+1).slice(2)}`;
  if(!SZ_DATA[b]||!SZ_DATA[b][season])return null;return {b,season,seed:+m[3],code:`${m[1]}-${m[2]}-${m[3]}`}}
function chStart(c){CH={...c,rd:szRng(c.seed*7+1),rs:null};const b=c.b;szS[b]={sel:c.season};if(CR[b])CR[b]=null;if(b==="football"){clearInterval(cupTimer);newDraft(dr?dr.form:"4-3-3")}else newTD(b);store.set("fb-ch-last",c.code);renderPanel()}
const xChs=()=>store.get("fb-ch",{});
function chBox(){const b=current,code=CH&&CH.b===b?CH.code:null,res=code?chResults(code):[];xNames(res.map(r=>r.id).filter(i=>i!=="me"));
  return `<section class="card chbox" id="chBox"><div class="chhead"><span class="label">${t("Challenge a friend")}</span>${code?`<h3>${esc(code)}</h3><p class="muted">${tf("Season {s}. Everyone who plays this code gets the same draft options and the same luck in the games.",{s:szDash(CH.season)})}</p>`:`<p class="muted">${t("Create a code and send it to a friend. You both draft from the same options and play the same season with the same luck. Then compare.")}</p>`}</div>
   ${code?`<div class="btns"><button class="btn ghost" data-ch="copy">${t("Copy the code")}</button><button class="btn ghost" data-ch="leave">${t("Leave the challenge")}</button></div>
     ${res.length?`<ol class="ptable">${res.map((r,i)=>`<li class="${r.id===XC.me||r.id==="me"?"me":""}" data-uid="${esc(r.id)}"><span class="rk">${i+1}</span><span class="nm">${esc(r.id==="me"?t("You"):xName(r.id))}</span><span class="muted">${tf("League: {p}",{p:ordL(r.pos)})} · ${r.r.toFixed(1)}</span><b>${r.t} 🏆</b></li>`).join("")}</ol>`:`<p class="fine">${t("Nobody has finished this season yet. Be the first.")}</p>`}`
   :`<div class="btns chrow"><button class="btn" data-ch="new">${t("Create a challenge")}</button><input id="chIn" placeholder="${t("Have a code? e.g. FB-17-48213")}" aria-label="${t("Challenge code")}" maxlength="14"><button class="btn ghost" data-ch="join">${t("Play this code")}</button></div><p class="msg" id="chMsg" aria-live="polite"></p>`}</section>`}
function chResults(code){const out={};Object.entries(XC.docs.challenges||{}).forEach(([id,d])=>{const x=d&&d.c&&d.c[code];if(x)out[id]=x});const mine=xChs()[code];if(mine)out[XC.me||"me"]=mine;
  return Object.entries(out).map(([id,x])=>({id,...x})).sort((a,b)=>b.t-a.t||a.pos-b.pos||b.pts-a.pts)}
function chWire(root){const on=(k,f)=>{const x=root.querySelector(`[data-ch="${k}"]`);if(x)x.onclick=f};
  on("new",()=>{const b=current,list=szAllSeasons(b),season=szS[b]&&szS[b].sel||list[list.length-1],y=season.slice(2,4),seed=10000+Math.floor(Math.random()*89999);chStart({b,season,seed,code:`${BR_CODE[b]}-${y}-${seed}`})});
  on("join",()=>{const c=chParse($("chIn").value);if(!c){$("chMsg").textContent=t("That code doesn't look right. It should look like FB-17-48213.");return}if(c.b!==current){playSel[c.b]=PLAY[c.b].find(x=>/^draft/.test(x[0]))[0];setSport(c.b,true)}chStart(c)});
  on("copy",async()=>{try{await navigator.clipboard.writeText(CH.code);xToast(t("Code copied. Send it to a friend!"))}catch(e){xToast(CH.code)}});
  on("leave",()=>{const b=CH.b;CH=null;szS[b]=null;renderPanel()})}
function chRecord(S){const tro=szTrophies(S).length,lg=S.C[0],pos=lg.pos||99,pts=(S.line&&S.line.length?S.line[S.line.length-1][0]:0),C=xChs(),prev=C[S.ch],cur={t:tro,pos,pts,r:Math.round(S.my.r*10)/10,ts:Date.now()};
  if(!prev||cur.t>prev.t||(cur.t===prev.t&&cur.pos<prev.pos)){C[S.ch]=cur;const ks=Object.keys(C);if(ks.length>30)ks.sort((a,b)=>C[a].ts-C[b].ts).slice(0,ks.length-30).forEach(k=>delete C[k]);store.set("fb-ch",C);xWrite("challenges",{c:C,ts:Date.now()})}
  store.set("fb-ch-done",store.get("fb-ch-done",0)+1)}

/* ---------- Season board, career mode, share card (all hang off the season view) ---------- */
const CR={};
const xSzBest=()=>store.get("fb-sz-rec",{});
function szBetter(a,b){return !b||a.t>b.t||(a.t===b.t&&a.pos<b.pos)}
function szRecordBest(S){const b=S.b,R=xSzBest(),cur={t:szTrophies(S).length,pos:S.C[0].pos||99,s:S.season,r:Math.round(S.my.r*10)/10,c:S.career?1:0,ts:Date.now()};if(szBetter(cur,R[b])){R[b]=cur;store.set("fb-sz-rec",R);xWrite("seasons",{b:R,ts:Date.now()})}}
function szBoard(b){const out={};Object.entries(XC.docs.seasons||{}).forEach(([id,d])=>{const x=d&&d.b&&d.b[b];if(x)out[id]=x});const m=xSzBest()[b];if(m)out[XC.me||"me"]=m;
  return Object.entries(out).map(([id,x])=>({id,...x})).sort((a,c)=>c.t-a.t||a.pos-c.pos||c.ts-a.ts).slice(0,8)}
function szLiveBoards(){const el=document.getElementById("szBoard");if(el){const b=el.dataset.b;el.outerHTML=szBoardHtml(b)}const c=document.getElementById("chBox");if(c&&CH&&CH.b===current){const w=document.createElement("div");w.innerHTML=chBox();c.replaceWith(w.firstElementChild);chWire($("chBox"))}}
function szBoardHtml(b){const rows=szBoard(b);xNames(rows.map(r=>r.id).filter(i=>i!=="me"));
  return `<article class="card szboard" id="szBoard" data-b="${b}"><span class="label">${t("Fans' best seasons")}</span>${rows.length?`<ol class="ptable">${rows.map((r,i)=>`<li class="${r.id===XC.me||r.id==="me"?"me":""}" data-uid="${esc(r.id)}"><span class="rk">${i+1}</span><span class="nm">${esc(r.id==="me"?t("You"):xName(r.id))}</span><span class="muted">${szDash(r.s)} · ${tf("League: {p}",{p:ordL(r.pos)})}${r.c?" · "+t("career"):""}</span><b>${r.t} 🏆</b></li>`).join("")}</ol>${XC.dl?`<div class="btns"><button class="btn ghost sm" data-szshare="${b}">${t("Save the board as an image")}</button></div>`:""}`:`<p class="empty">${t("Nobody is on this board yet. Finish a season and be the first.")}</p>`}</article>`}
document.addEventListener("click",e=>{const x=e.target.closest("[data-szshare]");if(!x)return;const b=x.dataset.szshare,rows=szBoard(b);xShare({title:t("Fans' best seasons"),sub:t(SPORTS[b].label),rows:rows.slice(0,8).map((r,i)=>[i+1,(r.id==="me"?t("You"):xName(r.id))+" · "+szDash(r.s),r.t+" ×"])},x)});
function crTeam(b){if(b==="football"&&dr){const info=teamInfo(dr.form,dr.picks,dr.captain);return dr.picks.map((p,i)=>({n:p.n,pos:p.pos,r:info.eff[i],r0:info.eff[i],src:p}))}
  const C=TDCFG[b],s=tdS[b];if(!C||!s)return null;const info=tdInfo(C,s.picks);return s.picks.map((p,i)=>({n:p.n,pos:p.pos,r:info.eff[i],r0:info.eff[i],src:p}))}
const crOvr=c=>c.ovr0+c.ps.reduce((a,p)=>a+(p.r-p.r0),0)/c.ps.length;
function crPool(b){return b==="football"?PLAYERS:TDCFG[b].pool}
function crOffseason(c){const age=c.hist.length;c.ch=c.ps.map(p=>{const d=Math.round((Math.random()*3.2-1.6-Math.min(age,6)*.35)*10)/10;p.r=Math.round(clamp(p.r+d,60,99)*10)/10;return {n:p.n,d}});
  const weak=c.ps.reduce((a,p,i)=>p.r<c.ps[a].r?i:a,0),wp=c.ps[weak],used=new Set(c.ps.map(p=>p.n)),pool=crPool(c.b).filter(p=>!used.has(p.n)&&p.pos===wp.pos);
  c.offer={i:weak,list:shuffle(pool).slice(0,3).map(p=>({n:p.n,pos:p.pos,r:p.r,src:p}))};c.off=true}
function crNextSeason(c){const list=szAllSeasons(c.b),i=list.indexOf(c.season);return list[i+1]||null}
function renderOffseason(b,el,myR,myName,onNew){const c=CR[b],nx=crNextSeason(c),o=c.offer;
  el.innerHTML=`<div class="szhead"><div><span class="label">${t("Career mode")} · ${t("Off-season")}</span><h3>${esc(c.name)} · ${crOvr(c).toFixed(1)}</h3></div><span class="muted">${tf(c.hist.length===1?"1 season played":"{n} seasons played",{n:c.hist.length})}</span></div>
   <div class="szgrid"><article class="card"><span class="label">${t("How your players changed")}</span><ul class="crch">${c.ch.map(x=>`<li><span>${esc(x.n)}</span><b class="${x.d>0?"good":x.d<0?"bad":""}">${x.d>0?"+":""}${x.d.toFixed(1)}</b></li>`).join("")}</ul><p class="fine">${t("Players get a little older every season. Most improve less and decline more as the years go by.")}</p></article>
    <article class="card"><span class="label">${t("Transfer window")}</span>${o&&o.list.length?`<p>${tf("Your weakest player is {n} ({r}). Bring in a replacement, or keep the squad.",{n:esc(c.ps[o.i].n),r:c.ps[o.i].r.toFixed(1)})}</p><div class="cands2">${o.list.map((p,k)=>`<button class="cand2" data-cro="${k}"><span class="r">${p.r}</span><span class="info"><b>${esc(p.n)}</b><small>${esc(p.pos)}</small></span><span></span></button>`).join("")}</div>`:`<p class="muted">${t("No new players available this summer.")}</p>`}<div class="btns"><button class="btn ghost" data-cro="keep">${t("Keep the squad")}</button></div></article>
    <article class="card"><span class="label">${t("Career so far")}</span>${crHist(c)}</article></div>
   <div class="btns">${nx?`<button class="btn" data-cr="go">${esc(tf("Start {s}",{s:szDash(nx)}))}</button>`:`<p class="msg">${t("You have reached the present day. What a career!")}</p>`}<button class="btn ghost" data-cr="end">${t("End the career")}</button></div>`;
  el.querySelectorAll("[data-cro]").forEach(x=>x.onclick=()=>{if(x.dataset.cro!=="keep"){const p=o.list[+x.dataset.cro],old=c.ps[o.i];c.ps[o.i]={n:p.n,pos:p.pos,r:p.r,r0:old.r0,src:p};xToast(tf("{a} joins, {b} leaves.",{a:p.n,b:old.n}))}c.offer=null;renderOffseason(b,el,myR,myName,onNew)});
  const on=(k,f)=>{const x=el.querySelector(`[data-cr="${k}"]`);if(x)x.onclick=f};
  on("go",()=>{c.off=false;c.season=nx;const S=szNewSeason(b,nx,crOvr(c),c.name);S.career=true;szS[b]={sel:nx,S};szRender(b,el,myR,myName,onNew)});
  on("end",()=>{const tot=c.hist.reduce((a,h)=>a+h.t,0),k=SK(b,"career-best");if(tot>store.get(k,0))store.set(k,tot);CR[b]=null;szS[b]=null;xBadgeCheck();szRender(b,el,myR,myName,onNew)})}
function crHist(c){return `<ol class="crhist">${c.hist.map(h=>`<li><span>${szDash(h.s)}</span><span class="muted">${tf("League: {p}",{p:ordL(h.pos)})}</span><b>${h.t} 🏆</b></li>`).join("")}</ol><p class="muted">${(n=>n===1?t("Total: 1 trophy"):tf("Total: {n} trophies",{n}))(c.hist.reduce((a,h)=>a+h.t,0))}</p>`}
EXT.szPre.push((b,el,myR,myName,onNew)=>{if(CR[b]&&CR[b].off){renderOffseason(b,el,myR,myName,onNew);return true}return false});
EXT.szAfter.push((...a)=>szAfter(...a));
function szAfter(b,el,myR,myName,onNew){const st=szS[b],S=st&&st.S;if(!S)return;
  if(S.career){["again","other","new"].forEach(k=>{const x=el.querySelector(`[data-sz="${k}"]`);if(x)x.remove()});const h=el.querySelector(".szhead .label");if(h)h.textContent=`${t("Career mode")} · ${szDash(S.season)}`;
    if(!S.done){const bt=el.querySelector(".btns");if(bt){bt.insertAdjacentHTML("beforeend",`<button class="btn ghost" data-cr="quit">${t("End the career")}</button>`);bt.querySelector('[data-cr="quit"]').onclick=()=>{const c=CR[b];if(c){const tot=c.hist.reduce((a,h)=>a+h.t,0),k=SK(b,"career-best");if(tot>store.get(k,0))store.set(k,tot)}CR[b]=null;szS[b]=null;szRender(b,el,myR,myName,onNew)}}}}
  if(!S.done)return;
  if(!S.recorded){S.recorded=true;szRecordBest(S);if(S.ch)chRecord(S);const c=CR[b];if(S.career&&c)c.hist.push({s:S.season,t:szTrophies(S).length,pos:S.C[0].pos||99});xBadgeCheck()}
  const c=CR[b],extra=document.createElement("div");extra.className="szextra";
  extra.innerHTML=`${S.career&&c?`<article class="card"><span class="label">${t("Career mode")}</span>${crHist(c)}<div class="btns"><button class="btn" data-cr="off">${t("Go to the off-season")}</button><button class="btn ghost" data-cr="end2">${t("End the career")}</button></div></article>`
     :!S.ch?`<article class="card"><span class="label">${t("Career mode")}</span><p>${t("Keep this team together for the next season, and the one after. Players age, and each summer you can sign a replacement.")}</p><div class="btns">${crNextSeason({b,season:S.season})?`<button class="btn" data-cr="start">${t("Start a career from here")}</button>`:`<span class="muted">${t("Careers start from an earlier season, since this is the latest one.")}</span>`}</div></article>`:""}
    ${szBoardHtml(b)}${XC.dl?`<article class="card"><span class="label">${t("Share")}</span><p>${t("Save a picture of your season to post or send.")}</p><div class="btns"><button class="btn ghost" data-cr="img">${t("Save result image")}</button></div></article>`:""}`;
  const sum=el.querySelector(".szsum");(sum||el.querySelector(".btns")).insertAdjacentElement("afterend",extra);
  const on=(k,f)=>{const x=extra.querySelector(`[data-cr="${k}"]`);if(x)x.onclick=f};
  on("start",()=>{const ps=crTeam(b);if(!ps)return;CR[b]={b,name:S.my.n,ps,ovr0:S.my.r,season:S.season,hist:[{s:S.season,t:szTrophies(S).length,pos:S.C[0].pos||99}]};crOffseason(CR[b]);szRender(b,el,myR,myName,onNew)});
  on("off",()=>{crOffseason(CR[b]);szRender(b,el,myR,myName,onNew)});
  on("end2",()=>{const tot=c.hist.reduce((a,h)=>a+h.t,0),k=SK(b,"career-best");if(tot>store.get(k,0))store.set(k,tot);CR[b]=null;szS[b]=null;xBadgeCheck();szRender(b,el,myR,myName,onNew)});
  on("img",e=>xShare(szCard(S),extra.querySelector('[data-cr="img"]')))}
function szCard(S){const tro=szTrophies(S),sc=Object.entries(S.scorers||{}).sort((a,b)=>b[1]-a[1])[0];
  return {title:`${t(SPORTS[S.b].label)} · ${szDash(S.season)}`,big:`${tro.length} 🏆`,sub:[tro.length?tro.map(x=>t(x)).join(" · "):t("No trophies this time"),tf("League: {p}",{p:ordL(S.C[0].pos||0)}),`${S.my.n} ${S.my.r.toFixed(1)}`,sc?`${t("Top scorer")}: ${sc[0]} ${sc[1]}`:"",S.ch?`${t("Challenge")} ${S.ch}`:"",S.career?t("Career mode"):""].filter(Boolean).join(" · ")}}

/* challenge box in the draft games */
EXT.play.push((p,g)=>{const ga=document.getElementById("gameArea");if(!ga||!/^draft/.test(g||""))return;const intro=ga.querySelector(".intro");
  const w=document.createElement("div");w.innerHTML=chBox();const box=w.firstElementChild;(intro||ga.querySelector("h2")).insertAdjacentElement("afterend",box);chWire(box)});

/* ---------- leaderboard, badges, helper, search ---------- */
EXT.collect.push(o=>{o.szt=Math.max(0,...HOME_BR.map(b=>store.get(SK(b,"sz-best"),0)));o.car=Math.max(0,...HOME_BR.map(b=>store.get(SK(b,"career-best"),0)))});
BOARDS.splice(BOARDS.length-1,0,["szt","Season mode · most trophies"],["car","Career mode · most trophies"]);
BADGES.push(["career","Dynasty","Win 5 or more trophies in one career.",()=>HOME_BR.some(b=>store.get(SK(b,"career-best"),0)>=5)],
 ["challenge","Game on","Finish a challenge season.",()=>store.get("fb-ch-done",0)>0],
 ["rater","Pundit","Rate the players after a match.",()=>Object.keys(xRates()).length>0]);
Object.assign(KAN_CHIPS_TAB,{records:["Who scored the most goals for the club?","What is the biggest win ever?","Who played the most games?"],europe:["What was the best European run?","How often have we played Manchester United?","What was the heaviest European defeat?"]});
EXT.kan.push((id,o)=>{if(RECORDS[id])o.records=RECORDS[id];if(id==="football")o.european_ties_fenerbahce_score_first=euRows().map(r=>r.slice(0,7).join(" | "))});
EXT.search.push(I=>{const seen=new Set();
  EU_TIES.forEach(r=>{if(seen.has(r[3]))return;seen.add(r[3]);const n=EU_TIES.filter(x=>x[3]===r[3]).length;I.push({kind:"e",label:`${r[3]} · ${t("In Europe")}`,sub:`${t(r[4])} · ${tf(n===1?"1 tie":"{n} ties",{n})}`,lab:sn(r[3]),hay:sn(r[3]+" "+r[4]+" europe avrupa "+EU_TIES.filter(x=>x[3]===r[3]).map(x=>x[0]+" "+x[5]+" "+x[6]).join(" ")),act:{b:"football",tb:"europe",i:r[3]},b:"football"})});
  Object.keys(RECORDS).forEach(b=>I.push({kind:"t",label:`${t("Records")} · ${t(SPORTS[b].label)}`,sub:RECORDS[b].facts.slice(0,2).map(f=>t(f[1])).join(" · "),lab:sn("records"),hay:sn("records rekorlar "+RECORDS[b].facts.map(f=>f[0]+" "+f[1]+" "+f[2]).join(" ")),act:{b,tb:"records"},b}))});
SKIND.e="In Europe";

/* ---------- Everyone's predictions, match by match: hidden as –:– until the match is over ---------- */
let lgM=null;
/* a match counts as over once its result is in, or two hours after kick-off (three hours for an unknown time) */
function lgOver(b,d,o,R){if(R[xKey(b,d,o)])return true;const L=LIVE[b],n=L&&L.next.find(x=>x[0]===d&&x[4]===o),[Y,M,D]=d.split("-").map(Number);
  const [h,mi]=((n&&n[1])||"21:00").split(":").map(Number);return Date.now()>=Date.UTC(Y,M-1,D,h-3,mi)+2*36e5}
function lgVenue(b,d,o){const L=LIVE[b];if(!L)return "H";const r=L.last.find(x=>x[0]===d&&x[3]===o);if(r)return r[2];const n=L.next.find(x=>x[0]===d&&x[4]===o);return n?n[3]:"H"}
function lgMatches(){const all=xAllDocs("predictions",xPreds(),"p"),R=xResults(),M={};
  Object.values(all).forEach(p=>Object.keys(p||{}).forEach(k=>{const [b,d,o]=k.split("|");if(!b||!d||!o||!SPORTS[b])return;(M[k]=M[k]||{k,b,d,o,n:0}).n++}));
  const L=Object.values(M);L.forEach(m=>m.over=lgOver(m.b,m.d,m.o,R));
  const past=L.filter(m=>m.over).sort((a,c)=>c.d.localeCompare(a.d)).slice(0,12),soon=L.filter(m=>!m.over).sort((a,c)=>a.d.localeCompare(c.d)).slice(0,8);return {past,soon}}
function lgAllHtml(){const {past,soon}=lgMatches(),list=past.concat(soon);
  if(!list.length)return `<span class="label">${t("Everyone's predictions")}</span><p class="fine">${t("Nobody has predicted a match yet.")}</p>`;
  if(!lgM||!list.some(m=>m.k===lgM))lgM=(past[0]&&(!soon[0]||past[0].d>=lgCut())?past[0]:soon[0]||past[0]).k;
  const m=list.find(x=>x.k===lgM),R=xResults(),res=R[m.k],hm=lgVenue(m.b,m.d,m.o)!=="A",all=xAllDocs("predictions",xPreds(),"p");
  const opt=x=>`<option value="${esc(x.k)}" ${x.k===lgM?"selected":""}>${esc(mDate(x.d,true)+" · "+x.o+" · "+t(SPORTS[x.b].label))}</option>`;
  const sel=`<select id="lgMSel" class="lgsel" aria-label="${esc(t("Match"))}">${past.length?`<optgroup label="${esc(t("Played"))}">${past.map(opt).join("")}</optgroup>`:""}${soon.length?`<optgroup label="${esc(t("Coming up"))}">${soon.map(opt).join("")}</optgroup>`:""}</select>`;
  const sc=v=>hm?`${v[0]}–${v[1]}`:`${v[1]}–${v[0]}`;
  const rows=Object.entries(all).filter(([,p])=>p&&p[m.k]).map(([id,p])=>({id,v:p[m.k],me:id===XC.me||id==="me",pts:res?xPoints(p[m.k],res):null}));
  xNames(rows.map(r=>r.id).filter(i=>i!=="me"));
  const nm=r=>r.me?t("You"):xName(r.id);
  if(m.over)rows.sort((a,c)=>(c.pts??-1)-(a.pts??-1)||nm(a).localeCompare(nm(c)));else rows.sort((a,c)=>(c.me-a.me)||nm(a).localeCompare(nm(c)));
  const head=`<p class="lgmhead"><b>${esc(hm?"Fenerbahçe":m.o)} – ${esc(hm?m.o:"Fenerbahçe")}</b><span class="muted">${m.over?(res?tf("Final score: {s}",{s:sc(res)}):t("Result not in yet")):t("Hidden until the final whistle")}</span></p>`;
  const note=`<p class="fine">${m.over?"":(rows.length===1?t("1 fan has predicted this match. Predictions are revealed after the final whistle."):tf("{n} fans have predicted this match. Predictions are revealed after the final whistle.",{n:rows.length}))}</p>`;
  const li=r=>{const show=m.over||r.me;return `<li class="${r.me?"me":""}" data-uid="${esc(r.id)}"><span class="nm">${esc(nm(r))}</span><b class="lgsc${show?"":" hid"}" ${show?"":`aria-label="${esc(t("Hidden until the final whistle"))}"`}>${show?sc(r.v):"–:–"}</b>${r.pts!=null?`<span class="lgpt ${r.pts===3?"good":r.pts?"":"muted"}">${tf(r.pts===1?"1 pt":"{n} pts",{n:r.pts})}</span>`:"<span></span>"}</li>`};
  return `<span class="label">${t("Everyone's predictions")}</span>${sel}${head}${rows.length?`<ul class="lgall">${rows.slice(0,40).map(li).join("")}</ul>`:`<p class="fine">${t("No predictions for this match yet.")}</p>`}${m.over?"":note}`}
function lgAddAll(){const box=$("leagueBox"),g=box&&box.querySelector(".lggrid");if(!g)return;let c=g.querySelector(".lgallc");if(!c){c=document.createElement("article");c.className="card lgallc";g.appendChild(c)}
  c.innerHTML=lgAllHtml();const s=c.querySelector("#lgMSel");if(s)s.onchange=()=>{lgM=s.value;lgAddAll();const n=$("lgMSel");if(n)n.focus()}}
{const _fl=fillLeague;fillLeague=function(){_fl();lgAddAll()}}

/* ===== Quiz with five levels. Questions are built from the facts already on this site (history, trophies,
   legends, records, league finishes, European ties, box scores and squads), so every answer can be checked on the page. ===== */
const QLV=[["easy","Easy",3,0,"Three options. The basics every fan knows."],["normal","Normal",4,0,"Four options. Titles, legends and famous nights."],
 ["hard","Hard",4,0,"Four options. Seasons, line-ups and closer guesses."],["super","Super hard",4,25,"Four options and 25 seconds a question."],
 ["extreme","Extreme",5,15,"Five options and 15 seconds. Deep cuts only."]];
const QN=7;
const qPick=a=>a[Math.floor(Math.random()*a.length)];
const yrOf=s=>{const m=String(s).match(/^(\d{4})/);return m?+m[1]:null};
/* build one question: q text, the right answer, a pool of wrong answers */
function qMk(q,right,wrong,n,e){right=String(right);const w=[...new Set(wrong.map(String))].filter(x=>x!==right&&x!=="");if(w.length<n-1)return null;
  const o=shuffle([right,...shuffle(w).slice(0,n-1)]);return {q,o,a:o.indexOf(right),e:e||""}}
const qNear=(v,spread,min=0)=>{const out=new Set();for(let i=1;out.size<8&&i<60;i++){const d=Math.ceil(Math.random()*spread)*(Math.random()<.5?-1:1),x=v+d;if(x>=min&&x!==v)out.add(x)}return [...out]};
const qYears=(y,spread)=>qNear(y,spread,1900).filter(x=>x<=2026);
const qScore=(s,mirror=true)=>{const m=String(s).match(/^(\d+)[–-](\d+)$/);if(!m)return [];const a=+m[1],b=+m[2],o=new Set();
  [[1,0],[0,1],[-1,0],[0,-1],[1,1],[2,0],[0,2],[-1,1],[1,-1]].concat(mirror?[[b-a,a-b]]:[]).forEach(([x,y])=>{const p=a+x,q=b+y;if(p>=0&&q>=0&&(p!==a||q!==b))o.add(`${p}–${q}`)});return [...o]};
const qPos=p=>p===1?t("Champions"):ordL(p);

/* ---------- question makers shared by every branch ---------- */
function qHistory(b,spread){const H=(SPORTS[b].history||[]).filter(h=>/^\d{4}$/.test(String(h[0]))&&!String(h[1]).includes(String(h[0])));if(!H.length)return null;const h=qPick(H),y=+h[0];
  return qMk(tf("In which year: “{h}”?",{h:t(h[1])}),y,qYears(y,spread),0,t(h[2]))}
function qTrophyCount(b,spread){const T=(SPORTS[b].trophies||[]).filter(x=>/^\d+$/.test(x[0])&&!/appearance|Triple|Final Four/i.test(x[1]));if(!T.length)return null;const x=qPick(T),c=+x[0];
  return qMk(tf("How many times has Fenerbahçe won the {x}?",{x:t(x[1])}),c,qNear(c,spread,1),0,t(x[2]))}
function qLegendRole(b){const L=(SPORTS[b].legends||[]);if(L.length<4)return null;const l=qPick(L),role=t(l[1]).split(" · ")[0],roles=[...new Set(L.map(x=>t(x[1]).split(" · ")[0]))];
  return qMk(tf("What was {n}'s role at Fenerbahçe?",{n:l[0]}),role,roles,0,t(l[2]))}
function qLegendYears(b){const L=(SPORTS[b].legends||[]).map(l=>[l[0],(t(l[1]).split(" · ")[1]||"")]).filter(x=>/^\d{4}([–-]\d{0,4})?(, \d{4}.*)?$/.test(x[1]));if(L.length<4)return null;const l=qPick(L);
  return qMk(tf("When was {n} at Fenerbahçe?",{n:l[0]}),l[1],L.map(x=>x[1]),0)}
function qLegendWho(b){const L=(SPORTS[b].legends||[]);if(L.length<4)return null;const l=qPick(L.filter(x=>!x[2].includes(x[0].split(" ")[0])));if(!l)return null;
  return qMk(tf("Who is this? “{d}”",{d:t(l[2])}),l[0],L.map(x=>x[0]),0,t(l[1]))}
function qGameScore(b){const G=(SPORTS[b].games||[]).filter(g=>g.res&&/^\d+–\d+$/.test(g.res));if(!G.length)return null;const g=qPick(G);
  return qMk(tf("{h} v {a}, {c} ({y}). What was the score?",{h:g.home,a:g.away,c:t(g.comp),y:String(g.date).slice(0,4)}),g.res,qScore(g.res),0,t(g.note))}
function qGameOpp(b){const G=(SPORTS[b].games||[]).filter(g=>g.res);if(G.length<4)return null;const g=qPick(G),opp=g.home==="Fenerbahçe"?g.away:g.home;
  return qMk(tf("Who did Fenerbahçe play in this game? {c}, {d}, {r}.",{c:t(g.comp),d:fmtDate(g.date),r:g.res}),opp,G.map(x=>x.home==="Fenerbahçe"?x.away:x.home),0,t(g.note))}
function qOldQuiz(b,n){const Q=SPORTS[b].quiz;if(!Q||!Q.length)return null;const x=qPick(Q),right=x.o[x.a],wrong=x.o.filter((_,i)=>i!==x.a);
  return qMk(t(x.q),t(right),wrong.map(w=>t(w)),0,t(x.e||""))}
function qRecord(b){const R=RECORDS[b];if(!R)return null;const f=qPick(R.facts),v=f[0];let wrong;
  let q;if(/^\d+$/.test(v)){const yr=+v>1900&&+v<2100;wrong=yr?qYears(+v,8):qNear(+v,Math.max(3,Math.round(+v*.25)),1);q=tf(yr?"Club record: {k}. In which year?":"Club record: {k}. What is the number?",{k:t(f[1])})}
  else if(/^\d+–\d+$/.test(v)){wrong=qScore(v,false);q=tf("Club record: {k}. Which is right?",{k:t(f[1])})}else return null;
  return qMk(q,v,wrong,0,t(f[2]))}
function qTitleYear(b,lvl){const H=SZ_HIST[b];if(!H||!H.t||H.t.length<2)return null;const y=qPick(H.t),wrong=[];for(let x=Math.max(b==="volleyball"?2009:0,Math.min(...H.t)-3);x<=2026;x++)if(!H.t.includes(x))wrong.push(x);
  const near=lvl==="easy"?wrong:wrong.filter(x=>Math.abs(x-y)<=6);return qMk(tf("Which of these years ended with a Turkish league title?"),y,near,0)}

/* ---------- football ---------- */

function qFbFinish(range){const S=SEASON_POS.filter(([s])=>{const y=yrOf(s);return y>=range[0]&&y<=range[1]});if(!S.length)return null;const [s,p]=qPick(S);
  const opts=[1,2,3,4,5,6,7,8].filter(x=>x!==p).map(qPos);return qMk(tf("Where did Fenerbahçe finish in the league in {s}?",{s:seasonLabel(s)}),qPos(p),opts,0)}
function qFbTitleSeason(range){const T=SEASON_POS.filter(([s,p])=>p===1&&yrOf(s)>=range[0]&&yrOf(s)<=range[1]);const N=SEASON_POS.filter(([s,p])=>p>1&&yrOf(s)>=range[0]-5&&yrOf(s)<=range[1]+5);if(!T.length)return null;
  return qMk(t("Which of these seasons ended with a Turkish league title?"),seasonLabel(qPick(T)[0]),N.map(x=>seasonLabel(x[0])),0)}
function qFbXI(range){const S=SEASONS.filter(x=>{const y=yrOf(x[0]);return y>=range[0]&&y<=range[1]});if(!S.length)return null;const s=qPick(S),xi=s[3].flat(),y=yrOf(s[0]);
  const wrong=Object.entries(PEOPLE).filter(([n,v])=>!xi.includes(n)&&v.seasons&&v.seasons.length&&!v.seasons.includes(s[0])&&v.seasons.some(z=>Math.abs(yrOf(z)-y)<=6)).map(([n])=>n);
  return qMk(tf("Who was in Fenerbahçe's most-used league XI in {s}?",{s:seasonLabel(s[0])}),qPick(xi),wrong,0)}
function qFbNat(){const P=PLAYERS.filter(p=>p.nat&&NAT[p.nat]);const p=qPick(P),nm=c=>capFirst(t(NAT[c].replace(/^the /,"")));
  return qMk(tf("Which country is {n} from?",{n:p.n}),nm(p.nat),Object.keys(NAT).filter(c=>c!==p.nat).map(nm),0)}
function qEuOpp(filter){const R=EU_TIES.filter(filter);if(!R.length)return null;const r=qPick(R),same=new Set(EU_TIES.filter(x=>x[0]===r[0]).map(x=>x[3]));
  return qMk(tf("Who did Fenerbahçe play in the {c} in {s} ({r})?",{c:t(EU_COMP[r[1]]),s:r[0],r:t(r[2])}),r[3],EU_TIES.filter(x=>!same.has(x[3])&&x[1]===r[1]).map(x=>x[3]),0,
    tf("Home {h}, away {a}, Fenerbahçe first.",{h:r[5].replace("-","–"),a:r[6].replace("-","–")}))}
function qEuOut(){const bySeason={};EU_TIES.forEach(r=>{(bySeason[r[0]]=bySeason[r[0]]||[]).push(r)});const outs=Object.values(bySeason).map(L=>L[L.length-1]).filter(r=>!/^[GL]\d/.test(r[7])&&euTie(r).k==="L");if(!outs.length)return null;
  const r=qPick(outs);return qMk(tf("Who knocked Fenerbahçe out of Europe in {s}?",{s:r[0]}),r[3],outs.filter(x=>x[3]!==r[3]).map(x=>x[3]),0,tf("{c}, {r}: {g} on aggregate.",{c:t(EU_COMP[r[1]]),r:t(r[2]),g:euTie(r).agg}))}
function qEuAgg(){const R=EU_TIES.filter(r=>!r[7]&&r[5]!=="-"&&r[6]!=="-");const r=qPick(R),T=euTie(r);
  return qMk(tf("{s} {c}, {r} against {o}. What was the aggregate score, Fenerbahçe first?",{s:r[0],c:t(EU_COMP[r[1]]),r:t(r[2]),o:r[3]}),T.agg,qScore(T.agg),0,tf("Home {h}, away {a}, Fenerbahçe first.",{h:r[5].replace("-","–"),a:r[6].replace("-","–")}))}
function qFbScorerRank(maxRank){const L=RECORDS.football.lists[0].rows.slice(0,maxRank);const i=Math.floor(Math.random()*L.length),r=L[i];
  return qMk(tf("Who is number {n} on the club's all-time scoring list?",{n:i+1}),r[0],RECORDS.football.lists[0].rows.concat(RECORDS.football.lists[1].rows).map(x=>x[0]),0,tf("{n} goals, {y}.",{n:r[2],y:r[1]}))}
function qFbListNum(li){const L=RECORDS.football.lists[li],r=qPick(L.rows);
  return qMk(tf(li?"How many games did {n} play for the club, as listed?":"How many goals did {n} score for the club, as listed?",{n:r[0]}),r[2],qNear(r[2],li?40:25,1),0,t(L.note))}
function qFbApps(){const L=RECORDS.football.lists[1].rows;return qMk(t("Who has played the most games for Fenerbahçe?"),L[0][0],L.slice(1).map(x=>x[0]).concat(RECORDS.football.lists[0].rows.map(x=>x[0])),0,tf("{n} games, {y}.",{n:L[0][2],y:L[0][1]}))}
function qFbTop(){const L=RECORDS.football.lists[0].rows;return qMk(t("Who is Fenerbahçe's all-time top scorer?"),L[0][0],L.slice(1).map(x=>x[0]),0,tf("{n} goals, {y}.",{n:L[0][2],y:L[0][1]}))}

/* ---------- basketball line-ups and volleyball squads ---------- */
function luAll(L){return L.st.map(x=>[x[1],x[2]]).concat(L.bench.map(x=>[x[0],x[1]]))}
function qLuTop(LS){const ok=LS.filter(L=>{const a=luAll(L).filter(x=>x[1]!=null).sort((p,q)=>q[1]-p[1]);return a.length>1&&a[0][1]>a[1][1]});if(!ok.length)return null;const L=qPick(ok),a=luAll(L).filter(x=>x[1]!=null).sort((p,q)=>q[1]-p[1]);
  return qMk(tf("Who was Fenerbahçe's top scorer in the {l} against {o}?",{l:t(L.label),o:L.opp}),a[0][0],a.slice(1).map(x=>x[0]),0,tf("{n} points.",{n:a[0][1]}))}
function qLuPts(LS){const L=qPick(LS),a=luAll(L).filter(x=>x[1]!=null&&x[1]>=4);if(!a.length)return null;const p=qPick(a);
  return qMk(tf("How many points did {n} score in the {l} against {o}?",{n:p[0],l:t(L.label),o:L.opp}),p[1],qNear(p[1],5,0),0)}
function qLuCoach(LS){const C=[...new Set(LS.map(L=>L.coach).filter(Boolean))];if(C.length<2)return null;const L=qPick(LS.filter(x=>x.coach));
  return qMk(tf("Who was Fenerbahçe's coach in the {l} against {o}?",{l:t(L.label),o:L.opp}),L.coach,C.concat(["Željko Obradović","Šarūnas Jasikevičius","Marina Maljković","Valérie Garnier","Miguel Méndez","Ergin Ataman","Dimitris Itoudis","Lucas Mondelo"]),0)}
function qLuIn(LS){const L=qPick(LS),inn=luAll(L).map(x=>x[0]),out=[...new Set(LS.flatMap(x=>luAll(x).map(y=>y[0])))].filter(n=>!inn.includes(n));
  return qMk(tf("Who played for Fenerbahçe in the {l} against {o}?",{l:t(L.label),o:L.opp}),qPick(inn),out,0)}
function qSqIn(SQ,pool){const s=qPick(SQ),inn=s.sq.map(x=>x[1]),out=[...new Set(SQ.flatMap(x=>x.sq.map(y=>y[1])).concat(pool||[]))].filter(n=>!inn.includes(n));
  return qMk(tf("Who was in this squad: {l}?",{l:t(s.label)}),qPick(inn),out,0,t(s.note||""))}
function qSqNum(SQ){const s=qPick(SQ),p=qPick(s.sq.filter(x=>x[0]!=null));if(!p)return null;
  return qMk(tf("Which shirt number did {n} wear? ({l})",{n:p[1],l:t(s.label)}),p[0],s.sq.map(x=>x[0]).filter(x=>x!=null).concat(qNear(p[0],6,1)),0)}

/* ---------- question pools by branch and level ---------- */
const QPOOL={
 football:{easy:[()=>qOldQuiz("football"),()=>qHistory("football",30),()=>qFbTop(),()=>qFbTitleSeason([2000,2014]),()=>qLegendWho("football")],
  normal:[()=>qOldQuiz("football"),()=>qHistory("football",8),()=>qTrophyCount("football",6),()=>qLegendRole("football"),()=>qFbApps(),()=>qGameScore("football"),()=>qFbFinish([2010,2026]),()=>qFbTitleSeason([1959,2014])],
  hard:[()=>qHistory("football",3),()=>qLegendYears("football"),()=>qFbFinish([1995,2026]),()=>qFbXI([2005,2026]),()=>qGameOpp("football"),()=>qEuOut(),()=>qFbNat(),()=>qFbScorerRank(5)],
  super:[()=>qFbFinish([1970,1999]),()=>qFbXI([2000,2026]),()=>qEuOpp(r=>yrOf(r[0])>=1990),()=>qRecord("football"),()=>qFbListNum(0),()=>qEuOut(),()=>qHistory("football",2)],
  extreme:[()=>qFbFinish([1959,1985]),()=>qEuAgg(),()=>qEuOpp(r=>yrOf(r[0])<1990),()=>qFbScorerRank(10),()=>qFbListNum(1),()=>qFbXI([2000,2012]),()=>qRecord("football")]},
 basketball:{easy:[()=>qOldQuiz("basketball"),()=>qHistory("basketball",30),()=>qLegendWho("basketball")],
  normal:[()=>qOldQuiz("basketball"),()=>qHistory("basketball",8),()=>qTrophyCount("basketball",5),()=>qLegendRole("basketball"),()=>qLuCoach(MB_LINEUPS),()=>qTitleYear("basketball","easy")],
  hard:[()=>qHistory("basketball",3),()=>qLegendYears("basketball"),()=>qLuTop(MB_LINEUPS),()=>qGameScore("basketball"),()=>qLuIn(MB_LINEUPS),()=>qTitleYear("basketball","hard")],
  super:[()=>qLuPts(MB_LINEUPS),()=>qLuTop(MB_LINEUPS),()=>qRecord("basketball"),()=>qGameScore("basketball"),()=>qHistory("basketball",2),()=>qTitleYear("basketball","hard")],
  extreme:[()=>qLuPts(MB_LINEUPS),()=>qLuIn(MB_LINEUPS),()=>qRecord("basketball"),()=>qGameOpp("basketball"),()=>qTitleYear("basketball","hard")]},
 "womens-basketball":{easy:[()=>qOldQuiz("womens-basketball"),()=>qHistory("womens-basketball",30),()=>qLegendWho("womens-basketball")],
  normal:[()=>qOldQuiz("womens-basketball"),()=>qHistory("womens-basketball",8),()=>qTrophyCount("womens-basketball",6),()=>qLegendRole("womens-basketball"),()=>qLuCoach(WB_LINEUPS)],
  hard:[()=>qHistory("womens-basketball",3),()=>qLegendYears("womens-basketball"),()=>qLuTop(WB_LINEUPS),()=>qLuIn(WB_LINEUPS),()=>qTitleYear("womens-basketball","hard")],
  super:[()=>qLuPts(WB_LINEUPS),()=>qLuTop(WB_LINEUPS),()=>qRecord("womens-basketball"),()=>qHistory("womens-basketball",2),()=>qTitleYear("womens-basketball","hard")],
  extreme:[()=>qLuPts(WB_LINEUPS),()=>qLuIn(WB_LINEUPS),()=>qRecord("womens-basketball"),()=>qTitleYear("womens-basketball","hard")]},
 volleyball:{easy:[()=>qOldQuiz("volleyball"),()=>qHistory("volleyball",30),()=>qLegendWho("volleyball")],
  normal:[()=>qOldQuiz("volleyball"),()=>qHistory("volleyball",8),()=>qTrophyCount("volleyball",5),()=>qLegendRole("volleyball"),()=>qGameScore("volleyball")],
  hard:[()=>qHistory("volleyball",3),()=>qLegendYears("volleyball"),()=>qSqIn(VB_SQUADS),()=>qGameOpp("volleyball"),()=>qTitleYear("volleyball","hard")],
  super:[()=>qSqIn(VB_SQUADS),()=>qRecord("volleyball"),()=>qHistory("volleyball",2),()=>qTitleYear("volleyball","hard"),()=>qSqNum(VB_SQUADS)],
  extreme:[()=>qSqNum(VB_SQUADS),()=>qSqIn(VB_SQUADS),()=>qRecord("volleyball"),()=>qTitleYear("volleyball","hard")]},
 "mens-volleyball":{easy:[()=>qOldQuiz("mens-volleyball"),()=>qHistory("mens-volleyball",30)],
  normal:[()=>qOldQuiz("mens-volleyball"),()=>qHistory("mens-volleyball",8),()=>qTrophyCount("mens-volleyball",4),()=>qLegendRole("mens-volleyball")],
  hard:[()=>qHistory("mens-volleyball",3),()=>qLegendYears("mens-volleyball"),()=>qTitleYear("mens-volleyball","hard"),()=>qGameScore("mens-volleyball"),()=>qSqIn(MV_SQUADS,MV_POOL.map(p=>p[0]))],
  super:[()=>qHistory("mens-volleyball",2),()=>qRecord("mens-volleyball"),()=>qTitleYear("mens-volleyball","hard"),()=>qSqNum(MV_SQUADS),()=>qSqIn(MV_SQUADS,MV_POOL.map(p=>p[0]))],
  extreme:[()=>qSqNum(MV_SQUADS),()=>qRecord("mens-volleyball"),()=>qTitleYear("mens-volleyball","hard"),()=>qHistory("mens-volleyball",3)]},
 "womens-football":{easy:[()=>qOldQuiz("womens-football"),()=>qHistory("womens-football",20)],
  normal:[()=>qOldQuiz("womens-football"),()=>qHistory("womens-football",6),()=>qLegendRole("womens-football"),()=>qGameScore("womens-football")],
  hard:[()=>qHistory("womens-football",3),()=>qGameOpp("womens-football"),()=>qSqIn(WF_SQUADS,WF_POOL.map(p=>p[0])),()=>qGameScore("womens-football")],
  super:[()=>qRecord("womens-football"),()=>qSqNum(WF_SQUADS),()=>qSqIn(WF_SQUADS,WF_POOL.map(p=>p[0])),()=>qHistory("womens-football",2)],
  extreme:[()=>qSqNum(WF_SQUADS),()=>qRecord("womens-football"),()=>qHistory("womens-football",3),()=>qSqIn(WF_SQUADS,WF_POOL.map(p=>p[0]))]},
 more:{easy:[()=>qOldQuiz("more"),()=>qHistory("more",30)],normal:[()=>qOldQuiz("more"),()=>qHistory("more",8),()=>qLegendRole("more")],
  hard:[()=>qHistory("more",3),()=>qLegendYears("more"),()=>qLegendWho("more")],super:[()=>qHistory("more",2),()=>qLegendYears("more"),()=>qLegendWho("more")],extreme:[()=>qHistory("more",2),()=>qHistory("more",4),()=>qLegendWho("more"),()=>qLegendYears("more")]}};

function qRound(b,lv){const L=QLV.find(x=>x[0]===lv),n=L[2],pool=(QPOOL[b]||QPOOL.more)[lv],out=[],seen=new Set();
  for(let k=0;out.length<QN&&k<300;k++){let q=null;try{q=qPick(pool)()}catch(e){q=null}if(!q||seen.has(q.q))continue;
    /* trim to the level's option count, keeping the right answer */
    const right=q.o[q.a],wrong=q.o.filter((_,i)=>i!==q.a);if(wrong.length<n-1)continue;
    const o=shuffle([right,...shuffle(wrong).slice(0,n-1)]);seen.add(q.q);out.push({q:q.q,o,a:o.indexOf(right),e:q.e})}
  return out}
/* qMk with n=0 returns every option; qRound trims to the level */

/* ---------- UI ---------- */
const QZ={};let qzTimer=null;
function gQuiz(el){const b=current;clearInterval(qzTimer);let st=QZ[b];
  if(!st||!st.lv){const best=lv=>store.get(SK(b,"qz-"+lv),null);
    el.innerHTML=`<h2>${t("Quiz")}</h2><p class="intro">${t("Pick a level. Every round has seven questions, built from the facts on this site.")}</p>
     <div class="qtime"><span class="label" id="qtLab">${t("Quiz timer")}</span><div class="seg" role="group" aria-labelledby="qtLab">${QT_LEVELS.map(([v,l])=>`<button type="button" data-qt="${v}" aria-pressed="${store.get("fb-qtime","1")===v}">${esc(t(l))}</button>`).join("")}</div></div>
     <div class="qlevels">${QLV.map(([id,lab,n,sec,d],i)=>`<button class="qlv card" data-qlv="${id}" style="--q:${i}"><span class="qdots">${"●".repeat(i+1)}${"○".repeat(4-i)}</span><b>${esc(t(lab))}</b><span>${esc(t(d))}</span>${sec&&qTimeMult()!==1?`<span class="qtadj">${esc(qTimeMult()?tf("With your setting: {n} seconds a question.",{n:sec*qTimeMult()}):t("With your setting: no timer."))}</span>`:""}<small>${best(id)!=null?esc(tf("Best: {s}/{n}",{s:best(id),n:QN})):t("Not played yet")}</small></button>`).join("")}</div>`;
    el.querySelectorAll("[data-qt]").forEach(x=>x.onclick=()=>{store.set("fb-qtime",x.dataset.qt);rerender();const f=document.querySelector(`[data-qt="${x.dataset.qt}"]`);if(f)f.focus()});
    el.querySelectorAll("[data-qlv]").forEach(x=>x.onclick=()=>{QZ[b]={lv:x.dataset.qlv,qs:qRound(b,x.dataset.qlv),i:0,score:0,picked:null};rerender()});return}
  const L=QLV.find(x=>x[0]===st.lv),lab=t(L[1]),N=st.qs.length;
  if(st.i>=N){const k=SK(b,"qz-"+st.lv),best=store.get(k,null);if(!st.saved){st.saved=true;if(best==null||st.score>best)store.set(k,st.score);if(st.score>store.get(SK(b,"quiz"),0))store.set(SK(b,"quiz"),st.score);if(st.score===N&&["super","extreme"].includes(st.lv))store.set("fb-quiz-hard",1);if(typeof xBadgeCheck==="function")xBadgeCheck();if(typeof xSyncScores==="function")xSyncScores()}
    const msg=st.score===N?"Perfect. True Fenerbahçeli.":st.score>=N*.6?"Solid. The stands would be proud.":"Time to read the History tab again.";
    el.innerHTML=`<h2>${t("Quiz")} · ${esc(lab)}</h2><div class="quiz"><span class="label">${t("Final score")}</span><div class="final">${st.score}/${N}</div><p style="font-size:18px;margin-top:6px">${t(msg)}</p><p class="gnote">${esc(tf("Best: {s}/{n}",{s:Math.max(best||0,st.score),n:N}))}</p>
     <div class="btns"><button class="btn" data-q="again">${t("Play again")}</button><button class="btn ghost" data-q="levels">${t("Change level")}</button>${st.lv!=="extreme"&&st.score>=N-1?`<button class="btn ghost" data-q="up">${esc(tf("Try {l}",{l:t(QLV[QLV.indexOf(L)+1][1])}))} →</button>`:""}</div></div>`;
    const on=(k,f)=>{const x=el.querySelector(`[data-q="${k}"]`);if(x)x.onclick=f};
    on("again",()=>{QZ[b]={lv:st.lv,qs:qRound(b,st.lv),i:0,score:0,picked:null};rerender()});on("levels",()=>{QZ[b]=null;rerender()});on("up",()=>{const nl=QLV[QLV.indexOf(L)+1][0];QZ[b]={lv:nl,qs:qRound(b,nl),i:0,score:0,picked:null};rerender()});return}
  const item=st.qs[st.i],sec=L[3]*(typeof qTimeMult==="function"?qTimeMult():1);
  el.innerHTML=`<h2>${t("Quiz")} · ${esc(lab)}</h2><div class="quiz qz-${st.lv}"><div class="top"><span class="label">${tf("Question {i} of {n}",{i:st.i+1,n:N})}</span><span class="label">${tf("Score {n}",{n:st.score})}</span></div><div class="progress"><i style="width:${st.i/N*100}%"></i></div>
   ${sec&&st.picked===null?`<div class="qtimer" aria-hidden="true"><i id="qzBar"></i></div><p class="fine" id="qzLeft" aria-live="off"></p>`:""}
   <h3>${esc(item.q)}</h3><div class="opts">${item.o.map((o,idx)=>{let c="opt";if(st.picked!==null){if(idx===item.a)c+=" right";else if(idx===st.picked)c+=" wrong"}return `<button class="${c}" data-qo="${idx}" ${st.picked!==null?"disabled":""}>${esc(o)}</button>`}).join("")}</div>
   ${st.picked!==null?`<p class="explain"><b>${st.picked===-1?t("Time's up."):st.picked===item.a?t("Correct."):t("Not quite.")}</b> ${st.picked!==item.a?esc(tf("The answer is {a}.",{a:item.o[item.a]}))+" ":""}${item.e?esc(item.e):""}</p><button class="btn qnext" data-q="next">${t(st.i+1<N?"Next question":"See score")}</button>`:""}
   <div class="btns"><button class="linkbtn" data-q="quit">${t("Change level")}</button></div></div>`;
  el.querySelectorAll("[data-qo]").forEach(x=>x.onclick=()=>{clearInterval(qzTimer);st.picked=+x.dataset.qo;if(st.picked===item.a)st.score++;rerender()});
  const nx=el.querySelector('[data-q="next"]');if(nx){nx.onclick=()=>{st.i++;st.picked=null;rerender()};nx.focus()}
  el.querySelector('[data-q="quit"]').onclick=()=>{clearInterval(qzTimer);QZ[b]=null;rerender()};
  if(sec&&st.picked===null){const end=Date.now()+sec*1000,bar=$("qzBar"),left=$("qzLeft");const tick=()=>{if(!document.body.contains(bar)){clearInterval(qzTimer);return}const ms=end-Date.now();bar.style.width=Math.max(0,ms/(sec*10))+"%";left.textContent=tf("{n} seconds left",{n:Math.max(0,Math.ceil(ms/1000))});bar.classList.toggle("low",ms<5000);
    if(ms<=0){clearInterval(qzTimer);st.picked=-1;rerender()}};tick();qzTimer=setInterval(tick,200)}};
/* result image and badge */
EXT.result.push(g=>{if(g==="quiz"){const s=QZ[current];if(s&&s.lv&&s.i>=s.qs.length)return{title:`${t("Quiz")} · ${t(QLV.find(x=>x[0]===s.lv)[1])}`,big:`${s.score}/${s.qs.length}`,sub:t(SPORTS[current].label)};return null}});
BADGES.push(["quizx","Brain of Kadıköy","Get 7 out of 7 on Super hard or Extreme.",()=>store.get("fb-quiz-hard",0)>0]);
Object.keys(PLAY).forEach(b=>PLAY[b].forEach(x=>{if(x[0]==="quiz")x[2]="Five levels, Easy to Extreme"}));

/* ===== Title race: simulate the rest of the league thousands of times from the current table.
   Fenerbahçe's own upcoming league games can be set to win, draw or loss. All odds are estimates. ===== */
const RACE_NEXT={"Basketbol Süper Ligi":"BSL"};
function raceTables(b){const L=LIVE[b];if(!L||!L.tables)return [];return L.tables.map((T,i)=>({T,i})).filter(({T})=>T.rows&&T.rows.length>=4&&T.cols.includes("P")&&T.rows.some(r=>r[0]==="Fenerbahçe"))}
function raceKind(T){return T.cols.includes("D")?"fb":/Sultanlar|Efeler/.test(T.comp)?"vb":"bb"}
let RS={};
function raceState(b){const tabs=raceTables(b);if(!tabs.length)return null;let s=RS[b];if(!s||!tabs[s.ti]){s=RS[b]={ti:0,fix:{},form:0}}return s}
/* table names can differ from result names by a sponsor ("Galatasaray" / "Galatasaray Daikin") */
function raceTeamIdx(teams,name){let j=teams.findIndex(x=>x.n===name);if(j<0)j=teams.findIndex(x=>name.startsWith(x.n+" ")||x.n.startsWith(name+" "));return j}
function raceData(b,s){const {T}=raceTables(b)[s.ti],kind=raceKind(T),ci=c=>T.cols.indexOf(c),P=ci("P"),W=ci("W"),D=ci("D"),Lc=ci("L"),n=T.rows.length,total=2*(n-1);
  const teams=T.rows.map(r=>{const p=+r[P+1],w=+r[W+1],d=D>=0?+r[D+1]:0,l=+r[Lc+1],pts=kind==="bb"&&ci("Pts")<0?w:+r[T.key+1];return {n:r[0],p,w,d,l,pts,left:Math.max(0,total-p)}});
  const nextComp=RACE_NEXT[T.comp]||T.comp,fx=(LIVE[b].next||[]).filter(x=>x[2]===nextComp).slice(0,8),fb=teams.findIndex(x=>x.n==="Fenerbahçe");
  /* Fenerbahçe's remaining league games: everyone twice, once at home and once away, minus the games already played.
     Only used when the results list covers every game in the table, so the opponents and venues are exact. */
  let rem=null;if(fb>=0){const played=LIVE[b].last.filter(r=>r[1]===T.comp||r[1]===nextComp);
    if(played.length===teams[fb].p){const need=new Map();teams.forEach((x,j)=>{if(j!==fb){need.set(j+"H",1);need.set(j+"A",1)}});let ok=true;
      played.forEach(r=>{const j=raceTeamIdx(teams,r[3]),k=j+(r[2]==="A"?"A":"H");if(j<0||!need.has(k)){ok=false;return}need.delete(k)});
      if(ok){rem=[];fx.forEach((f,k)=>{const j=raceTeamIdx(teams,f[4]),key=j+(f[3]==="A"?"A":"H");if(j>=0&&need.has(key)){need.delete(key);rem.push({j,home:f[3]!=="A",fx:k})}});
        [...need.keys()].forEach(key=>rem.push({j:parseInt(key,10),home:key.endsWith("H"),fx:null}));if(rem.length!==teams[fb].left)rem=null}}}
  return {T,kind,teams,total,fx,n,fb,rem}}
/* home advantage on the log-odds scale: about 60% home wins in basketball, a little less in football and volleyball */
const RACE_HOME={fb:.3,bb:.4,vb:.2};
/* one season run: returns final order of team indexes */
function raceRun(D,s,str){const pts=D.teams.map(x=>x.pts),wins=D.teams.map(x=>x.w),left=D.teams.map(x=>x.left),n=D.n,fb=D.fb,HA=RACE_HOME[D.kind];
  const award=(i,j,res)=>{/* res: 1 i wins, 0 draw, -1 j wins */
    if(D.kind==="fb"){if(res>0)pts[i]+=3;else if(res<0)pts[j]+=3;else{pts[i]++;pts[j]++}}
    else if(D.kind==="vb"){const tie=Math.random()<.25;if(res>0){pts[i]+=tie?2:3;if(tie)pts[j]+=1;wins[i]++}else{pts[j]+=tie?2:3;if(tie)pts[i]+=1;wins[j]++}}
    else{const ptsMode=D.T.cols.includes("Pts");if(res>0){wins[i]++;pts[i]+=ptsMode?2:1;if(ptsMode)pts[j]+=1}else{wins[j]++;pts[j]+=ptsMode?2:1;if(ptsMode)pts[i]+=1}}};
  const lg=x=>Math.log(x/(1-x));
  /* result from the home side's point of view */
  const play=(h,a)=>{const pw=1/(1+Math.exp(-(lg(str[h])-lg(str[a])+HA)));if(D.kind==="fb"){const dr=.26,r=Math.random();return r<dr?0:(r<dr+(1-dr)*pw?1:-1)}return Math.random()<pw?1:-1};
  const game=(i,j,iHome)=>iHome?play(i,j):-play(j,i);
  const setRes=k=>{const v=k!=null&&s.fix[k];return v?(v==="W"?1:v==="D"?0:-1):null};
  if(fb>=0&&D.rem){D.rem.forEach(g=>{const r=setRes(g.fx),res=r!=null?r:game(fb,g.j,g.home);award(fb,g.j,res);left[fb]--;if(left[g.j]>0)left[g.j]--})}
  else if(fb>=0){D.fx.forEach((f,k)=>{const r=setRes(k);if(r==null||left[fb]<=0)return;const j=raceTeamIdx(D.teams,f[4]);
    if(j>=0&&left[j]>0){award(fb,j,r);left[j]--}else{const o=(fb+1+Math.floor(Math.random()*(n-1)))%n;award(fb,o,r)}left[fb]--})}
  /* everyone else: random opponents among teams that still have games, random venue */
  for(let i=0;i<n;i++)while(left[i]>0){const c=[];for(let j=0;j<n;j++)if(j!==i&&left[j]>0&&!(D.rem&&j===fb))c.push(j);
    let j;if(c.length){j=c[Math.floor(Math.random()*c.length)];left[j]--}else{j=Math.floor(Math.random()*(n-1));if(j>=i)j++}
    left[i]--;award(i,j,game(i,j,Math.random()<.5))}
  return {order:[...Array(n).keys()].sort((a,c)=>pts[c]-pts[a]||wins[c]-wins[a]||Math.random()-.5),pts}}
function raceSim(b,s,N=3000){const D=raceData(b,s),n=D.n,fb=D.teams.findIndex(x=>x.n==="Fenerbahçe");
  const gdI=D.T.cols.indexOf("GD"),str=D.teams.map((x,i)=>{const g=Math.max(1,x.p);let v;
    if(D.kind==="fb"){const gd=gdI>=0?parseInt(String(D.T.rows.find(r=>r[0]===x.n)[gdI+1]).replace("−","-"),10)||0:0,r=((x.pts/g-1.4)*.6+(gd/g)*.25)*g/(g+8);v=1/(1+Math.exp(-1.6*r))}
    else v=(x.w+.5*8)/(g+8);
    if(i===fb)v=clamp(v+s.form*.05,.05,.95);return clamp(v,.06,.94)});
  const pos=D.teams.map(()=>new Array(n).fill(0)),sum=D.teams.map(()=>0);
  for(let r=0;r<N;r++){const {order,pts}=raceRun(D,s,str);order.forEach((ti,p)=>{pos[ti][p]++;sum[ti]+=pts[ti]})}
  return {D,N,fb,rows:D.teams.map((x,i)=>({n:x.n,now:x.pts,proj:sum[i]/N,pos:pos[i].map(v=>v/N)})).sort((a,c)=>c.proj-a.proj)}}
const pct=v=>v>=.995?"99%+":v<.005&&v>0?"<1%":Math.round(v*100)+"%";
function renderRace(p){const b=current,s=raceState(b);if(!s){p.innerHTML=`<h2>${t("Title race")}</h2><p class="muted">${t("There's no league table for this branch yet.")}</p>`;return}
  const tabs=raceTables(b),R=raceSim(b,s),D=R.D,me=R.rows.find(r=>r.n==="Fenerbahçe"),n=D.n,top=Math.min(4,n-1),bottom=D.kind==="fb"&&n>=14?3:0;
  const chartRows=R.rows.slice().sort((a,c)=>c.pos[0]-a.pos[0]).filter((r,i)=>i<8&&(r.pos[0]>0||r.n==="Fenerbahçe"));
  const lbl=x=>D.kind==="fb"?{W:t("Win"),D:t("Draw"),L:t("Loss")}[x]:{W:t("Win"),L:t("Loss")}[x];
  p.innerHTML=`<h2>${t("Title race")} ${dchip("est")}</h2><p class="intro">${tf("We play out the rest of the {c} {n} times from today's table, using each team's results so far. Change Fenerbahçe's next games and watch the odds move.",{c:t(D.T.comp),n:R.N.toLocaleString()})}</p>
   ${tabs.length>1?`<div class="filter" role="group" aria-label="${t("Competition")}">${tabs.map((x,k)=>`<button data-rti="${k}" aria-pressed="${k===s.ti}">${esc(t(x.T.comp))}</button>`).join("")}</div>`:""}
   <div class="racegrid">
    <article class="card racebig"><span class="label">${t("Fenerbahçe")}</span><div class="raceodds"><div><b>${pct(me.pos[0])}</b><span>${t("finish first")}</span></div><div><b>${pct(me.pos.slice(0,top).reduce((a,v)=>a+v,0))}</b><span>${tf("top {n}",{n:top})}</span></div>${n>=12?`<div><b>${pct(me.pos.slice(0,8).reduce((a,v)=>a+v,0))}</b><span>${tf("top {n}",{n:8})}</span></div>`:""}<div><b>${me.proj.toFixed(0)}</b><span>${t("projected points")}</span></div></div>
     <span class="label" style="margin-top:12px">${t("Where Fenerbahçe finish")}</span>${raceHist(me.pos)}</article>
    <article class="card"><span class="label">${t("Fenerbahçe's next league games")}</span>${D.fx.length?`<ul class="racefx">${D.fx.map((f,k)=>`<li><div><span class="muted">${f[0]?mDate(f[0],true):esc(t(f[5]||""))}</span><b>${esc(f[3]==="H"?"Fenerbahçe – "+f[4]:f[4]+" – Fenerbahçe")}</b></div><div class="seg" role="group" aria-label="${esc(f[4])}">${["","W",...(D.kind==="fb"?["D"]:[]),"L"].map(x=>`<button data-rfx="${k}|${x}" aria-pressed="${(s.fix[k]||"")===x}" class="${x?"r"+x:""}">${x?lbl(x):t("Sim")}</button>`).join("")}</div></li>`).join("")}</ul>`:`<p class="muted">${t("No league fixtures listed yet.")}</p>`}
     ${D.rem&&D.rem.some(g=>g.fx==null)?`<details class="racerest"><summary>${esc(tf("All {n} remaining league games",{n:D.rem.length}))}</summary><p class="muted">${D.rem.map(g=>`${esc(D.teams[g.j].n)} <small>(${t(g.home?"home":"away")})</small>`).join(", ")}</p></details>`:""}
     <label class="raceform"><span>${t("Fenerbahçe's form for the rest of the season")}</span><input type="range" min="-3" max="3" step="1" value="${s.form}" id="raceForm"><span class="muted">${esc(t(["Poor","Shaky","Off the pace","As now","Good","Strong","Unstoppable"][s.form+3]))}</span></label>
     <div class="btns"><button class="btn ghost" data-race="reset">${t("Reset")}</button><button class="btn ghost" data-race="again">${t("Run again")}</button></div></article></div>
   <figure class="card racechart"><figcaption class="label">${t("Chance of finishing first")}</figcaption>${chartRows.map(r=>`<div class="rcrow ${r.n==="Fenerbahçe"?"me":""}"><span>${esc(r.n)}</span><div class="rcbar"><i style="width:${(r.pos[0]*100).toFixed(1)}%"></i></div><b>${pct(r.pos[0])}</b></div>`).join("")}</figure>
   <div class="tscroll card racetable"><table class="stand"><thead><tr><th>#</th><th>${t("Team")}</th><th>${t("Now")}</th><th>${t("Projected")}</th><th>${t("1st")}</th><th>${tf("Top {n}",{n:top})}</th>${bottom?`<th>${tf("Bottom {n}",{n:bottom})}</th>`:""}</tr></thead><tbody>${R.rows.map((r,i)=>`<tr class="${r.n==="Fenerbahçe"?"fb":""}"><td>${i+1}</td><td>${esc(r.n)}</td><td>${r.now}</td><td>${r.proj.toFixed(1)}</td><td>${pct(r.pos[0])}</td><td>${pct(r.pos.slice(0,top).reduce((a,v)=>a+v,0))}</td>${bottom?`<td>${pct(r.pos.slice(n-bottom).reduce((a,v)=>a+v,0))}</td>`:""}</tr>`).join("")}</tbody></table></div>
   <p class="fine">${D.rem?tf("Fenerbahçe's {r} remaining league games use the real opponents and venues. The other teams play out the rest of their {g}-game season against random opponents. Win chances come from results so far, with an edge for the home side. It doesn't know injuries or transfers, so treat it as a rough guide.",{r:D.rem.length,g:D.total}):tf("Each team plays out the rest of its {g}-game season against random opponents, with win chances based on results so far and an edge for the home side. It doesn't know injuries, transfers or the real fixture list, so treat it as a rough guide.",{g:D.total})}</p>`;
  p.querySelectorAll("[data-rti]").forEach(x=>x.onclick=()=>{s.ti=+x.dataset.rti;s.fix={};renderRace(p)});
  p.querySelectorAll("[data-rfx]").forEach(x=>x.onclick=()=>{const [k,v]=x.dataset.rfx.split("|");if(v)s.fix[k]=v;else delete s.fix[k];renderRace(p);const f=p.querySelector(`[data-rfx="${k}|${v}"]`);if(f)f.focus()});
  const fr=$("raceForm");let tm;fr.oninput=()=>{clearTimeout(tm);tm=setTimeout(()=>{s.form=+fr.value;renderRace(p);$("raceForm").focus()},120)};
  p.querySelector('[data-race="reset"]').onclick=()=>{RS[b]=null;renderRace(p)};p.querySelector('[data-race="again"]').onclick=()=>renderRace(p)}
function raceHist(pos){const W=600,H=120,n=pos.length,bw=W/n,mx=Math.max(...pos,.01);
  return `<svg class="racehist" viewBox="0 0 ${W} ${H+18}" role="img" aria-label="${t("Where Fenerbahçe finish")}">${pos.map((v,i)=>{const h=v/mx*(H-6);return `<rect x="${(i*bw+2).toFixed(1)}" y="${(H-h).toFixed(1)}" width="${(bw-4).toFixed(1)}" height="${Math.max(h,v>0?2:0).toFixed(1)}" rx="3" class="${i===0?"s1":"s2"}"><title>${ordL(i+1)}: ${pct(v)}</title></rect>`}).join("")}${pos.map((v,i)=>n<=20||i%2===0?`<text x="${(i*bw+bw/2).toFixed(1)}" y="${H+14}" text-anchor="middle" class="ax">${i+1}</text>`:"").join("")}</svg>`}
/* tab wiring */
EXT.tabs.push((id,T)=>{if(id==="more"||!raceTables(id).length)return;const i=T.findIndex(x=>x[0]==="standings");T.splice(i+1,0,["race","Title race"])});
EXT.panels.race=p=>renderRace(p);
KAN_CHIPS_TAB.race=["Can we still win the league?","Who is our main rival?","How many points do we need?"];

/* ===== Real time: live quiz rooms and the match-night watch party (room capability) ===== */
const RT={room:null,user:null,names:{},tried:false};
async function rtRoom(){if(RT.room||RT.tried)return RT.room;RT.tried=true;try{const c=window.claude;if(!c||!c.use)return null;RT.room=await c.use("room");RT.user=await c.use("user")}catch(e){RT.room=null}return RT.room}
async function rtNames(ids){ids=ids.filter(i=>i&&!(i in RT.names));if(!ids.length||!RT.user||!RT.user.profiles)return false;ids.forEach(i=>RT.names[i]="");try{const ps=await RT.user.profiles(ids);ids.forEach(i=>RT.names[i]=(ps[i]&&ps[i].name)||"")}catch(e){}return true}
let rtName=(peer)=>{if(!peer)return t("Someone");if(peer.isMe)return t("You");const n=peer.by&&RT.names[peer.by];return n||(peer.presence&&typeof peer.presence.nick==="string"&&peer.presence.nick.slice(0,24))||t("A fan")};
const rtNoRoom=()=>`<p class="msg">${t("Live features couldn't connect right now. You can still play everything else here.")}</p>`;

/* ---------------- Live quiz ---------------- */
const LQT={start:"qstart",q:"qq",ans:"qans",rev:"qrev",end:"qend",sync:"qsync"};
let LQ=null;
function lqSeeded(seed,b,lv){const o=Math.random;Math.random=szRng(seed);try{return qRound(b,lv)}finally{Math.random=o}}
function lqCode(){const A="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";let s="";for(let i=0;i<5;i++)s+=A[Math.floor(Math.random()*A.length)];return s}
async function lqJoin(code,host,lv){const R=await rtRoom();if(!R)return false;code=code.toUpperCase().replace(/[^A-Z0-9]/g,"").slice(0,6);if(code.length<4)return false;
  let nr;try{nr=await R.join("lq-"+code.toLowerCase())}catch(e){xToast(t("Couldn't join that room. Try again."));return false}
  if(LQ&&LQ.nr&&LQ.nr!==nr){try{LQ.nr.leave()}catch(e){}}
  LQ={nr,code,host,lv:lv||"normal",b:current,phase:"lobby",i:-1,qs:[],scores:{},ans:{},mine:{},hostPeer:null,un:[],dur:20000};
  nr.presence({role:host?"host":"player",at:Date.now()}).catch(()=>{});
  const on=(tp,f)=>LQ.un.push(nr.on(tp,f));
  on(LQT.start,m=>{if(!lqFromHost(m))return;const d=m.data||{};LQ.b=d.b;LQ.lv=d.lv;LQ.seed=d.seed;LQ.dur=d.dur;LQ.qs=lqSeeded(d.seed,d.b,d.lv);LQ.scores={};LQ.ans={};LQ.mine={};LQ.phase="wait";LQ.i=-1;lqDraw()});
  on(LQT.q,m=>{if(!lqFromHost(m))return;const d=m.data||{};if(!LQ.qs.length)return;LQ.i=d.i;LQ.phase="q";LQ.t0=Date.now();LQ.left=d.dur||LQ.dur;lqDraw();lqTick()});
  on(LQT.ans,m=>{const d=m.data||{};if(typeof d.i!=="number"||typeof d.a!=="number")return;(LQ.ans[d.i]=LQ.ans[d.i]||{})[m.peer]={a:d.a,ms:+d.ms||0,by:m.by};if(LQ.host)lqMaybeReveal();lqDrawAnswers()});
  on(LQT.rev,m=>{if(!lqFromHost(m))return;const d=m.data||{};LQ.phase="rev";if(d.scores&&typeof d.scores==="object")LQ.scores=d.scores;clearInterval(LQ.tick);lqDraw()});
  on(LQT.end,m=>{if(!lqFromHost(m))return;const d=m.data||{};if(d.scores)LQ.scores=d.scores;LQ.phase="end";clearInterval(LQ.tick);lqDraw();lqSaveBest()});
  on(LQT.sync,m=>{if(LQ.host||!lqFromHost(m))return;const d=m.data||{};if(LQ.phase!=="lobby"&&LQ.seed===d.seed)return;LQ.b=d.b;LQ.lv=d.lv;LQ.seed=d.seed;LQ.dur=d.dur;LQ.qs=d.seed?lqSeeded(d.seed,d.b,d.lv):[];LQ.scores=d.scores||{};LQ.i=d.i;LQ.phase=d.phase==="q"||d.phase==="rev"?"wait":d.phase||"lobby";lqDraw()});
  LQ.un.push(nr.onPeers(ch=>{const P=ch.peers;rtNames(P.map(p=>p.by)).then(n=>{if(n)lqDraw()});const h=P.find(p=>p.presence&&p.presence.role==="host");
    if(h)LQ.hostPeer=h.peer;else if(LQ.hostPeer&&!LQ.host&&LQ.phase!=="end"){LQ.phase="gone"}
    if(LQ.host&&ch.joined.some(p=>!p.isMe))lqSync();lqDraw()}));
  if(host){const R2=RT.room;R2.presence({lq:{c:code,b:current,lv:LQ.lv}}).catch(()=>{})}
  lqDraw();return true}
function lqFromHost(m){if(LQ.host)return m.isMe&&m.sameTab;const P=LQ.nr.peers().find(p=>p.peer===m.peer);return !!(P&&P.presence&&P.presence.role==="host")}
function lqSync(){LQ.nr.emit(LQT.sync,{seed:LQ.seed||0,b:LQ.b,lv:LQ.lv,dur:LQ.dur,i:LQ.i,phase:LQ.phase,scores:LQ.scores}).catch(()=>{})}
function lqScore(){const S={};Object.entries(LQ.ans).forEach(([i,M])=>{const q=LQ.qs[+i];if(!q)return;Object.entries(M).forEach(([peer,x])=>{S[peer]=S[peer]||0;if(x.a===q.a)S[peer]+=500+Math.round(500*Math.max(0,1-x.ms/LQ.dur))})});return S}
let lqRevTimer=null;
function lqMaybeReveal(){const n=LQ.nr.peers().filter(p=>p.kind==="viewer").length,got=Object.keys(LQ.ans[LQ.i]||{}).length;if(LQ.phase==="q"&&got>=n)lqReveal()}
function lqReveal(){if(!LQ.host||LQ.phase!=="q")return;clearTimeout(lqRevTimer);LQ.scores=lqScore();LQ.nr.emit(LQT.rev,{i:LQ.i,scores:LQ.scores}).catch(()=>{});
  lqRevTimer=setTimeout(()=>{if(!LQ||!LQ.host)return;if(LQ.i+1<LQ.qs.length)lqAsk(LQ.i+1);else{LQ.nr.emit(LQT.end,{scores:LQ.scores}).catch(()=>{});RT.room&&RT.room.presence({lq:null}).catch(()=>{})}},4500)}
function lqAsk(i){LQ.nr.emit(LQT.q,{i,dur:LQ.dur}).catch(()=>{});clearTimeout(lqRevTimer);lqRevTimer=setTimeout(lqReveal,LQ.dur+600)}
function lqStart(){const lv=LQ.lv,L=QLV.find(x=>x[0]===lv);LQ.dur=(L[3]||20)*1000;const seed=1+Math.floor(Math.random()*2e9);
  LQ.nr.emit(LQT.start,{seed,b:current,lv,dur:LQ.dur}).catch(()=>{});setTimeout(()=>lqAsk(0),1800)}
function lqLeave(){if(!LQ)return;clearInterval(LQ.tick);clearTimeout(lqRevTimer);LQ.un.forEach(u=>{try{u()}catch(e){}});try{LQ.nr.leave()}catch(e){}if(LQ.host&&RT.room)RT.room.presence({lq:null}).catch(()=>{});LQ=null}
function lqTick(){clearInterval(LQ.tick);LQ.tick=setInterval(()=>{const bar=$("lqBar");if(!LQ||LQ.phase!=="q"||!bar){clearInterval(LQ&&LQ.tick);return}const ms=LQ.left-(Date.now()-LQ.t0);bar.style.width=Math.max(0,ms/LQ.left*100)+"%";bar.classList.toggle("low",ms<5000)},150)}
function lqSaveBest(){const me=LQ.nr.peers().find(p=>p.isMe&&p.sameTab);if(!me)return;const S=Object.entries(LQ.scores).sort((a,c)=>c[1]-a[1]),rank=S.findIndex(x=>x[0]===me.peer)+1;if(rank===1&&S.length>1)store.set("fb-lq-wins",store.get("fb-lq-wins",0)+1);if(typeof xBadgeCheck==="function")xBadgeCheck()}
function lqBoard(){const P=LQ.nr.peers().filter(p=>p.kind==="viewer"),rows=P.map(p=>({p,s:LQ.scores[p.peer]||0})).sort((a,c)=>c.s-a.s);
  return `<ol class="ptable lqboard">${rows.map((r,i)=>`<li class="${r.p.isMe&&r.p.sameTab?"me":""}"><span class="rk">${i+1}</span><span class="nm">${esc(rtName(r.p))}${r.p.presence&&r.p.presence.role==="host"?` <small class="muted">${t("host")}</small>`:""}</span><b>${r.s}</b></li>`).join("")}</ol>`}
function lqDrawAnswers(){const el=$("lqGot");if(el&&LQ&&LQ.phase==="q"){const n=LQ.nr.peers().filter(p=>p.kind==="viewer").length;el.textContent=tf("{a} of {n} answered",{a:Object.keys(LQ.ans[LQ.i]||{}).length,n})}}
function lqDraw(){const el=$("lqArea");if(!el)return;if(!LQ){gLive(el.parentElement);return}
  const L=QLV.find(x=>x[0]===LQ.lv),head=`<div class="lqhead"><div><span class="label">${t("Room code")}</span><b class="lqcode">${esc(LQ.code)}</b></div><div class="muted">${esc(t(SPORTS[LQ.b]?SPORTS[LQ.b].label:""))} · ${esc(t(L[1]))}</div><button class="btn ghost" data-lq="leave">${t("Leave")}</button></div>`;
  let body="";
  if(LQ.phase==="gone")body=`<p class="msg">${t("The host has left, so this game is over.")}</p>`;
  else if(LQ.phase==="lobby")body=LQ.host?`<p>${t("Tell your friends to open the Live quiz and enter this code. Start when everyone is in.")}</p><label class="lqlv"><span>${t("Level")}</span><select id="lqLv">${QLV.map(([id,lab])=>`<option value="${id}" ${id===LQ.lv?"selected":""}>${esc(t(lab))}</option>`).join("")}</select></label><div class="btns"><button class="btn" data-lq="start">${t("Start the quiz")}</button><button class="btn ghost" data-lq="copy">${t("Copy the code")}</button></div>`
     :`<p class="muted">${t("Waiting for the host to start…")}</p>`;
  else if(LQ.phase==="wait")body=`<p class="muted">${t("Get ready…")}</p>`;
  else if((LQ.phase==="q"||LQ.phase==="rev")&&LQ.qs[LQ.i]){const q=LQ.qs[LQ.i],my=LQ.mine[LQ.i],rev=LQ.phase==="rev";
    body=`<div class="quiz"><div class="top"><span class="label">${tf("Question {i} of {n}",{i:LQ.i+1,n:LQ.qs.length})}</span><span class="label" id="lqGot"></span></div>${!rev?`<div class="qtimer"><i id="lqBar"></i></div>`:""}
     <h3>${esc(q.q)}</h3><div class="opts">${q.o.map((o,k)=>{let c="opt";if(rev){if(k===q.a)c+=" right";else if(k===my)c+=" wrong"}else if(k===my)c+=" picked";return `<button class="${c}" data-lqa="${k}" ${my!=null||rev?"disabled":""}>${esc(o)}</button>`}).join("")}</div>
     ${rev?`<p class="explain"><b>${my===q.a?t("Correct."):my==null?t("Time's up."):t("Not quite.")}</b> ${esc(tf("The answer is {a}.",{a:q.o[q.a]}))}</p>`:my!=null?`<p class="muted">${t("Locked in. Waiting for the others…")}</p>`:""}</div>`}
  else if(LQ.phase==="end"){const P=LQ.nr.peers(),S=Object.entries(LQ.scores).sort((a,c)=>c[1]-a[1]),w=P.find(p=>S[0]&&p.peer===S[0][0]);
    body=`<div class="lqwin"><span class="label">${t("Winner")}</span><b>${esc(w?rtName(w):t("Someone"))}</b><span>${S[0]?S[0][1]:0} ${t("points")}</span></div>${LQ.host?`<div class="btns"><button class="btn" data-lq="again">${t("Play another round")}</button></div>`:`<p class="muted">${t("The host can start another round.")}</p>`}`}
  el.innerHTML=head+`<div class="lqmain"><div>${body}</div><aside><span class="label">${tf("Players ({n})",{n:LQ.nr.peers().filter(p=>p.kind==="viewer").length})}</span>${lqBoard()}</aside></div>`;
  lqDrawAnswers();if(LQ.phase==="q")lqTick();
  const on=(k,f)=>{const x=el.querySelector(`[data-lq="${k}"]`);if(x)x.onclick=f};
  on("leave",()=>{lqLeave();lqDraw()});on("start",()=>{const s=$("lqLv");if(s)LQ.lv=s.value;lqStart()});on("again",()=>{LQ.phase="lobby";LQ.scores={};lqSync();lqDraw()});
  on("copy",async()=>{try{await navigator.clipboard.writeText(LQ.code);xToast(t("Code copied. Send it to a friend!"))}catch(e){xToast(LQ.code)}});
  const lvS=$("lqLv");if(lvS)lvS.onchange=()=>{LQ.lv=lvS.value;RT.room&&RT.room.presence({lq:{c:LQ.code,b:current,lv:LQ.lv}}).catch(()=>{});lqDraw()};
  el.querySelectorAll("[data-lqa]").forEach(x=>x.onclick=()=>{if(LQ.mine[LQ.i]!=null||LQ.phase!=="q")return;const a=+x.dataset.lqa;LQ.mine[LQ.i]=a;LQ.nr.emit(LQT.ans,{i:LQ.i,a,ms:Date.now()-LQ.t0}).catch(()=>{});lqDraw()})}
function gLive(el){el.innerHTML=`<h2>${t("Live quiz")}</h2><p class="intro">${t("Play the quiz against friends in real time. Everyone gets the same questions in their own language. Faster right answers score more.")}</p><div id="lqArea" class="card lqarea"></div>`;
  const area=$("lqArea");if(LQ){lqDraw();return}area.innerHTML=`<p class="muted">${t("Connecting…")}</p>`;
  rtRoom().then(R=>{if(!$("lqArea"))return;if(!R){area.innerHTML=rtNoRoom();return}
    const open=()=>R.peers().filter(p=>p.presence&&p.presence.lq&&p.presence.lq.c&&!p.isMe).map(p=>({p,...p.presence.lq}));
    const draw=()=>{if(LQ||!$("lqArea"))return;const O=open();rtNames(O.map(o=>o.p.by)).then(n=>{if(n)draw()});
      area.innerHTML=`<div class="lqstart"><article><span class="label">${t("Host a game")}</span><p>${t("Create a room, share the code, and start when your friends are in.")}</p><label class="lqlv"><span>${t("Level")}</span><select id="lqLv0">${QLV.map(([id,lab])=>`<option value="${id}" ${id==="normal"?"selected":""}>${esc(t(lab))}</option>`).join("")}</select></label><div class="btns"><button class="btn" data-lq0="host">${t("Create a room")}</button></div></article>
       <article><span class="label">${t("Join a game")}</span><div class="btns chrow"><input id="lqIn" placeholder="${t("Room code")}" aria-label="${t("Room code")}" maxlength="6"><button class="btn ghost" data-lq0="join">${t("Join")}</button></div><p class="msg" id="lqMsg" aria-live="polite"></p>
       ${O.length?`<span class="label">${t("Open rooms")}</span><ul class="lqopen">${O.map(o=>`<li><span>${esc(rtName(o.p))} · ${esc(t(SPORTS[o.b]?SPORTS[o.b].label:""))}</span><button class="btn ghost" data-lqj="${esc(o.c)}">${t("Join")} ${esc(o.c)}</button></li>`).join("")}</ul>`:`<p class="fine">${t("No open rooms right now.")}</p>`}</article></div>`;
      area.querySelector('[data-lq0="host"]').onclick=()=>lqJoin(lqCode(),true,$("lqLv0").value);
      area.querySelector('[data-lq0="join"]').onclick=async()=>{const ok=await lqJoin($("lqIn").value,false);if(!ok&&$("lqMsg"))$("lqMsg").textContent=t("Enter the 5-character code from the host.")};
      area.querySelectorAll("[data-lqj]").forEach(x=>x.onclick=()=>lqJoin(x.dataset.lqj,false))};
    draw();const un=R.onPeers(()=>{if(!$("lqArea")||LQ){un();return}const f=document.activeElement;if(f&&f.id==="lqIn")return;draw()})})}
GAME_FN.live=gLive;
Object.keys(PLAY).forEach(b=>{const i=PLAY[b].findIndex(x=>x[0]==="quiz");PLAY[b].splice(i+1,0,["live","Live quiz","Play against friends in real time"])});

/* ---------------- Match-night watch party ---------------- */
const WP_REACT=[["goal","⚽","Goal!"],["chance","😱","What a chance"],["save","🧤","Great save"],["card","🟨","Card"],["wow","🔥","Atmosphere"],["sad","😩","Oh no"]];
let WP=null;
function wpFixture(b){const L=LIVE[b];if(!L)return null;const now=Date.now();const list=L.next.filter(n=>n[0]).map(n=>{const [Y,M,D]=n[0].split("-").map(Number),[h,mi]=(n[1]||"18:00").split(":").map(Number);return {n,ko:Date.UTC(Y,M-1,D,h-3,mi)}});
  return list.find(x=>now<x.ko+150*60000)||null}
const wpKey=(b,f)=>xKey(b,f.n[0],f.n[4]);
const wpRoomName=(b,f)=>("wp-"+BR_CODE[b]+"-"+f.n[0].replace(/-/g,"")+"-"+sn(f.n[4]).replace(/[^a-z0-9]/g,"").slice(0,16)).toLowerCase();
const wpMin=f=>Math.floor((Date.now()-f.ko)/60000);
const xWatch=()=>store.get("fb-watch",{});
function wpCard(b){const f=wpFixture(b);if(!f)return "";const m=wpMin(f),live=m>=-30&&m<150,opp=f.n[4],title=f.n[3]==="H"?`Fenerbahçe – ${opp}`:`${opp} – Fenerbahçe`;
  return `<article class="card wpcard ${live?"live":""}" id="wpCard"><div><span class="label">${live?(m<0?t("Watch party · starting soon"):t("Watch party · live now")):t("Match-night watch party")}</span><h3>${esc(title)}</h3><p class="muted">${live?t("Join other fans on the page: react to every chance and chat while the game is on."):tf("Opens 30 minutes before kick-off, {d}. You can drop in early to chat.",{d:mDate(f.n[0],true)+(f.n[1]?" · "+f.n[1]:"")})}</p></div><button class="btn ${live?"":"ghost"}" data-wp="open">${t(live?"Join the watch party":"Open it now")}</button></article>`}
async function wpOpen(b){const f=wpFixture(b);if(!f)return;const R=await rtRoom();
  if(!R){ovOpen(`<article class="wp"><h2>${t("Watch party")}</h2>${rtNoRoom()}</article>`,t("Watch party"));return}
  let nr;try{nr=await R.join(wpRoomName(b,f))}catch(e){xToast(t("Couldn't join that room. Try again."));return}
  if(WP&&WP.nr!==nr){try{WP.nr.leave()}catch(e){}}
  WP={b,f,nr,key:wpKey(b,f),feed:[],counts:{},un:[],last:0,pend:false};nr.presence({w:1}).catch(()=>{});
  WP.un.push(nr.on("react",m=>{const d=m.data||{};const R0=WP_REACT.find(x=>x[0]===d.k);if(!R0)return;WP.counts[d.k]=(WP.counts[d.k]||0)+1;WP.feed.unshift({k:"r",r:R0,p:m,min:+d.m||0,ts:Date.now()});WP.feed=WP.feed.slice(0,60);wpFloat(R0[1]);wpDraw()}));
  WP.un.push(nr.on("chat",m=>{const d=m.data||{};if(typeof d.x!=="string")return;const x=d.x.replace(/[\u0000-\u001f​-‏‪-‮]/g,"").slice(0,140).trim();if(!x)return;WP.feed.unshift({k:"c",x,p:m,min:+d.m||0,ts:Date.now()});WP.feed=WP.feed.slice(0,60);wpDraw()}));
  WP.un.push(nr.onPeers(ch=>{rtNames(ch.peers.map(p=>p.by)).then(n=>{if(n)wpDraw()});const c=$("wpN");if(c)c.textContent=tf(ch.peers.length===1?"1 fan here":"{n} fans here",{n:ch.peers.length})}));
  const title=f.n[3]==="H"?`Fenerbahçe – ${f.n[4]}`:`${f.n[4]} – Fenerbahçe`;
  ovOpen(`<article class="wp"><span class="label">${t("Watch party")} · ${esc(t(f.n[2]))}</span><h2>${esc(title)}</h2><p class="muted"><span id="wpN"></span> · <span id="wpClock"></span></p>
    <div class="wpreact">${WP_REACT.map(([k,e,l])=>`<button data-wpr="${k}" aria-label="${esc(t(l))}"><span class="e">${e}</span><span class="l">${esc(t(l))}</span><b id="wpc-${k}">0</b></button>`).join("")}</div>
    <form class="wpchat" id="wpForm"><input id="wpIn" maxlength="140" placeholder="${t("Say something…")}" aria-label="${t("Message")}" autocomplete="off"><button class="btn">${t("Send")}</button></form>
    <ol class="wpfeed" id="wpFeed" aria-live="polite"></ol><div class="wpfloat" id="wpFloat" aria-hidden="true"></div>
    <p class="fine">${t("Messages are only seen by fans on the page right now and aren't saved. Your reactions are saved so the match page can show the loudest moments.")}</p></article>`,title);
  const ov=$("ov"),obs=new MutationObserver(()=>{if(ov.hidden){wpClose();obs.disconnect()}});obs.observe(ov,{attributes:true,attributeFilter:["hidden"]});
  document.querySelectorAll("[data-wpr]").forEach(x=>x.onclick=()=>wpReact(x.dataset.wpr));
  $("wpForm").onsubmit=e=>{e.preventDefault();const v=$("wpIn").value.trim();if(!v||Date.now()-WP.last<1500)return;if(modBad(v)){xToast(t("Please keep it friendly. That message wasn't sent."));return}WP.last=Date.now();WP.nr.emit("chat",{x:v.slice(0,140),m:wpMin(WP.f)}).catch(()=>xToast(t("Messages can't be sent from this view.")));$("wpIn").value=""};
  WP.clock=setInterval(()=>{const c=$("wpClock");if(!c||!WP){clearInterval(WP&&WP.clock);return}const m=wpMin(WP.f);c.textContent=m<0?tf("Kick-off in {n} min",{n:-m}):m<130?tf("About {n}' played",{n:Math.min(m,120)}):t("Full time")},1000);wpDraw()}
function wpClose(){if(!WP)return;clearInterval(WP.clock);WP.un.forEach(u=>{try{u()}catch(e){}});try{WP.nr.leave()}catch(e){}wpFlush();WP=null}
let wpRT=0;
function wpReact(k){if(!WP||Date.now()-wpRT<700)return;wpRT=Date.now();const m=wpMin(WP.f);WP.nr.emit("react",{k,m}).catch(()=>xToast(t("Messages can't be sent from this view.")));
  const W=xWatch(),M=W[WP.key]=W[WP.key]||{},bk=String(Math.max(-30,Math.min(130,Math.floor(m/5)*5)));(M[bk]=M[bk]||{})[k]=(M[bk][k]||0)+1;
  const ks=Object.keys(W);if(ks.length>20)ks.slice(0,ks.length-20).forEach(x=>delete W[x]);store.set("fb-watch",W);WP.pend=true;clearTimeout(WP.ft);WP.ft=setTimeout(wpFlush,5000)}
function wpFlush(){if(!WP||!WP.pend)return;WP.pend=false;xWrite("watch",{w:xWatch(),ts:Date.now()})}
function wpFloat(e){const f=$("wpFloat");if(!f)return;const s=document.createElement("span");s.textContent=e;s.style.left=(10+Math.random()*80)+"%";f.appendChild(s);setTimeout(()=>s.remove(),2200)}
function wpDraw(){if(!WP)return;WP_REACT.forEach(([k])=>{const c=$("wpc-"+k);if(c)c.textContent=WP.counts[k]||0});const F=$("wpFeed");if(!F)return;
  F.innerHTML="";WP.feed.slice(0,40).forEach(x=>{const li=document.createElement("li");const who=document.createElement("b");who.textContent=rtName(x.p);const mn=document.createElement("span");mn.className="muted";mn.textContent=x.min<0?t("pre-match"):`${x.min}'`;
    const body=document.createElement("span");if(x.p&&x.p.by)li.dataset.uid=x.p.by;if(x.k==="c")li.dataset.msg=x.x;body.textContent=x.k==="c"?modClean(x.x):`${x.r[1]} ${t(x.r[2])}`;li.append(mn," ",who," ",body);if(x.k==="r")li.className="r";F.appendChild(li)})}
/* loudest moments on the match page, from everyone's saved reactions */
function wpMoments(key){const all=xAllDocs("watch",xWatch(),"w"),B={};Object.values(all).forEach(W=>{const M=W&&W[key];if(!M)return;Object.entries(M).forEach(([bk,o])=>{B[bk]=B[bk]||{};Object.entries(o||{}).forEach(([k,v])=>{v=+v;if(v>0&&v<500)B[bk][k]=(B[bk][k]||0)+v})})});return B}
function wpMomentsHtml(key){const B=wpMoments(key),ks=Object.keys(B).map(Number).sort((a,c)=>a-c);if(!ks.length)return "";const tot=k=>Object.values(B[k]).reduce((a,v)=>a+v,0),mx=Math.max(...ks.map(tot)),peak=ks.reduce((a,k)=>tot(k)>tot(a)?k:a,ks[0]),top=Object.entries(B[peak]).sort((a,c)=>c[1]-a[1])[0],R0=WP_REACT.find(x=>x[0]===top[0]);
  return `<section><h4 class="mh">${t("Watch party")}</h4><p>${tf("The loudest moment came around {m}: {e} {l}.",{m:peak<0?t("pre-match"):`${peak}'–${peak+5}'`,e:R0?R0[1]:"",l:R0?t(R0[2]):""})}</p><div class="wpspark">${ks.map(k=>`<i style="height:${Math.max(6,tot(k)/mx*100)}%" title="${k<0?t("pre-match"):k+"'"}: ${tot(k)}"></i>`).join("")}</div></section>`}
/* hooks: matches tab card, match page, home */
EXT.afterPanel.push(p=>{if(tab!=="matches")return;const h=p.querySelector("h2"),c=wpCard(current);if(c&&h&&!$("wpCard")){const intro=p.querySelector(".intro"),later=!c.includes("wpcard live")&&(p.querySelector(".mgrid")||p.querySelector(".mcols"));
  /* a party that hasn't started waits below the results; a live one goes to the top */
  if(later)later.insertAdjacentHTML("afterend",c);else (intro||h).insertAdjacentHTML("afterend",c)}});
document.addEventListener("click",e=>{const w=e.target.closest('[data-wp="open"]');if(w)wpOpen(w.dataset.wpb||current)});
EXT.matchPage.push((b,i)=>{const r=LIVE[b]&&LIVE[b].last[i];if(!r)return;const h=wpMomentsHtml(xKey(b,r[0],r[3]));if(h){const nav=document.querySelector(".mp .mpnav");if(nav)nav.insertAdjacentHTML("beforebegin",h)}});
EXT.home.push(p=>{const live=HOME_BR.map(b=>{const f=wpFixture(b);if(!f)return null;const m=wpMin(f);return m>=-30&&m<150?{b,f}:null}).filter(Boolean);
  if(live.length){const h=p.querySelector(".intro");h.insertAdjacentHTML("afterend",live.map(({b,f})=>`<article class="card wpcard live"><div><span class="label">${t("Watch party · live now")} · ${esc(t(SPORTS[b].label))}</span><h3>${esc(f.n[3]==="H"?"Fenerbahçe – "+f.n[4]:f.n[4]+" – Fenerbahçe")}</h3></div><button class="btn" data-wp="open" data-wpb="${b}">${t("Join the watch party")}</button></article>`).join(""))}});
BADGES.push(["live","Quizmaster","Win a live quiz against friends.",()=>store.get("fb-lq-wins",0)>0]);

/* ===== Finding your way: Play in groups, home page tabs, first-visit tour, settings (design, language, text size,
   quiz timer) and a plain note on which features are shared with other fans. ===== */

/* ---------- Play, in four groups ---------- */
const PLAY_GROUPS=[["quiz","Quizzes",["quiz","daily","wordle","who","which"]],["team","Teams & seasons",["draft","draft5","draft6","draft11","xi","lineup","squad"]],
 ["quick","Quick games",["penalties","ft","serve","timeline","hol","gts","memory"]],["friends","With friends",["live","board","badges"]]];
const playGrpOf=g=>(PLAY_GROUPS.find(x=>x[2].includes(g))||PLAY_GROUPS[2])[0];
const playLast=store.get("fb-playlast",{});
function playGroups(list){return PLAY_GROUPS.map(([k,l])=>[k,l,list.filter(x=>playGrpOf(x[0])===k)]).filter(x=>x[2].length)}
function pickGame(id){playSel[current]=id;playLast[current+"|"+playGrpOf(id)]=id;store.set("fb-playlast",playLast);store.set("fb-playsel",playSel);if(tab!=="play"){tab="play";syncHash();render()}else renderPanel()}
function renderPlayRaw(p){const list=PLAY[current];let g=playSel[current];if(!list.some(x=>x[0]===g))g=list[0][0];playSel[current]=g;
  const groups=playGroups(list),cur=groups.find(x=>x[0]===playGrpOf(g))||groups[0];
  p.innerHTML=`<div class="playnav"><div class="pgroups" role="tablist" aria-label="${t("Games")}">${groups.map(([k,l,xs])=>`<button role="tab" id="pg-${k}" aria-controls="pcards" aria-selected="${k===cur[0]}" tabindex="${k===cur[0]?0:-1}" data-pgrp="${k}">${esc(t(l))}<small aria-hidden="true">${xs.length}</small></button>`).join("")}</div>
   <div class="launcher" id="pcards" role="tabpanel" aria-labelledby="pg-${cur[0]}">${cur[2].map(([id,x,d])=>`<button class="lcard" aria-pressed="${id===g}" data-game="${id}"><b>${t(x)}</b><span>${t(d)}</span></button>`).join("")}</div>
   ${cur[0]==="friends"?`<p class="livenote" data-livenote></p>`:""}</div><div id="gameArea" class="gamearea"></div>`;
  p.querySelectorAll("[data-game]").forEach(x=>x.onclick=()=>{pickGame(x.dataset.game);const a=document.getElementById("gameArea");if(a&&a.getBoundingClientRect().top<0)a.scrollIntoView({block:"start"})});
  const tabsEl=[...p.querySelectorAll("[data-pgrp]")];
  tabsEl.forEach((x,i)=>{x.onclick=()=>{const G=groups.find(y=>y[0]===x.dataset.pgrp),keep=playLast[current+"|"+G[0]];pickGame(keep&&G[2].some(y=>y[0]===keep)?keep:G[2][0][0]);const f=document.querySelector(`[data-pgrp="${G[0]}"]`);if(f)f.focus()};
    x.onkeydown=e=>{const rtl=document.documentElement.dir==="rtl",d={ArrowRight:rtl?-1:1,ArrowLeft:rtl?1:-1,Home:-99,End:99}[e.key];if(d==null)return;e.preventDefault();const j=Math.max(0,Math.min(tabsEl.length-1,d===-99?0:d===99?tabsEl.length-1:i+d));tabsEl[j].click()}});
  /* keep the chosen card in view in the swipeable row (phones) without moving the page */
  const row=p.querySelector("#pcards"),on=row.querySelector('[aria-pressed="true"]');if(on&&row.scrollWidth>row.clientWidth+4){const r0=row.getBoundingClientRect(),r1=on.getBoundingClientRect();if(r1.left<r0.left||r1.right>r0.right)row.scrollLeft+=r1.left-r0.left-16}
  const ga=document.getElementById("gameArea");GAME_FN[g](ga);xAfterGame(g);paintLiveNotes()}

/* ---------- Shared features: say up front what needs signing in ---------- */
function paintLiveNotes(){const st=XC.on&&!XC.noWrite?"on":XC.tried?"off":"wait";
  const txt={on:"Your predictions, votes, ratings and scores are shared with other fans here. Pick a fan name in Settings so others know who you are. The live quiz and watch parties work with friends who open this page.",
    off:"Shared features (the prediction league, live quiz, watch parties, fan ratings and leaderboards) couldn't connect right now, so what you do is saved on this device only.",
    wait:"Checking whether shared features are available…"}[st];
  document.querySelectorAll("[data-livenote]").forEach(el=>{const full=el.dataset.livenote==="full",x=full?txt:st==="off"?"Saved on this device only. Shared features couldn't connect right now.":"";
    el.className="livenote "+st;el.innerHTML=x?`<span class="ln-dot" aria-hidden="true"></span><span>${esc(t(x))}</span>`:""})}
setTimeout(()=>{if(!XC.tried){XC.tried=true;paintLiveNotes()}},5000);

/* ---------- Small sport icons, used where several branches share one list ---------- */
const BR_SVG={
 fb:'<circle cx="12" cy="12" r="9"/><path d="M12 7.5l3.6 2.6-1.4 4.2H9.8l-1.4-4.2z"/><path d="M12 3v4.5M15.6 10.1L20 8.6M14.2 14.3l2.6 3.9M9.8 14.3l-2.6 3.9M8.4 10.1L4 8.6"/>',
 bb:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3v18M5.6 5.6c3 2.6 3 10.2 0 12.8M18.4 5.6c-3 2.6-3 10.2 0 12.8"/>',
 vb:'<circle cx="12" cy="12" r="9"/><path d="M12 3c-1.5 4 0 8 0 9s-4 4.5-8.4 4.6M12 12c1.3.2 6 2.3 8.6-1.8M12 12c-1.8-.8-4.6-4-3.6-8.4M12 12c.5 2 1.8 6 5.6 7.8"/>'};
function brIcon(b){const k=b.includes("basketball")?"bb":b.includes("volleyball")?"vb":"fb";
  return `<svg class="bri" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" role="img" aria-label="${esc(t(SPORTS[b].label))}"><title>${esc(t(SPORTS[b].label))}</title>${BR_SVG[k]}</svg>`}
/* ---------- One way to write a match everywhere: Fenerbahçe's score first, then "vs Opponent" or "at Opponent" ---------- */
function vsOpp(ha,o){return tf(ha==="A"?"at {o}":ha==="N"?"vs {o} (neutral)":"vs {o}",{o})}
/* ---------- Home page: one scrolling page ---------- */
function homeResults(n){const out=[];HOME_BR.forEach(b=>{const L=LIVE[b];if(!L)return;L.last.forEach((r,i)=>{if(r[0])out.push({b,r,i})})});return out.sort((a,c)=>c.r[0].localeCompare(a.r[0])).slice(0,n||8)}
/* one result, newest first lists; opens the match page */
function homeResRow({b,r,i}){const o=outcome(r),away=r[2]==="A";
  return `<li class="hfrow card mclick" data-mi="${i}" data-mb="${b}" tabindex="0" role="button" aria-label="${esc(tf("Match details: Fenerbahçe {a}–{b} {o}",{a:r[4],b:r[5],o:r[3]}))}"><div class="md"><b>${mDate(r[0],true)}</b><span>${fmtDay(isoDay(r[0]),{weekday:"short"})}</span></div><div class="mm"><span class="mcomp">${brIcon(b)}${esc(t(r[1]))}</span><span class="mopp">${esc(vsOpp(r[2],r[3]))}</span></div><div class="ms"><b>${r[4]}–${r[5]}</b>${rdot(o)}</div></li>`}
function homeLines(){const today=todayISO();
  return `<h3 class="mh">${t("Every team")}</h3><ul class="hlines">${HOME_BR.map(b=>{const L=LIVE[b];if(!L)return "";const r=L.last[0],n=(L.next||[]).find(x=>!x[0]||x[0]>=today);
    const last=r?`<span class="hl-last">${rdot(outcome(r))}<b>${esc(r[4])}–${esc(r[5])}</b> ${esc(vsOpp(r[2],r[3]))}</span>`:`<span class="hl-last muted">–</span>`;
    const nx=n?`<span class="hl-next"><span class="muted">${t("Next up")}</span> ${n[0]?mDate(n[0],true):esc(t(n[5]||"TBC"))} · ${esc(vsOpp(n[3],n[4]))}</span>`:`<span class="hl-next muted">${t("No fixture listed")}</span>`;
    return `<li><button class="hline" data-gosport="${b}"><span class="hl-br">${brIcon(b)}<b>${esc(t(SPORTS[b].label))}</b></span>${last}${nx}<span class="hl-go" aria-hidden="true">›</span></button></li>`}).join("")}</ul>`}
/* ---------- Match centre: the next match first, then the latest results, before anything else ---------- */
function countdown(iso){const d=Math.round((isoDay(iso)-isoDay(todayISO()))/DAY);return d<=0?t("Today"):d===1?t("Tomorrow"):tf("In {n} days",{n:d})}
function homeCentre(){const fx=homeFixtures(),first=fx[0],res=homeResults(6);
  const next=first?(()=>{const {b,n}=first,h=n[3]==="H";return `<article class="nextup card mcnext"><span class="label">${t("Next match")} · ${esc(t(SPORTS[b].label))} · ${esc(t(n[2]))}</span>
     <div class="nx-teams"><span class="${h?"fb":""}">${esc(h?"Fenerbahçe":n[4])}</span><span class="vs">${t("vs")}</span><span class="${h?"":"fb"}">${esc(h?n[4]:"Fenerbahçe")}</span></div>
     <div class="nx-meta"><b>${mDate(n[0])}</b>${n[1]?`<span>${esc(n[1])}</span>`:""}<span class="chip">${t(h?"Home":"Away")}</span><span class="chip win">${countdown(n[0])}</span></div>${calLinks(n,true)}
     <button class="btn ghost sm" data-gosport="${b}">${esc(tf("Open {x}",{x:t(SPORTS[b].label)}))} →</button></article>`})()
    :`<article class="nextup card mcnext"><span class="label">${t("Next match")}</span><p class="muted">${t("No upcoming fixtures in this snapshot.")}</p></article>`;
  return `<section class="mcentre" aria-labelledby="mcH"><h2 class="vh" id="mcH">${esc(t("Next match and latest results"))}</h2>${next}
    <section class="mcres"><h3 class="mh">${t("Latest results")} <small>${t("newest first")}</small></h3><ol class="hfx">${res.map(homeResRow).join("")}</ol>
     <button class="linkbtn" data-gohome="fixtures">${t("Every upcoming game →")}</button></section></section>`}
/* the home page itself is laid out in x_look.js */
/* the hero's "next match" line is only needed where the match centre isn't on screen */
EXT.afterPanel.push(p=>{document.body.dataset.view=tab==="matches"?"matches":"other";fitLede();
  /* phones: the score prediction folds away so the results follow the next match straight away */
  const pb=tab==="matches"&&p.querySelector("#predBox");if(!pb||!matchMedia("(max-width:560px)").matches||p.querySelector(".predtog"))return;
  pb.hidden=true;pb.insertAdjacentHTML("beforebegin",`<button class="btn ghost sm predtog" type="button" aria-expanded="false" aria-controls="predBox">${t("Predict the score")}</button>`);
  const b=p.querySelector(".predtog");b.onclick=()=>{pb.hidden=!pb.hidden;b.setAttribute("aria-expanded",!pb.hidden)}});

/* ---------- Short intro: two lines of the description, the rest on request ---------- */
let ledeOpen=false,ledeFor="";
function paintFooter(){const w=document.querySelector("footer .wrap");if(!w)return;let a=$("aboutSite");if(!a){w.insertAdjacentHTML("afterbegin",`<p id="aboutSite" class="about"></p>`);a=$("aboutSite")}
  a.textContent=t("About this site: results and tables are updated every Monday and Friday morning, so scores don't change live during a match. Made by a fan (D.Y).")}
function fitLede(){paintFooter();const el=$("heroLede");if(!el)return;let b=$("ledeMore");
  let a=$("heroAsof");if(!a){el.insertAdjacentHTML("beforebegin",`<p class="asof" id="heroAsof"></p>`);a=$("heroAsof")}a.textContent=tf("Results and tables updated {d}",{d:mDate(ASOF_ISO)});
  if(ledeFor!==current){ledeFor=current;ledeOpen=false}
  if(!b){el.insertAdjacentHTML("afterend",`<button class="linkbtn ledemore" id="ledeMore" type="button" aria-controls="heroLede" hidden></button>`);b=$("ledeMore");b.onclick=()=>{ledeOpen=!ledeOpen;fitLede()}}
  el.classList.toggle("open",ledeOpen);el.classList.add("clamp");
  const over=!ledeOpen&&el.scrollHeight>el.clientHeight+2;b.hidden=!(over||ledeOpen);b.textContent=t(ledeOpen?"Show less":"Read more");b.setAttribute("aria-expanded",ledeOpen)}
window.addEventListener("resize",()=>{clearTimeout(fitLede.tm);fitLede.tm=setTimeout(fitLede,150)});
const PLAY_TEASE=[["daily","Daily Mix","Five new questions every day"],["wordle","Fenerdle","Guess the player in six tries"],["quiz","Quiz","Five levels, from Easy to Extreme"],["live","Live quiz","Play against friends in real time"]];
function homePlay(){return `<section class="hsec" id="hs-play"><h3 class="mh">${t("Play")}</h3><div class="hplay">${PLAY_TEASE.map(([g,n,d])=>`<button class="hpcard" data-hplay="${g}"><b>${esc(t(n))}</b><span>${esc(t(d))}</span></button>`).join("")}
   <button class="hpcard" data-gohome="predict"><b>${esc(t("Predict the score"))}</b><span>${esc(t("Join the fans' prediction league"))}</span></button></div></section>`}
document.addEventListener("click",e=>{const g=e.target.closest("[data-hplay]");if(g){const id=g.dataset.hplay,b=PLAY.football.some(x=>x[0]===id)?"football":Object.keys(PLAY).find(k=>PLAY[k].some(x=>x[0]===id));setSport(b);pickGame(id);const a=$("gameArea");if(a)a.scrollIntoView({block:"start"});return}
  const x=e.target.closest("[data-gohome]");if(!x)return;if(current!=="home")setSport("home");const s=$("hs-"+x.dataset.gohome);if(s)s.scrollIntoView({block:"start",behavior:matchMedia("(prefers-reduced-motion:reduce)").matches?"auto":"smooth"})});

/* ---------- Settings: design, language, text size, quiz timer, tour ---------- */
const TS_LEVELS=[["0","Normal"],["1","Large"],["2","Larger"]],QT_LEVELS=[["1","Standard"],["2","Double time"],["0","No timer"]];
const qTimeMult=()=>+store.get("fb-qtime","1");
function applyTextSize(){document.documentElement.dataset.ts=store.get("fb-ts","0")}
applyTextSize();
const GEAR='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2.2"/><circle cx="10" cy="17" r="2.2"/></svg>';
function initSettings(){const host=document.querySelector(".bar .wrap");if(!host||$("setBtn"))return;
  host.insertAdjacentHTML("beforeend",`<div class="setwrap"><button class="hset" id="setBtn" type="button" aria-expanded="false" aria-controls="setPanel">${GEAR}<span data-t="Settings">${t("Settings")}</span></button>
   <div class="setpanel" id="setPanel" role="dialog" aria-modal="false" aria-label="${esc(t("Settings"))}" hidden></div></div>`);
  const btn=$("setBtn"),pan=$("setPanel");
  const close=(back)=>{pan.hidden=true;btn.setAttribute("aria-expanded","false");if(back)btn.focus()};
  btn.onclick=()=>{if(!pan.hidden){close(false);return}fillSettings();pan.hidden=false;btn.setAttribute("aria-expanded","true");const f=pan.querySelector("select,button");if(f)f.focus()};
  document.addEventListener("click",e=>{if(!pan.hidden&&!e.target.closest(".setwrap"))close(false)});
  pan.addEventListener("keydown",e=>{if(e.key==="Escape"){e.stopPropagation();close(true)}})}
function fillSettings(){const pan=$("setPanel");if(!pan)return;pan.setAttribute("aria-label",t("Settings"));const ts=store.get("fb-ts","0"),qt=store.get("fb-qtime","1");
  const seg=(name,list,val)=>`<div class="seg" role="group" aria-labelledby="sl-${name}">${list.map(([v,l])=>`<button type="button" data-set="${name}" data-v="${v}" aria-pressed="${v===val}">${esc(t(l))}</button>`).join("")}</div>`;
  pan.innerHTML=`<h2 id="setTitle">${t("Settings")}</h2>
   <label class="setrow"><span>${t("Design")}</span><select id="setTheme">${$("theme").innerHTML}</select></label>
   <label class="setrow"><span>${t("Language")}</span><select id="setLang">${$("lang").innerHTML}</select></label>
   <div class="setrow"><span id="sl-ts">${t("Text size")}</span>${seg("ts",TS_LEVELS,ts)}</div>
   <div class="setrow"><span id="sl-qt">${t("Quiz timer")}</span>${seg("qt",QT_LEVELS,qt)}<small>${t("For the Super hard and Extreme quiz levels. The live quiz keeps the same clock for everyone.")}</small></div>
   <div class="btns"><button class="btn ghost sm" id="setTour" type="button">${t("Take the tour")}</button></div>
   <p class="livenote" data-livenote="full"></p>`;
  $("setTheme").value=$("theme").value;$("setLang").value=$("lang").value;
  $("setTheme").onchange=e=>{$("theme").value=e.target.value;$("theme").dispatchEvent(new Event("change"))};
  $("setLang").onchange=e=>{$("lang").value=e.target.value;$("lang").dispatchEvent(new Event("change"));setTimeout(()=>{if(!$("setPanel").hidden){fillSettings();const f=$("setLang");if(f)f.focus()}},400)};
  pan.querySelectorAll("[data-set]").forEach(b=>b.onclick=()=>{const k=b.dataset.set,v=b.dataset.v;
    if(k==="ts"){store.set("fb-ts",v);applyTextSize()}else{store.set("fb-qtime",v);if(tab==="play"&&playSel[current]==="quiz")renderPanel()}
    pan.querySelectorAll(`[data-set="${k}"]`).forEach(x=>x.setAttribute("aria-pressed",x.dataset.v===v));b.focus()});
  $("setTour").onclick=()=>{pan.hidden=true;$("setBtn").setAttribute("aria-expanded","false");startTour()};paintLiveNotes()}

/* ---------- First-visit tour ---------- */
const TOUR=[
 ["#brRow","Pick a branch","Football, basketball, volleyball and more. \"All branches\" brings you back to the overview."],
 [".strip","Scores at the top","The latest scores and next games from every team. Tap one to see the details."],
 ["#hs-fixtures","Everything at a glance","The next match and the latest results from every team. Scroll down for every team, games and the fans' prediction league."],
 ["#tabs","Season, club and games","Each branch has this season's matches and tables, the club's history, and games to play."],
 ["#bnav","Always one tap away","Home, matches, tables, games and search sit at the bottom of the screen."],
 ["#hSearch","Search","Find players, matches, records and seasons in any branch."],
 [".kanbtn","Ask Kanarya","The site's helper answers questions about the club from the facts on this page."],
 ["#setBtn","Make it yours","Change the design, language, text size and quiz timer. You can replay this tour here."],
 [null,"Playing with other fans","The prediction league, live quiz, watch parties, ratings and leaderboards are shared with other fans. Pick a fan name in Settings to appear on the leaderboards."]];
let TR=null;
function tourSteps(){return TOUR.filter(([sel])=>{if(!sel)return true;const el=document.querySelector(sel);if(!el)return false;const r=el.getBoundingClientRect();return r.width>0&&r.height>0})}
function startTour(){endTour(false);const steps=tourSteps();if(!steps.length)return;
  const ov=document.createElement("div");ov.className="tour";ov.innerHTML=`<div class="tourring" aria-hidden="true"></div><div class="tourcard" role="dialog" aria-modal="true" aria-labelledby="tourH" aria-describedby="tourP" tabindex="-1"></div>`;
  document.documentElement.appendChild(ov);TR={ov,steps,i:0,back:document.activeElement};
  ov.addEventListener("keydown",e=>{if(e.key==="Escape"){e.preventDefault();endTour(true)}
    if(e.key==="Tab"){const f=[...ov.querySelectorAll("button")];if(!f.length)return;const a=f[0],z=f[f.length-1];if(e.shiftKey&&document.activeElement===a){e.preventDefault();z.focus()}else if(!e.shiftKey&&document.activeElement===z){e.preventDefault();a.focus()}}});
  window.addEventListener("resize",tourPlace);window.addEventListener("scroll",tourPlace,{passive:true});tourShow()}
function tourShow(){if(!TR)return;const [sel,h,d]=TR.steps[TR.i],n=TR.steps.length,last=TR.i===n-1,card=TR.ov.querySelector(".tourcard");
  card.innerHTML=`<span class="label">${esc(tf("Step {i} of {n}",{i:TR.i+1,n}))}</span><h3 id="tourH">${esc(t(h))}</h3><p id="tourP">${esc(t(d))}</p>
   <div class="btns">${TR.i?`<button class="btn ghost sm" data-tr="back">${t("Back")}</button>`:""}<button class="btn sm" data-tr="next">${t(last?"Done":"Next")}</button>${last?"":`<button class="linkbtn" data-tr="skip">${t("Skip the tour")}</button>`}</div>`;
  card.querySelectorAll("[data-tr]").forEach(b=>b.onclick=()=>{const k=b.dataset.tr;if(k==="skip")return endTour(true);if(k==="back")TR.i--;else if(last)return endTour(true);else TR.i++;tourShow()});
  const el=sel&&document.querySelector(sel);if(el){const r=el.getBoundingClientRect();if(r.top<70||r.bottom>innerHeight-200)el.scrollIntoView({block:"center",behavior:"instant"})}
  tourPlace();const nb=card.querySelector('[data-tr="next"]');(nb||card).focus()}
function tourPlace(){if(!TR)return;const [sel]=TR.steps[TR.i],el=sel&&document.querySelector(sel),ring=TR.ov.querySelector(".tourring"),card=TR.ov.querySelector(".tourcard");
  const W=innerWidth,H=innerHeight,cw=Math.min(360,W-32);card.style.width=cw+"px";
  if(!el){ring.style.cssText="left:50%;top:50%;width:0;height:0";card.style.left=(W-cw)/2+"px";card.style.top=Math.max(16,(H-card.offsetHeight)/2)+"px";return}
  const r=el.getBoundingClientRect(),pad=6;ring.style.cssText=`left:${r.left-pad}px;top:${r.top-pad}px;width:${r.width+pad*2}px;height:${r.height+pad*2}px`;
  const ch=card.offsetHeight,below=r.bottom+pad+14,above=r.top-pad-14-ch;let top=below+ch<H-8?below:above>8?above:Math.max(8,H-ch-8);
  let left=Math.min(Math.max(16,r.left+r.width/2-cw/2),W-cw-16);card.style.left=left+"px";card.style.top=top+"px"}
function endTour(done){if(!TR)return;store.set("fb-tour",1);window.removeEventListener("resize",tourPlace);window.removeEventListener("scroll",tourPlace);const back=TR.back;TR.ov.remove();TR=null;if(done&&back&&back.focus&&document.contains(back))back.focus()}
/* first visit only; automated browsers (tests, previews) never see it */
/* the tour never starts by itself: a button on the home page (and one in Settings) starts it */
function maybeTour(){}
const TOUR_ICON='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="9.5"/><path d="M15.5 8.5l-2 5-5 2 2-5z" stroke-linejoin="round"/></svg>';
function tourButton(){const lede=$("heroLede");if(!lede)return;let b=$("tourBtn");
  if(!b){(($("ledeMore"))||lede).insertAdjacentHTML("afterend",`<button class="tourbtn" id="tourBtn" type="button">${TOUR_ICON}<span></span></button>`);b=$("tourBtn");b.onclick=()=>startTour()}
  b.querySelector("span").textContent=t("New here? Take a quick tour of the site")}

/* ===== v23: the "Matchday" layout. A score strip on top, a navy band with every branch as an icon tab, a two-column
   home page, card-based branch pages and a bottom tab bar on phones. Ideas taken from big sports sites (score strip,
   white cards on grey, stacked match rows, bottom bar); no club crests: teams get initials in a coloured circle. ===== */

/* ---------- Team initials ---------- */
const BADGE_COL=["#c8423b","#3d6aa6","#3f8f4a","#8e5b9a","#d7822c","#2f8f8a","#7c5b48","#b08a1e","#c0507a","#5b6b7c"];
function teamCode(n){if(n==="Fenerbahçe")return "FB";const w=n.replace(/[()]/g,"").split(/\s+/).filter(Boolean);
  const c=w.length===1?w[0].slice(0,3):w.slice(0,3).map(x=>x[0]).join("");return c.toLocaleUpperCase("tr")}
function teamBadge(n){const fb=n==="Fenerbahçe";let h=0;for(const ch of n)h=(h*31+ch.charCodeAt(0))>>>0;
  return `<span class="tb${fb?" fbb":""}" style="${fb?"":"--tb:"+BADGE_COL[h%BADGE_COL.length]}" aria-hidden="true">${esc(teamCode(n))}</span>`}

/* ---------- Day labels for grouped lists ---------- */
function dayLabel(iso){const d=Math.round((isoDay(iso)-isoDay(todayISO()))/DAY);
  return d===0?t("Today"):d===-1?t("Yesterday"):d===1?t("Tomorrow"):fmtDay(isoDay(iso),{weekday:"long",day:"numeric",month:"long"})}

/* ---------- Score strip ---------- */
function stripTile(x){
  if(x.r){const {b,r,i}=x,P=sides(r),o=outcome(r);
    return `<button class="stile" data-mi="${i}" data-mb="${b}" aria-label="${esc(tf("Match details: Fenerbahçe {a}–{b} {o}",{a:r[4],b:r[5],o:r[3]}))}"><span class="stc">${brIcon(b)}<span>${esc(t(r[1]))}</span></span><span class="sts">${mDate(r[0],true)} · ${t("FT")}</span>
      ${P.map(([n,sc])=>`<span class="str${n==="Fenerbahçe"?" fb":""}">${teamBadge(n)}<span class="sn">${esc(teamCode(n))}</span><b>${esc(sc)}</b></span>`).join("")}</button>`}
  const {b,n}=x,P=n[3]==="A"?[n[4],"Fenerbahçe"]:["Fenerbahçe",n[4]];
  return `<button class="stile up" data-gosport="${b}" aria-label="${esc(t(SPORTS[b].label)+": "+vsOpp(n[3],n[4])+", "+mDate(n[0])+(n[1]?" "+n[1]:""))}"><span class="stc">${brIcon(b)}<span>${esc(t(n[2]))}</span></span><span class="sts">${mDate(n[0],true)}${n[1]?" · "+esc(n[1]):""}</span>
    ${P.map(nm=>`<span class="str${nm==="Fenerbahçe"?" fb":""}">${teamBadge(nm)}<span class="sn">${esc(teamCode(nm))}</span></span>`).join("")}</button>`}
let stripPainted=false;
function paintStrip(){const tr=$("strack");if(!tr)return;const res=homeResults(9999).reverse(),fx=homeFixtures();
  let mon="",html="";const monTag=d=>{const m=d.slice(0,7);if(m===mon)return "";mon=m;return `<span class="smon" aria-hidden="true">${esc(fmtDay(isoDay(m+"-15"),{month:"short"}))}<small>${m.slice(0,4)}</small></span>`};
  res.forEach(x=>{html+=monTag(x.r[0])+stripTile(x)});if(fx.length)html+=`<span class="ssep" aria-hidden="true"></span>`;fx.forEach(x=>{html+=monTag(x.n[0])+stripTile(x)});
  tr.innerHTML=html;
  if(!stripPainted){stripPainted=true;requestAnimationFrame(()=>{const f=tr.querySelector(".stile.up");if(f&&tr.scrollWidth>tr.clientWidth){const rtl=document.documentElement.dir==="rtl";tr.scrollLeft=rtl?-(tr.scrollWidth-f.offsetLeft-f.offsetWidth-tr.clientWidth/3):Math.max(0,f.offsetLeft-tr.clientWidth/3)}})}}

/* ---------- Branch tabs with icons ---------- */
const BR_ROW=["home","football","womens-football","basketball","womens-basketball","volleyball","mens-volleyball","more"];
const ICON_HOME='<svg class="bri" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 11l8-6 8 6v8a1 1 0 0 1-1 1h-4v-6H9v6H5a1 1 0 0 1-1-1z"/></svg>';
const ICON_MORE='<svg class="bri" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><rect x="4" y="4" width="6.5" height="6.5" rx="1.5"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.5"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.5"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.5"/></svg>';
function brRowIcon(b){return b==="home"?ICON_HOME:b==="more"?ICON_MORE:brIcon(b).replace('role="img"','aria-hidden="true"').replace(/<title>.*?<\/title>/,"")}
function paintBrRow(){const nav=$("brRow");if(!nav)return;
  nav.querySelector(".wrap").innerHTML=BR_ROW.filter(b=>b==="home"||SPORTS[b]).map(b=>`<button type="button" data-br="${b}"${b===current?' aria-current="page"':""}>${brRowIcon(b)}<span>${esc(b==="home"?t("All branches"):b==="more"?t("More"):b==="football"?t("Men's Football"):t(SPORTS[b].label))}</span></button>`).join("");
  {const w=nav.querySelector(".wrap");nav.classList.remove("tight");if(w.scrollWidth>w.clientWidth+1)nav.classList.add("tight")}
  const on=nav.querySelector('[aria-current="page"]');if(on){const w=nav.querySelector(".wrap"),r0=w.getBoundingClientRect(),r1=on.getBoundingClientRect();if(r1.left<r0.left||r1.right>r0.right)w.scrollLeft+=r1.left-r0.left-24}}
{let rz;addEventListener("resize",()=>{clearTimeout(rz);rz=setTimeout(paintBrRow,150)})}
document.addEventListener("click",e=>{const x=e.target.closest("[data-br]");if(!x)return;setSport(x.dataset.br);scrollTo({top:0})});

/* ---------- Bottom tab bar (phones) ---------- */
let lastBr="football";
const BN=[["home","nav:Home",ICON_HOME],
 ["matches","Matches",'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M9 3v4M15 3v4"/></svg>'],
 ["standings","Standings",'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="M5 20V10M12 20V4M19 20v-7"/></svg>'],
 ["play","Play",'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="7" width="18" height="11" rx="4"/><path d="M8 11v3M6.5 12.5h3M15.5 12h.01M18 13.5h.01"/></svg>'],
 ["search","Search",'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="6.5"/><path d="M16 16l4 4"/></svg>']];
function bnActive(){return current==="home"?"home":tab==="standings"||tab==="race"?"standings":tab==="play"?"play":tab==="matches"?"matches":""}
function paintBnav(){const nav=$("bnav");if(!nav)return;const a=bnActive();
  nav.innerHTML=BN.map(([k,l,ic])=>`<button type="button" data-bn="${k}"${k===a?' aria-current="page"':""}>${ic}<span>${esc(t(l))}</span></button>`).join("")}
function goBranchTab(tb){const b=current==="home"?lastBr:current;let x=tb;if(!tabsFor(b).some(y=>y[0]===x))x=tabsFor(b).some(y=>y[0]==="matches")?"matches":tabsFor(b)[0][0];
  if(current!==b){current=b;gameFilter="All";mFilter="All";mAll=false}tab=x;syncHash();render();scrollTo({top:0})}
document.addEventListener("click",e=>{const x=e.target.closest("[data-bn]");if(!x)return;const k=x.dataset.bn;
  if(k==="home"){setSport("home");scrollTo({top:0})}else if(k==="search")openSearch();else goBranchTab(k)});

/* ---------- Home: matches grouped by day ---------- */
let hmTab="results";
function homeMatches(){const items=hmTab==="results"?homeResults(14).map(x=>({d:x.r[0],h:srowResult(x.b,x.r,x.i,true)})):homeFixtures().slice(0,14).map(x=>({d:x.n[0],h:srowFixture(x.b,x.n,true)}));
  let last="",out="";items.forEach(x=>{if(x.d!==last){if(last)out+="</ol>";out+=`<h4 class="dayh">${esc(dayLabel(x.d))}</h4><ol class="mlist srows">`;last=x.d}out+=x.h});if(last)out+="</ol>";
  return out||`<p class="muted">${t(hmTab==="results"?"No results yet.":"No upcoming fixtures in this snapshot.")}</p>`}
function paintHomeMatches(){const box=$("hmList");if(!box)return;box.innerHTML=homeMatches();
  document.querySelectorAll("[data-hm]").forEach(b=>b.setAttribute("aria-pressed",b.dataset.hm===hmTab));const c=$("hmCsv");if(c)c.hidden=hmTab!=="upcoming"}
document.addEventListener("click",e=>{const b=e.target.closest("[data-hm]");if(b){hmTab=b.dataset.hm;paintHomeMatches();b.focus();return}
  const g=e.target.closest('[data-gohome="fixtures"]');if(g){hmTab="upcoming";if(current==="home")paintHomeMatches()}
  const s=e.target.closest("[data-gostand]");if(s){current=s.dataset.gostand;tab="standings";gameFilter="All";mFilter="All";syncHash();render();scrollTo({top:0})}},true);

EXT.home.push(p=>{const lg=p.querySelector("#leagueBox"),csvBtn=p.querySelector("[data-calcsv]"),csv=csvBtn&&csvBtn.closest(".btns"),live=[...p.querySelectorAll(".wpcard.live")],more=p.querySelector(".hmore");
  const tmp=document.createElement("div");tmp.innerHTML=homeCentre();const next=tmp.querySelector(".mcnext");
  p.innerHTML=`<h2 class="vh">${t("All branches")}</h2>
   <h2 class="vh">${esc(t("Latest results and next games"))}</h2><div class="hgrid2"><div class="hmain" id="hMain"></div><aside class="hside" id="hSide"></aside></div>
   <section class="hsec" id="hs-predict"></section>`;
  const M=$("hMain"),S=$("hSide");
  live.forEach(x=>M.appendChild(x));
  M.insertAdjacentHTML("beforeend",`<section class="card mcard" id="hs-fixtures"><header class="mch"><h3>${t("Matches")}</h3>
     <div class="filter" role="group" aria-label="${t("Show")}"><button data-hm="results" aria-pressed="true">${t("Results")}</button><button data-hm="upcoming" aria-pressed="false">${t("Upcoming")}</button></div></header>
     <div id="hmList"></div><div id="hmCsv" hidden></div></section>
    <section class="card mcard" id="hs-teams"><header class="mch"><h3>${t("Every team")}</h3></header>${homeLines().replace(/^<h3 class="mh">.*?<\/h3>/,"")}</section>`);
  if(csv)$("hmCsv").appendChild(csv);
  if(next){next.classList.add("mcard");S.appendChild(next)}
  S.insertAdjacentHTML("beforeend",miniTable("football").replace('data-goto="standings"','data-gostand="football"')+
   `<section class="card mcard" id="hs-play"><header class="mch"><h3>${t("Play")}</h3></header><div class="hplay side">${PLAY_TEASE.map(([g,n,d])=>`<button class="hpcard" data-hplay="${g}"><b>${esc(t(n))}</b><span>${esc(t(d))}</span></button>`).join("")}
     <button class="hpcard" data-gohome="predict"><b>${esc(t("Predict the score"))}</b><span>${esc(t("Join the fans' prediction league"))}</span></button></div></section>`);
  if(lg)$("hs-predict").appendChild(lg);if(more)$("hs-predict").insertAdjacentElement("afterend",more);
  paintHomeMatches();document.body.dataset.view="home";fitLede();tourButton();paintChrome()});
EXT.afterPanel.push(()=>paintChrome());

/* ---------- Everything outside the panel ---------- */
function paintChrome(){if(current!=="home")lastBr=current;[["brRow","Branches"],["bnav","Main"]].forEach(([i,l])=>{const e=$(i);if(e)e.setAttribute("aria-label",t(l))});{const e=document.querySelector(".strip");if(e)e.setAttribute("aria-label",t("Latest results and next games"))}paintBrRow();paintBnav();paintStrip()}
function lookInit(){EN_NS["nav:Home"]="Home";const hero=document.querySelector(".hero"),col=hero&&hero.querySelector(".wrap>div");
  if(col){col.appendChild($("stats"));col.appendChild($("home"))}
  if(hero){const tw=document.createElement("div");tw.className="wrap herotabs";tw.appendChild($("tabs"));hero.appendChild(tw)}
  const bar=document.querySelector(".bar");
  if(bar){bar.insertAdjacentHTML("beforeend",`<nav class="brrow" id="brRow" aria-label="${esc(t("Branches"))}"><div class="wrap"></div></nav>`);
    bar.insertAdjacentHTML("beforebegin",`<div class="strip" role="region" aria-label="${esc(t("Latest results and next games"))}"><div class="wrap"><div class="strack" id="strack"></div></div></div>`)}
  const pk=document.querySelector(".picker");if(pk){pk.setAttribute("aria-hidden","true");pk.querySelectorAll("select").forEach(s=>s.tabIndex=-1)}
  document.body.insertAdjacentHTML("beforeend",`<nav class="bnav" id="bnav" aria-label="${esc(t("Main"))}"></nav>`);paintChrome()}

/* Settings and account panels: never taller than the screen, with their own scrollbar */
(function(){const fit=p=>{if(!p||p.hidden)return;p.style.maxHeight="";const r=p.getBoundingClientRect();const bn=document.getElementById("bnav"),bt=bn&&getComputedStyle(bn).display!=="none"&&bn.getBoundingClientRect().height?bn.getBoundingClientRect().top:innerHeight;
  p.style.maxHeight=Math.max(220,Math.floor(Math.min(innerHeight,bt)-Math.max(r.top,8)-12))+"px"};
  const fitAll=()=>document.querySelectorAll(".setpanel").forEach(fit);
  const mo=new MutationObserver(ms=>ms.forEach(m=>{if(m.target.classList&&m.target.classList.contains("setpanel")&&!m.target.hidden)requestAnimationFrame(()=>fit(m.target))}));
  const watch=()=>document.querySelectorAll(".setpanel").forEach(p=>{if(!p._fitW){p._fitW=1;mo.observe(p,{attributes:true,attributeFilter:["hidden"]})}});
  watch();setInterval(watch,1000);addEventListener("resize",fitAll);addEventListener("scroll",fitAll,{passive:true})})();

/* ===== XI Draft, Golazo style: spin a formation, spin a season, pick one player from that squad ===== */
Object.assign(NAT,{SWE:"Sweden",ENG:"England",BEL:"Belgium",MLI:"Mali",RUS:"Russia",CPV:"Cape Verde",GRE:"Greece",COD:"DR Congo",SVN:"Slovenia",MKD:"North Macedonia"});
/* Regulars from the season line-ups who are not in the main player pool. Ratings are fan ratings made for this game. */
const GZ_EXTRA=[
 ["Kennet Andersson","ST","",77,"SWE",2000,2002],["Nikola Lazetić","CM","W",74,"SRB",2000,2001],["Milan Rapaić","W","AM",78,"CRO",2000,2001],
 ["Samuel Johnson","CM","",75,"GHA",2000,2003],["Mustafa Doğan","CB","RB",76,"TUR",2000,2002],["Zoran Mirković","CB","",75,"SRB",2000,2002],
 ["Abdullah Ercan","LB","",74,"TUR",2000,2002],["Ali Güneş","ST","W",74,"TUR",2001,2004],["Kemal Aslan","CM","",73,"TUR",2002,2003],
 ["Hakan Bayraktar","CM","",72,"TUR",2002,2003],["Ceyhun Eriş","AM","W",72,"TUR",2002,2003],["Stjepan Tomas","CB","",76,"CRO",2003,2004],
 ["Deniz Barış","CM","CB",76,"TUR",2004,2009],["Servet Çetin","CB","",76,"TUR",2004,2005],["Serkan Balcı","RB","LB",75,"TUR",2004,2006],
 ["Fábio Bilica","CB","",75,"BRA",2009,2010],["Alper Potuk","W","AM",75,"TUR",2013,2017],["Fernandão","ST","",76,"BRA",2015,2016],
 ["Jeremain Lens","W","",77,"NED",2016,2017],["Volkan Şen","W","",74,"TUR",2016,2017],["Giuliano de Paula","AM","W",78,"BRA",2017,2018],
 ["Nabil Dirar","W","RB",77,"MAR",2017,2020],["Aatif Chahechouhe","W","",74,"MAR",2017,2018],["Roman Neustädter","CB","CM",76,"RUS",2017,2019],
 ["Roberto Soldado","ST","",77,"ESP",2018,2019],["André Ayew","W","ST",77,"GHA",2018,2019],["Eljif Elmas","CM","AM",76,"MKD",2018,2019],
 ["Jailson","CM","",75,"BRA",2018,2020],["Harun Tekin","GK","",75,"TUR",2018,2019],["Ozan Tufan","CM","",76,"TUR",2019,2021],
 ["Garry Rodrigues","W","",75,"CPV",2019,2020],["Max Kruse","AM","ST",79,"GER",2019,2020],["Dimitris Pelkas","AM","",76,"GRE",2020,2021],
 ["José Sosa","AM","CM",76,"ARG",2020,2021],["Marcel Tisserand","CB","",75,"COD",2020,2021],["Serdar Dursun","ST","",76,"TUR",2021,2022],
 ["Miha Zajc","AM","CM",75,"SVN",2021,2023],["Diego Rossi","W","",76,"URU",2021,2023],["Miguel Crespo","CM","",76,"POR",2021,2022],
 ["Bright Osayi-Samuel","RB","",77,"NGA",2021,2024],["Michy Batshuayi","ST","",79,"BEL",2022,2023],["Samet Akaydın","CB","",74,"TUR",2022,2023],
 ["Lincoln","AM","W",76,"BRA",2022,2023],["Alexander Djiku","CB","",77,"GHA",2023,2025],["Sofyan Amrabat","CM","",80,"MAR",2024,2025],
 ["Dorgeles Nene","W","ST",77,"MLI",2025,2026],["Nélson Semedo","RB","",79,"POR",2025,2026],["Archie Brown","LB","",77,"ENG",2025,2026],
 ["Oğuz Aydın","W","",77,"TUR",2024,2026],["Mert Hakan Yandaş","CM","",75,"TUR",2020,2026],["Tarık Çetin","GK","",72,"TUR",2026,2026],
 ["Yiğit Efe Demir","CB","",72,"TUR",2026,2026],["Nathan Aké","CB","LB",81,"NED",2026,2026],["Kojo Peprah Oppong","CB","RB",77,"GHA",2026,2026],
 ["Ognjen Mimović","RB","",74,"SRB",2026,2026],["Bartuğ Elmaz","CM","",73,"TUR",2026,2026],["N'Golo Kanté","CM","",83,"FRA",2026,2026],
 ["Romelu Lukaku","ST","",82,"BEL",2026,2026],["Mason Greenwood","W","ST",84,"ENG",2026,2026]
].map(([n,pos,alt,r,nat,from,to])=>({n,pos,alt:alt?alt.split(","):[],r,nat,from,to,short:lastName(n),gx:1}));
const GZ_BY={};PLAYERS.concat(GZ_EXTRA).forEach(p=>{if(!GZ_BY[p.n])GZ_BY[p.n]=p});
const GZ_SEASONS=SEASONS.map(s=>s[0]).concat(["2026-27"]);
const GZ_ROLE_ORDER={GK:0,RB:1,CB:2,LB:3,CM:4,AM:5,W:6,ST:7};
const gzCurSet=()=>{const s=new Set();try{SQUADS.football.groups.forEach(g=>g[1].forEach(x=>s.add(x[1])))}catch(e){}return s};
const GZ_SQ={};
function gzSquad(id){if(GZ_SQ[id])return GZ_SQ[id];const y=+id.slice(0,4),S=SEASONS.find(s=>s[0]===id),names=new Set(S?S[3].flat():[]),cur=y===2026?gzCurSet():null;
  const list=Object.values(GZ_BY).filter(p=>names.has(p.n)||(cur&&cur.has(p.n))||(!p.gx&&p.from<=y&&p.to>=y+1&&!(y===2026)));
  return GZ_SQ[id]=list.sort((a,b)=>GZ_ROLE_ORDER[a.pos]-GZ_ROLE_ORDER[b.pos]||b.r-a.r)}
const gzCan=(p,role)=>p.pos===role||p.alt.includes(role);
const gzUsed=()=>new Set(dr.picks.filter(Boolean).map(p=>p.n));
function gzFits(p){if(gzUsed().has(p.n))return [];return FORMS[dr.form].map((_,i)=>i).filter(i=>!dr.picks[i]&&gzCan(p,slotRole(dr.form,i)))}
function gzStrength(picks){const ps=picks.filter(Boolean);if(!ps.length)return {avg:0,min:0,str:0};const avg=ps.reduce((a,p)=>a+p.r,0)/ps.length,min=Math.min(...ps.map(p=>p.r));return {avg,min,str:.65*avg+.35*min}}
/* team rating used by the season simulator, the penalties and the career mode */
function teamInfo(form,picks,cap){const eff=picks.map((p,i)=>p?p.r-(gzCan(p,slotRole(form,i))?0:3):null),f=picks.filter(Boolean);
  if(!f.length)return {eff,ovr:0,base:0};const g=gzStrength(picks.map((p,i)=>p?{r:eff[i]}:null));return {eff,ovr:f.length===11?g.str:g.avg,base:g.avg}}
function newDraft(){dr={form:null,picks:Array(11).fill(null),offers:{},active:null,rerolls:3,captain:null,phase:"form",season:null,sel:null,spun:[],free:0,anim:null}}
const gzRm=()=>{if(window.GZ_FAST)return true;try{return matchMedia("(prefers-reduced-motion: reduce)").matches}catch(e){return false}};
function gzPickRandom(list){return chWith("football","rd",()=>list[Math.floor(Math.random()*list.length)])}
function gzReel(items,label,landIdx){const W=112,reps=4,seq=[];for(let k=0;k<reps;k++)items.forEach(x=>seq.push(x));const target=(reps-1)*items.length+landIdx;
  return {html:`<div class="gzreel" role="img" aria-label="${esc(label)}"><div class="gzwin"><div class="gztrack" style="transform:translateX(0px)">${seq.map(x=>`<span class="gztile">${esc(x)}</span>`).join("")}</div></div><span class="gzmark" aria-hidden="true"></span></div>`,target,W}}
function gzAnimate(root,target,W,done){const tr=root.querySelector(".gztrack"),win=root.querySelector(".gzwin");if(!tr||!win||gzRm()){done();return}
  const off=win.clientWidth/2-W/2,x=-(target*W)+off;tr.style.transition="none";tr.style.transform=`translateX(${off}px)`;void tr.offsetWidth;
  tr.style.transition="transform 1.6s cubic-bezier(.12,.75,.18,1)";tr.style.transform=`translateX(${x}px)`;let fin=false;const end=()=>{if(fin)return;fin=true;done()};tr.addEventListener("transitionend",end,{once:true});setTimeout(end,1900)}
function gzSpinForm(p){if(dr.anim)return;const keys=Object.keys(FORMS),f=gzPickRandom(keys),R=gzReel(keys,t("Formation wheel"),keys.indexOf(f));
  const box=p.querySelector("#gzWheel");box.innerHTML=R.html;dr.anim="form";gzAnimate(box,R.target,R.W,()=>{dr.anim=null;dr.form=f;dr.phase="spin";renderPanel()})}
function gzSpinSeason(p,kind){if(dr.anim)return;if(kind==="re"){if(!dr.rerolls)return;dr.rerolls--}
  const list=GZ_SEASONS.filter(s=>s!==dr.season),s=gzPickRandom(list),R=gzReel(list.map(szDash),t("Season wheel"),list.indexOf(s));
  const box=p.querySelector("#gzWheel");box.innerHTML=R.html;dr.anim="season";dr.sel=null;
  gzAnimate(box,R.target,R.W,()=>{dr.anim=null;dr.season=s;dr.spun.push(s);dr.phase="pick";renderPanel()})}
function gzScroll(){const h=document.querySelector(".gzhead");if(!h)return;const r=h.getBoundingClientRect();if(r.top<0||r.top>innerHeight*.5)h.scrollIntoView({block:"start",behavior:gzRm()?"auto":"smooth"})}
function gzPlace(p,i){dr.picks[i]=p;dr.sel=null;dr.season=null;if(dr.picks.every(Boolean)){dr.phase="done";const g=gzStrength(dr.picks),bs=store.get("fb-gz-best",null);if(bs==null||g.str>bs)store.set("fb-gz-best",Math.round(g.str*10)/10);if(typeof updateArcadeStats==="function")updateArcadeStats()}else dr.phase="spin";renderPanel();gzScroll()}
function gzPitch(){const F=FORMS[dr.form||"4-3-3"],fit=dr.sel?gzFits(dr.sel):[];
  return `<div class="pitch2 gzpitch"><span class="box18 top"></span><span class="box18"></span>${F.map(([pos,x,y],i)=>{const p=dr.picks[i],can=fit.includes(i),lab=dr.form?pos:"";
    return `<button type="button" class="ps ${p?"filled":""} ${can?"active fit":""}" style="left:${x}%;top:${y}%" data-gzslot="${i}" ${can?"":"tabindex=\"-1\""} aria-label="${esc(dr.form?pos:t("Empty"))}${p?": "+esc(p.n):""}"><span class="disc">${p?p.r:esc(lab)}</span><span class="nm">${p?esc(p.short):""}</span></button>`}).join("")}</div>`}
function gzSquadHtml(){const sq=gzSquad(dr.season),used=gzUsed(),anyFit=sq.some(p=>gzFits(p).length);
  const rows=sq.map(p=>{const f=gzFits(p),inXI=used.has(p.n),role=p.pos,why=inXI?t("Already in your XI"):!f.length?t("No open spot for him"):"";
    return `<button class="cand2 gzp ${dr.sel===p?"on":""}" data-gzp="${esc(p.n)}" ${f.length?"":"disabled"} aria-pressed="${dr.sel===p}"><span class="r">${p.r}</span><span class="info"><b>${esc(p.n)}</b><small>${esc(t(ROLE_NAME[role]))}${p.alt.length?" · "+p.alt.map(a=>esc(t(ROLE_NAME[a]))).join(", "):""} · ${esc(t(NAT[p.nat]||p.nat))}</small></span>${why?`<em class="tag">${esc(why)}</em>`:"<span></span>"}</button>`}).join("");
  return `<div class="gzsq"><div class="gzsqh"><span class="label">${t("The wheel picked")}</span><h3>${esc(tf("The {s} squad",{s:"\u2066"+szDash(dr.season)+"\u2069"}))}</h3>
    <p class="muted">${t(dr.sel?"Now tap a highlighted spot on the pitch.":anyFit?"Pick one player. Greyed-out players have no open spot.":"Nobody in this squad fits an open spot.")}</p></div>
    <div class="cands2">${rows}</div>
    <div class="btns">${anyFit?`<button class="btn ghost" data-gz="re" ${dr.rerolls?"":"disabled"}>${esc(tf(dr.rerolls===1?"Re-spin (1 left)":"Re-spin ({n} left)",{n:dr.rerolls}))}</button>`:`<button class="btn" data-gz="free">${t("Spin again (free)")}</button>`}</div></div>`}
function renderDraft(p){if(!dr||!("spun" in dr))newDraft();clearInterval(cupTimer);
  const n=dr.picks.filter(Boolean).length,g=gzStrength(dr.picks),best=store.get("fb-gz-best",null);
  let side="";
  if(dr.phase==="form")side=`<div class="box gzstep"><span class="label">${t("Step 1 of 2")}</span><h3>${t("Spin the formation")}</h3><div id="gzWheel" class="gzwheel"></div><div class="btns"><button class="btn" data-gz="form">${t("Spin the formation")}</button></div></div>`;
  else if(dr.phase==="spin")side=`<div class="box gzstep"><span class="label">${esc(tf("Pick {n} of 11",{n:n+1}))}</span><h3>${t("Spin a season")}</h3><p class="muted">${t("The wheel lands on a Fenerbahçe season from 2000–01 to today. You take one player from that squad.")}</p><div id="gzWheel" class="gzwheel"></div><div class="btns"><button class="btn" data-gz="season">${t("Spin a season")}</button></div></div>`;
  else if(dr.phase==="pick")side=`<div class="box gzstep"><div id="gzWheel" class="gzwheel"></div>${gzSquadHtml()}</div>`;
  else side=`<div class="box" id="cupBox"></div>`;
  const head=`<div class="gzhead" role="status"><span><b>${n}/11</b> ${t("picked")}</span><span>${t("Avg rating")} <b>${n?g.avg.toFixed(1):"–"}</b></span><span>${t("Formation")} <b><bdi>${dr.form?esc(dr.form):"?"}</bdi></b></span><span>${t("Re-spins")} <b>${dr.rerolls}</b></span><span>${t("Best ever")} <b>${best!=null?Number(best).toFixed(1):"–"}</b></span></div>`;
  p.innerHTML=`<h2>${t("XI Draft")}</h2><p class="intro">${t("Spin the wheel for a formation, then spin it for a Fenerbahçe season and take one player from that squad. Eleven spins later you have your XI. A player can only go in a position he plays, and you get 3 re-spins for weak squads. Your team strength is 65% your average rating and 35% your weakest player, so one weak link costs you. Then play a whole season.")}</p>
   ${head}<div class="draft gzdraft"><div>${gzPitch()}</div><div class="side">${side}</div></div>
   <div class="btns"><button class="btn ghost sm" data-gz="restart">${t("Start a new draft")}</button></div>
   <p class="gnote">${t("Ratings are fan ratings made for this game. Squads use the players the site has for each season, so they are smaller than the real ones.")}</p>`;
  const on=(k,f)=>{const x=p.querySelector(`[data-gz="${k}"]`);if(x)x.onclick=f};
  on("form",()=>gzSpinForm(p));on("season",()=>gzSpinSeason(p));on("re",()=>gzSpinSeason(p,"re"));on("free",()=>{dr.free++;gzSpinSeason(p)});
  on("restart",()=>{if(typeof szS!=="undefined")szS.football=null;newDraft();renderPanel()});
  p.querySelectorAll("[data-gzp]").forEach(b=>b.onclick=()=>{const pl=gzSquad(dr.season).find(x=>x.n===b.dataset.gzp);if(!pl)return;const f=gzFits(pl);if(f.length===1){gzPlace(pl,f[0]);return}dr.sel=dr.sel===pl?null:pl;renderPanel();const s=p.querySelector(".ps.fit");if(s)s.focus()});
  p.querySelectorAll("[data-gzslot]").forEach(b=>b.onclick=()=>{if(!dr.sel)return;const i=+b.dataset.gzslot;if(gzFits(dr.sel).includes(i))gzPlace(dr.sel,i)});
  if(dr.phase==="done")renderCupBox()}
function renderCupBox(){const el=document.getElementById("cupBox");if(!el||!dr)return;const g=gzStrength(dr.picks),weak=dr.picks.reduce((a,p)=>p.r<a.r?p:a,dr.picks[0]);
  el.innerHTML=`<span class="label">${t("Your XI")}</span><div class="ovr" style="margin-top:8px"><span class="big">${g.str.toFixed(1)}</span><dl><dt>${t("Team strength")}</dt><dd>${t("65% average, 35% weakest")}</dd><dt>${t("Avg rating")}</dt><dd>${g.avg.toFixed(1)}</dd><dt>${t("Weakest")}</dt><dd>${esc(weak.short)} · ${weak.r}</dd><dt>${t("Seasons spun")}</dt><dd>${dr.spun.length}</dd></dl></div>
   <h3 style="margin-top:10px">${t(tier(g.str))}</h3><p class="gnote">${t("Pick a season below and play it through.")}</p>`;
  const host=el.closest(".draft");if(!host)return;szRender("football",szArea(host),g.str,t("Your XI"),()=>{szS.football=null;newDraft();renderPanel()})}

/* ===== Keeping it friendly: a word filter for fan names, chat, write-in votes and league names =====
   Matching works on a simplified form of the text: lower case, Turkish/accented letters folded, look-alike digits
   turned back into letters and repeated letters squeezed ("fuuuck" -> "fuck"). Words marked "=" must be a whole word,
   "^" must start a word, "*" may appear anywhere (only for long, unmistakable words, so normal words aren't caught). */
const MOD_WORDS=(()=>{const L={
  "=":"amk aq oç sik yarak yarrak kahpe gavat puşt pust kaltak sürtük surtuk ibne şerefsiz serefsiz cock twat slut whore fag fags cunt shit bitch bitches bastard asshole wanker nigger niggers nigga niggas faggot faggots neger spast kike spic chink paki tranny nazi puta puto pute putain salope connard connasse joder mierda cabron cabrón gilipollas maricon maricón pendejo fdp hdp fick ficken ficker fotze nique niquer zob زب كس عرص خول قحبة شرموط شرموطة منيوك",
  "^":"fuck sikt siker sikey sikiy sikis sikiş sikim amcik amcık orosp oruspu pezeven scheis scheiß arschloch hurens wichs schlamp schwuchtel missgeb encul batard bâtard shitt motherf",
  "*":"fuck faggot motherfuck orospu siktir sikerim sikeyim aminakoy pezevenk hurensohn wichser"};
  const out={"=":[],"^":[],"*":[]};Object.entries(L).forEach(([m,s])=>s.split(/\s+/).filter(Boolean).forEach(w=>{const n=modNorm(w);if(n)out[m].push({n,sq:modSq(n)===n})}));return out})();
/* lower case, folded letters and look-alike digits; modSq also squeezes repeated letters */
function modNorm(s){return String(s||"").toLocaleLowerCase("tr").replace(/i̇/g,"i")
  .replace(/[ıİ]/g,"i").replace(/ş/g,"s").replace(/ğ/g,"g").replace(/ç/g,"c").replace(/[öô]/g,"o").replace(/[üû]/g,"u").replace(/[àâä]/g,"a").replace(/[éèêë]/g,"e").replace(/[îï]/g,"i").replace(/ñ/g,"n").replace(/ß/g,"ss")
  .replace(/0/g,"o").replace(/1/g,"i").replace(/3/g,"e").replace(/4/g,"a").replace(/5/g,"s").replace(/7/g,"t").replace(/@/g,"a").replace(/\$/g,"s")}
function modSq(n){return n.replace(/([\p{L}])\1+/gu,"$1")}
/* true if the text contains a word from the list. Words with double letters (like "nigger") are only matched as written,
   so squeezing never turns them into ordinary words (like "Niger") */
function modBad(s){const n0=modNorm(s);if(!n0)return false;const T0=n0.split(/[^\p{L}]+/u).filter(Boolean),T1=T0.map(modSq);
  const hit=(toks,useSq)=>{const ok=e=>useSq?e.sq:true;if(toks.some(w=>MOD_WORDS["="].some(e=>ok(e)&&w===e.n)||MOD_WORDS["^"].some(e=>ok(e)&&w.startsWith(e.n))))return true;
    const j=toks.join("");return MOD_WORDS["*"].some(e=>ok(e)&&j.includes(e.n))};
  return hit(T0,false)||hit(T1,true)}
/* the same text with offending words replaced by asterisks */
function modClean(s){s=String(s||"");if(!modBad(s))return s;
  const out=s.split(/(\s+)/).map(p=>/^\s+$/.test(p)||!modBad(p)?p:p.replace(/\S/g,"*")).join("");return modBad(out)?out.replace(/\S/g,"*"):out}

/* names: an offensive fan name shows as "A fan" everywhere */
{const _xn=xName;xName=id=>{const n=_xn(id);return n&&id!==XC.me&&modBad(n)?t("A fan"):n}}
{const _rn=rtName;rtName=p=>{const n=_rn(p);return n&&!(p&&p.isMe)&&modBad(n)?t("A fan"):n}}

/* [regex, Turkish, German]: $1 = raw group, @1 = translated group, @l1 lower-cased, @U1 capitalised; or a function (m, g) */
const TR_DECADE={"40":"larda","50":"lerde","60":"larda","70":"lerde","80":"lerde","90":"larda","00":"lerde","10":"larda","20":"lerde"};
const lowTR=x=>x.toLocaleLowerCase("tr"),capTR=x=>x?x[0].toLocaleUpperCase("tr")+x.slice(1):x;
/* "two" → 2, then back to words for each language */
const NUM_EN={a:1,one:1,two:2,three:3};
function NUMW(w,L){const n=NUM_EN[w]!=null?NUM_EN[w]:+w;if(!L)return n;const W={tr:["","bir","iki","üç"],de:["","einem","zwei","drei"],es:["","un","dos","tres"],fr:["","un","deux","trois"],ar:["","","",""]}[L];return W&&W[n]?W[n]:String(n)}
/* "24 November" → a local date; the year is the one after the snapshot date */
function liveDay(s){const m=s.match(/^(\d{1,2}) ([A-Z][a-z]+)$/);if(!m||!EN_MONTHS.includes(m[2]))return s;const y=+ASOF_ISO.slice(0,4),mo=EN_MONTHS.indexOf(m[2]),d=new Date(y+(mo<+ASOF_ISO.slice(5,7)-2?1:0),mo,+m[1],12);return fmtDay(d,{day:"numeric",month:"long"})}
const I18N_PATS=[
[/^League phase, matchday (\d+)$/,"Lig aşaması, $1. maç günü","Ligaphase, $1. Spieltag"],
[/^(?:Round|Week) (\d+)$/,"$1. hafta","$1. Spieltag"],
[/^Week (\d+) · (.+)$/,"$1. hafta · @2","$1. Spieltag · @2"],
[/^Group C, round (\d+)$/,"C Grubu, $1. hafta","Gruppe C, $1. Spieltag"],
[/^(\d+) questions on (.+) at Fenerbahçe\.$/,"Fenerbahçe @l2 hakkında $1 soru.","$1 Fragen zu Fenerbahçe (@2)."],
[/^Question (\d+) of (\d+)$/,"Soru $1 / $2","Frage $1 von $2"],
[/^Score (\d+)$/,"Skor $1","Punkte $1"],
[/^Best: (\d+) · green = ace, red = error$/,"En iyi: $1 · yeşil = as, kırmızı = hata","Rekord: $1 · grün = Ass, rot = Fehler"],
[/^Best: (.+)$/,"En iyi: $1","Rekord: $1"],
[/^Best score: (\d+) of 36\.$/,"En iyi skor: 36 üzerinden $1.","Bestwert: $1 von 36."],
[/^Best score: (\d+)\.$/,"En iyi skor: $1.","Bestwert: $1."],
[/^Got it in (\d+)! It was$/,"$1. denemede bildin! Cevap:","Im $1. Versuch! Gesucht war"],
[/^Out of guesses\. It was$/,"Tahmin hakkın bitti. Cevap:","Keine Versuche mehr. Gesucht war"],
[/^, a regular in (\d+) seasons?\.$/,", $1 sezon as oyuncu.",m=>`, ${m[1]} ${m[1]==="1"?"Saison":"Saisons"} Stammspieler.`],
[/^The name has (\d+) letters\.$/,"İsim $1 harfli.","Der Name hat $1 Buchstaben."],
[/^Hard mode: letter (\d+) must be (\w)\.$/,"Zor mod: $1. harf $2 olmalı.","Schwerer Modus: Buchstabe $1 muss $2 sein."],
[/^Hard mode: your guess must use (\w)\.$/,"Zor mod: tahminin $2 harfini içermeli.".replace("$2","$1"),"Schwerer Modus: Dein Tipp muss $1 enthalten."],
[/^(\d+) letters(?: \(([\d +]+)\))? · (\d+) guesses? left · (?:daily puzzle #(\d+)|(practice round))$/,
  m=>`${m[1]} harf${m[2]?` (${m[2]})`:""} · ${m[3]} hak kaldı · ${m[4]?`günlük bulmaca #${m[4]}`:"antrenman turu"}`,
  m=>`${m[1]} Buchstaben${m[2]?` (${m[2]})`:""} · noch ${m[3]} ${m[3]==="1"?"Versuch":"Versuche"} · ${m[4]?`Tagesrätsel #${m[4]}`:"Übungsrunde"}`],
[/^Guess the (.+) player in six tries\.$/,"@l1 oyuncusunu altı denemede bul.","Errate in sechs Versuchen eine Person aus: @1."],
[/^Daily stats · (.+)$/,"Günlük istatistik · @1","Tagesstatistik · @1"],
[/^(\d+) possible players\.$/,"$1 olası oyuncu.","$1 mögliche Spieler."],
[/^In the (.+) box scores?$/,"$1 maç istatistiklerinde","In den Boxscores von $1"],
[/^([\d–, ]+) squads?$/,"$1 kadrosu","Kader $1"],
[/^Regular from (.+)$/,"$1 sezonundan beri as","Stammspieler ab $1"],
[/^Joined around (\d+)$/,"$1 civarında geldi","Kam um $1"],
[/^Starts with (.)$/,"$1 harfiyle başlar","Beginnt mit $1"],
[/^(\d+) mystery (.+) players\.$/,"$1 gizemli oyuncu · @2.","$1 geheime Spieler · @2."],
[/^Player (\d+) of (\d+)$/,"Oyuncu $1 / $2","Spieler $1 von $2"],
[/^Correct, \+(\d+)\.$/,"Doğru, +$1.","Richtig, +$1."],
[/^It was ([^.]+)\.$/,"Cevap: $1.","Gesucht war: $1."],
[/^Not (.+)\. Here's another clue\.$/,"$1 değil. İşte bir ipucu daha.","Nicht $1. Hier kommt ein weiterer Hinweis."],
[/^Worth (\d+) points? right now\.(?: Tried: (.+))?$/,m=>`Şu an ${m[1]} puan değerinde.${m[2]?` Denenenler: ${m[2]}`:""}`,m=>`Gerade ${m[1]} ${m[1]==="1"?"Punkt":"Punkte"} wert.${m[2]?` Versucht: ${m[2]}`:""}`],
[/^(\d+) lives? left$/,"$1 can kaldı","Noch $1 Leben"],
[/^You scored (\d+) of 36\.$/,"36 üzerinden $1 puan topladın.","Du hast $1 von 36 Punkten geholt."],
[/^You scored (\d+)\.$/,"$1 puan topladın.","Du hast $1 Punkte geholt."],
[/^That was (\d+)\.$/,"Doğrusu $1.","Richtig wäre $1 gewesen."],
[/^Turkish champions for the (\d+)(?:st|nd|rd|th) time$/,"$1. kez Türkiye şampiyonu","Zum $1. Mal türkischer Meister"],
[/^The (\d+)(?:st|nd|rd|th) Turkish Cup win$/,"$1. Türkiye Kupası zaferi","Der $1. türkische Pokalsieg"],
[/^(.+) (?:takes over as head coach|becomes head coach)$/,"$1 başantrenör oldu","$1 übernimmt das Traineramt"],
[/^(.+) becomes captain$/,"$1 kaptan oldu","$1 wird Kapitänin"],
[/^A Final Four in (.+)$/,"Final Four: @1","Final Four in @1"],
[/^Super League champions for the (\d+)(?:st|nd|rd|th) time$/,"$1. kez Süper Lig şampiyonu","Zum $1. Mal Meister der Super League"],
[/^Turkish League champions \(title (\d+) in the current format\)$/,"Türkiye Ligi şampiyonu (mevcut formatta $1. şampiyonluk)","Türkischer Meister (Titel Nr. $1 im heutigen Format)"],
[/^(.+) signs for Fenerbahçe$/,"$1 Fenerbahçe'ye imza attı","$1 unterschreibt bei Fenerbahçe"],
[/^(.+) becomes a first-team regular \(season starts this year\)$/,"$1 A takımda as oyuncu oldu (sezon bu yıl başlıyor)","$1 wird Stammspieler (die Saison beginnt in diesem Jahr)"],
[/^(\d+) pts$/,"$1 sayı","$1 Pkt."],
[/^Bench · (\d+) more in the box score$/,"Yedekler · istatistikte $1 kişi daha","Bank · $1 weitere im Boxscore"],
[/^vs (.+), (\d+–\d+) (win|loss)( \(OT\))?$/,m=>`${m[1]} karşısında ${m[2]} ${m[3]==="win"?"galibiyet":"mağlubiyet"}${m[4]?" (uzatma)":""}`,m=>`gegen ${m[1]}, ${m[2]} ${m[3]==="win"?"Sieg":"Niederlage"}${m[4]?" (n.V.)":""}`],
[/^vs (.+), Champions$/,"$1 karşısında şampiyonluk","gegen $1, Titel gewonnen"],
[/^(.+) · coach (.+)$/,"@1 · antrenör $2","@1 · Trainer: $2"],
[/^(.+) · (\d{1,2} [A-Z][a-z]+ \d{4}|[A-Z][a-z]+ \d{4})$/,"@1 · @2","@1 · @2"],
[/^(.+) isn't in this one \(−2\)\.$/,"$1 bu kadroda yok (−2).","$1 ist hier nicht dabei (−2)."],
[/^(.+) isn't in this XI \(−2\)\.$/,"$1 bu 11'de yok (−2).","$1 steht nicht in dieser Elf (−2)."],
[/^You already have ([^.]+)\.$/,"$1 zaten bulundu.","$1 hast du schon."],
[/^Yes: ([^.]+)\.$/,"Evet: $1.","Ja: $1."],
[/^You named (\d+) of (\d+)\.$/,"$2 oyuncudan $1 tanesini bildin.","Du hast $1 von $2 genannt."],
[/^of (\d+)$/,"/ $1","von $1"],
[/^Pick (\d+) of (\d+) · tap any empty spot to switch$/,"Seçim $1 / $2 · değiştirmek için boş bir yere dokun","Wahl $1 von $2 · zum Wechseln auf eine freie Position tippen"],
[/^New options \((\d+) left\)$/,"Yeni seçenekler ($1 hak)","Neue Optionen (noch $1)"],
[/^(.+), empty$/,"@1, boş","@1, leer"],
[/^(Final Four|Final Six) wins$/,"$1 zaferi","$1-Siege"],
[/^(\d+)–(\d+) \(OT\)$/,"$1–$2 (uzt.)","$1–$2 (n.V.)"],
[/^(\d+)–(\d+) in sets$/,"setlerde $1–$2","$1–$2 in Sätzen"],
[/^Set (\d+)$/,"$1. set","Satz $1"],
[/^Your top scorers: (.+)\.$/,"En skorerlerin: $1.","Deine Topscorer: $1."],
[/^Game MVP: (.+) \((\d+) pts\)\.$/,"Maçın MVP'si: $1 ($2 sayı).","MVP des Spiels: $1 ($2 Pkt.)."],
[/^Match MVP: (.+)\.$/,"Maçın MVP'si: $1.","MVP des Spiels: $1."],
[/^(Final Four|Final Six) champions!$/,"$1 şampiyonu!","$1-Sieger!"],
[/^Through to the (.+)\.$/,(m,g)=>capTR(lowTR(g(m[1])))+"e yükseldin.","Weiter ins @1."],
[/^Knocked out in the (.+)\.$/,(m,g)=>capTR(lowTR(g(m[1])))+"de elendin.","Aus im @1."],
[/^Start the (.+)$/,(m,g)=>capTR(lowTR(g(m[1])))+"i başlat","@1 starten"],
[/^Kick off the (.+)$/,(m,g)=>capTR(lowTR(g(m[1])))+" maçını başlat","Anpfiff: @1"],
[/^· (\S+) · rated ([\d.]+) \(you: ([\d.]+)\)$/,"· $1 · reyting $2 (sen: $3)","· $1 · Wertung $2 (du: $3)"],
[/^· rated ([\d.]+) \(you: ([\d.]+)\)$/,"· reyting $1 (sen: $2)","· Wertung $1 (du: $2)"],
[/^Watch out for (.+)$/,"Dikkat: $1","Achtung vor: $1"],
[/^Danger men: (.+)$/,"Tehlikeli isimler: $1","Die gefährlichsten Spieler: $1"],
[/^Shot (\d+) of 10$/,"Atış $1 / 10","Wurf $1 von 10"],
[/^Serve (\d+) of 12$/,"Servis $1 / 12","Aufschlag $1 von 12"],
[/^Fact (\d+) of 10$/,"Bilgi $1 / 10","Fakt $1 von 10"],
[/^It's (.+)\.$/,"Doğru cevap: @1.","Richtig ist: @1."],
[/^All pairs found in (\d+) moves and (\d+) seconds\.$/,"Tüm çiftler $1 hamle ve $2 saniyede bulundu.","Alle Paare in $1 Zügen und $2 Sekunden gefunden."],
[/^(.+) · Winger$/,"$1 · Kanat","$1 · Flügel"],
[/^(\d+)–(\d+) \((\d+)–(\d+) pens\)$/,"$1–$2 (pen. $3–$4)","$1–$2 ($3–$4 i.E.)"],
[/^Full-time · penalties (\d+)–(\d+)$/,"Maç sonu · penaltılar $1–$2","Abpfiff · Elfmeterschießen $1–$2"],
[/^Possession (\d+)% · Chances (\d+)–(\d+)$/,"Topla oynama %$1 · Pozisyon $2–$3","Ballbesitz $1 % · Chancen $2–$3"],
[/^GOAL! (.+) scores after a pass from (.+)\.$/,"GOL! $1 golü attı, asist: $2.","TOR! $1 trifft nach Vorlage von $2."],
[/^GOAL! (.+) scores\.$/,"GOL! $1 golü attı.","TOR! $1 trifft."],
[/^GOAL! (.+) finishes it off\. (.+) with the assist\.$/,"GOL! $1 bitirdi. Asist: $2.","TOR! $1 vollendet. Vorlage: $2."],
[/^GOAL! (.+) finishes it off\.$/,"GOL! $1 bitirdi.","TOR! $1 vollendet."],
[/^GOAL! What a strike from (.+)!$/,"GOL! $1 ne vuruş yaptı!","TOR! Was für ein Schuss von $1!"],
[/^(.+) saves from (.+)\.$/,"$1, $2 şutunu kurtardı.","$1 pariert gegen $2."],
[/^Big stop by (.+), denying (.+)\.$/,"$1 müthiş kurtardı, $2 gol olamadı.","Großartige Parade von $1 gegen $2."],
[/^(.+) tests (.+), who holds on\.$/,"$1 şansını denedi, $2 topu tuttu.","$1 prüft $2, der festhält."],
[/^(.+) drags it wide\.$/,"$1 dışarı vurdu.","$1 schiebt vorbei."],
[/^(.+) heads over the bar\.$/,"$1 kafayla üstten auta gönderdi.","$1 köpft drüber."],
[/^Chance for (.+), but it's blocked\.$/,"$1 için fırsat ama şut bloke edildi.","Chance für $1, aber geblockt."],
[/^Yellow card for (.+) \((.+)\)\.$/,"$1 sarı kart gördü (@2).","Gelbe Karte für $1 (@2)."],
[/^Start the clock \((.+)\)$/,"Süreyi başlat ($1)","Uhr starten ($1)"],
[/^Time's up! You found (\d+) of 11\.$/,"Süre bitti! 11 oyuncudan $1 tanesini buldun.","Zeit ist um! Du hast $1 von 11 gefunden."],
[/^You found (\d+) of 11\.$/,"11 oyuncudan $1 tanesini buldun.","Du hast $1 von 11 gefunden."],
[/^Picked by (.+) in the Süper Lig\.$/,"Ölçüt: Süper Lig'de @1.","Ausgewählt nach @1 in der Süper Lig."],
[/^Re-spin last \((\d+) left\)$/,"Sonuncuyu yeniden çevir ($1 hak)","Letzten neu drehen (noch $1)"],
[/^In goal: ([^.]+?)( \(from your drafted XI\))?\.$/,m=>`Kalede: ${m[1]}${m[2]?" (draft ettiğin 11'den)":""}.`,m=>`Im Tor: ${m[1]}${m[2]?" (aus deiner gedrafteten Elf)":""}.`],
[/^Your kick (\d+)( · sudden death)?$/,m=>`${m[1]}. atışın${m[2]?" · ani ölüm":""}`,m=>`Dein ${m[1]}. Schuss${m[2]?" · Sudden Death":""}`],
[/^composure (\d+)$/,"soğukkanlılık $1","Nervenstärke $1"],
[/^You're in goal · (.+)$/,"Kaledesin · $1","Du stehst im Tor · $1"],
[/^Their taker is eyeing (.+)$/,"Atıcı @1 bakıyor","Der Schütze schielt auf @1"],
[/^Dive (.+)$/,"@U1 köşeye atla","Sprung nach @1"],
[/^Order: (.+)$/,"Sıra: $1","Reihenfolge: $1"],
[/^Shootouts won: (\d+)$/,"Kazanılan seriler: $1","Gewonnene Elfmeterschießen: $1"],
[/^In (\d{4}–\d{2}) I was in Fenerbahçe's most-used XI with (.+) and (.+)\.$/,"$1 sezonunda $2 ve $3 ile birlikte Fenerbahçe'nin en çok oynayan 11'indeydim.","$1 stand ich mit $2 und $3 in Fenerbahçes meisteingesetzter Elf."],
[/^I was a regular in (\d+) different seasons, between (.+) and (.+)\.$/,"$2 ile $3 arasında $1 farklı sezonda as oynadım.","Ich war in $1 verschiedenen Saisons Stammspieler, zwischen $2 und $3."],
[/^I mostly played as a (.+?)(?: and I'm from (.+))?\.$/,(m,g)=>`Çoğunlukla ${lowTR(g(m[1]))} oynadım.${m[2]?` Ülkem: ${g(m[2])}.`:""}`,(m,g)=>`Meist spielte ich als ${g(m[1])}.${m[2]?` Herkunft: ${g(m[2])}.`:""}`],
[/^At Fenerbahçe I played alongside (.+)\.$/,m=>`Fenerbahçe'de ${m[1].replace(" and "," ve ")} ile birlikte oynadım.`,m=>`Bei Fenerbahçe spielte ich an der Seite von ${m[1].replace(" and "," und ")}.`],
[/^My Fenerbahçe career started in the (\d+)s\.$/,m=>`Fenerbahçe kariyerim ${m[1]}'${TR_DECADE[m[1].slice(-2)]||"larda"} başladı.`,"Meine Zeit bei Fenerbahçe begann in den $1ern."],
[/^My Fenerbahçe years were roughly (\d+)–(\d+)\.$/,"Fenerbahçe yıllarım kabaca $1–$2.","Meine Fenerbahçe-Jahre: etwa $1–$2."],
[/^I'm from (.+) and I played as a (.+)\.$/,(m,g)=>`Ülkem: ${g(m[1])}. ${capTR(g(m[2]))} olarak oynadım.`,"Herkunft: @1. Ich spielte als @2."],
[/^I'm a ([^.]+) from ([^.]+)\.$/,"Mevkim: @1. Ülkem: @2.","Position: @1. Herkunft: @2."],
[/^I'm a ([^.]+)\.$/,"Mevkim: @1.","Position: @1."],
[/^I played as a (.+)\.$/,(m,g)=>capTR(g(m[1]))+" olarak oynadım.","Ich spielte als @1."],
[/^I'm from ([^.]+)\.$/,"Ülkem: @1.","Herkunft: @1."],
[/^My initials are (.+)$/,"Baş harflerim: $1","Meine Initialen: $1"],
[/^My Fenerbahçe years: ([^.]+)\.$/,"Fenerbahçe yıllarım: $1.","Meine Fenerbahçe-Jahre: $1."],
[/^In the (.+) against (.+) I (started|was on the bench)(?: (but didn't get on the court)| (and didn't score)| and scored (\d+))\.$/,
  (m,g)=>`${g(m[1])} maçında ${m[2]} karşısında ${m[3]==="started"?"ilk beşte başladım":"yedek kulübesindeydim"}${m[4]?" ama oyuna girmedim":m[5]?" ve sayı atmadım":` ve ${m[6]} sayı attım`}.`,
  (m,g)=>`Im Spiel „${g(m[1])}“ gegen ${m[2]} ${m[3]==="started"?"stand ich in der Startformation":"saß ich auf der Bank"}${m[4]?", kam aber nicht zum Einsatz":m[5]?" und blieb ohne Punkte":` und erzielte ${m[6]} Punkte`}.`],
[/^I (?:wore number (\d+)|was) in the (.+) squad(?: \(listed as (.+)\))?\.$/,
  (m,g)=>`${g(m[2])} kadrosundaydım${m[1]?`, forma numaram ${m[1]}`:""}${m[3]?` (${m[3]} olarak kayıtlı)`:""}.`,
  (m,g)=>`Ich stand im Kader „${g(m[2])}“${m[1]?` mit der Nummer ${m[1]}`:""}${m[3]?` (geführt als ${m[3]})`:""}.`],
[/^I appear in (\d+) of these box scores: ([^.]+)\.$/,(m,g)=>`Bu istatistiklerin ${m[1]} tanesinde varım: ${m[2].split(", ").map(g).join(", ")}.`,(m,g)=>`Ich tauche in ${m[1]} dieser Boxscores auf: ${m[2].split(", ").map(g).join(", ")}.`],
[/^I was in (\d+) of these squads: ([^.]+)\.$/,"Bu kadroların $1 tanesindeydim: $2.","Ich stand in $1 dieser Kader: $2."],
[/^(.*)\(later played as (.+)\)$/,"$1(sonra $2 adıyla oynadı)","$1(spielte später als $2)"],
[/^([a-z][a-z ]+): (.+)$/,m=>{const x=lookup(m[1]);return x?`${x}: ${m[2]}`:null},m=>{const x=lookup(m[1]);return x?`${x}: ${m[2]}`:null}],
[/^(.+) · (\d{4} (?:Final|Semi))$/,"$1 · @2","$1 · @2"],
/* live-data phrases written by the twice-weekly refresh */
[/^After week (\d+)$/,"$1. hafta sonrası","Nach dem $1. Spieltag"],
[/^After week (\d+) · (.+)$/,"$1. hafta sonrası · @2","Nach dem $1. Spieltag · @2"],
[/^(.+) v (.+) still to play$/,"$1 – $2 maçı henüz oynanmadı","$1 – $2 steht noch aus"],
[/^Fenerbahçe have (a|one|two|three|\d+) games? in hand$/,m=>`Fenerbahçe'nin ${NUMW(m[1],"tr")} maç eksiği var`,m=>`Fenerbahçe hat ${NUMW(m[1],"de")} ${NUMW(m[1])===1?"Spiel":"Spiele"} weniger`],
[/^(.+) (?:have|has) (a|one|two|three|\d+) games? in hand$/,m=>`${m[1]}: ${NUMW(m[1+1],"tr")} maç eksik`,m=>`${m[1]} mit ${NUMW(m[2],"de")} ${NUMW(m[2])===1?"Spiel":"Spielen"} weniger`],
[/^(?:Pool|Group|League) phase starts on (\d{1,2} [A-Z][a-z]+)\.$/,m=>`Grup aşaması ${liveDay(m[1])} tarihinde başlıyor.`,m=>`Die Gruppenphase beginnt am ${liveDay(m[1])}.`],
[/^(.+?) · (.+)$/,m=>{const a=trText(m[1],true),b=trText(m[2],true);return a==null&&b==null?null:`${a==null?m[1]:a} · ${b==null?m[2]:b}`},m=>{const a=trText(m[1],true),b=trText(m[2],true);return a==null&&b==null?null:`${a==null?m[1]:a} · ${b==null?m[2]:b}`}],
/* generic, keep last */
[/^(.+ \d+–\d+ .+) \(([^()]+)\)$/,"$1 (@2)","$1 (@2)"],
[/^([^()]+) \(([^()]+)\)$/,(m,g)=>{const a=lookup(m[1]),b=lookup(m[2]);return a==null&&b==null?null:`${a||m[1]} (${b||m[2]})`},(m,g)=>{const a=lookup(m[1]),b=lookup(m[2]);return a==null&&b==null?null:`${a||m[1]} (${b||m[2]})`}],
[/^, (.+)\.$/,m=>{const x=lookup(m[1]);return x?`, ${x}.`:null},m=>{const x=lookup(m[1]);return x?`, ${x}.`:null}]
];

const I18N_X={es:{},fr:{},ar:{}};
function XL(rows){rows.forEach(r=>["es","fr","ar"].forEach((L,i)=>{if(r[i+1]!=null)I18N_X[L][r[0]]=r[i+1]}))}
/* Spanish, French, Arabic templates, aligned one-to-one with I18N_PATS. null = reuse the language-neutral German entry */
const frOrd=n=>n+(n==="1"?"re":"e");
const I18N_PATS_X=[
["Fase liga, jornada $1","Phase de ligue, journée $1","مرحلة الدوري، الجولة $1"],
["Jornada $1","Journée $1","الجولة $1"],
["Jornada $1 · @2","Journée $1 · @2","الجولة $1 · @2"],
["Grupo C, jornada $1","Groupe C, journée $1","المجموعة C، الجولة $1"],
["$1 preguntas sobre el Fenerbahçe (@l2).","$1 questions sur le Fenerbahçe (@l2).","$1 أسئلة عن فنربخشة (@2)."],
["Pregunta $1 de $2","Question $1 sur $2","السؤال $1 من $2"],
["Puntos $1","Score $1","النقاط $1"],
["Mejor: $1 · verde = ace, rojo = error","Record : $1 · vert = ace, rouge = faute","الأفضل: $1 · الأخضر = إرسال ساحق، الأحمر = خطأ"],
["Mejor: $1","Record : $1","الأفضل: $1"],
["Mejor puntuación: $1 de 36.","Meilleur score : $1 sur 36.","أفضل نتيجة: $1 من 36."],
["Mejor puntuación: $1.","Meilleur score : $1.","أفضل نتيجة: $1."],
["¡Acertaste en el intento $1! Era","Trouvé au $1e essai ! C'était","عرفتها في المحاولة $1! الإجابة"],
["Sin intentos. Era","Plus d'essais. C'était","نفدت المحاولات. الإجابة"],
[m=>`, titular en ${m[1]} ${m[1]==="1"?"temporada":"temporadas"}.`,m=>`, titulaire pendant ${m[1]} ${m[1]==="1"?"saison":"saisons"}.`,"، أساسي في $1 موسم."],
["El nombre tiene $1 letras.","Le nom compte $1 lettres.","عدد حروف الاسم: $1."],
["Modo difícil: la letra $1 debe ser $2.","Mode difficile : la lettre $1 doit être $2.","الوضع الصعب: يجب أن يكون الحرف رقم $1 هو $2."],
["Modo difícil: tu intento debe incluir la $1.","Mode difficile : ton essai doit contenir $1.","الوضع الصعب: يجب أن يحتوي تخمينك على $1."],
[m=>`${m[1]} letras${m[2]?` (${m[2]})`:""} · ${m[3]} ${m[3]==="1"?"intento restante":"intentos restantes"} · ${m[4]?`reto diario n.º ${m[4]}`:"ronda de práctica"}`,
 m=>`${m[1]} lettres${m[2]?` (${m[2]})`:""} · ${m[3]} ${m[3]==="1"?"essai restant":"essais restants"} · ${m[4]?`défi du jour n° ${m[4]}`:"partie d'entraînement"}`,
 m=>`${m[1]} حروف${m[2]?` (${m[2]})`:""} · المحاولات المتبقية: ${m[3]} · ${m[4]?`لغز اليوم رقم ${m[4]}`:"جولة تدريبية"}`],
["Adivina el jugador (@l1) en seis intentos.","Devine le joueur (@l1) en six essais.","خمّن اللاعب (@1) في ست محاولات."],
["Estadísticas del día · @1","Stats du jour · @1","إحصاءات اليوم · @1"],
["$1 jugadores posibles.","$1 joueurs possibles.","عدد اللاعبين المحتملين: $1."],
["En las estadísticas de $1","Dans les feuilles de match de $1","في إحصاءات $1"],
["Plantilla $1","Effectif $1","تشكيلة $1"],
["Titular desde $1","Titulaire dès $1","أساسي منذ $1"],
["Llegó hacia $1","Arrivé vers $1","انضم نحو عام $1"],
["Empieza por $1","Commence par $1","يبدأ بحرف $1"],
["$1 jugadores misteriosos · @2.","$1 joueurs mystère · @2.","$1 لاعبين غامضين · @2."],
["Jugador $1 de $2","Joueur $1 sur $2","اللاعب $1 من $2"],
["¡Correcto! +$1.","Exact, +$1.","صحيح، +$1."],
["Era $1.","C'était $1.","الإجابة: $1."],
["No es $1. Aquí tienes otra pista.","Ce n'est pas $1. Voici un autre indice.","ليس $1. إليك تلميحًا آخر."],
[m=>`Ahora vale ${m[1]} ${m[1]==="1"?"punto":"puntos"}.${m[2]?` Probados: ${m[2]}`:""}`,m=>`Vaut ${m[1]} ${m[1]==="1"?"point":"points"} pour l'instant.${m[2]?` Essayés : ${m[2]}`:""}`,m=>`قيمتها الآن ${m[1]} نقطة.${m[2]?` جرّبت: ${m[2]}`:""}`],
[m=>`${m[1]} ${m[1]==="1"?"vida":"vidas"}`,m=>`${m[1]} ${m[1]==="1"?"vie":"vies"}`,"الأرواح المتبقية: $1"],
["Has sumado $1 de 36.","Tu as marqué $1 sur 36.","حصلت على $1 من 36."],
["Has sumado $1.","Tu as marqué $1.","حصلت على $1."],
["Era $1.","La réponse était $1.","الإجابة كانت $1."],
["Campeones de Turquía por $1.ª vez",m=>`Champions de Turquie pour la ${frOrd(m[1])} fois`,"بطل تركيا للمرة رقم $1"],
["$1.ª Copa de Turquía",m=>`${frOrd(m[1])} Coupe de Turquie`,"الفوز رقم $1 بكأس تركيا"],
["$1 asume el banquillo","$1 devient entraîneur","$1 يتولى تدريب الفريق"],
["$1, nueva capitana","$1 devient capitaine","$1 تصبح القائدة"],
["Final Four en @1","Un Final Four à @1","فاينال فور في @1"],
["Campeonas de la Superliga por $1.ª vez",m=>`Championnes de Super Ligue pour la ${frOrd(m[1])} fois`,"بطلات الدوري الممتاز للمرة رقم $1"],
["Campeonas de la liga turca (título $1 en el formato actual)","Championnes de Turquie (titre n° $1 dans le format actuel)","بطلات الدوري التركي (اللقب رقم $1 بالنظام الحالي)"],
["$1 ficha por el Fenerbahçe","$1 signe au Fenerbahçe","$1 يوقّع لفنربخشة"],
["$1 se asienta como titular (la temporada empieza este año)","$1 devient titulaire (la saison commence cette année)","$1 يصبح أساسيًا في الفريق الأول (يبدأ الموسم هذا العام)"],
["$1 pts","$1 pts","$1 نقطة"],
["Banquillo · $1 más en las estadísticas","Banc · $1 de plus sur la feuille de match","البدلاء · $1 آخرون في الإحصاءات"],
[m=>`vs ${m[1]}, ${m[3]==="win"?"victoria":"derrota"} ${m[2]}${m[4]?" (prórr.)":""}`,m=>`contre ${m[1]}, ${m[3]==="win"?"victoire":"défaite"} ${m[2]}${m[4]?" (a.p.)":""}`,m=>`أمام ${m[1]}، ${m[3]==="win"?"فوز":"خسارة"} ${m[2]}${m[4]?" (وقت إضافي)":""}`],
["vs $1, campeones","contre $1, titre remporté","أمام $1، الفوز باللقب"],
["@1 · entrenador $2","@1 · entraîneur $2","@1 · المدرب $2"],
["@1 · @2","@1 · @2","@1 · @2"],
["$1 no está en esta (−2).","$1 n'en fait pas partie (−2).","$1 ليس ضمن هذه القائمة (−2)."],
["$1 no está en este once (−2).","$1 n'est pas dans ce onze (−2).","$1 ليس في هذه التشكيلة (−2)."],
["Ya tienes a $1.","Tu as déjà $1.","لديك $1 بالفعل."],
["Sí: $1.","Oui : $1.","نعم: $1."],
["Has nombrado $1 de $2.","Tu en as trouvé $1 sur $2.","سمّيت $1 من $2."],
["de $1","sur $1","من $1"],
["Elección $1 de $2 · toca un hueco libre para cambiar","Choix $1 sur $2 · touche une place libre pour changer","الاختيار $1 من $2 · المس أي مركز فارغ للتبديل"],
["Nuevas opciones (quedan $1)","Nouvelles options (encore $1)","خيارات جديدة (متبقٍ $1)"],
["@1, vacío","@1, vide","@1، فارغ"],
["Victorias en la @1","Victoires au @1","انتصارات @1"],
["$1–$2 (prórr.)","$1–$2 (a.p.)","$1–$2 (وقت إضافي)"],
["$1–$2 en sets","$1–$2 en sets","$1–$2 بالأشواط"],
["Set $1","Set $1","الشوط $1"],
["Tus máximos anotadores: $1.","Tes meilleurs marqueurs : $1.","أفضل مسجليك: $1."],
["MVP del partido: $1 ($2 pts).","MVP du match : $1 ($2 pts).","أفضل لاعب في المباراة: $1 ($2 نقطة)."],
["MVP del partido: $1.","MVP du match : $1.","أفضل لاعب في المباراة: $1."],
["¡Campeones de la @1!","Vainqueurs du @1 !","أبطال @1!"],
["Pasas a la @l1.","Qualifié pour la @l1.","تأهلت إلى @1."],
["Eliminado en @l1.","Éliminé en @l1.","خرجت من @1."],
["Empezar: @1","Lancer : @1","ابدأ @1"],
["Saque inicial: @1","Coup d'envoi : @1","انطلاق @1"],
["· $1 · valoración $2 (tú: $3)","· $1 · note $2 (toi : $3)","· $1 · التقييم $2 (أنت: $3)"],
["· valoración $1 (tú: $2)","· note $1 (toi : $2)","· التقييم $1 (أنت: $2)"],
["Cuidado con $1","Attention à $1","احذر من $1"],
["Los más peligrosos: $1","Les plus dangereux : $1","الأخطر: $1"],
["Tiro $1 de 10","Tir $1 sur 10","الرمية $1 من 10"],
["Saque $1 de 12","Service $1 sur 12","الإرسال $1 من 12"],
["Dato $1 de 10","Fait $1 sur 10","المعلومة $1 من 10"],
["Es @1.","C'est @1.","الإجابة: @1."],
["Todas las parejas en $1 movimientos y $2 segundos.","Toutes les paires trouvées en $1 coups et $2 secondes.","وجدت كل الأزواج في $1 حركة و$2 ثانية."],
["$1 · Extremo","$1 · Ailier","$1 · جناح"],
["$1–$2 ($3–$4 pen.)","$1–$2 ($3–$4 t.a.b.)","$1–$2 (ركلات الترجيح $3–$4)"],
["Final · penaltis $1–$2","Fin du match · tirs au but $1–$2","نهاية المباراة · ركلات الترجيح $1–$2"],
["Posesión $1% · Ocasiones $2–$3","Possession $1 % · Occasions $2–$3","الاستحواذ $1% · الفرص $2–$3"],
["¡GOL! Marca $1 tras pase de $2.","BUT ! $1 marque sur une passe de $2.","هدف! $1 يسجل بعد تمريرة من $2."],
["¡GOL! Marca $1.","BUT ! $1 marque.","هدف! $1 يسجل."],
["¡GOL! $1 la manda dentro. Asistencia de $2.","BUT ! $1 conclut. Passe décisive de $2.","هدف! $1 يُنهي الهجمة. التمريرة الحاسمة من $2."],
["¡GOL! $1 la manda dentro.","BUT ! $1 conclut.","هدف! $1 يُنهي الهجمة."],
["¡GOL! ¡Qué disparo de $1!","BUT ! Quelle frappe de $1 !","هدف! يا لها من تسديدة من $1!"],
["$1 detiene el disparo de $2.","$1 arrête la frappe de $2.","$1 يتصدى لتسديدة $2."],
["Paradón de $1 ante $2.","Grosse parade de $1 devant $2.","تصدٍّ رائع من $1 يحرم $2."],
["$1 prueba a $2, que atrapa.","$1 teste $2, qui capte.","$1 يختبر $2 الذي يمسك الكرة."],
["$1 la manda fuera.","$1 tire à côté.","$1 يسدد بجانب المرمى."],
["$1 cabecea por encima del larguero.","$1 met sa tête au-dessus.","$1 يضرب برأسه فوق العارضة."],
["Ocasión para $1, pero se la bloquean.","Occasion pour $1, mais c'est contré.","فرصة لـ$1 لكنها تُصد."],
["Tarjeta amarilla para $1 (@2).","Carton jaune pour $1 (@2).","بطاقة صفراء لـ$1 (@2)."],
["Iniciar el reloj ($1)","Lancer le chrono ($1)","ابدأ المؤقت ($1)"],
["¡Se acabó el tiempo! Encontraste $1 de 11.","Temps écoulé ! Tu en as trouvé $1 sur 11.","انتهى الوقت! وجدت $1 من 11."],
["Encontraste $1 de 11.","Tu en as trouvé $1 sur 11.","وجدت $1 من 11."],
["Elegidos por @1 en la Süper Lig.","Sélectionnés selon @1 en Süper Lig.","الاختيار حسب @1 في الدوري الممتاز."],
["Volver a girar el último (quedan $1)","Relancer le dernier (encore $1)","أعد تدوير الأخير (متبقٍ $1)"],
[m=>`En la portería: ${m[1]}${m[2]?" (de tu once del draft)":""}.`,m=>`Dans les buts : ${m[1]}${m[2]?" (de ton onze drafté)":""}.`,m=>`في المرمى: ${m[1]}${m[2]?" (من تشكيلتك في الدرافت)":""}.`],
[m=>`Tu lanzamiento ${m[1]}${m[2]?" · muerte súbita":""}`,m=>`Ton tir n° ${m[1]}${m[2]?" · mort subite":""}`,m=>`ركلتك رقم ${m[1]}${m[2]?" · الموت المفاجئ":""}`],
["sangre fría $1","sang-froid $1","الهدوء $1"],
["Estás en la portería · $1","Tu es dans les buts · $1","أنت في المرمى · $1"],
["Su lanzador mira hacia @1","Leur tireur vise @1","المسدد ينظر نحو @1"],
["Lánzate hacia @1","Plonger vers @1","ارتمِ نحو @1"],
["Orden: $1","Ordre : $1","الترتيب: $1"],
["Tandas ganadas: $1","Séances gagnées : $1","ركلات الترجيح التي فزت بها: $1"],
["En $1 estuve en el once más utilizado del Fenerbahçe con $2 y $3.","En $1, j'étais dans le onze le plus utilisé du Fenerbahçe avec $2 et $3.","في موسم $1 كنت ضمن التشكيلة الأكثر استخدامًا في فنربخشة مع $2 و$3."],
["Fui titular en $1 temporadas distintas, entre $2 y $3.","J'ai été titulaire lors de $1 saisons différentes, entre $2 et $3.","كنت أساسيًا في $1 مواسم مختلفة بين $2 و$3."],
[(m,g)=>`Jugué sobre todo de ${g(m[1])}.${m[2]?` País: ${g(m[2])}.`:""}`,(m,g)=>`J'ai surtout joué au poste de ${g(m[1])}.${m[2]?` Pays : ${g(m[2])}.`:""}`,(m,g)=>`لعبت غالبًا في مركز ${g(m[1])}.${m[2]?` البلد: ${g(m[2])}.`:""}`],
[m=>`En el Fenerbahçe jugué junto a ${m[1].replace(" and "," y ")}.`,m=>`Au Fenerbahçe, j'ai joué aux côtés de ${m[1].replace(" and "," et ")}.`,m=>`في فنربخشة لعبت إلى جانب ${m[1].replace(" and "," و")}.`],
["Mi etapa en el Fenerbahçe empezó en los años $1.","Ma carrière au Fenerbahçe a commencé dans les années $1.","بدأت مسيرتي مع فنربخشة في عقد $1."],
["Mis años en el Fenerbahçe fueron más o menos $1–$2.","Mes années au Fenerbahçe : environ $1–$2.","سنواتي في فنربخشة تقريبًا $1–$2."],
["País: @1. Jugué de @2.","Pays : @1. J'ai joué au poste de @2.","البلد: @1. لعبت في مركز @2."],
["Posición: @1. País: @2.","Poste : @1. Pays : @2.","المركز: @1. البلد: @2."],
["Posición: @1.","Poste : @1.","المركز: @1."],
["Jugué de @1.","J'ai joué au poste de @1.","لعبت في مركز @1."],
["País: @1.","Pays : @1.","البلد: @1."],
["Mis iniciales: $1","Mes initiales : $1","حروفي الأولى: $1"],
["Mis años en el Fenerbahçe: $1.","Mes années au Fenerbahçe : $1.","سنواتي في فنربخشة: $1."],
[(m,g)=>`En el partido «${g(m[1])}» contra ${m[2]} ${m[3]==="started"?"fui titular":"estuve en el banquillo"}${m[4]?", pero no salí a pista":m[5]?" y no anoté":` y anoté ${m[6]} puntos`}.`,
 (m,g)=>`Lors du match « ${g(m[1])} » contre ${m[2]}, ${m[3]==="started"?"j'étais titulaire":"j'étais sur le banc"}${m[4]?" mais je ne suis pas entré en jeu":m[5]?" et je n'ai pas marqué":` et j'ai marqué ${m[6]} points`}.`,
 (m,g)=>`في مباراة «${g(m[1])}» أمام ${m[2]} ${m[3]==="started"?"بدأت أساسيًا":"كنت على دكة البدلاء"}${m[4]?" لكنني لم أشارك":m[5]?" ولم أسجل":` وسجلت ${m[6]} نقطة`}.`],
[(m,g)=>`Estuve en la plantilla «${g(m[2])}»${m[1]?` con el dorsal ${m[1]}`:""}${m[3]?` (inscrita como ${m[3]})`:""}.`,
 (m,g)=>`J'étais dans l'effectif « ${g(m[2])} »${m[1]?` avec le numéro ${m[1]}`:""}${m[3]?` (inscrite sous le nom ${m[3]})`:""}.`,
 (m,g)=>`كنت ضمن تشكيلة «${g(m[2])}»${m[1]?` بالرقم ${m[1]}`:""}${m[3]?` (مسجلة باسم ${m[3]})`:""}.`],
[(m,g)=>`Aparezco en ${m[1]} de estas estadísticas: ${m[2].split(", ").map(g).join(", ")}.`,(m,g)=>`J'apparais dans ${m[1]} de ces feuilles de match : ${m[2].split(", ").map(g).join(", ")}.`,(m,g)=>`أظهر في ${m[1]} من هذه الإحصاءات: ${m[2].split(", ").map(g).join("، ")}.`],
["Estuve en $1 de estas plantillas: $2.","J'étais dans $1 de ces effectifs : $2.","كنت في $1 من هذه التشكيلات: $2."],
["$1(después jugó como $2)","$1(a joué ensuite sous le nom $2)","$1(لعب لاحقًا باسم $2)"],
null,
null,
["Tras la jornada $1","Après la $1e journée","بعد الجولة $1"],
["Tras la jornada $1 · @2","Après la $1e journée · @2","بعد الجولة $1 · @2"],
["Falta por jugar el $1 – $2","$1 – $2 reste à jouer","لم تُلعب بعد مباراة $1 – $2"],
[m=>`El Fenerbahçe tiene ${NUMW(m[1],"es")} ${NUMW(m[1])===1?"partido":"partidos"} menos`,m=>`Fenerbahçe compte ${NUMW(m[1],"fr")} ${NUMW(m[1])===1?"match":"matchs"} en retard`,m=>`لدى فنربخشة ${NUMW(m[1])===1?"مباراة مؤجلة":NUMW(m[1])===2?"مباراتان مؤجلتان":NUMW(m[1])+" مباريات مؤجلة"}`],
[m=>`${m[1]} tiene ${NUMW(m[2],"es")} ${NUMW(m[2])===1?"partido":"partidos"} menos`,m=>`${m[1]} compte ${NUMW(m[2],"fr")} ${NUMW(m[2])===1?"match":"matchs"} en retard`,m=>`لدى ${m[1]} ${NUMW(m[2])===1?"مباراة مؤجلة":NUMW(m[2])===2?"مباراتان مؤجلتان":NUMW(m[2])+" مباريات مؤجلة"}`],
[m=>`La fase de grupos empieza el ${liveDay(m[1])}.`,m=>`La phase de poules commence le ${liveDay(m[1])}.`,m=>`تبدأ مرحلة المجموعات في ${liveDay(m[1])}.`],
[m=>{const a=trText(m[1],true),b=trText(m[2],true);return a==null&&b==null?null:`${a==null?m[1]:a} · ${b==null?m[2]:b}`},m=>{const a=trText(m[1],true),b=trText(m[2],true);return a==null&&b==null?null:`${a==null?m[1]:a} · ${b==null?m[2]:b}`},m=>{const a=trText(m[1],true),b=trText(m[2],true);return a==null&&b==null?null:`${a==null?m[1]:a} · ${b==null?m[2]:b}`}],
null,null,null
];

/* ================= LANGUAGES ================= */
const LANGS=[["en","English","EN","en-GB"],["tr","Türkçe","TR","tr-TR"],["de","Deutsch","DE","de-DE"],["es","Español","ES","es-ES"],["fr","Français","FR","fr-FR"],["ar","العربية","AR","ar-u-nu-latn"]];
let LANG=(()=>{try{const v=localStorage.getItem("fb-lang");if(LANGS.some(l=>l[0]===v))return v}catch(e){}return "en"})();
const LOC=()=>LANGS.find(l=>l[0]===LANG)[3];
const EN_NS={"res:W":"W","res:D":"D","res:L":"L","ha:H":"H","ha:A":"A","ha:N":"N","col:P":"P","col:W":"W","col:D":"D","col:L":"L","col:GF":"GF","col:GA":"GA","col:GD":"GD","col:Pts":"Pts","col:+/−":"+/−","col:PF":"PF","col:PA":"PA","col:Sets":"Sets",
 "colt:P":"Played","colt:W":"Won","colt:D":"Drawn","colt:L":"Lost","colt:GF":"Goals for","colt:GA":"Goals against","colt:GD":"Goal difference","colt:Pts":"Points","colt:+/−":"Points difference","colt:PF":"Points for","colt:PA":"Points against","colt:Sets":"Sets won–lost"};
const XLANGS=["es","fr","ar"],DICT={tr:{},de:{},es:{},fr:{},ar:{}},LOWER={tr:{},de:{},es:{},fr:{},ar:{}},PATTERNS={tr:[],de:[],es:[],fr:[],ar:[]},TCACHE=new Map();
const capFirst=s=>s?s[0].toLocaleUpperCase(LOC())+s.slice(1):s;
function addZip(L,en,x){if(x==null||en==null)return;
  if(typeof x==="string"){if(typeof en==="string"&&en!==x){DICT[L][en]=x}return}
  if(Array.isArray(x)){x.forEach((v,i)=>addZip(L,en[i],v));return}
  if(typeof x==="object")Object.keys(x).forEach(k=>addZip(L,en[k],x[k]))}
function lookup(s){if(s==null)return null;const D=DICT[LANG];if(D[s]!=null)return D[s];const lo=LOWER[LANG][s.toLowerCase()];if(lo==null)return null;const [k,x]=lo,up=c=>c!==c.toLowerCase();
  if(up(s[0])&&!up(k[0]))return capFirst(x);if(!up(s[0])&&up(k[0])&&LANG==="tr")return x[0].toLocaleLowerCase("tr")+x.slice(1);return x}
/* translate one group for templates; falls back to the original text */
function g1(x){if(x==null)return "";const r=trText(x,true);return r==null?x:r}
function fillTpl(tpl,m){return tpl.replace(/([@$])(l|U)?(\d)/g,(_,k,mod,i)=>{let v=m[+i];if(v==null)return "";if(k==="@")v=g1(v);if(mod==="l")v=v.toLocaleLowerCase(LOC());if(mod==="U")v=capFirst(v);return v})}
function trText(s,noSplit){if(LANG==="en"||s==null)return null;const key=LANG+"\u0001"+s;if(TCACHE.has(key))return TCACHE.get(key);
  let r=lookup(s);
  if(r==null)for(const [re,f] of PATTERNS[LANG]){const m=s.match(re);if(!m)continue;const out=typeof f==="function"?f(m,g1):fillTpl(f,m);if(out!=null){r=out;break}}
  if(r==null&&!noSplit){const parts=s.split(/(?<=[.!?])\s+(?=[A-Z0-9“"'‘(])/);if(parts.length>1){let any=false;const out=parts.map(p=>{const x=trText(p,true);if(x!=null){any=true;return x}return p});if(any)r=out.join(" ")}}
  TCACHE.set(key,r);return r}
function t(s){if(s==null)return s;if(LANG==="en")return EN_NS[s]!=null?EN_NS[s]:s;const r=trText(String(s));return r!=null?r:(EN_NS[s]!=null?EN_NS[s]:s)}
function tf(s,v){return t(s).replace(/\{(\w+)\}/g,(m,k)=>v[k]!=null?v[k]:m)}
function lbl(s){return LANG==="en"?s.label.toLowerCase():["tr","es","fr"].includes(LANG)?t(s.label).toLocaleLowerCase(LOC()):t(s.label)}
function asOf(){return fmtDay(new Date(ASOF_ISO+"T12:00:00"),{day:"numeric",month:"long",year:"numeric"})}
/* English date strings in the data ("25 May 2025", "April 2024") */
const EN_MONTHS=["January","February","March","April","May","June","July","August","September","October","November","December"];
function trDate(s){let m=s.match(/^(\d{1,2}) ([A-Z][a-z]+) (\d{4})$/),d;if(m&&EN_MONTHS.includes(m[2])){d=new Date(+m[3],EN_MONTHS.indexOf(m[2]),+m[1],12);return fmtDay(d,{day:"numeric",month:"long",year:"numeric"})}
  m=s.match(/^([A-Z][a-z]+) (\d{4})$/);if(m&&EN_MONTHS.includes(m[1])){d=new Date(+m[2],EN_MONTHS.indexOf(m[1]),15,12);return fmtDay(d,{month:"long",year:"numeric"})}return null}

/* Build dictionaries from the packs */


/* Translate whatever the game engines render (they write English) */
const TR_SKIP="script,style,textarea,[translate=no]";
function trDom(root){if(LANG==="en"||!root)return;const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT),nodes=[];while(w.nextNode())nodes.push(w.currentNode);
  nodes.forEach(n=>{const p=n.parentElement;if(!p||p.closest(TR_SKIP))return;const v=n.nodeValue,s=v.trim();if(!s||!/[A-Za-z]/.test(s))return;const r=trText(s);if(r!=null&&r!==s)n.nodeValue=v.replace(s,r)});
  root.querySelectorAll("[placeholder],[aria-label],[title]").forEach(el=>{if(el.closest(TR_SKIP))return;["placeholder","aria-label","title"].forEach(a=>{const v=el.getAttribute(a);if(!v)return;const r=trText(v.trim());if(r!=null&&r!==v)el.setAttribute(a,r)})})}
let trObs=null;
function watchPanel(){const panel=$("panel"),opts={childList:true,subtree:true,characterData:true};
  trObs=new MutationObserver(()=>{if(LANG==="en")return;trObs.disconnect();try{trDom(document.getElementById("gameArea"))}finally{trObs.takeRecords();trObs.observe(panel,opts)}});trObs.observe(panel,opts)}

/* Static text, picker and switching */
function staticTexts(){document.documentElement.lang=LANG;document.documentElement.dir=LANG==="ar"?"rtl":"ltr";
  [...$("sport").options].forEach(o=>{if(SPORTS[o.value])o.textContent=t(SPORTS[o.value].label)});$("sport").setAttribute("aria-label",t("Choose a branch"));
  document.querySelectorAll("[data-t]").forEach(el=>el.textContent=t(el.dataset.t));
  if(typeof themeTexts==="function")themeTexts();if(typeof helperTexts==="function")helperTexts();const ls=$("lang");ls.value=LANG;ls.setAttribute("aria-label",t("Language"));$("langCode").textContent=LANGS.find(l=>l[0]===LANG)[2]}



/* ===== Language packs: translations load on demand, so English visitors don't download them ===== */
const PACK_OK={},PACK_WAIT={};
function LANGPACK(L,p){const D=DICT[L],Lo=LOWER[L];Object.assign(D,p.d);
  Object.keys(p.d).forEach(en=>{const k=en.toLowerCase();if(!Lo[k])Lo[k]=[en,D[en]]});(p.o||[]).forEach(([k,en,x])=>Lo[k]=[en,x]);
  PACK_OK[L]=true;TCACHE.clear()}
function loadPack(L){if(L==="en"||PACK_OK[L])return Promise.resolve(true);if(PACK_WAIT[L])return PACK_WAIT[L];
  PACK_WAIT[L]=new Promise(res=>{const s=document.createElement("script");s.src=`lang-${L}.js`;s.async=true;s.onload=()=>res(!!PACK_OK[L]);s.onerror=()=>{delete PACK_WAIT[L];res(false)};document.head.appendChild(s)});return PACK_WAIT[L]}
function buildI18n(){
  ["tr","de"].forEach((L,li)=>{PATTERNS[L]=I18N_PATS.map(p=>[p[0],p[1+li]]).filter(p=>p[1]!=null);PATTERNS[L].push([/^.+$/,m=>trDate(m[0])])});
  XLANGS.forEach((L,li)=>{PATTERNS[L]=I18N_PATS.map((p,i)=>{const x=I18N_PATS_X[i];return [p[0],x?x[li]:p[2]]}).filter(p=>p[1]!=null);PATTERNS[L].push([/^.+$/,m=>trDate(m[0])])})}
function applyLang(){staticTexts();render();renderOnThisDay();if(typeof kanRender==="function")kanRender()}
function setLang(c){if(c==="ar"&&window.loadFont)loadFont(FONT_EXTRA.ar);if(!LANGS.some(l=>l[0]===c))return;const prev=LANG;
  if(c==="en"||PACK_OK[c]){LANG=c;try{localStorage.setItem("fb-lang",c)}catch(e){}applyLang();return}
  document.documentElement.classList.add("lwait");
  loadPack(c).then(ok=>{document.documentElement.classList.remove("lwait");if(!ok){$("lang").value=prev;return}LANG=c;try{localStorage.setItem("fb-lang",c)}catch(e){}applyLang()})}
function initLang(){if(LANG==="ar"&&window.loadFont)loadFont(FONT_EXTRA.ar);buildI18n();$("lang").innerHTML=LANGS.map(([c,n])=>`<option value="${c}">${n}</option>`).join("");$("lang").addEventListener("change",e=>setLang(e.target.value));
  const want=LANG;if(want!=="en"&&!PACK_OK[want]){LANG="en";document.documentElement.classList.add("lwait");const done=()=>document.documentElement.classList.remove("lwait");
    const tm=setTimeout(done,2500);loadPack(want).then(ok=>{clearTimeout(tm);done();if(ok){LANG=want;applyLang()}})}
  staticTexts();watchPanel()}

/* ===== Stand-alone site: Supabase stands in for the Claude page features (db, user, room, downloads) =====
   Only included in the GitHub Pages build. Inside Claude the real window.claude is used instead. */
(function(){
  if(window.claude&&window.claude.use)return;
  const CFG=window.FB_SB||{};
  const ok=()=>!!(CFG.url&&CFG.key&&window.supabase&&window.supabase.createClient);
  let sb=null,uidP=null;
  const client=()=>{if(!sb&&ok())sb=window.supabase.createClient(CFG.url,CFG.key,{auth:{persistSession:true,autoRefreshToken:true,storageKey:"fb-auth"},realtime:{params:{eventsPerSecond:10}}});return sb};
  /* every visitor gets an anonymous account the first time, kept in this browser */
  function uid(){if(uidP)return uidP;uidP=(async()=>{const c=client();if(!c)return null;
    let {data}=await c.auth.getSession();if(data&&data.session)return data.session.user.id;
    const r=await c.auth.signInAnonymously();if(r.error)throw r.error;return r.data.user.id})().catch(e=>{uidP=null;console.warn("[fb] sign-in",e&&e.message);return null});return uidP}
  const COLS=["predictions","motm","scores","ratings","seasons","challenges","watch"];

  /* ---- db: collection(col).onSnapshot(cb) and doc("col/id").set(data) ---- */
  /* what each shared collection keeps in this browser, so an account's saved data shows up on a new device */
  const LOCAL={predictions:["p","fb-preds"],motm:["v","fb-motm"],ratings:["r","fb-ratings"],challenges:["c","fb-ch"],seasons:["b","fb-sz-rec"],watch:["w","fb-watch"]};
  let REMOTE_SCORES={};
  function hydrate(c,me){return c.from("docs").select("col,data").eq("id",me).then(({data,error})=>{if(error)return;let changed=false;
    (data||[]).forEach(r=>{if(r.col==="scores"){REMOTE_SCORES=(r.data&&r.data.s)||{};return}const L=LOCAL[r.col];if(!L||typeof store==="undefined")return;const rem=(r.data&&r.data[L[0]])||{};
      const loc=store.get(L[1],{})||{};let n=0;Object.keys(rem).forEach(k=>{if(!(k in loc)){loc[k]=rem[k];n++}});if(n){store.set(L[1],loc);changed=true}});
    if(changed)setTimeout(()=>{try{xRefresh();if(typeof xBadgeCheck==="function")xBadgeCheck()}catch(e){}},0)}).catch(()=>{})}
  function makeDb(me){const c=client();const hyd=hydrate(c,me);
    const docSnap=(id,d)=>({id,exists:true,data:()=>d});
    return {
      collection(col){return {onSnapshot(cb,err){if(!COLS.includes(col)){err&&err(new Error("unknown collection"));return ()=>{}}
        const m={};let alive=true;const emit=()=>{if(alive)cb({docs:Object.entries(m).filter(([id])=>!(window.FB_BANNED&&window.FB_BANNED.has(id))).map(([id,d])=>docSnap(id,d))})};
        c.from("docs").select("id,data").eq("col",col).limit(5000).then(({data,error})=>{if(error){err&&err(error);return}(data||[]).forEach(r=>m[r.id]=r.data);emit()});
        const ch=c.channel("db-"+col+"-"+Math.random().toString(36).slice(2,8)).on("postgres_changes",{event:"*",schema:"public",table:"docs",filter:"col=eq."+col},p=>{
          if(p.eventType==="DELETE"){const id=p.old&&p.old.id;if(id){delete m[id];emit()}return}const r=p.new;if(r&&r.id){m[r.id]=r.data;emit()}}).subscribe();
        return ()=>{alive=false;c.removeChannel(ch)}}}},
      doc(path){const [col,id]=path.split("/");return {
        async set(data){if(!COLS.includes(col)||id!==me)throw Object.assign(new Error("not allowed"),{code:"forbidden"});await hyd;
          if(col==="scores"&&data&&data.s){const s={...data.s};Object.entries(REMOTE_SCORES).forEach(([k,v])=>{if(typeof v==="number"&&!(s[k]>=v))s[k]=v});data={...data,s};REMOTE_SCORES=s}
          const {error}=await c.from("docs").upsert({col,id,data,updated_at:new Date().toISOString()});if(error)throw error},
        async get(){const {data}=await c.from("docs").select("data").eq("col",col).eq("id",id).maybeSingle();return {id,exists:!!data,data:()=>data&&data.data}}}}}}

  /* ---- user: id() and profiles(ids); fans pick their own name in Settings ---- */
  const NAMES={};
  function makeUser(me){const c=client();
    /* when another fan renames themselves, update the boards without a reload */
    c.channel("profiles-"+Math.random().toString(36).slice(2,8)).on("postgres_changes",{event:"*",schema:"public",table:"profiles"},p=>{const r=p.new;if(!r||!r.id)return;NAMES[r.id]=r.name||"";
      try{if(typeof XC!=="undefined"&&r.id in XC.names)XC.names[r.id]=NAMES[r.id];if(typeof RT!=="undefined"&&r.id in RT.names)RT.names[r.id]=NAMES[r.id];if(typeof xRefresh==="function")xRefresh()}catch(e){}}).subscribe();
    return {
    async id(){return me},
    async profiles(ids){ids=[...new Set(ids)].filter(Boolean);const out={};const need=ids.filter(i=>!(i in NAMES));
      if(need.length){const {data}=await c.from("profiles").select("id,name").in("id",need.slice(0,200));need.forEach(i=>NAMES[i]="");(data||[]).forEach(r=>NAMES[r.id]=r.name||"")}
      ids.forEach(i=>out[i]={name:NAMES[i]||""});return out},
    async setName(n){n=String(n||"").replace(/\s+/g," ").trim().slice(0,24);if(n&&modBad(n))throw Object.assign(new Error("rude"),{code:"rude"});const {error}=await c.from("profiles").upsert({id:me,name:n,updated_at:new Date().toISOString()});if(error)throw error;NAMES[me]=n;return n},
    myName(){return NAMES[me]||""}}}

  /* ---- room: join(name) gives emit/on/presence/peers/onPeers/leave over Supabase Realtime ---- */
  function makeRoom(me){const c=client(),conn=Math.random().toString(36).slice(2,12);
    function open(name){const ch=c.channel("room:"+String(name).slice(0,60),{config:{broadcast:{self:true,ack:false},presence:{key:conn}}});
      let pres={},joined=false;const peerL=new Set(),msgL={};
      const peers=()=>{const st=ch.presenceState();return Object.entries(st).map(([k,metas])=>{const m=metas[metas.length-1]||{};const {by,presence_ref,...rest}=m;return {peer:k,by,isMe:by===me,sameTab:k===conn,kind:"viewer",presence:rest.p||{}}})};
      let prev={};const firePeers=()=>{const P=peers(),now={};P.forEach(p=>now[p.peer]=p);const joined=P.filter(p=>!prev[p.peer]),left=Object.values(prev).filter(p=>!now[p.peer]),updated=P.filter(p=>prev[p.peer]&&JSON.stringify(prev[p.peer].presence)!==JSON.stringify(p.presence));prev=now;
        peerL.forEach(f=>{try{f({peers:P,joined,left,updated})}catch(e){}})};
      ch.on("presence",{event:"sync"},firePeers);
      ch.on("broadcast",{event:"*"},({event,payload})=>{const L=msgL[event];if(!L||!payload)return;const P=peers().find(p=>p.peer===payload.peer);
        const m={topic:event,kind:"viewer",data:payload.data,peer:payload.peer,by:payload.by,isMe:payload.by===me,sameTab:payload.peer===conn,presence:P?P.presence:{}};L.forEach(f=>{try{f(m)}catch(e){}})});
      const ready=new Promise((res,rej)=>ch.subscribe(st=>{if(st==="SUBSCRIBED"){joined=true;ch.track({by:me,p:pres}).catch(()=>{});res()}else if(st==="CHANNEL_ERROR"||st==="TIMED_OUT")rej(new Error(st))}));
      const R={
        async emit(type,data){await ready;const r=await ch.send({type:"broadcast",event:type,payload:{data,peer:conn,by:me}});if(r!=="ok")throw new Error("send "+r)},
        on(type,f){(msgL[type]=msgL[type]||new Set()).add(f);return ()=>msgL[type].delete(f)},
        /* like the Claude room: keys are merged, a null value removes the key */
        async presence(patch){pres={...pres};Object.entries(patch||{}).forEach(([k,v])=>{if(v===null)delete pres[k];else pres[k]=v});await ready;await ch.track({by:me,p:pres})},
        peers,onPeers(f){peerL.add(f);if(joined)setTimeout(()=>{const P=peers();f({peers:P,joined:P,left:[],updated:[]})},0);return ()=>peerL.delete(f)},
        connected:()=>joined,onConnection(f){ready.then(()=>f(true),()=>f(false));return ()=>{}},
        async leave(){try{await ch.untrack()}catch(e){}try{await c.removeChannel(ch)}catch(e){}},
        async join(n){return openRoom(n)}};
      R._ready=ready;return R}
    const cache={};async function openRoom(n){if(cache[n])return cache[n];const r=open(n);cache[n]=r;try{await r._ready}catch(e){delete cache[n];throw e}const leave=r.leave;r.leave=()=>{delete cache[n];return leave()};return r}
    return openRoom("lobby")}

  /* ---- downloads: an ordinary browser download ---- */
  const downloads={async save({filename,data}){const blob=data instanceof Blob?data:new Blob([data],{type:/\.csv$/i.test(filename)?"text/csv;charset=utf-8":"application/octet-stream"});
    const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=filename||"download";document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},1500);return {saved:true}}};

  /* ---- accounts: username + password; the guest account becomes the permanent one, so nothing is lost ---- */
  const U_DOM="fans.fenerbahcefanhub.app";
  const uMail=u=>u+"@"+U_DOM;
  const uOk=u=>/^[a-z0-9][a-z0-9._-]{1,18}[a-z0-9]$/.test(u);
  const err=(code)=>Object.assign(new Error(code),{code});
  const authErr=e=>{const m=((e&&(e.code||""))+" "+(e&&e.message||"")).toLowerCase();if(e&&e.status===429||/rate limit|too many/.test(m))return err("slow");
    if(/already|exists|registered|taken/.test(m))return err("taken");if(/invalid login|credentials/.test(m))return err("wrong");if(/password/.test(m)&&/(short|least|weak|characters)/.test(m))return err("pw");return err("net")};
  async function account(){const c=client();if(!c)return null;const {data}=await c.auth.getSession();const u=data&&data.session&&data.session.user;if(!u)return null;
    const em=u.email||"";return {anon:!!u.is_anonymous||!em,username:em.endsWith("@"+U_DOM)?em.slice(0,-U_DOM.length-1):(em||null)}}
  async function register(name,pw){const c=client();if(!c)throw err("net");const u=String(name||"").trim().toLowerCase();if(!uOk(u))throw err("name");if(modBad(u))throw err("rude");if(String(pw||"").length<6)throw err("pw");
    const me=await uid();if(!me)throw err("net");const a=await account();if(a&&!a.anon)throw err("already");
    let r=await c.auth.updateUser({email:uMail(u)});if(r.error)throw authErr(r.error);
    r=await c.auth.updateUser({password:pw});if(r.error)throw authErr(r.error);
    try{const U=await window.claude.use("user");if(U&&!U.myName())await U.setName(String(name).trim())}catch(e){}
    return u}
  async function login(name,pw){const c=client();if(!c)throw err("net");const u=String(name||"").trim().toLowerCase();if(!uOk(u))throw err("wrong");
    const r=await c.auth.signInWithPassword({email:uMail(u),password:pw});if(r.error)throw authErr(r.error);return u}
  async function logout(){const c=client();if(!c)return;await c.auth.signOut().catch(()=>{});
    /* the next visitor on this browser starts fresh, without this account's predictions and votes */
    if(typeof store!=="undefined")Object.values(LOCAL).forEach(([,k])=>{try{store.set(k,{})}catch(e){}})}

  const cache={};
  window.FB_SITE={on:false,client,uid,account,register,login,logout};
  window.claude={async use(cap){
    if(cap==="downloads")return downloads;
    if(cap==="sample")return null; /* Kanarya stays off on the stand-alone site */
    if(cache[cap])return cache[cap];
    const me=await uid();if(!me)return null;window.FB_SITE.on=true;window.FB_SITE.me=me;
    if(cap==="db")return cache[cap]=makeDb(me);
    if(cap==="user")return cache[cap]=makeUser(me);
    if(cap==="room"){try{return cache[cap]=await makeRoom(me)}catch(e){console.warn("[fb] room",e&&e.message);return null}}
    return null}};
})();

/* Fan name field in Settings (stand-alone site only) */
(function(){if(!window.FB_SITE)return;const base=fillSettings;
  fillSettings=function(){base();const pan=$("setPanel");if(!pan||!XC.user||!XC.user.setName)return;const cur=XC.user.myName()||"";
    const tour=pan.querySelector("#setTour");const row=document.createElement("label");row.className="setrow";
    row.innerHTML=`<span>${t("Your fan name")}</span><span class="fnrow"><input id="setName" maxlength="24" autocomplete="nickname" value="${esc(cur)}" placeholder="${esc(t("e.g. Kadıköy Kanaryası"))}"><button class="btn ghost sm" type="button" id="setNameOk">${t("Save")}</button></span><small>${t("Shown on leaderboards and in watch parties. Leave it empty to appear as “A fan”.")}</small>`;
    (tour?tour.closest(".btns"):pan.lastElementChild).before(row);
    const save=async()=>{const b=$("setNameOk");b.disabled=true;try{const n=await XC.user.setName($("setName").value);XC.names[XC.me]=n;RT.names[XC.me]=n;xToast(n?tf("Saved. You're {n} now.",{n}):t("Saved."));xRefresh()}catch(e){xToast(t(e&&e.code==="rude"?"Please keep it friendly. Pick another name.":"Couldn't save your name. Try again."))}b.disabled=false};
    $("setNameOk").onclick=save;$("setName").onkeydown=e=>{if(e.key==="Enter"){e.preventDefault();save()}}};
  const AE={name:"Usernames need 3–20 letters (a–z), numbers, dots, dashes or underscores.",pw:"Passwords need at least 6 characters.",taken:"That username is already taken. Pick another one.",
    wrong:"Wrong username or password.",slow:"Too many attempts. Wait a few minutes and try again.",net:"Couldn't connect. Try again.",rude:"Please keep it friendly. Pick another name.",already:"You're already logged in."};
  async function fillAccount(){const box=$("setAcct");if(!box)return;const a=await FB_SITE.account().catch(()=>null);if(!$("setAcct"))return;acBtnLabel(a);
    if(a&&!a.anon){box.innerHTML=`<b class="acctin">${tf("Logged in as {u}.",{u:`<b>${esc(a.username||"")}</b>`})}</b><small>${t("Your points, predictions and fan name are saved to your account. Log in with the same username on any device.")}</small><div class="btns"><button class="btn ghost sm" type="button" id="acOut">${t("Log out")}</button></div>`;
      $("acOut").onclick=async()=>{$("acOut").disabled=true;await FB_SITE.logout();location.reload()};return}
    box.innerHTML=`<small>${t("You're playing as a guest on this device. Create an account to keep your points, predictions and fan name, and to log in on other devices.")}</small>
      <form id="acForm" class="acform" autocomplete="on"><input id="acUser" name="username" autocomplete="username" maxlength="20" autocapitalize="none" spellcheck="false" placeholder="${esc(t("Username"))}" aria-label="${esc(t("Username"))}">
      <input id="acPw" name="password" type="password" autocomplete="current-password" maxlength="72" placeholder="${esc(t("Password"))}" aria-label="${esc(t("Password"))}">
      <div class="btns"><button class="btn sm" type="button" data-ac="register">${t("Create account")}</button><button class="btn ghost sm" type="submit" data-ac="login">${t("Log in")}</button></div>
      <p class="fine" id="acMsg" role="status" aria-live="polite"></p></form>
      <small>${t("Usernames: 3–20 letters (a–z), numbers, dots, dashes or underscores. There is no password reset, so keep your password somewhere safe.")}</small>`;
    /* Enter logs in; "Create account" registers */
    let mode="login";const form=$("acForm");
    box.querySelector('[data-ac="login"]').onclick=()=>{mode="login";$("acPw").autocomplete="current-password"};
    box.querySelector('[data-ac="register"]').onclick=()=>{mode="register";$("acPw").autocomplete="new-password";form.requestSubmit?form.requestSubmit():form.onsubmit(new Event("submit"))};
    form.onsubmit=async e=>{e.preventDefault();const m=mode;mode="login";const msg=$("acMsg"),bs=box.querySelectorAll("[data-ac]");bs.forEach(b=>b.disabled=true);msg.textContent=t(m==="register"?"Creating your account…":"Logging in…");
      try{if(m==="register"){const u=await FB_SITE.register($("acUser").value,$("acPw").value);xToast(tf("Account created. You're logged in as {u}.",{u}));fillAccount();if($("setPanel")&&!$("setPanel").hidden)fillSettings()}
        else{await FB_SITE.login($("acUser").value,$("acPw").value);location.reload()}}
      catch(x){msg.textContent=t(AE[x&&x.code]||AE.net);bs.forEach(b=>b.disabled=false)}}}
  /* account button in the top bar, next to the language picker */
  const PERSON='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="8" r="3.6"/><path d="M4.5 20c1.2-3.8 4-5.6 7.5-5.6s6.3 1.8 7.5 5.6"/></svg>';
  function acBtnLabel(a){const b=$("acBtn");if(!b)return;const inn=a&&!a.anon;const lab=inn?(a.username||t("Your account")):t("Log in");
    b.querySelector(".aclab").textContent=lab;b.classList.toggle("in",!!inn);b.setAttribute("aria-label",inn?tf("Logged in as {u}.",{u:a.username||""}).replace(/<[^>]+>/g,""):t("Log in or create an account"))}
  function initAcct(){const host=document.querySelector(".bar .wrap");if(!host||$("acBtn"))return;const lp=host.querySelector(".langpick");
    const w=document.createElement("div");w.className="acwrap";w.innerHTML=`<button class="hset hacct" id="acBtn" type="button" aria-expanded="false" aria-controls="acPanel">${PERSON}<span class="aclab">${t("Log in")}</span></button>
      <div class="setpanel acpanel" id="acPanel" role="dialog" aria-modal="false" aria-labelledby="acTitle" hidden><h2 id="acTitle">${t("Your account")}</h2><div class="setrow acct" id="setAcct"></div></div>`;
    if(lp)host.insertBefore(w,lp);else host.appendChild(w);
    const btn=$("acBtn"),pan=$("acPanel");const close=back=>{pan.hidden=true;btn.setAttribute("aria-expanded","false");if(back)btn.focus()};
    btn.onclick=async()=>{if(!pan.hidden){close(false);return}$("acTitle").textContent=t("Your account");pan.hidden=false;btn.setAttribute("aria-expanded","true");await fillAccount();const f=pan.querySelector("input,button");if(f)f.focus()};
    document.addEventListener("click",e=>{if(!pan.hidden&&!e.target.closest(".acwrap"))close(false)});
    pan.addEventListener("keydown",e=>{if(e.key==="Escape"){e.stopPropagation();close(true)}});
    FB_SITE.account().then(acBtnLabel).catch(()=>{})}
  /* show the button once the shared features are connected; relabel it when the language changes */
  const waitAc=setInterval(()=>{if(FB_SITE.on){clearInterval(waitAc);initAcct()}},500);setTimeout(()=>clearInterval(waitAc),30000);
  document.addEventListener("change",e=>{if(e.target&&(e.target.id==="lang"||e.target.id==="setLang"))setTimeout(()=>{FB_SITE.account().then(acBtnLabel).catch(()=>{});const p=$("acPanel");if(p&&!p.hidden){$("acTitle").textContent=t("Your account");fillAccount()}},500)},true);
  /* load my own name once signed in */
  const wait=setInterval(()=>{if(XC.on&&XC.user&&XC.user.profiles){clearInterval(wait);XC.user.profiles([XC.me]).then(()=>{const f=$("setName"),n=XC.user.myName();if(f&&n&&!f.value&&document.activeElement!==f)f.value=n}).catch(()=>{})}},800);setTimeout(()=>clearInterval(wait),30000)})();

/* ===== Stand-alone site: private prediction leagues, reporting names and messages ===== */
(function(){if(!window.FB_SITE)return;
  /* an invite link looks like …#league=ABC234; remember the code and open the home page */
  let PENDING=null;{const m=location.hash.match(/^#league=([A-Za-z2-9]{6})$/);if(m){PENDING=m[1].toUpperCase();try{history.replaceState(null,"","#all")}catch(e){location.hash="all"}}}
  const LG={list:[],members:{},ready:false};
  let lgL=(()=>{try{return localStorage.getItem("fb-lg-sel")||"all"}catch(e){return "all"}})();
  const cl=()=>FB_SITE.client();
  async function lgLoad(){const c=cl();if(!c||!FB_SITE.on)return;
    const [a,b]=await Promise.all([c.from("leagues").select("code,name,owner").order("created_at"),c.from("league_members").select("code,id")]);
    if(a.error||b.error)return;LG.list=a.data||[];LG.members={};(b.data||[]).forEach(r=>(LG.members[r.code]=LG.members[r.code]||new Set()).add(r.id));LG.ready=true;
    if(lgL!=="all"&&!LG.list.some(l=>l.code===lgL))lgL="all";xNames([...new Set((b.data||[]).map(r=>r.id))]);if(typeof fillLeague==="function")fillLeague()}
  const ERR={bad:"League names need 1–30 characters.",rude:"Please keep it friendly. Pick another name.",none:"There's no league with that code. Check it and try again.",
    full:"That league is full.",many:"You can run up to 10 leagues.",net:"Couldn't connect. Try again."};
  const errOf=e=>{const m=(e&&e.message||"").toLowerCase();return /no such/.test(m)?"none":/full/.test(m)?"full":/too many/.test(m)?"many":/bad name/.test(m)?"bad":"net"};
  async function lgCreate(name){name=String(name||"").replace(/\s+/g," ").trim();if(!name||name.length>30)throw {k:"bad"};if(modBad(name))throw {k:"rude"};
    const {data,error}=await cl().rpc("create_league",{league_name:name});if(error)throw {k:errOf(error)};lgL=data;store.set("fb-lg-sel",lgL);await lgLoad();return data}
  async function lgJoin(code){code=String(code||"").trim().toUpperCase().replace(/[^A-Z0-9]/g,"");if(!/^[A-Z2-9]{6}$/.test(code))throw {k:"none"};
    const {data,error}=await cl().rpc("join_league",{league_code:code});if(error)throw {k:errOf(error)};lgL=code;store.set("fb-lg-sel",lgL);await lgLoad();return data}
  async function lgLeave(code){const {error}=await cl().rpc("leave_league",{league_code:code});if(error)throw {k:"net"};if(lgL===code){lgL="all";store.set("fb-lg-sel","all")}await lgLoad()}
  const invite=code=>location.origin+location.pathname+"#league="+code;

  /* the fan prediction table can show just the members of one of your leagues */
  {const _t=lgTable;lgTable=(b,per)=>{const r=_t(b,per);if(lgL==="all"||!LG.members[lgL])return r;const M=LG.members[lgL];return r.filter(x=>M.has(x.id==="me"?XC.me:x.id))}}
  {const _fl=fillLeague;fillLeague=function(){_fl();lgPaint()}}
  function lgPaint(){const box=$("leagueBox"),g=box&&box.querySelector(".lggrid");if(!g||!FB_SITE.on)return;
    const tcard=g.querySelector("article.card");if(tcard&&LG.list.length&&!tcard.querySelector("#lgLeague")){const sel=document.createElement("select");sel.id="lgLeague";sel.className="lgsel";sel.setAttribute("aria-label",t("League"));
      sel.innerHTML=`<option value="all">${esc(t("All fans"))}</option>`+LG.list.map(l=>`<option value="${esc(l.code)}" ${l.code===lgL?"selected":""}>${esc(modClean(l.name))}</option>`).join("");if(lgL==="all")sel.value="all";
      const bs=tcard.querySelector("#lgSel");(bs||tcard.querySelector(".label")).after(sel);sel.onchange=()=>{lgL=sel.value;store.set("fb-lg-sel",lgL);fillLeague();const n=$("lgLeague");if(n)n.focus()}}
    let c=g.querySelector(".lgpriv");if(!c){c=document.createElement("article");c.className="card lgpriv";c.id="lgPriv";g.appendChild(c)}
    const mine=LG.list.map(l=>{const n=LG.members[l.code]?LG.members[l.code].size:1;return `<li><div><b>${esc(modClean(l.name))}</b><span class="muted">${tf(n===1?"1 member":"{n} members",{n})} · ${t("Code")} <code>${esc(l.code)}</code></span></div>
      <div class="btns"><button class="btn ghost sm" type="button" data-lgcopy="${esc(l.code)}">${t("Copy invite link")}</button><button class="btn ghost sm" type="button" data-lgshow="${esc(l.code)}">${t("Show table")}</button><button class="btn ghost sm lgleave" type="button" data-lgleave="${esc(l.code)}">${t("Leave")}</button></div></li>`}).join("");
    const guest=FB_SITE._anon!==false;
    c.innerHTML=`<span class="label">${t("Private leagues")}</span><p class="fine">${t("Play the prediction league with just your friends. Everyone predicts as usual; your league gets its own table. Share the invite link in your group chat.")}</p>
      ${PENDING?`<div class="lginv"><p>${tf("You've been invited to a private league (code {c}).",{c:`<code>${esc(PENDING)}</code>`})}</p><div class="btns"><button class="btn sm" type="button" id="lgInvYes">${t("Join league")}</button><button class="btn ghost sm" type="button" id="lgInvNo">${t("No thanks")}</button></div></div>`:""}
      ${mine?`<ul class="lgmylist">${mine}</ul>`:""}
      <form class="lgform" id="lgNewF"><input id="lgNew" maxlength="30" placeholder="${esc(t("League name, e.g. Kadıköy Crew"))}" aria-label="${esc(t("League name"))}"><button class="btn sm" type="submit">${t("Create league")}</button></form>
      <form class="lgform" id="lgJoinF"><input id="lgCode" maxlength="6" autocapitalize="characters" spellcheck="false" placeholder="${esc(t("Code, e.g. ABC234"))}" aria-label="${esc(t("League code"))}"><button class="btn ghost sm" type="submit">${t("Join")}</button></form>
      <p class="fine" id="lgPMsg" role="status" aria-live="polite"></p>
      ${guest?`<p class="fine">${t("Tip: create an account (top right) to keep your leagues when you switch devices.")}</p>`:""}`;
    const msg=x=>{const m=$("lgPMsg");if(m)m.textContent=x};
    const busy=(f,el)=>async e=>{e&&e.preventDefault&&e.preventDefault();const bs=c.querySelectorAll("button");bs.forEach(b=>b.disabled=true);try{await f(el)}catch(x){msg(t(ERR[x&&x.k]||ERR.net))}bs.forEach(b=>b.disabled=false)};
    $("lgNewF").onsubmit=busy(async()=>{const code=await lgCreate($("lgNew").value);xToast(tf("League created. Share the code {c} or copy the invite link.",{c:code}))});
    $("lgJoinF").onsubmit=busy(async()=>{const r=await lgJoin($("lgCode").value);xToast(tf("You joined {n}.",{n:modClean(r.name)}))});
    if(PENDING){$("lgInvYes").onclick=busy(async()=>{const code=PENDING;const r=await lgJoin(code);PENDING=null;xToast(tf("You joined {n}.",{n:modClean(r.name)}));lgPaint()});$("lgInvNo").onclick=()=>{PENDING=null;lgPaint()}}
    c.querySelectorAll("[data-lgcopy]").forEach(b=>b.onclick=async()=>{const u=invite(b.dataset.lgcopy);try{await navigator.clipboard.writeText(u);xToast(t("Invite link copied."))}catch(e){msg(u)}});
    c.querySelectorAll("[data-lgshow]").forEach(b=>b.onclick=()=>{lgL=b.dataset.lgshow;store.set("fb-lg-sel",lgL);fillLeague();const s=$("lgLeague");if(s){s.scrollIntoView({block:"center",behavior:"smooth"});s.focus()}});
    c.querySelectorAll("[data-lgleave]").forEach(b=>b.onclick=busy(async()=>{if(b.dataset.sure!=="1"){b.dataset.sure="1";b.textContent=t("Click again to leave");return}await lgLeave(b.dataset.lgleave);xToast(t("You left the league."))}));
    if(PENDING&&!c.dataset.scrolled){c.dataset.scrolled="1";setTimeout(()=>c.scrollIntoView({block:"center",behavior:"smooth"}),400)}}

  /* ---- reports: a small flag next to other fans' names and messages ---- */
  const HIDDEN=new Set();
  {const _xn=xName;xName=id=>HIDDEN.has(id)&&id!==XC.me?t("A fan"):_xn(id)}
  {const _rn=rtName;rtName=p=>p&&!p.isMe&&HIDDEN.has(p.by)?t("A fan"):_rn(p)}
  const UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  async function report(uid,kind,content){const {error}=await cl().from("reports").insert({reporter:XC.me,target:uid,kind,content:String(content||"").slice(0,300)});
    if(error&&error.code!=="23505")throw error}
  function flag(el){const uid=el.dataset.uid;el.dataset.rep="1";if(!UUID.test(uid)||uid===XC.me)return;const kind=el.dataset.msg!=null?"message":"name";
    const b=document.createElement("button");b.type="button";b.className="rflag";b.setAttribute("aria-label",t(kind==="message"?"Report this message":"Report this name"));b.title=b.getAttribute("aria-label");
    b.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M5 21V4M5 4h11l-2 4 2 4H5"/></svg>';
    b.onclick=e=>{e.stopPropagation();if(el.querySelector(".rask"))return;const ask=document.createElement("span");ask.className="rask";
      ask.innerHTML=`<span>${t(kind==="message"?"Report this message?":"Report this name?")}</span><button type="button" class="btn sm" data-r="y">${t("Report")}</button><button type="button" class="btn ghost sm" data-r="n">${t("Cancel")}</button>`;
      el.appendChild(ask);ask.querySelector('[data-r="n"]').onclick=ev=>{ev.stopPropagation();ask.remove()};
      ask.querySelector('[data-r="y"]').onclick=async ev=>{ev.stopPropagation();ask.querySelectorAll("button").forEach(x=>x.disabled=true);
        try{await report(uid,kind,kind==="message"?el.dataset.msg:(XC.names[uid]||(el.querySelector(".nm")||{}).textContent||""));ask.remove();b.remove();xToast(t("Thanks for letting us know."))}
        catch(x){ask.remove();xToast(t("Couldn't send the report. Try again."))}}};
    const nm=el.querySelector(".nm");(nm||el).appendChild(b)}
  const scan=()=>{if(!FB_SITE.on||!XC.me)return;document.querySelectorAll("[data-uid]:not([data-rep])").forEach(flag)};
  let st=null;new MutationObserver(()=>{clearTimeout(st);st=setTimeout(scan,120)}).observe(document.body,{childList:true,subtree:true});

  /* start once the shared features are connected */
  const w=setInterval(async()=>{if(!FB_SITE.on||!XC.me)return;clearInterval(w);
    try{const a=await FB_SITE.account();FB_SITE._anon=!a||a.anon}catch(e){}
    try{const {data}=await cl().rpc("hidden_names");(data||[]).forEach(r=>HIDDEN.add(typeof r==="string"?r:(r.hidden_names||r)));if(HIDDEN.size){Object.keys(XC.names).forEach(()=>0);xRefresh()}}catch(e){}
    await lgLoad();scan();
    cl().channel("lg-"+Math.random().toString(36).slice(2,8)).on("postgres_changes",{event:"*",schema:"public",table:"league_members"},()=>{clearTimeout(w._t);w._t=setTimeout(lgLoad,600)}).subscribe()},700);
  setTimeout(()=>clearInterval(w),30000);
})();

/* ===== Moderation (admins only; every action is checked again by the database) ===== */
(function(){if(!window.FB_SITE)return;window.FB_BANNED=new Set();
  const cl=()=>FB_SITE.client();
  async function loadBans(){try{const {data}=await cl().rpc("banned_ids");const B=new Set((data||[]).map(r=>typeof r==="string"?r:r.banned_ids));window.FB_BANNED=B;
    let ch=false;Object.values(XC.docs).forEach(col=>B.forEach(id=>{if(col&&col[id]){delete col[id];ch=true}}));B.forEach(id=>{if(XC.names[id]){XC.names[id]="";ch=true}});if(ch)xRefresh()}catch(e){}}
  const SHIELD='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M12 3l7 3v5c0 4.5-3 8.3-7 10-4-1.7-7-5.5-7-10V6z"/><path d="M9 12l2 2 4-4"/></svg>';
  let tab="reports";
  const nm=x=>x.name?esc(x.name):'<span class="muted">(no name)</span>';
  const badges=x=>`${x.registered?`<span class="mbadge">registered${x.username?" · "+esc(x.username):""}</span>`:`<span class="mbadge">guest</span>`}${x.banned?'<span class="mbadge bad">banned</span>':""}`;
  const acts=(x,dismiss)=>`<div class="btns"><button class="btn ghost sm" data-ma="name" data-id="${x.id||x.target}">Reset name</button><button class="btn ghost sm" data-ma="clear" data-id="${x.id||x.target}">Clear predictions &amp; scores</button>
    ${x.banned?`<button class="btn ghost sm" data-ma="unban" data-id="${x.id||x.target}">Unban</button>`:`<button class="btn ghost sm mdanger" data-ma="ban" data-id="${x.id||x.target}">Ban</button>`}${dismiss?`<button class="btn ghost sm" data-ma="dismiss" data-id="${x.target}" data-k="${esc(x.kind)}">Dismiss</button>`:""}</div>`;
  async function paint(){const body=$("modBody");if(!body)return;body.innerHTML='<p class="fine">Loading…</p>';
    try{if(tab==="reports"){const {data,error}=await cl().rpc("admin_reports");if(error)throw error;
        body.innerHTML=(data||[]).length?`<ul class="mlist">${data.map(x=>`<li><div class="mhead"><b>${nm(x)}</b>${badges(x)}<span class="muted">${x.kind==="message"?"message":"name"} · ${x.reporters} report${x.reporters===1?"":"s"} · ${esc(mDate(String(x.last).slice(0,10),true))}</span></div>
          ${(x.samples||[]).filter(Boolean).length?`<p class="msample">${x.samples.filter(Boolean).map(s=>"“"+esc(s)+"”").join("<br>")}</p>`:""}${x.target?acts(x,true):""}</li>`).join("")}</ul>`:'<p class="fine">No reports. All quiet.</p>'}
      else if(tab==="find"){body.innerHTML=`<form id="mFindF" class="lgform"><input id="mFind" placeholder="Fan name or username" aria-label="Fan name or username"><button class="btn sm" type="submit">Search</button></form><div id="mFound"></div>`;
        $("mFindF").onsubmit=async e=>{e.preventDefault();const q=$("mFind").value.trim();if(!q)return;const {data,error}=await cl().rpc("admin_find",{q});const f=$("mFound");if(error){f.innerHTML='<p class="fine">Search failed.</p>';return}
          f.innerHTML=(data||[]).length?`<ul class="mlist">${data.map(x=>`<li><div class="mhead"><b>${nm(x)}</b>${badges(x)}<span class="muted">joined ${esc(mDate(String(x.created_at).slice(0,10),true))}</span></div>${acts(x,false)}</li>`).join("")}</ul>`:'<p class="fine">No fans found.</p>';wire()};$("mFind").focus()}
      else{const {data,error}=await cl().rpc("admin_leagues");if(error)throw error;
        body.innerHTML=(data||[]).length?`<ul class="mlist">${data.map(x=>`<li><div class="mhead"><b>${esc(x.name)}</b><span class="muted"><code>${esc(x.code)}</code> · ${x.members} member${x.members===1?"":"s"}${x.owner_name?" · made by "+esc(x.owner_name):""}</span></div>
          <div class="btns"><input class="mren" value="${esc(x.name)}" maxlength="30" aria-label="New league name"><button class="btn ghost sm" data-ma="lrename" data-id="${esc(x.code)}">Rename</button><button class="btn ghost sm mdanger" data-ma="ldel" data-id="${esc(x.code)}">Delete league</button></div></li>`).join("")}</ul>`:'<p class="fine">No private leagues yet.</p>'}
      wire()}catch(e){body.innerHTML='<p class="fine">Couldn\'t load this. Try again.</p>'}}
  const RPC={name:id=>["admin_reset_name",{target:id}],clear:id=>["admin_clear_data",{target:id}],ban:id=>["admin_ban",{target:id,why:null}],unban:id=>["admin_unban",{target:id}],ldel:id=>["admin_delete_league",{c:id}]};
  const DONE={name:"Name reset.",clear:"Predictions and scores cleared.",ban:"Fan banned. They can't save anything any more and show as “A fan”.",unban:"Ban lifted.",dismiss:"Report dismissed.",ldel:"League deleted.",lrename:"League renamed."};
  function wire(){document.querySelectorAll("#modBody [data-ma]").forEach(b=>b.onclick=async()=>{const a=b.dataset.ma,id=b.dataset.id;
    if(["clear","ban","ldel"].includes(a)&&b.dataset.sure!=="1"){b.dataset.sure="1";b.textContent="Click again to confirm";return}
    b.disabled=true;let r;
    if(a==="dismiss")r=await cl().rpc("admin_dismiss",{target:id,k:b.dataset.k});
    else if(a==="lrename")r=await cl().rpc("admin_rename_league",{c:id,n:b.parentNode.querySelector(".mren").value});
    else{const [f,args]=RPC[a](id);r=await cl().rpc(f,args)}
    if(r.error){b.disabled=false;xToast("That didn't work: "+r.error.message);return}
    xToast(DONE[a]);if(a==="name"||a==="ban"){XC.names[id]="";if(window.RT&&RT.names)RT.names[id]=""}if(a==="clear"||a==="ban")Object.values(XC.docs).forEach(c=>{if(c)delete c[id]});
    await loadBans();xRefresh();const mb=document.querySelector("#modDlg .modbox");if(mb)mb.focus();if(tab==="find"&&$("mFindF"))$("mFindF").requestSubmit();else paint()})}
  function open(){let d=$("modDlg");if(!d){d=document.createElement("div");d.id="modDlg";d.className="moddlg";d.setAttribute("role","dialog");d.setAttribute("aria-modal","true");d.setAttribute("aria-labelledby","modT");
      d.innerHTML=`<div class="modbox" tabindex="-1"><div class="modtop"><h2 id="modT">Moderation</h2><button class="btn ghost sm" type="button" id="modX" aria-label="Close">✕</button></div>
        <div class="seg" role="tablist"><button type="button" role="tab" data-mt="reports">Reports</button><button type="button" role="tab" data-mt="find">Find a fan</button><button type="button" role="tab" data-mt="leagues">Leagues</button></div>
        <p class="fine">Only you can see this. Reset name: their name goes back to “A fan”. Clear: deletes their predictions, votes and scores. Ban: they can't save names, predictions or scores and don't appear on leaderboards; it also takes them out of all leagues.</p><div id="modBody"></div></div>`;
      document.body.appendChild(d);$("modX").onclick=close;d.addEventListener("click",e=>{if(e.target===d)close()});document.addEventListener("keydown",e=>{const m=$("modDlg");if(e.key==="Escape"&&m&&!m.hidden)close()});
      d.querySelectorAll("[data-mt]").forEach(b=>b.onclick=()=>{tab=b.dataset.mt;mark();paint()})}
    d.hidden=false;document.body.style.overflow="hidden";mark();paint();$("modX").focus()}
  function mark(){document.querySelectorAll("#modDlg [data-mt]").forEach(b=>{const on=b.dataset.mt===tab;b.classList.toggle("on",on);b.setAttribute("aria-selected",on)})}
  function close(){const d=$("modDlg");if(d)d.hidden=true;document.body.style.overflow="";const b=$("modBtn");if(b&&b.offsetParent)b.focus();else{const a=$("acBtn");if(a)a.focus()}}
  const w=setInterval(async()=>{if(!FB_SITE.on||!XC.me)return;clearInterval(w);await loadBans();
    try{const {data}=await cl().rpc("is_admin");if(data!==true)return}catch(e){return}
    const host=document.querySelector(".bar .wrap"),acw=host&&host.querySelector(".acwrap");if(!host||$("modBtn"))return;
    const b=document.createElement("button");b.id="modBtn";b.type="button";b.className="hset hmod";b.title="Moderation";b.setAttribute("aria-label","Moderation");b.innerHTML=SHIELD;b.onclick=open;
    const wrap=document.createElement("div");wrap.className="modwrap";wrap.appendChild(b);host.insertBefore(wrap,acw||host.querySelector(".langpick"));
    /* also a button inside the account panel (the only place it shows on phones) */
    const addInPanel=()=>{const box=$("setAcct");if(box&&box.querySelector("#acOut")&&!$("modOpen")){const r=document.createElement("div");r.className="btns";r.innerHTML='<button class="btn sm" type="button" id="modOpen">'+SHIELD+' Moderation</button>';box.appendChild(r);$("modOpen").onclick=()=>{const p=$("acPanel");if(p)p.hidden=true;open()}}};
    new MutationObserver(addInPanel).observe(document.body,{childList:true,subtree:true});addInPanel()},800);
  setTimeout(()=>clearInterval(w),40000);
})();

WP_FB=wPool(PEOPLE);
initTheme();initLang();mergeContent();mergeNew();staticTexts();initHelper();initSettings();lookInit();
renderOnThisDay();
{const [h,play]=fromHash();setSport(h,play)}
initCommunity();maybeTour();
