const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();
const pg=await b.newPage({viewport:{width:1280,height:1000}});
const errs=[];pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error'&&!m.text().includes('ERR_TUNNEL'))errs.push(m.text())});
await pg.goto('file://'+process.cwd()+'/fenerbahce.html#games');await pg.waitForTimeout(300);
await pg.click('[data-form="4-2-3-1"]');
for(let i=0;i<5;i++){await pg.click('[data-cand="0"]');}
await pg.evaluate(()=>document.getElementById('panel').scrollIntoView());
await pg.screenshot({path:'v1.png'});
for(let i=0;i<6;i++){await pg.click('[data-cand="0"]');}
await pg.click('[data-slot="10"]');
await pg.click('[data-c="play"]');await pg.waitForTimeout(2500);
await pg.screenshot({path:'v2.png'});
await pg.click('[data-c="skip"]').catch(()=>{});await pg.waitForTimeout(300);
await pg.screenshot({path:'v3.png'});
// wordle
await pg.click('[data-tab=wordle]');await pg.click('[data-h="nat"]');
const ans=await pg.evaluate(()=>wd.ans);
for(const k of ('XXXX'.padEnd(ans.length,'X')).split(''))await pg.keyboard.press(k);await pg.keyboard.press('Enter');
for(const k of ans.split(''))await pg.keyboard.press(k);await pg.keyboard.press('Enter');await pg.waitForTimeout(800);
await pg.evaluate(()=>document.getElementById('panel').scrollIntoView());
await pg.screenshot({path:'v4.png'});
// xi
await pg.click('[data-tab=xi]');await pg.click('[data-xm="clock"]');await pg.click('[data-x="start"]');
for(const n of ['durann','skriniar','kerem','ismail','zzz']){await pg.fill('#xiGuess',n);await pg.press('#xiGuess','Enter');}
await pg.waitForTimeout(1200);
await pg.evaluate(()=>document.getElementById('panel').scrollIntoView());
await pg.screenshot({path:'v5.png'});
// penalties
await pg.click('[data-tab=penalties]');
for(let r=0;r<6;r++){
  for(let s=0;s<2;s++){await pg.waitForTimeout(300+Math.random()*500);await pg.keyboard.press('Space');}
  await pg.waitForTimeout(2200);
  const z=await pg.$('[data-z]');if(z){await z.click();await pg.waitForTimeout(2200);}
  if(r===1){await pg.evaluate(()=>document.getElementById('panel').scrollIntoView());await pg.screenshot({path:'v6.png'});}
}
// who
await pg.click('[data-tab=who]');await pg.fill('#whoGuess','nobody');await pg.press('#whoGuess','Enter');
const wn=await pg.evaluate(()=>who.q[who.i].p.short);await pg.fill('#whoGuess',wn);await pg.press('#whoGuess','Enter');
await pg.evaluate(()=>document.getElementById('panel').scrollIntoView());
await pg.screenshot({path:'v7.png'});
// timeline
await pg.click('[data-tab=timeline]');for(let i=0;i<4;i++){await pg.click('[data-ins="0"]');}
await pg.evaluate(()=>document.getElementById('panel').scrollIntoView());
await pg.screenshot({path:'v8.png'});
const m=await b.newPage({viewport:{width:390,height:844}});m.on('pageerror',e=>errs.push(e.message));
await m.goto('file://'+process.cwd()+'/fenerbahce.html#games');await m.waitForTimeout(300);
await m.click('[data-cand="0"]');await m.click('[data-cand="0"]');
await m.screenshot({path:'vm1.png',fullPage:true});
await m.click('[data-tab=penalties]');await m.waitForTimeout(300);
await m.screenshot({path:'vm2.png',fullPage:true});
console.log(errs, await m.evaluate(()=>document.documentElement.scrollWidth));
await b.close();})();
