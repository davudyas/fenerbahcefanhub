const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();
const pg=await b.newPage({viewport:{width:1280,height:900}});
const errs=[];pg.on('pageerror',e=>errs.push(e.message));
await pg.goto('file://'+process.cwd()+'/fenerbahce.html#games');await pg.waitForTimeout(300);
for(let i=0;i<11;i++){await pg.click('[data-pick="0"]');}
await pg.evaluate(()=>document.getElementById('panel').scrollIntoView());
await pg.screenshot({path:'g1.png'});
await pg.click('[data-tab=wordle]');for(const k of ['A','L','E','X','Enter'])await pg.keyboard.press(k);
await pg.click('[data-tab=xi]');for(const n of ['ederson','skriniar','kerem','nobody']){await pg.fill('#xiGuess',n);await pg.press('#xiGuess','Enter');}
await pg.click('[data-x=hint]');
await pg.screenshot({path:'g2.png'});
await pg.click('[data-tab=penalties]');for(let i=0;i<14;i++){const z=await pg.$('[data-z]:not([disabled])');if(!z){await pg.waitForTimeout(400);continue}await z.click();await pg.waitForTimeout(1700);}
await pg.screenshot({path:'g3.png'});
await pg.click('[data-tab=who]');await pg.click('[data-wh=more]');await pg.click('[data-who]');
await pg.click('[data-tab=timeline]');await pg.click('[data-mv="0,1"]');await pg.click('[data-tl=check]');
await pg.screenshot({path:'g4.png'});
const m=await b.newPage({viewport:{width:400,height:850}});m.on('pageerror',e=>errs.push(e.message));
await m.goto('file://'+process.cwd()+'/fenerbahce.html#games');await m.waitForTimeout(300);
await m.click('[data-tab=wordle]');for(const k of ['S','E','M','I','H','Enter'])await m.keyboard.press(k);
await m.screenshot({path:'m1.png',fullPage:true});
console.log(errs, await m.evaluate(()=>document.documentElement.scrollWidth));
await b.close();})();
