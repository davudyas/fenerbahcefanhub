const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const errs=[];
for(const [w,h,dv] of [[1366,800,'d'],[390,844,'m']]){const pg=await b.newPage({viewport:{width:w,height:h}});pg.on('pageerror',e=>errs.push(e.message));
await pg.goto('file://'+process.argv[2]+'#all');await pg.waitForTimeout(700);
const info=await pg.evaluate(()=>{const tr=document.getElementById('strack');return {tiles:tr.querySelectorAll('.stile').length,up:tr.querySelectorAll('.stile.up').length,mon:tr.querySelectorAll('.smon').length,sl:tr.scrollLeft,first:tr.querySelector('.stile.up')&&tr.querySelector('.stile.up').innerText.replace(/\n/g,' ')}});
console.log(dv,JSON.stringify(info));await pg.screenshot({path:`../strip_${dv}.png`,clip:{x:0,y:0,width:w,height:dv==='d'?260:300}});
for(const br of ['mens-volleyball','womens-basketball','volleyball']){await pg.evaluate(b=>setSport(b),br);await pg.waitForTimeout(250);console.log(br, await pg.evaluate(()=>[...document.querySelectorAll('#panel .srow')].length))}
if(dv==='d'){await pg.evaluate(()=>setSport('mens-volleyball'));await pg.waitForTimeout(250);await pg.evaluate(()=>document.querySelector('.mgrid').scrollIntoView());await pg.screenshot({path:'../mv_matches.png'})}
await pg.close()}console.log(errs);await b.close()})();
